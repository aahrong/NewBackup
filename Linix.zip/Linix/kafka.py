#KAFKA 
#https://blog.parse.ly/post/3886/pykafka-now/
#https://github.com/Parsely/pykafka

#note: when adjusting TIMEOUT config parameters, ensure the parameters are first changed on the broker side, then on the consumer side or kafka will not accept the changes as valid
#note: when adjusting Timeout config parameters the below constraints must be conformed to 
#1. group.max.session.timeout.ms in server.properties > session.timout.ms in consumer.properties
#2. group.min.session.timout.ms in server.properties < session.timout.ms in consumer.properites 
#3. request.timeout.ms > session.timeout.ms and fetch.max.wait.ms 
#4. (session.timeout.ms)/3 > heartbeat.interval.ms
#5. session.timeout.ms > Worst case processing time of Consumer Records per consumer poll(ms).

#0.kafka root directory
cd /home/docadmin/Mueller/DTCC_Img/DTCC-demo/kafka_tools/kafka_2.11-2.0.0/
cd /home/nlpsomnath/NegNews/rebase/NN_Kafka/kafka_tools/
cd /home/nlpsomnath/NegNews/Al*/KYC_new/NN_Kafka/kafka_tools/k*

#./home/nlpsomnath/NegNews/rebase/NN_Kafka/kafka_tools/bin/zookeeper-server-start.sh config/zookeeper.properties 
# ./home/nlpsomnath/NegNews/rebase/NN_Kafka/kafka_tools/bin/kafka-server-start.sh config/server.properties



#1.start zookeeper(part of kafka in v 2.0) 
#note: zookeeper manages the overall functionality and processes tied to KAFKA que
./bin/zookeeper-server-start.sh config/zookeeper.properties

#2.Start Kafka Server 
./bin/kafka-server-start.sh config/server.properties

#3.Create a topic (test) with single partition and one replica 
#note: scale up partitions and replica's for fault tolerance and parrelization 
bin/kafka-topics.sh --create --zookeeper localhost:2181 --replication-factor 1 --partitions 1 --topic test

#4.View topic by running list topic command 
bin/kafka-topics.sh --list --zookeeper localhost:2181

#5.Send messages
bin/kafka-console-producer.sh --broker-list localhost:9092 --topic test

#6.Start a consumer(which will consume and print ur messages) 
bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic test --from-beginning

#7.Describe which brokers are doing what 
bin/kafka-topics.sh --describe --zookeeper localhost:2181 --topic my-replicated-topic

#delete all topics starting with 09
./bin/kafka-topics.sh --zookeeper localhost:2181 --delete --topic 01-.*
./bin/kafka-topics.sh --zookeeper localhost:2181 --delete --topic bing.*

###Shutdown zookeeper 
 ./bin/zookeeper-server-stop.sh
  ./bin/zookeeper-server-start.sh
###Shutdown kafka server 
./bin/kafka-server-stop.sh
./bin/kafka-server-start.sh         
       
#kill a broker 
ps aux | grep server-1.properties

#TROUBLESHOOT ERRORS ON LOADING 
#to find all java processes that are casusing error when loading zookeeper
ps -aux | grep java.

#to kill all java processes specific to kafka (the pids will always change) 
kill -9 20410
kill -9 29576

#kill a kafka topic: https://stackoverflow.com/questions/16284399/purge-kafka-topic/30833940
#clear a kafka topic by abusing use of retention rate 
###AT START OF PROCESS CLEAR OUT EXISTING RETAINED ITEMS IN A TOPIC
####THIS IS MANUALLY DONE HERE, CAN BE WRAPPED IN subprocess.call(['sudo',kwargs**])
#change retention to a minute
./bin/kafka-configs.sh --zookeeper localhost:2181 --alter --entity-type topics --entity-name 'bing' --add-config retention.ms=100
#check retention rate by printing the configured parameters for a toic (only outputs configs that are other than default) 
./bin/kafka-configs.sh --zookeeper localhost:2181 --describe --entity-type topics --entity-name 'bing'    
#reset retention rate to default 
./bin/kafka-configs.sh --zookeeper localhost:2181 --alter --entity-type topics --entity-name 'bing' --delete-config retention.ms   

#total items in a topic 
./bin/kafka-run-class.sh kafka.tools.GetOffsetShell --broker-list localhost:9092 --topic 'bing' --time -1 --offsets 1 | awk -F ":" '{sum += $3} END {print sum}'
