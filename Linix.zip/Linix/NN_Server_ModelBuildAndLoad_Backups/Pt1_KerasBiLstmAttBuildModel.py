## -*- coding: utf-8 -*-
"""
Created on Fri Jan 25 11:07:37 2019

@author: caridza
"""
import os 
import sys
import pandas as pd 
import pymagnitude
import re
import string 
from sklearn import preprocessing , model_selection, metrics
import numpy as np
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk import regexp_tokenize
from nltk.tokenize import word_tokenize , sent_tokenize


#MUST IMPORT ALL FROM EITHER KERAS or Tensorflow.python.keras. YOU CANNOT MIX
import keras 
from keras.preprocessing.text import Tokenizer 
from keras.preprocessing.sequence import pad_sequences 
from keras.preprocessing.text import Tokenizer 
from keras.preprocessing.sequence import pad_sequences 
from keras.callbacks import ModelCheckpoint, EarlyStopping
from keras_self_attention import SeqSelfAttention 
import gensim
from imblearn.over_sampling import SMOTE  # or: import RandomOverSampler
from imblearn.pipeline import Pipeline as imbPipeline
from sklearn.model_selection import StratifiedShuffleSplit
from keras.models import model_from_json 

#custom modules 
from negative_news2.consumer.utils.nn_modelutils import TextSelector , NumberSelector
from negative_news2.consumer.utils import upsample_rare,make_df,make_embeddings_pymag


stemmer = SnowballStemmer('english')
stopwords = stopwords.words("english")
newStopWords = ['.','?','%','Google','Wells Fargo','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December']
stopwords.extend(newStopWords)
stop_list=set(stopwords)


def build_bilstm(stopwords=stopwords):
    stemmer = SnowballStemmer('english')
    exclude = set(string.punctuation)
    stopwords = stopwords.words('english')
    newStopWords = ['.','?','%','Google','Wells Fargo','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December']
    stopwords.extend(newStopWords)
    stop_list=set(stopwords)
    
    datapath = "//home//nlpsomnath//NegNews/zackc//Misc Notebooks//Python Misc//Data//SentDF.pickle"
    wv=pymagnitude.Magnitude('//home//nlpsomnath//NegNews//rebase//NN_Kafka//sourcefiles//GoogleNews-vectors-negative300.magnitude')

    #inputs requiring path specification
    max_features = 100000 #maximum number of words to consider in analysis 
    EMBEDDING_DIM = 300 #NOTE: becuase we use pymag this must be set to 300 
    stop_list = stop_list
    stemmer = stemmer
    target = 'MandA'

    ##################################################
    #load data and generate balanced training dataset#
    ##################################################
    Data = pd.read_pickle(datapath)
    sss = StratifiedShuffleSplit(n_splits=2, test_size=0.01, random_state=0) #generate stratified sample 
    
    #extract index values of test data 
    indicies  = []
    for train_index ,test_index in sss.split(Data.index,Data[target]):
        indicies.extend(test_index)
    testrows=indicies

    #create holdout with population distributions of target preserved 
    holdout= Data.iloc[testrows,:]  

    #generate balanced dataframe for testing using data not included in holdout
    data = Data.loc[set(Data.index)-set(holdout.index)]

    #oversample rare event to generate balanced training dataset 
    balanced_data = upsample_rare(data,target)


    #############################
    #####Dataset Preperation#####
    ###SEQUENCE TRANSFORMATION###
    ############################# 
    #transform original Df into sequence tokenized data and split into test and train. get list of words in vocab , and maxlen of sequence
    xtr,ytr,xte,yte,word_index, maxlen,words = make_df(balanced_data,      #path to sentence level data 
                                                max_features,  #maximum number of words to consider in model 
                                                EMBEDDING_DIM,  #number of dims form embedding vector to use(if pymag used this must be 300)
                                                stop_list,
                                                stemmer,
                                                target=target)


    #generate embedding vector using pymagnitude 
    nb_words = min(max_features, len(word_index)+1) #total features to consider, min of the max feats vs total feats 
    embedding_vector =  make_embeddings_pymag(wv, max_features,words, word_index, EMBEDDING_DIM, nb_words)



    ###############################
    #Compile Sequence Model Layers#
    ###############################
    model=keras.models.Sequential()
    #add embedding layer
    model.add(keras.layers.Embedding(input_dim = nb_words #max_features
                                    , output_dim= EMBEDDING_DIM #embedding size 
                                    , weights = [embedding_vector]
                                    , mask_zero=False
                                    , trainable=False
                                    , input_length = maxlen #the max sequence length, this is the length that all sequences will be padded to (so all sequences will have same length)
                                    ))
    #add bilstm layer with dropout 
    model.add(keras.layers.Bidirectional(keras.layers.LSTM(units = 300,
                                                        return_sequences=True,
                                                        dropout=.3,
                                                        recurrent_dropout=.3,
                                                        #stateful = True , 
                                                        #unroll = True
                                                        )))

    #add self attention layer 
    #model.add(SeqSelfAttention(attention_activation='sigmoid'))
    model.add(SeqSelfAttention(attention_width=15,
                            attention_type=SeqSelfAttention.ATTENTION_TYPE_MUL,
                            attention_activation=None,
                            kernel_regularizer=keras.regularizers.l2(1e-6),
                            use_attention_bias=False,    
                            name='Attention',))
        
    #flatten layers
    model.add(keras.layers.Flatten())
    #add output layer
    model.add(keras.layers.Dense(units =1,activation='sigmoid'))

    #compile model 
    model.compile(optimizer='adam',loss = 'binary_crossentropy',metrics =['accuracy'] )
    model.summary()

    #specify callbacks for keras model 
    filepath="//home//nlpsomnath//NegNews//zackc//Misc Notebooks//Python Misc//models//checkpt_model_and_weights-improvement-{epoch:02d}-{val_loss:.2f}.hdf5"
    ckpt = ModelCheckpoint(filepath, monitor='val_loss', verbose=1, save_best_only=False, save_weights_only=True, mode='auto')
    early = EarlyStopping(monitor="val_loss", mode="min", patience=2)

    #fit model 
    model_out = model.fit(xtr, ytr, batch_size=256, epochs=20, validation_split=0.2, callbacks=[early,ckpt])

    #save model and architecture down to json config 
    model.save('//home//nlpsomnath//NegNews//zackc//Misc Notebooks//Python Misc//models//{}_NN_BiLSTMSelfAtt_modelfromlastepoch.h5'.format(target))

    #check confusion matrix on validation set 
    y_preds = model.predict_classes(xte)
    matrix = metrics.confusion_matrix(yte, y_preds)
    print(matrix)










