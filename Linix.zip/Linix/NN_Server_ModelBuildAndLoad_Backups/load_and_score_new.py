
#################################################################
###############FUNCTIONS THAT MUST BE USED WHEN RUN##############
#################################################################
#load model and score new data through the pipeline defined in the finalmodel 
def load_and_score(Data=None,model_path=None,stop_words=stop_list,stemmer=stemmer,target=''):
    
    
    vocab_size = 10000
    batch_size = 100
    num_labels= 1
    target = target

    print('load_and_score_data')
    data = Data.copy()
    #INPUTS
    #data = dataframe of source data with one col reprsenting sent tokenized text 
    #model_path = path to model that is going to ggenerate predictions 
    #stop_words = set of stopwords to be removed from each sentence 
    #stemmer = stemmer class to be utilized for stemming vocabulary 
    
    #get doc_index as col to join results back to
    data.reset_index(inplace=True)
    data.rename(columns={'index': 'DocIndex'}, inplace=True)
    
    #create sent level df 
    list(data)
    SentDF = DocDF2SentDF(data,cols = ['DocIndex','date','entity','url','source','title','jobname','sentence_tokenized'])
    
    print('SentDF',SentDF.head())
    #clean data (because we are scoring data we dont have a target flag(sot), so we leave it blank to indiciate we are scoring new data)
    newdata = orig_text_clean(SentDF,target='',txtfeild='Sentence',stopwords=stop_words,stemmer=stemmer)
    print('NewData',newdata.head())
    
    #load pickled model for evaluation on unseen data
    #Valid Models: Keras or Sklearn  
    if "Keras" in model_path:
        
        #fit tfidf on trianing data and transform the tfidf on the test data
        loaded_vec = TfidfVectorizer(decode_error="replace",vocabulary=pickle.load(open("//home//nlpsomnath//NegNews//zackc//Misc Notebooks//Python Misc//models//NNKerasMLP_tfidfVocab.pkl", "rb")),
                                    analyzer='word', ngram_range=(1,1),stop_words='english', smooth_idf=True, norm='l2',sublinear_tf=True,lowercase=True,
                                    )
        
        x_score_vec = loaded_vec.fit_transform(newdata).toarray()   
        #load saved model  
        loaded_model = keras.models.load_model(model_path)
        #make new predictions 
        predictions =  loaded_model.predict_classes(x_score_vec) 
        
    else:
        loaded_model = joblib.load(model_path)
        predictions =  loaded_model.predict(newdata)

    preds = pd.DataFrame(data=predictions, columns = ['Pred_'+target])
    
    #create df of preds to join back to original doc level data
    results = pd.concat([newdata, preds], axis=1)
    col = results.filter(like='Pred_').columns.values
    results2 = results .groupby(['DocIndex'])[col].sum()
    results2.reset_index(inplace=True)
    
    #merge preds to original df by doc index 
    finaldf = pd.merge(data[['DocIndex']], results2, on='DocIndex', how='left')
    #finaldf['Pred_'+target] = finaldf['Pred_'+target].apply(lambda x: 1 if x> 0 else x)
    finaldf['Pred_'+target] = finaldf['Pred_'+target].apply(lambda x: map_pred_to_risk(target) if x> 0 else x)
    
    return(finaldf['Pred_'+target].values)
