# -*- coding: utf-8 -*-
"""
Created on Wed Feb 13 09:41:48 2019

@author: caridza
"""



def bilstm_load_and_score(Data=None,model_path=None,stop_words=stop_list,stemmer=stemmer,target='',trainmaxlen=None ,max_features=10000,EMBEDDING_DIM=300,wv_path='//home//nlpsomnath//NegNews//rebase//NN_Kafka//sourcefiles//GoogleNews-vectors-negative300.magnitude'):

    wv=pymagnitude.Magnitude(wv_path)

    data = Data.copy()
    #INPUTS
    #data = dataframe of source data with one col reprsenting sent tokenized text 
    #model_path = path to model that is going to ggenerate predictions 
    #stop_words = set of stopwords to be removed from each sentence 
    #stemmer = stemmer class to be utilized for stemming vocabulary 
    
    #get doc_index as col to join results back to
    data.reset_index(inplace=True)
    data.rename(columns={'index': 'DocIndex'}, inplace=True)
    
    #create sent level df 
    list(data)
    SentDF = DocDF2SentDF(data,cols = ['DocIndex','date','entity','url','source','title','jobname','sentence_tokenized'])

    #create sequences from text 
    X,word_index, maxlen,words= make_df(SentDF, max_features,EMBEDDING_DIM,stop_list,stemmer,trainmaxlen=trainmaxlen,target='')

    #generate embedding vector using pymagnitude 
    nb_words = min(max_features, len(word_index)+1) #total features to consider, min of the max feats vs total feats 
    embedding_vector =  make_embeddings_pymag(wv, max_features,words, word_index, EMBEDDING_DIM, nb_words)
  
    #load model to use in scoring 
    model = load_model(model_path,custom_objects={'SeqSelfAttention':keras_self_attention.SeqSelfAttention})

    
    #load pickled model for evaluation on unseen data 
    predictions =  model.predict_classes(X)

    preds = pd.DataFrame(data=predictions, columns = ['Pred_'+target])
    
    #create df of preds to join back to original doc level data
    results = pd.concat([SentDF, preds], axis=1)
    col = results.filter(like='Pred_').columns.values
    results2 = results .groupby(['DocIndex'])[col].sum()
    results2.reset_index(inplace=True)
    
    #merge preds to original df by doc index 
    finaldf = pd.merge(data[['DocIndex']], results2, on='DocIndex', how='left')
    finaldf['Pred_'+target] = finaldf['Pred_'+target].apply(lambda x: 1 if x> 0 else x)
    return(finaldf['Pred_'+target].values)