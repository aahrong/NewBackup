## -*- coding: utf-8 -*-
"""
Created on Fri Jan 25 11:07:37 2019
KERAS MLP PT 1
KERAS MLP MODEL WITH TFIDF VECTORIZOR FROM SKLEARN 
@author: caridza
"""
import pandas as pd
import string, pickle, sys
from itertools import islice #iterating over vectorized objects (countvectorizer, tfidfvectorizer,etc..)
#required modules for data preprocessing and modeling
import sklearn
from sklearn import decomposition, ensemble,model_selection, preprocessing, metrics
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer,TfidfTransformer
from sklearn.pipeline import Pipeline,make_pipeline,FeatureUnion 
from sklearn.preprocessing import StandardScaler,MinMaxScaler
from sklearn.model_selection import train_test_split,GridSearchCV

from sklearn.neural_network import MLPClassifier
#text parsing
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
from nltk import word_tokenize

#plotting
import numpy as np
import joblib
import re
import pymagnitude
#pipelien 
from imblearn.over_sampling import SMOTE  # or: import RandomOverSampler
from imblearn.pipeline import Pipeline as imbPipeline

import keras 
from keras.preprocessing.text import Tokenizer
from keras.models import Sequential
from keras.layers import Activation, Dense, Dropout
from keras.utils import to_categorical
from keras.callbacks import ModelCheckpoint, EarlyStopping
from keras import regularizers 
from keras.models import load_model
    
def orig_text_clean(data,target='LegalAction',txtfeild='origtext',stopwords=['the','is','a','i','are','it'],stemmer=None):
    trainDF = pd.DataFrame()
    trainDF['text'] = data[txtfeild].apply(lambda x: remove_punctuation(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_nonchars(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_stop(x,stopwords=stopwords))
    
    if stemmer!=None:
        trainDF[txtfeild] = trainDF['text'].apply(lambda x: stem_words(x,stemmer=stemmer))
    else:
        trainDF[txtfeild] = trainDF['text']
        
    if target!='':
        trainDF['label'] = data[target]
        le = preprocessing.LabelEncoder() 
        le.fit(trainDF['label'])
        trainDF['label_id'] =le.transform(trainDF['label'])
            
    trainDF=trainDF.reset_index(drop=True)
    return trainDF 

#preprocess data 
#func to remove punc from string and return string
def remove_punctuation(text,excluded_punct={'+', ':', '[', '^', '"', '|', '{', '@', '=', ')', '%', '#', '`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}):
    return ' '.join([word for word in nltk.word_tokenize(text) if word not in excluded_punct])

#func to remove stop words 
def remove_stop(text,stopwords=['the','is','a','i','are','it']):
    return ' '.join([word for word in text.split(' ') if word.lower() not in stopwords])

#func to stem words 
def stem_words(text,stemmer=None):
    return ' '.join([stemmer.stem(word) for word in text.split(' ')])

#remove non alpha characters from text 
def remove_nonchars(text):
    return ' '.join([re.sub('[^A-Za-z|^\$|^\.]+', ' ', word) for word in text.split(' ') if (word.isalnum() and len(word)>2)])



def build_mlp(stopwords=stopwords):

    datapath = "//home//nlpsomnath//NegNews/zackc//Misc Notebooks//Python Misc//Data//SentDF.pickle"
    stemmer = SnowballStemmer('english')
    exclude = set(string.punctuation)
    stopwords = stopwords.words('english')
    newStopWords = ['.','?','%','Google','Wells Fargo','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December']
    stopwords.extend(newStopWords)
    stop_list=set(stopwords)
    wv=pymagnitude.Magnitude('//home//nlpsomnath//NegNews//rebase//NN_Kafka//sourcefiles//GoogleNews-vectors-negative300.magnitude')

    #user input
    vocab_size = 10000
    batch_size = 100
    num_labels=1
    target = 'MandA'
    textfeild = 'Sentence'
    data = pd.read_pickle(datapath)
    data.drop(columns=['date'],inplace=True)
    list(data)

    # load the dataset
    Data = orig_text_clean(data,target='MandA',txtfeild=textfeild)   
    train_x,test_x,train_y,test_y =model_selection.train_test_split(Data[textfeild], Data['label_id'],shuffle=True, stratify=Data['label_id'],test_size=.25, random_state=10)


    #fit tfidf on trianing data and transform the tfidf on the test data 
    vectorizer = TfidfVectorizer(analyzer='word', ngram_range=(1,1), max_features=vocab_size,min_df=2 ,stop_words='english', max_df=.1, smooth_idf=True, norm='l2',sublinear_tf=True,lowercase=True,)
    x_train_vec = vectorizer.fit_transform(train_x).toarray()
    x_test_vec = vectorizer.transform(test_x).toarray()

    #determine inbalnce between target and non target event for use in model.fit()
    NegCounts = pd.value_counts(train_y, sort=False)[0]
    PosCounts = pd.value_counts(train_y, sort=False)[1]
    ClassWeight = round(NegCounts / PosCounts,0)
    ClassWeights = {0:ClassWeight,1:1}
    print(ClassWeights)

    #create model layers 
    model = Sequential() 
    model.add(Dense(200, input_shape=(vocab_size,),kernel_regularizer=regularizers.l2(0.001),activity_regularizer=regularizers.l2(.001)))
    model.add(Activation('relu')) 
    model.add(Dropout(0.6)) 
    model.add(Dense(num_labels)) 
    model.add(Activation('sigmoid')) 
    model.summary() 


    #specify callbacks for keras model 
    model_filepath="//home//nlpsomnath//NegNews//zackc//Misc Notebooks//Python Misc//models//MLP_{}_best_model_and_weights.hdf5".format(target)
    ckpt = ModelCheckpoint(model_filepath, monitor='val_binary_accuracy', verbose=1, save_best_only=True, save_weights_only=False, mode='max')
    early = EarlyStopping(monitor="val_binary_accuracy", mode="max", patience=12)

    #set loss function, gds ooptimizer, and metrics to track for callbacks and cross validation 
    model.compile(loss='binary_crossentropy',
                optimizer='adam',
                metrics=['binary_accuracy'])
    
    #fit model
    #class weights used to represent imbalanced data 
    history = model.fit(x_train_vec,train_y,
                        batch_size=batch_size,
                        epochs=50,
                        verbose=1,
                        validation_split=0.2,
                        callbacks = [early,ckpt],
                        class_weight = ClassWeights,
                        )


    loss, accuracy = model.evaluate(x_train_vec, train_y, verbose=1)
    print("Training Accuracy: {:.4f}".format(accuracy))
    loss, accuracy = model.evaluate(x_test_vec, test_y, verbose=1)
    print("Testing Accuracy:  {:.4f}".format(accuracy))
    #plot_history(history, metric='acc')

    #load best model from keras
    new_model = load_model(model_filepath)
    y_preds = new_model.predict_classes(x_test_vec)
    print(metrics.confusion_matrix(test_y,y_preds))
    
    #save model and architecture down to json config 
    model.save("//home//nlpsomnath//.local//lib//python3.5//site-packages//negative_news2//resources//NN_KerasMLP_{}.sav".format(target))
    
  







