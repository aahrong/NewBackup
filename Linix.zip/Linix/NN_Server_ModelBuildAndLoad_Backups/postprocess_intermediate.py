import os
import sys
import time
from datetime import datetime, timezone, timedelta
import logging
from multiprocessing import Manager, Process
import traceback
from collections import defaultdict
import string
import operator 
from functools import reduce 
import dateparser
import numpy as np
import pandas as pd
from tinysegmenter import TinySegmenter
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from fuzzywuzzy import fuzz
import matplotlib
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer

from .minhash import MinHash
from .translate import threaded_translate_text
from .fines import (
    get_data_from_article_title,
    transform_article_title,
    load_entity_dict,
    generate_report_string,
    max_marketshare,
)
from .desm import desm_pandas_wrapper
from ..database import get_processed_results_handle

# from .model import (
#     orig_text_clean,
#     remove_nonchars,
#     stem_words,
#     remove_stop,
#     remove_punctuation,
#     load_and_score,
#     NumberSelector,
#     TextSelector,
# )

logger = logging.getLogger(__name__)

# setup
matplotlib.use("Agg")

# constants
RESOURCES_PATH = f"{os.path.dirname(os.path.dirname(__file__))}/resources"

stopwords = stopwords.words("english")
stemmer = SnowballStemmer("english")
model_path = f"{RESOURCES_PATH}/NN_MLP_MonetaryFine.sav"
avg_top_n_scores = 3
regulatory_url_list = [".gov", "finra.org"]
url_fuzzy_threshold = 80
title_fuzzy_threshold = 95
norm_date = datetime.now().date() - timedelta(10 * 365)

MODEL_WEIGHTS_DICT = {
    "WEIGHT_TERM_SIMILARITY": 0.85,
    "WEIGHT_ENTITY_COUNT": 0.05,
    "WEIGHT_SENTIMENT": 0.03,
    "WEIGHT_FINE_AMOUNT": 0.05,
    "WEIGHT_DOCUMENT_AGE": 0.02,
}

ASYMPTOTIC_OFFSETS_DICT = {
    "ASYMPTOTIC_OFFSET_ENTITY": 2 / 0.3,
    "ASYMPTOTIC_OFFSET_URL_COUNT": 2 / 0.3,
    "ASYMPTOTIC_OFFSET_TERM_SIMILARITY": 200,
}

RISK_SCORE_NORMS_DICT = {"RISK_SCORE_NORM_MIN": 0.2, "RISK_SCORE_NORM_MAX": 0.45}

THRESHOLD_RANGE_DICT = {
    "max_desm_score": {"range": [0.14, 0.172]},
    "doc_sentiment": {"range": [0.18, 0.4]},
    "age_norm": {"range": [0.37, 0.7]},
    "entity_count_norm": {"range": [0.6, 0.9]},
    "fine_amt_norm": {"range": [0.001, 0.4]},
}

ENTITY_DICT = load_entity_dict(f"{RESOURCES_PATH}/entity_dict.pickle")

TERM_SIMILARITY_REMOVAL_THRESHOLD = 0.55


def aggregate_into_single_list(row, col_name_list):
    final_list = []
    for col in col_name_list:
        if type(row[col]) == list:
            for item in row[col]:
                final_list.append(item)
        else:
            final_list.append(row[col])
    return final_list


# need to account for foreign date formats
# link this to language abbreviation?
def date_extract_pandas_wrapper(row):
    # logger.debug('Extracting date: initial value is "{}" with type "{}"'.format(row['date'], type(row['date'])))

    if type(row["date"]) == str:
        extracted_date = dateparser.parse(row["date"])
        if extracted_date is not None:
            # logger.debug('Dateparser extracted the following date: {}'.format(extracted_date))
            return datetime(
                extracted_date.year, extracted_date.month, extracted_date.day
            )
    elif type(row["date"]) != datetime:
        return None
    else:
        return row["date"]


def date_filter_pandas_wrapper(date, datetime_threshold):
    try:
        return date >= datetime_threshold
    except TypeError:
        return (
            datetime(date.year, date.month, date.day, tzinfo=timezone.utc)
            >= datetime_threshold
        )


def get_window_filter_idx(original_list, window_size=1, criteria=lambda x: True):
    new_list = []
    max_idx = len(original_list) - 1

    for idx, val in enumerate(original_list):
        if criteria(val):
            new_list.append(idx)

            i = window_size
            while i > 0:
                new_list.append(max(idx - i, 0))
                new_list.append(min(idx + i, max_idx))
                i -= 1

    new_list = list(set(new_list))

    return new_list


def final_score(
    model_weights_dict,
    term_similarity=0,
    entity_count=0,
    sentiment=0,
    fine_amt=0,
    age=0,
):
    return (
        (term_similarity * model_weights_dict["WEIGHT_TERM_SIMILARITY"])
        + (entity_count * model_weights_dict["WEIGHT_ENTITY_COUNT"])
        + (-1 * sentiment * model_weights_dict["WEIGHT_SENTIMENT"])
        + (fine_amt * model_weights_dict["WEIGHT_FINE_AMOUNT"])
        + (-1 * age * model_weights_dict["WEIGHT_DOCUMENT_AGE"])
    )


def normalize_pandas_series(series, max=None, min=None):
    if max is None:
        if series.max() == 0:
            max = 1
        else:
            max = series.max()

    if min is None:
        min = series.min()

    return (series - min) / (max - min)


def asymptotic_normalization(val, offset):
    return (val ** 2) / ((val ** 2) + offset)


def reg_site_classifier(url):
    if any(k in url for k in regulatory_url_list):
        return True
    else:
        return False


def dict_to_tupes_wrapper(dict_input, avg_top_n_scores=3):
    tupe_list = []

    for q in dict_input:
        doc_idx, scores = zip(*dict_input[q])
        top_avg = np.mean(scores[:avg_top_n_scores])
        tupe_list.append((q, top_avg))

    return tupe_list


def url_fuzzy_dupes(l, threshold=80):
    """
    Return the dataframe indexes of fuzzy matches for input list and input threshold.
    Arguments:
        l {list} -- list of strings for fuzzy matching
        threshold {int} -- matching threshold above which the index is flagged for deletion. Default is 80
    """

    dupe_dict = defaultdict(list)

    for i in range(0, len(l)):
        for j in range(i + 1, len(l)):
            if fuzz.partial_ratio(l[l.index[i]], l[l.index[j]]) > threshold:
                dupe_dict[i].append(j)

    idx_to_remove1 = list(
        set([idx for idx_list in dupe_dict.values() for idx in idx_list])
    )
    return idx_to_remove1


def get_highest_fine_bin(fine_tuple_list, is_org=1):
    _list = []

    for fine_tuple in fine_tuple_list:

        orgs_from_title, total_fine, generate_flag, _, pct_equity_list = fine_tuple

        if generate_flag:
            for pct in pct_equity_list:
                if pct > 0.1:
                    _list.append(("equity", 7))
                elif ((is_org == 1) & (total_fine > 500_000)) | (
                    (is_org == 0) & (total_fine > 100_000)
                ):
                    _list.append(("fine threshold", 3))
                else:
                    _list.append(("other", 1))
        else:
            _list.append(("other", 1))

    highest_bin = sorted(_list, key=lambda x: x[1], reverse=True)[0]

    return highest_bin


def wordsims(model,RiskTerms,WordTokenizedSent,DocRiskFunc =None,CatRisk=None,threshold=None,):
    word_sims =0

    for r_term in RiskTerms:
        word_sims  = max(word_sims, max(model.similarity(r_term,WordTokenizedSent)))
        
    if DocRiskFunc !=None:
        #word_sims = word_sims.apply(DocRiskFunc)
        word_sims = DocRiskFunc(data=word_sims,CatRisk=CatRisk,threshold=threshold)
    return word_sims

def Create_DocCat(data=None, CatRisk=3,threshold=.4):
    return np.where(data>threshold,CatRisk,0)

def generate_output_args(
    scraped_data,
    wv,
    nlp,
    is_org,
    max_sentiment,
    min_year,
    min_month,
    min_similarity,
    search_terms,
    max_search_results,
    output_path,
    entity_name,
    entity_name_translated,
    known_aliases,
    location,
    employment,
    language_abbrv,
    threshold_range_dict=THRESHOLD_RANGE_DICT,
    risk_score_norms_dict=RISK_SCORE_NORMS_DICT,
    asymptotic_offsets_dict=ASYMPTOTIC_OFFSETS_DICT,
    model_weights_dict=MODEL_WEIGHTS_DICT,
    entity_dict=ENTITY_DICT,
):
    # create dataframe from list of dictionaries representing scraped data
    df = pd.DataFrame(scraped_data)

    # check to make sure we do not have an empty initial dataframe
    if df.shape[0] <= 1:
        raise Exception(
            "Initially created dataframe was empty. Aborting postprocessing .."
        )

    # drop null content
    num_rows_before_filter = len(df)
    tock = time.perf_counter()
    df.dropna(subset=["content"], inplace=True)
    tick = time.perf_counter()
    logger.debug(
        "Dropped {} rows due to null 'content'. {} remaining rows. Took {}s ..".format(
            num_rows_before_filter - len(df), len(df), round(tick - tock, 2)
        )
    )

    # check to make sure we still have rows after filtering out null content
    if df.shape[0] <= 1:
        raise Exception(
            "Dataframe empty after null content filter. Aborting postprocessing .."
        )

    # convert string dates/fill empty dates
    logger.debug(
        "Attempting to convert string dates to datetime or fill empty/null dates .. "
    )
    tock = time.perf_counter()
    df["date"] = df.apply(lambda x: date_extract_pandas_wrapper(x), axis=1)
    tick = time.perf_counter()
    logger.debug(f"Date processing complete. Took {round(tick - tock, 2)}s..")

    # drop null dates
    num_rows_before_filter = len(df)
    tock = time.perf_counter()
    df.dropna(subset=["date"], inplace=True)
    tick = time.perf_counter()
    logger.debug(
        "Dropped {} rows due to null dates. {} remaining rows. Took {}s .. ".format(
            num_rows_before_filter - len(df), len(df), round(tick - tock, 2)
        )
    )

    # apply date filter
    num_rows_before_filter = len(df)
    date_threshold = datetime(min_year, max(1, min_month - 1), 1, tzinfo=timezone.utc)
    df = df[
        df.apply(
            lambda x: date_filter_pandas_wrapper(x["date"], date_threshold), axis=1
        )
    ]
    logger.debug(
        "Dropped {} rows due to date threshold ({}). {} remaining rows .. ".format(
            num_rows_before_filter - len(df), date_threshold.date(), len(df)
        )
    )

    # check to make sure we still have rows after filtering based on date
    if df.shape[0] <= 1:
        raise Exception("Dataframe empty after date filter. Aborting postprocessing ..")

    # AG EDIT 1/17/19 FOR FUZZY DUPES
    logger.debug("Identifying duplicates via fuzzy match on URLs ..")
    tock = time.perf_counter()
    dupe_idx2 = url_fuzzy_dupes(df["url"], url_fuzzy_threshold)
    df.drop(df.index[dupe_idx2], inplace=True)
    tick = time.perf_counter()
    logger.debug(
        f"Dropped {len(dupe_idx2)} rows due to fuzzy URL duplicates. {len(df)} rows remaining. "
        + f"Took {round(tick - tock, 2)}s .."
    )

    # check to make sure we still have rows after filtering out fuzzy URL duplicates
    if df.shape[0] <= 1:
        raise Exception(
            "Dataframe empty after removal of fuzzy URL duplicates. Aborting postprocessing .."
        )

    logger.debug("Identifying duplicates via fuzzy match on title ..")
    tock = time.perf_counter()
    dupe_idx3 = url_fuzzy_dupes(df["title"], title_fuzzy_threshold)
    df.drop(df.index[dupe_idx3], inplace=True)
    tick = time.perf_counter()
    logger.debug(
        f"Dropped {len(dupe_idx3)} rows due to fuzzy title duplicates. {len(df)} rows remaining. "
        + f"Took {round(tick - tock, 2)}s .."
    )

    # check to make sure we still have rows after filtering out fuzzy title duplicates
    if df.shape[0] <= 1:
        raise Exception(
            "Dataframe empty after removal of fuzzy title duplicates. Aborting postprocessing .."
        )

    # calculate age
    df["age"] = df.apply(
        lambda x: (datetime.now().date() - x["date"].date()).days, axis=1
    )
    df["alt_age"] = df.apply(lambda x: (x["date"].date() - norm_date).days, axis=1)

    # assign tokenizer based on language
    if language_abbrv == "EN":
        sent_tokenizer = nltk.tokenize.sent_tokenize
        word_tokenizer = nltk.tokenize.word_tokenize
    elif language_abbrv == "JA":
        sent_tokenizer = nltk.RegexpTokenizer("[^ !??]*[!??.\n]").tokenize
        word_tokenizer = TinySegmenter().tokenize
    else:
        raise ValueError(
            "'{}' is an unsupported language abbreviation .. ".format(language_abbrv)
        )

    logger.debug("Performing tokenization .. ")
    tock = time.perf_counter()
    # sentence tokenize documents
    df["sentence_tokenized"] = df.apply(lambda x: sent_tokenizer(x["content"]), axis=1)
    # word tokenize each sentence token
    df["sentence_tokenized_word_tokenized"] = df.apply(
        lambda x: list(map(lambda y: word_tokenizer(y), x["sentence_tokenized"])),
        axis=1,
    )
    tick = time.perf_counter()
    logger.debug(f"Tokenization complete. Took {round(tick - tock, 2)}s ..")

    logger.debug(
        "Counting occurrences of sentences containing entity name and/or known aliases .."
    )

    # this threshold defines the fuzzy score below which we will
    # not count as an entity mention
    ENTITY_FUZZ_SCORE_THRESHOLD = 90

    # combine the entity name and all known aliases
    # into a single list for the purposes
    # of fuzzy scoring
    names = known_aliases + [entity_name]

    # for each sentence in each article, return the max fuzzy score between all names associated with the entity
    # aggregate these max fuzzy scores into a list for each article
    tock = time.perf_counter()
    df["name_fuzzy_score_list"] = df.apply(
        lambda x: list(
            map(
                lambda sent: max([fuzz.partial_ratio(sent, name) for name in names]),
                x["sentence_tokenized"],
            )
        ),
        axis=1,
    )

    # for each article, determine how many of sentence-level fuzzy scores exceed the threshold
    df["entity_count"] = df.apply(
        lambda x: sum(
            list(
                map(
                    lambda score: score > ENTITY_FUZZ_SCORE_THRESHOLD,
                    x["name_fuzzy_score_list"],
                )
            )
        ),
        axis=1,
    )
    tick = time.perf_counter()
    logger.debug(f"Entity count complete. Took {round(tick - tock, 2)}s ..")

    # filter based on entity occurrences
    num_rows_before_filter = len(df)
    tock = time.perf_counter()
    df = df[df["entity_count"] > 0]
    tick = time.perf_counter()
    logger.debug(
        "Dropped {} rows due to missing entity mention. {} rows remaining. Took {}s .. ".format(
            num_rows_before_filter - len(df), len(df), round(tick - tock, 2)
        )
    )

    # check to make sure we still have rows after filtering based on entity occurrences
    if df.shape[0] <= 1:
        raise Exception(
            "Dataframe empty after entity filter. Aborting postprocessing .."
        )

    # generate sentence indices to keep based on window filtering method
    df["window_filter_idx_list"] = df.apply(
        lambda x: get_window_filter_idx(
            x["name_fuzzy_score_list"],
            criteria=lambda score: score > ENTITY_FUZZ_SCORE_THRESHOLD,
        ),
        axis=1,
    )

    # filter sentence tokens based on the results of our window filter indices
    df["sentence_tokenized"] = df.apply(
        lambda x: [x["sentence_tokenized"][idx] for idx in x["window_filter_idx_list"]],
        axis=1,
    )

    # filter word-tokenized, sentence tokens based on the results of our window filter indices
    df["sentence_tokenized_word_tokenized"] = df.apply(
        lambda x: [
            x["sentence_tokenized_word_tokenized"][idx]
            for idx in x["window_filter_idx_list"]
        ],
        axis=1,
    )

    # remove duplicates via MinHash algorithm
    tock = time.perf_counter()
    try:
        dupe_idx = MinHash(df["content"]).idx_to_remove
    except ValueError:
        # when computing the minimum hash, we will occasionally receive a ValueError < min() arg is an empty sequence
        # eventually, we should better diagnose this issue; however, for now, we will simply set the duplicate indices
        # to an empty list
        exc_info = sys.exc_info()
        logger.debug(
            "Aborting remove duplicates operation because"
            + "ValueError occurred while running MinHash: {}".format(
                "".join(traceback.format_exception(*exc_info))
            )
        )
        dupe_idx = []

    df.drop(df.index[dupe_idx], inplace=True)
    tick = time.perf_counter()
    logger.debug(
        "Dropped {} rows after MinHash duplicate analysis. {} rows remaining. Took {}s ..".format(
            len(dupe_idx), len(df), round(tick - tock, 2)
        )
    )

    # remove stop words from word-tokenized sentence tokens
    logger.debug("Removing stop words and punctuation from word tokens ..")
    tock = time.perf_counter()
    df["sentence_tokenized_word_tokenized"] = df.apply(
        lambda row: [
            [
                word
                for word in sent
                if word.lower() not in stopwords and word not in string.punctuation
            ]
            for sent in row["sentence_tokenized_word_tokenized"]
        ],
        axis=1,
    )
    tick = time.perf_counter()
    logger.debug(
        f"Finished stop word and punctuation removal. Took {round(tick - tock, 2)}s .."
    )

    # remove similar search terms
    terms_to_remove = []
    for i in range(len(search_terms)):
        for j in range(i + 1, len(search_terms)):
            if (
                wv.similarity(search_terms[i], search_terms[j])
                > TERM_SIMILARITY_REMOVAL_THRESHOLD
            ):
                logger.debug(
                    f"Removing '{search_terms[j]}' from search terms due to similarity to '{search_terms[i]}' .."
                )
                terms_to_remove.append(search_terms[j])
    logger.debug(f"Removed {len(terms_to_remove)} search terms ..")
    search_terms_desm = [term for term in search_terms if term not in terms_to_remove]

    # calculate term similarity
    logger.debug("Calculating DESM scores .. ")
    tock = time.perf_counter()
    df["max_desm_score"], df["desm_sentences"], df["desm_term"], df[
        "desm_score_dict"
    ] = zip(*df.apply(lambda x: desm_pandas_wrapper(wv, search_terms_desm, x), axis=1))
    tick = time.perf_counter()
    df.sort_values("max_desm_score", ascending=False, inplace=True)
    logger.debug(f"DESM score calculation complete. Took {round(tick - tock, 2)}s ..")

    # AG EDIT 1/16/19 - ADD ALL Q terms
    df["term_tupes"] = df.apply(
        lambda x: dict_to_tupes_wrapper(x["desm_score_dict"]), axis=1
    )
    # END AG EDITS 1/16/19

    # column name containing content to translate if necessary
    COLUMN_NAME_TO_TRANSLATE = "content"

    # max number of attempts to hit Bing Translate API
    # before raising exception
    MAX_TRANSLATION_ATTEMPTS = 3

    # counter for Bing Translate API attempts
    translation_attempt_counter = 0

    # attempt to translate the content of the articles
    # if the language is not English for the purpose of
    # sentiment scoring (VADER requires English)
    if language_abbrv != "EN":

        logger.debug(
            'Source language is not English. Translating from "{}" to "EN" .. '.format(
                language_abbrv
            )
        )

        while True:

            translation_attempt_counter += 1

            process_manager = Manager()
            process_list = []

            THREAD_SCHEDULING_PAUSE_SECONDS = 0.5
            THREAD_TIMEOUT_SECONDS = 5

            with process_manager as m:
                dump_list = m.list()

                try:
                    for idx, text_to_translate in enumerate(
                        df[COLUMN_NAME_TO_TRANSLATE]
                    ):
                        p = Process(
                            target=threaded_translate_text,
                            args=(
                                idx,
                                text_to_translate,
                                language_abbrv,
                                "EN",
                                dump_list,
                            ),
                        )
                        process_list.append(p)
                        p.start()
                        time.sleep(THREAD_SCHEDULING_PAUSE_SECONDS)

                    for p in process_list:
                        p.join(THREAD_TIMEOUT_SECONDS)

                    translated_content = sorted(
                        dump_list, key=lambda x: x[0], reverse=False
                    )
                except Exception:
                    logger.debug("Error occurred while performing translation .. ")
                    translated_content = []

            if (
                len(df) != len(translated_content)
                and translation_attempt_counter == MAX_TRANSLATION_ATTEMPTS
            ):
                raise Exception(
                    "Translation failed and attempts have exceeded threshold."
                    + "Aborting output generation process .. "
                )
            elif len(df) != len(translated_content):
                logger.debug(
                    "Translation attempt #{} failed. Reattempting translation process .. ".format(
                        translation_attempt_counter + 1
                    )
                )
                continue
            else:
                break

        content_translated = [item[1] for item in translated_content]
        df["sentence_tokenized_english"] = df.apply(
            lambda x: list(
                map(lambda y: nltk.tokenize.sent_tokenize(y), content_translated)
            ),
            axis=1,
        )

        logger.debug("Translation complete .. ")
    else:
        df["sentence_tokenized_english"] = df["sentence_tokenized"]

    # make SentimentIntensityAnalyzer object for the purpose
    # of generating VADER sentiment scores
    analyzer = SentimentIntensityAnalyzer()

    # this constant represents the top N most negative sentences
    # whose sentiment scores will be averaged to calculate
    # the overall article sentiment
    TAKE_N_MOST_NEGATIVE_SENTENCES = 3

    # calculate a sentiment score for each sentence in each document
    sentence_sentiment_list = []
    doc_sentiment_list = []
    for doc_idx, doc in enumerate(df["sentence_tokenized_english"]):
        sentence_sentiment_list.append([])
        for i_idx, item in enumerate(doc):
            try:
                sentence_sentiment_list[doc_idx].append(
                    analyzer.polarity_scores(item)["compound"]
                )
            except Exception:
                logger.debug(
                    "Sentiment calculation failed at doc index {}. Sentence is: {}".format(
                        doc_idx, item
                    )
                )
                sentence_sentiment_list[doc_idx].append(0)
        doc_sentiment_list.append(
            np.mean(
                sorted(sentence_sentiment_list[doc_idx])[
                    :TAKE_N_MOST_NEGATIVE_SENTENCES
                ]
            )
        )

    # assign sentiment
    df["sentence_sentiment"] = sentence_sentiment_list
    df["doc_sentiment"] = doc_sentiment_list

    # store number of rows before filtering for sentiment for logging purposes
    num_rows_before_filter = len(df)

    # filter rows based on sentiment
    # this negative threshold is the recommended value from the documentation:
    # https://github.com/cjhutto/vaderSentiment#about-the-scoring
    NEGATIVE_SENTIMENT_THRESHOLD = -0.05
    df = df[df["doc_sentiment"] <= NEGATIVE_SENTIMENT_THRESHOLD]
    logger.debug("Sentiment filtering complete ..")
    logger.debug(
        f"Dropped {num_rows_before_filter - len(df)} rows due to sentiment threshold"
        + f"({NEGATIVE_SENTIMENT_THRESHOLD}). {len(df)} rows remaining .."
    )

    # check to make sure we still have rows after filtering based on sentiment
    if df.shape[0] <= 1:
        raise Exception(
            "Dataframe empty after sentiment filter. Aborting postprocessing .."
        )

    # adjust this constant to the name of the column containing the top sentences
    logger.debug("Beginning fine extraction via spaCy ..")
    tock = time.perf_counter()

    TOP_SENTENCES_COL_NAME = "desm_sentences"

    # NER tag desired columns
    logger.debug("Beginning NER tagging via spaCy ..")
    _tock = time.perf_counter()
    df["tagged_top_sentences"] = df.apply(
        lambda x: list(map(lambda sent: nlp(sent), x[TOP_SENTENCES_COL_NAME])), axis=1
    )
    df["tagged_title"] = df.apply(
        lambda x: nlp(
            transform_article_title(x["title"]), " ".join(x[TOP_SENTENCES_COL_NAME])
        ),
        axis=1,
    )
    df["tagged_summary"] = df.apply(lambda x: nlp(x["summary"]), axis=1)
    _tick = time.perf_counter()
    logger.debug(f"Finished NER tagging via spaCy. Took {round(_tick - _tock, 2)}s ..")

    # generate fine tuples (e.g., (['ent1', 'ent2'], 1000000000.0, True) )
    df["fine_tuples_top_sentences"] = df.apply(
        lambda x: [
            get_data_from_article_title(
                entity_dict,
                tagged_text=sent,
                entity_name=entity_name,
                use_stemmer=False,
            )
            for sent in x["tagged_top_sentences"]
        ],
        axis=1,
    )

    df["fine_tuples_title"] = df.apply(
        lambda x: get_data_from_article_title(
            entity_dict,
            tagged_text=x["tagged_title"],
            entity_name=entity_name,
            use_stemmer=False,
        ),
        axis=1,
    )

    df["fine_tuples_summary"] = df.apply(
        lambda x: get_data_from_article_title(
            entity_dict,
            tagged_text=x["tagged_summary"],
            entity_name=entity_name,
            use_stemmer=False,
        ),
        axis=1,
    )

    # aggregate fine tuples into one list for each row
    df["fine_tuples_aggregated"] = df.apply(
        lambda row: aggregate_into_single_list(
            row,
            ["fine_tuples_top_sentences", "fine_tuples_title", "fine_tuples_summary"],
        ),
        axis=1,
    )

    # sum total fine amount from fine tuples
    FINE_AMOUNT_IDX = 1
    FINE_GENERATE_FLAG_IDX = 2
    df["total_entity_fine_amt"] = df.apply(
        lambda x: sum(
            set(
                [
                    t[FINE_AMOUNT_IDX] if t[FINE_GENERATE_FLAG_IDX] else 0
                    for t in x["fine_tuples_aggregated"]
                ]
            )
        ),
        axis=1,
    )

    # generate fine report strings
    df["fine_report_strings"] = df.apply(
        lambda row: list(
            set(
                [
                    fr
                    for ft in row["fine_tuples_aggregated"]
                    for fr in generate_report_string(
                        fine_tuple=ft, entity_dict=entity_dict
                    )
                ]
            )
        ),
        axis=1,
    )
    tick = time.perf_counter()

    logger.debug(f"Fine extraction complete. Took {round(tick - tock,2)}s ..")

    df["fine_bins"] = df.apply(
        lambda row: get_highest_fine_bin(row["fine_tuples_aggregated"], is_org), axis=1
    )

    # TODO: implement regulatory site count
    # TODO: monetary fine, legal action, regulatory references classifications

    logger.debug("Calculating metrics for final score generation ..")

    # for each article, generate fuzzy scores for each sentence for location and employment
    df["location_fuzzy_score_list"] = df.apply(
        lambda row: [
            fuzz.partial_token_sort_ratio(location, sent)
            for sent in row["sentence_tokenized"]
        ],
        axis=1,
    )
    df["employment_fuzzy_score_list"] = df.apply(
        lambda row: [
            fuzz.partial_token_sort_ratio(employment, sent)
            for sent in row["sentence_tokenized"]
        ],
        axis=1,
    )

    # for each article; take the average of the name, location, and employment sentence scores to generate
    # the final scores for each category
    df["name_fuzzy_score_final"] = df.apply(
        lambda row: np.mean(row["name_fuzzy_score_list"]), axis=1
    )
    df["location_fuzzy_score_final"] = df.apply(
        lambda row: np.mean(row["location_fuzzy_score_list"]), axis=1
    )
    df["employment_fuzzy_score_final"] = df.apply(
        lambda row: np.mean(row["employment_fuzzy_score_list"]), axis=1
    )

    # normalize fine amount and document age relative to itself
    # df["fine_amt_norm"] = normalize_pandas_series(df["total_entity_fine_amt"])
    df["fine_amt_norm"] = df.apply(
        lambda row: max_marketshare(row["fine_tuples_aggregated"], mktshare_tuploc=4),
        axis=1,
    )
    df["fine_amt_norm"] = normalize_pandas_series(df["fine_amt_norm"], max=0.1, min=0)

    df["fine_total_sum"] = df["total_entity_fine_amt"].sum()
    df["age_norm"] = df["alt_age"] / (10 * 365)

    # apply asymptotic normalization to entity count
    df["entity_count_norm"] = asymptotic_normalization(
        df["entity_count"], asymptotic_offsets_dict["ASYMPTOTIC_OFFSET_ENTITY"]
    )

    # compute final score for each document
    df["final_score"] = final_score(
        model_weights_dict=model_weights_dict,
        term_similarity=df["max_desm_score"],
        entity_count=df["entity_count_norm"],
        sentiment=df["doc_sentiment"],
        fine_amt=df["fine_amt_norm"],
        age=df["age_norm"],
    )

    # sort dataframe by final score
    df.sort_values("final_score", ascending=False, inplace=True)

    # take the top n scores, mean, weight based on # of links, normalize_pandas_series; clean up this comment
    normalized_risk_score = df["final_score"].head(
        20
    ).mean() * asymptotic_normalization(
        len(df), asymptotic_offsets_dict["ASYMPTOTIC_OFFSET_URL_COUNT"]
    )
    normalized_risk_score = normalize_pandas_series(
        normalized_risk_score,
        risk_score_norms_dict["RISK_SCORE_NORM_MAX"],
        risk_score_norms_dict["RISK_SCORE_NORM_MIN"],
    )
    normalized_risk_score = min(1, normalized_risk_score)
    normalized_risk_score = max(0, normalized_risk_score)
    normalized_risk_score = normalized_risk_score * 100

    # bins for risk metrics
    # change value of age and to be opposite. May need to do with sentiment possibly.
    logger.debug("Calculating bins for final score features ..")
    # df["age_norm"] = 1 - df["age_norm"]

    for key, val in threshold_range_dict.items():
        df.loc[df[key].abs() < val["range"][0], key + "_bin"] = "Low"
        df.loc[
            (df[key].abs() >= val["range"][0]) & (df[key].abs() < val["range"][1]),
            key + "_bin",
        ] = "Med"
        df.loc[df[key].abs() >= val["range"][1], key + "_bin"] = "High"

    df.rename(index=str,
        columns={
            "max_desm_score_bin": "Similarity Rank",
            "fine_amt_norm_bin": "Fine Rank",
            "age_norm_bin": "Date Rank",
            "entity_count_norm_bin": "Entity Count Rank",
            "doc_sentiment_bin": "Sentiment Rank",
        },
        inplace=True,
        )
    

    if is_org == 0:
        entity_fname = entity_name_translated.split()[0]
        entity_lname = entity_name_translated.split()[-1]
    else:
        entity_fname = entity_name_translated
        entity_lname = ""

    # Document Classification
    docCat = [[0 for i in range(0, len(df))] for k in range(0, 1)] #initalize and use first list to represent "other negative news"
    percC = [0, 0, 0, 0]

    # Website Classification
    # df['regulatory_flag'] = False
    df["regulatory_flag"] = df.apply(lambda x: reg_site_classifier(x["url"]), axis=1)
    df['LegalAction']= df["sentence_tokenized_word_tokenized"].apply(lambda x: max([wordsims(wv,['legal', 'judicial', 'action','federal'],reduce(operator.concat,x),DocRiskFunc=Create_DocCat,CatRisk=2,threshold=.5)]))#np.random.randint(0, 1, df.shape[0])#load_and_score(Data = df,model_path=LA_modelpath,target='LegalAction') 
    df['MonetaryFine']=df["sentence_tokenized_word_tokenized"].apply(lambda x: max([wordsims(wv,['fine', 'penalty'],reduce(operator.concat,x),DocRiskFunc=Create_DocCat,CatRisk=3,threshold=.4)]))#np.random.randint(0, 1, df.shape[0])#load_and_score(Data = df,model_path=MF_modelpath,target='MonetaryFine')
    df['RegulatoryReference']=df["sentence_tokenized_word_tokenized"].apply(lambda x: max([wordsims(wv,['regulate', 'oversight','finra','sec','occ'],reduce(operator.concat,x),DocRiskFunc=Create_DocCat,CatRisk=2,threshold=.7)]))#np.random.randint(0, 1, df.shape[0])#load_and_score(Data = df,model_path=RegRef_modelpath,target='RegulatoryRefrence')
    df['MandA'] =df["sentence_tokenized_word_tokenized"].apply(lambda x: max([wordsims(wv,['merger', 'aquisition','aquire'],reduce(operator.concat,x),DocRiskFunc=Create_DocCat,CatRisk=3,threshold=.4)]))
    df['ChangeManagment'] =df["sentence_tokenized_word_tokenized"].apply(lambda x: max([wordsims(wv,['managment'],reduce(operator.concat,x),DocRiskFunc=Create_DocCat,CatRisk=7,threshold=.4)]))
    df['StatutoryDisqual'] =df["sentence_tokenized_word_tokenized"].apply(lambda x: max([wordsims(wv,['disqualify','statutory'],reduce(operator.concat,x),DocRiskFunc=Create_DocCat,CatRisk=9,threshold=.8)]))
    df['TradeSuspension'] =df["sentence_tokenized_word_tokenized"].apply(lambda x: max([wordsims(wv,['suspend','suspension'],reduce(operator.concat,x),DocRiskFunc=Create_DocCat,CatRisk=9,threshold=.7)]))
    df['Complaint'] =df["sentence_tokenized_word_tokenized"].apply(lambda x: max([wordsims(wv,['complaint','unsatisfied','unhappy'],reduce(operator.concat,x),DocRiskFunc=Create_DocCat,CatRisk=1,threshold=.4)]))
    df['finebin_equity'] =df['fine_bins'].apply(lambda x: 7 if x[0]=='equity' else 0) 
    df['finebin_fineThresh'] =df['fine_bins'].apply(lambda x: 3 if x[0]=='fine threshold' else 0) 
    
    #zjc NEW 2/11
    #create tuples of max row values and associated description and append abck to df
    max_colnames = df[['finebin_fineThresh','finebin_equity','Complaint','MandA','MonetaryFine','RegulatoryReference','TradeSuspension','StatutoryDisqual','ChangeManagment','LegalAction']].idxmax(axis=1)
    max_values = df[['finebin_fineThresh','finebin_equity','Complaint','MandA','MonetaryFine','RegulatoryReference','TradeSuspension','StatutoryDisqual','ChangeManagment','LegalAction']].max(axis=1)  
    df['risk_ranking_final_score'] = [[(x,y)] for x,y in zip(max_colnames,max_values)]

    #assign 3 actions to list and divivde values in list by 2 becuase they are summed not counted in pdf_summary 
    legal_action = list(df['LegalAction']/2)
    monetary_fine = list(df['MonetaryFine']/3)
    regulatory_reference = list(df['RegulatoryReference']/2)
    
    docCat.insert(1,legal_action)
    docCat.insert(2,monetary_fine)
    docCat.insert(3,regulatory_reference)
    
    #zjc
    df2concat = pd.DataFrame(docCat).transpose()
    df2concat.columns = ["DocCat_OtherNegNews","DocCat_LegalAction","DocCat_MonetaryFine","DocCat_RegulatoryReference"]
    df = pd.concat(df,df2concat,axis=1)

    for idx,ll in enumerate(docCat):
        percC[idx] = sum(ll)/len(ll)
    print('percC', percC)
    print('doccat',docCat)

    #constants to add to df (used in genearte_output_args)
    df['NumStartUrls']= len(scraped_data)
    df['normalized_risk_score']=normalized_risk_score
    df['percC'] = ' '.join(percC)
    df['all_search_terms'] = ' '.join([term.title() for term in search_terms])
    df['model_weights_dict']=str(model_weights_dict)

    #  # Final Model Predictions on entire dataset
    # df['LegalAction'] = load_and_score(
    #     model_path=model_path,
    #     data2score=df,
    #     concat_2df=False,
    #     stemmer=stemmer,
    #     stopwords=stopwords
    # )
    # legal_action = list(df['LegalAction'])
    # docCat.insert(0, legal_action)
    # for idx, ll in enumerate(docCat):
    #     percC[idx] = sum(ll) / len(ll)

    # save 'df' to disk; for testing purposes only; delete this on push to production
    logger.debug("Saving postprocess dataframe to pickle ..")
    try:
        df.to_pickle(output_path + "postprocess_df.pk")
        logger.debug(
            f"Postprocess dataframe save complete: {output_path}postprocess_df.pk"
        )
    except Exception as e:
        logger.debug(f"Exception occurred while saving postprocess dataframe: {str(e)}")

    # push 'df' rows to 'processed_results' MongoDB collection for use in output_args
    #binned_df cols:"Similarity Rank","Fine Rank","Date Rank","Entity Count Rank","Sentiment Rank",
    try:
        feed_handle = get_processed_results_handle()
        df[[
            "entity",
            "url",
            "NumStartUrls",
            "normalized_risk_score",
            "name_fuzzy_score_final",
            "location_fuzzy_score_final",
            "location_fuzzy_score_final",
            "employment_fuzzy_score_final",
            "desm_sentences",
            "summary",
            "regulatory_flag",

            "DocCat_OtherNegNews",
            "DocCat_LegalAction",
            "DocCat_MonetaryFine",
            "DocCat_RegulatoryReference",

            "percC",
            "source",
            "date",
            "title",
            "desm_term",
            "all_search_terms",
            "fine_report_strings",
            "model_weights_dict",
            "Similarity Rank",
            "Fine Rank",
            "Date Rank",
            "Entity Count Rank",
            "Sentiment Rank",
            "final_score",
            "risk_ranking_final_score",
            
        ]]

        
        feed_handle.insert_many(df.to_dict("records"))
        logger.debug(f"Postprocess data push completed successfully ..")
    except Exception as e:
        logger.debug(f"Exception occurred while pushing postprocess data: {str(e)}")


    output_args = {
        "output_path": output_path,
        "url_list": list(df["url"]),
        "NumStartUrls": len(scraped_data),
        "max_links_for_score": len(df),
        "entity_name": entity_name,
        "entity_name_translated": entity_name_translated,
        "entity_fname": entity_fname,
        "entity_lname": entity_lname,
        "normalized_risk_score": normalized_risk_score,
        "name_fuzzy_score": np.mean(df["name_fuzzy_score_final"]),
        "location_fuzzy_score": 0,
        "employment_fuzzy_score": 0,
        "w2vtopsent": list(df["desm_sentences"]),
        "summary": list(df["summary"]),
        "regnoreg": list(df["regulatory_flag"]),
        "docCat": docCat,
        "percC": percC,
        "newssource": list(df["source"]),
        "datelist": list(df["date"]),
        "docTitles": list(df["title"]),
        "entity_querylist": list(df["source"].unique()),
        "top_search_terms": [term.title() for term in df["desm_term"]],
        "all_search_terms": [term.title() for term in search_terms],
        "fine_reports_list": [
            list(fine_report) for fine_report in df["fine_report_strings"]
        ],
        "model_weights": model_weights_dict,
        "binned_values": df[["Similarity Rank","Fine Rank","Date Rank","Entity Count Rank","Sentiment Rank",]],
        "unnormalized_doc_scores": list(df["final_score"]),
        "total_fine_amt": df["fine_total_sum"].max(),
        "risk_rankings": list(df['risk_ranking_final_score']),
    }

    # push 'df' rows to 'processed_results' MongoDB collection
    #try:
    #    feed_handle = get_processed_results_handle()
    #    df.drop(
    #        ["tagged_top_sentences", "tagged_summary", "tagged_title"],
    #        axis=1,
    #        inplace=True,
    #    )
    #    feed_handle.insert_many(df.to_dict("records"))
    #    logger.debug(f"Postprocess data push completed successfully ..")
    #except Exception as e:
    #    logger.debug(f"Exception occurred while pushing postprocess data: {str(e)}")

    return output_args
