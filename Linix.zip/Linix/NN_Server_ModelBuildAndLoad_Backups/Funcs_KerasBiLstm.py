## -*- coding: utf-8 -*-
"""
Created on Fri Jan 25 11:07:37 2019
nn_bilstmutils.py

Functions specific for bilstm with attenion
@author: caridza
"""


#####MODEL DATA PREPROCESSING FUNCTION 
#####MODEL DATA PREPROCESSING FUNCTION 
import os 
import sys
import pandas as pd 
import pymagnitude
import re
import string 
from sklearn import preprocessing , model_selection, metrics
import numpy as np
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk import regexp_tokenize
from nltk.tokenize import word_tokenize , sent_tokenize


#MUST IMPORT ALL FROM EITHER KERAS or Tensorflow.python.keras. YOU CANNOT MIX
import keras 
from keras.preprocessing.text import Tokenizer 
from keras.preprocessing.sequence import pad_sequences 
from keras.preprocessing.text import Tokenizer 
from keras.preprocessing.sequence import pad_sequences 
from keras.callbacks import ModelCheckpoint, EarlyStopping
from keras_self_attention import SeqSelfAttention 
import keras_self_attention
import gensim
from imblearn.over_sampling import SMOTE  # or: import RandomOverSampler
from imblearn.pipeline import Pipeline as imbPipeline
from sklearn.model_selection import StratifiedShuffleSplit
from keras.models import model_from_json 
from keras.models import load_model
from negative_news2.consumer.utils import DocDF2SentDF
import pymagnitude 

stemmer = SnowballStemmer('english')
stopwords = stopwords.words("english")
newStopWords = ['.','?','%','Google','Wells Fargo','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December']
stopwords.extend(newStopWords)
stop_list=set(stopwords)

#preprocess sequences of text into sequencees of paddd numbers to be used in sequence modeling  
def make_df(datapath , max_features,EMBEDDING_DIM,stop_list,stemmer,target='',trainmaxlen = 0,test_size=.3):
    '''
    Inputs: 
    ##### datapath = path to dataframe of sentences and label ids 
    ##### max_features = total number of features from text to consider when buildling embedding layer
    ##### EMBEDDING_DIM = total number of dimensions from embedding we want to use in embedding layer (Note: if using pymag you must use 300)
    ##### stop_lsit = list of stopwords to use for preprocessing 
    ##### stemmer = stemming class to use to stem words in sentences 
    ##### target = name of the target feild you are trying to predict in the dataset 
    PROCESS STEPS: 
    ##### 1. toeknize text
    ##### 2. Convert text to sequences
    ##### 3. Pad Sequences 
    ##### 4. Split into Test and Train
    ##### 5. Return X_train , X_Test, Y, WordIndex 
    '''
    
    #load data
    if isinstance(datapath,object): 
        data = datapath 
    else:
        data = pd.read_pickle(datapath)
    
    #clean original sentence level text
    trainDF = orig_text_clean(data,target=target , txtfeild='Sentence',stopwords=stop_list,stemmer=stemmer) 
    
    #specify X (standard columns are created in orig_text_clean)
    X = trainDF['Sentence']

    #generate list of unique words based on total words specified to consider
    sentences = []
    lines = X.values.tolist()
    lines = [word_tokenize(sent) for sent in lines]
    model=gensim.models.Word2Vec(sentences=lines, size=EMBEDDING_DIM,window=5,workers=4,min_count=1)
    words = list(model.wv.vocab)
    
    #model process 
    #fit tokenizer to words and turn to sequences 
    tokenizer_obj = Tokenizer()
    tokenizer_obj.fit_on_texts(X)
    sequences = tokenizer_obj.texts_to_sequences(X)
    
    #define max length for padding and total vocab size
    #NOTE: the length of the sequences being scored must be the same as the sequences the model was trained on
    #if no target is specified then we are scoring new data and require the max length of sereies the data was trained on
    if target=='':
        max_length = trainmaxlen#max([len(s.split()) for s in X]) 
    else: 
        max_length =max([len(s.split()) for s in X]) 
        
    #total vocab size
    vocab_size = len(tokenizer_obj.word_index)+1
    
    #pad sequences 
    word_index = tokenizer_obj.word_index
    review_pad = pad_sequences(sequences,maxlen=max_length)
    
    if target !='':
        Y = trainDF['label_id']
        label = Y.values
   
        #split data 
        x_train,x_test,y_train,y_test = model_selection.train_test_split(review_pad, label,shuffle=True, stratify=Y,test_size=test_size, random_state=10)
        sm = SMOTE(random_state=2)
        x_train, y_train = sm.fit_sample(x_train, y_train)

        return x_train, y_train, x_test, y_test, word_index, max_length , words
    else: 
        X_Out = review_pad
        return X_Out, word_index, max_length , words



#pymagnitude vectors 
def make_embeddings_pymag(wv, max_features,words, word_index, embed_size, nb_words):
    #embeddings using pymagnitude 
    embeddings_index = {}
    for w in words:
        word =w
        coefs = wv.query(word) #np.asarray(values[1:])
        embeddings_index[word]=coefs

    embedding_matrix = np.zeros((nb_words, embed_size))
    for word, i in word_index.items():
        if i >= max_features:
            continue
        embedding_vector = embeddings_index.get(word)
        if embedding_vector is not None:
            embedding_matrix[i] = embedding_vector
    return embedding_matrix

#FUNCTION TO CLEAN ORIGINAL TEXT FOR MODEL INPUT
def orig_text_clean(data,target='LegalAction',txtfeild='origtext',maplabelvars=['source']
                    ,stopwords=['the','is','a','i','are','it'],stemmer=None):
    trainDF = pd.DataFrame()
    trainDF['text'] = data[txtfeild].apply(lambda x: remove_punctuation(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_nonchars(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_stop(x,stopwords=stopwords))
    trainDF[txtfeild] = trainDF['text'].apply(lambda x: stem_words(x,stemmer=stemmer))
    
    if target!='':
        trainDF['label'] = data[target]
        le = preprocessing.LabelEncoder() 
        le.fit(trainDF['label'])
        trainDF['label_id'] =le.transform(trainDF['label'])
            
    trainDF=trainDF.reset_index(drop=True)
    return trainDF 

#preprocess data 
#func to remove punc from string and return string
def remove_punctuation(text,excluded_punct={'+', ':', '[', '^', '"', '|', '{', '@', '=', ')', '%', '#', '`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}):
    return ' '.join([word for word in nltk.word_tokenize(text) if word not in excluded_punct])

#func to remove stop words 
def remove_stop(text,stopwords=['the','is','a','i','are','it']):
    return ' '.join([word for word in text.split(' ') if word.lower() not in stopwords])

#func to stem words 
def stem_words(text,stemmer=None):
    return ' '.join([stemmer.stem(word) for word in text.split(' ')])

#remove non alpha characters from text 
def remove_nonchars(text):
    return ' '.join([re.sub('[^A-Za-z|^\$|^\.]+', ' ', word) for word in text.split(' ') if (word.isalnum() and len(word)>2)])

#upsample rare event for model training
def upsample_rare(data, Rare_ColStr):
    '''
    Input: {'data':'dataframe with rare event','Rare_ColStr':'name of the column containing the rare target event we want to oversample'
    Output: Dataframe of equal proportions of target event to be used only in training (MUST SPLIT TEST DATA SET BEFORE RUNNING THIS)

    '''
    negobs = data[data[Rare_ColStr]==False]
    posobs = data[data[Rare_ColStr]==True]

    #create a list of dataframes, where each data frame contains a replica of all postive observations which we can use for oversampling 
    rep_1 =[posobs for x in range(negobs.shape[0]//posobs.shape[0] )]
    keep_1s = pd.concat(rep_1, axis=0)
    train_dat = pd.concat([keep_1s,negobs],axis=0)
    return(train_dat)   



def bilstm_load_and_score(Data=None,model_path=None,stop_words=stop_list,stemmer=stemmer,target='',trainmaxlen=None ,max_features=10000,EMBEDDING_DIM=300,wv_path='//home//nlpsomnath//NegNews//rebase//NN_Kafka//sourcefiles//GoogleNews-vectors-negative300.magnitude'):

    wv=pymagnitude.Magnitude(wv_path)

    data = Data.copy()
    #INPUTS
    #data = dataframe of source data with one col reprsenting sent tokenized text 
    #model_path = path to model that is going to ggenerate predictions 
    #stop_words = set of stopwords to be removed from each sentence 
    #stemmer = stemmer class to be utilized for stemming vocabulary 
    
    #get doc_index as col to join results back to
    data.reset_index(inplace=True)
    data.rename(columns={'index': 'DocIndex'}, inplace=True)
    
    #create sent level df 
    list(data)
    SentDF = DocDF2SentDF(data,cols = ['DocIndex','date','entity','url','source','title','jobname','sentence_tokenized'])

    #create sequences from text 
    X,word_index, maxlen,words= make_df(SentDF, max_features,EMBEDDING_DIM,stop_list,stemmer,trainmaxlen=trainmaxlen,target='')

    #generate embedding vector using pymagnitude 
    nb_words = min(max_features, len(word_index)+1) #total features to consider, min of the max feats vs total feats 
    embedding_vector =  make_embeddings_pymag(wv, max_features,words, word_index, EMBEDDING_DIM, nb_words)
  
    #load model to use in scoring 
    model = load_model(model_path,custom_objects={'SeqSelfAttention':keras_self_attention.SeqSelfAttention})

    
    #load pickled model for evaluation on unseen data 
    predictions =  model.predict_classes(X)

    preds = pd.DataFrame(data=predictions, columns = ['Pred_'+target])
    
    #create df of preds to join back to original doc level data
    results = pd.concat([SentDF, preds], axis=1)
    col = results.filter(like='Pred_').columns.values
    results2 = results .groupby(['DocIndex'])[col].sum()
    results2.reset_index(inplace=True)
    
    #merge preds to original df by doc index 
    finaldf = pd.merge(data[['DocIndex']], results2, on='DocIndex', how='left')
    finaldf['Pred_'+target] = finaldf['Pred_'+target].apply(lambda x: 1 if x> 0 else x)
    return(finaldf['Pred_'+target].values)
