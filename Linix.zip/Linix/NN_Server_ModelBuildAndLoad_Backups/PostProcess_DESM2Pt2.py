#output dependent on : search_terms_desm
max_desm_score 
desm_sentences 
desm_term
desm_score_dict 

#unused variables to remove 
term_tupes 


#542-554 : Similarity Calculation 
    # calculate term similarity
    logger.debug("Calculating DESM scores .. ")
    tock = time.perf_counter()
    df["max_desm_score"], df["desm_sentences"], df["desm_term"], df["desm_score_dict"] = zip(
        *df.apply(lambda x: desm_pandas_wrapper(wv, search_terms_desm, x), axis=1)
    )
    tick = time.perf_counter()
    df.sort_values("max_desm_score", ascending=False, inplace=True)
    logger.debug(f"DESM score calculation complete. Took {round(tick - tock, 2)}s ..")

    # AG EDIT 1/16/19 - ADD ALL Q terms
    df["term_tupes"] = df.apply(lambda x: dict_to_tupes_wrapper(x["desm_score_dict"]), axis=1)
    # END AG EDITS 1/16/19
	
#620-707: Sentiment and Fine Extraction 
	# make SentimentIntensityAnalyzer object for the purpose
    # of generating VADER sentiment scores
    analyzer = SentimentIntensityAnalyzer()

    # this constant represents the top N most negative sentences
    # whose sentiment scores will be averaged to calculate
    # the overall article sentiment
    TAKE_N_MOST_NEGATIVE_SENTENCES = 3

    # calculate a sentiment score for each sentence in each document
    sentence_sentiment_list = []
    doc_sentiment_list = []
    for doc_idx, doc in enumerate(df["sentence_tokenized_english"]):
        sentence_sentiment_list.append([])
        for i_idx, item in enumerate(doc):
            try:
                sentence_sentiment_list[doc_idx].append(analyzer.polarity_scores(item)["compound"])
            except Exception:
                logger.debug("Sentiment calculation failed at doc index {}. Sentence is: {}".format(doc_idx, item))
                sentence_sentiment_list[doc_idx].append(0)
        doc_sentiment_list.append(np.mean(sorted(sentence_sentiment_list[doc_idx])[:TAKE_N_MOST_NEGATIVE_SENTENCES]))

    # assign sentiment
    # TODO: we may be able to remove this sentence_sentiment column (not used anywhere)
    df["sentence_sentiment"] = sentence_sentiment_list
    df["doc_sentiment"] = doc_sentiment_list

    logger.debug("Beginning fine extraction via spaCy ..")
    tock = time.perf_counter()

    # adjust this constant to the name of the column containing the top sentences
    TOP_SENTENCES_COL_NAME = "desm_sentences"

    # NER tag desired columns
    logger.debug("Beginning NER tagging via spaCy ..")
    _tock = time.perf_counter()
    df["tagged_top_sentences"] = df.apply(lambda x: list(map(lambda sent: nlp(sent), x[TOP_SENTENCES_COL_NAME])), axis=1)
    df["tagged_title"] = df.apply(lambda x: nlp(transform_article_title(x["title"]), " ".join(x[TOP_SENTENCES_COL_NAME])), axis=1)
    df["tagged_summary"] = df.apply(lambda x: nlp(x["summary"]), axis=1)
    _tick = time.perf_counter()
    logger.debug(f"Finished NER tagging via spaCy. Took {round(_tick - _tock, 2)}s ..")

    # generate fine tuples (e.g., (['ent1', 'ent2'], 1000000000.0, True) )
    df["fine_tuples_top_sentences"] = df.apply(
        lambda x: [
            get_data_from_article_title(entity_dict, tagged_text=sent, entity_name=entity_name, use_stemmer=False)
            for sent in x["tagged_top_sentences"]
        ],
        axis=1,
    )

    df["fine_tuples_title"] = df.apply(
        lambda x: get_data_from_article_title(entity_dict, tagged_text=x["tagged_title"], entity_name=entity_name, use_stemmer=False),
        axis=1,
    )

    df["fine_tuples_summary"] = df.apply(
        lambda x: get_data_from_article_title(
            entity_dict, tagged_text=x["tagged_summary"], entity_name=entity_name, use_stemmer=False
        ),
        axis=1,
    )

    # aggregate fine tuples into one list for each row
    df["fine_tuples_aggregated"] = df.apply(
        lambda row: aggregate_into_single_list(row, ["fine_tuples_top_sentences", "fine_tuples_title", "fine_tuples_summary"]), axis=1
    )

    # sum total fine amount from fine tuples
    FINE_AMOUNT_IDX = 1
    FINE_GENERATE_FLAG_IDX = 2
    df["total_entity_fine_amt"] = df.apply(
        lambda x: sum(set([t[FINE_AMOUNT_IDX] if t[FINE_GENERATE_FLAG_IDX] else 0 for t in x["fine_tuples_aggregated"]])), axis=1
    )

    # generate fine report strings
    df["fine_report_strings"] = df.apply(
        lambda row: list(
            set([fr for ft in row["fine_tuples_aggregated"] for fr in generate_report_string(fine_tuple=ft, entity_dict=entity_dict)])
        ),
        axis=1,
    )
    tick = time.perf_counter()

    logger.debug(f"Fine extraction complete. Took {round(tick - tock,2)}s ..")

    df["fine_bins"] = df.apply(lambda row: get_highest_fine_bin(row["fine_tuples_aggregated"], is_org), axis=1)
