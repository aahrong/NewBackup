# -*- coding: utf-8 -*-
"""
Created on Wed Jan 16 09:01:40 2019
NN_MODELUTILs.py 
Model build and scoring functions for sklearn mlp models 
@author: caridza
"""
import sys
import pickle
import joblib
import pandas as pd
from sklearn import preprocessing
import nltk
from nltk.corpus import stopwords
import re 
from sklearn.pipeline import Pipeline,make_pipeline
from nltk.corpus import stopwords
import string
from nltk.stem.snowball import SnowballStemmer
from sklearn.base import BaseEstimator, TransformerMixin

stemmer = SnowballStemmer('english')
stopwords = stopwords.words("english")
newStopWords = ['.','?','%','Google','Wells Fargo','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December']
stopwords.extend(newStopWords)
stop_list=set(stopwords)


#################################################################
###############FUNCTIONS THAT MUST BE USED WHEN RUN##############
#################################################################
#load model and score new data through the pipeline defined in the finalmodel 
def load_and_score(Data=None,model_path=None,stop_words=stop_list,stemmer=stemmer,target=''):


    data = Data.copy()
    #INPUTS
    #data = dataframe of source data with one col reprsenting sent tokenized text 
    #model_path = path to model that is going to ggenerate predictions 
    #stop_words = set of stopwords to be removed from each sentence 
    #stemmer = stemmer class to be utilized for stemming vocabulary 
    
    #get doc_index as col to join results back to
    data.reset_index(inplace=True)
    data.rename(columns={'index': 'DocIndex'}, inplace=True)
    
    #create sent level df 
    list(data)
    SentDF = DocDF2SentDF(data,cols = ['DocIndex','date','entity','url','source','title','jobname','sentence_tokenized'])
    
    #clean data 
    newdata = orig_text_clean(SentDF,target='',txtfeild='Sentence',maplabelvars=['source'],stopwords=stop_words,stemmer=stemmer)
    
    #load pickled model for evaluation on unseen data 
    loaded_model = joblib.load(model_path)
    predictions =  loaded_model.predict(newdata) #loaded_model.predict_proba(newdata)
    preds = pd.DataFrame(data=predictions, columns = ['Pred_'+target])
    
    #create df of preds to join back to original doc level data
    results = pd.concat([newdata, preds], axis=1)
    col = results.filter(like='Pred_').columns.values
    results2 = results .groupby(['DocIndex'])[col].sum()
    results2.reset_index(inplace=True)
    
    #merge preds to original df by doc index 
    finaldf = pd.merge(data[['DocIndex']], results2, on='DocIndex', how='left')
    finaldf['Pred_'+target] = finaldf['Pred_'+target].apply(lambda x: 1 if x> 0 else x)
    return(finaldf['Pred_'+target].values)


#convert raw doc level data into sentence level data frame 
def DocDF2SentDF(DocDF,cols = ['DocIndex','date','entity','url','source','title','jobname','sentence_tokenized']):
    #subset feilds from source data 
    data = DocDF[cols]
    data.reset_index(inplace=True,drop=True)
    #data.rename(columns={'index': 'DocIndex'}, inplace=True)
    
    #convert dataframe to sent level 
    rows = []
    _ = data.apply(lambda row: [rows.append([row['DocIndex'],row['date'],row['entity'],row['source'],row['title'],row['url'],row['jobname'],sent])
                             for sent in row.sentence_tokenized],axis=1)
    
    SentDF = pd.DataFrame(rows,columns = data.columns)
    SentDF.reset_index(inplace=True)
    SentDF.rename(columns={'index': 'SentIndex'}, inplace=True)
    SentDF.rename(columns={'sentence_tokenized': 'Sentence'}, inplace=True)
    #NOTE: predictions made at the SentIndex level will be rolled up to DocIndex level 

    return SentDF



#preprocess data 
#func to remove punc from string and return string
def remove_punctuation(text,excluded_punct={'+', ':', '[', '^', '"', '|', '{', '@', '=', ')', '%', '#', '`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}):
    return ' '.join([word for word in nltk.word_tokenize(text) if word not in excluded_punct])

#func to remove stop words 
def remove_stop(text,stopwords=['the','is','a','i','are','it']):
    return ' '.join([word for word in text.split(' ') if word.lower() not in stopwords])

#func to stem words 
def stem_words(text,stemmer=None):
    return ' '.join([stemmer.stem(word) for word in text.split(' ')])

#remove non alpha characters from text 
def remove_nonchars(text):
    return ' '.join([re.sub('[^A-Za-z|^\$|^\.]+', ' ', word) for word in text.split(' ') if (word.isalnum() and len(word)>2)])

#clean original text to be used in generation of tfidf and other text transformation objects
def orig_text_clean(data,target='',txtfeild='origtext',maplabelvars=['source'],stopwords=['the','is','a','i','are','it'],stemmer=None):
    trainDF = data
    
    #clean text 
    trainDF['text'] = data[txtfeild].apply(lambda x: remove_punctuation(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_nonchars(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_stop(x,stopwords=stopwords))
    trainDF['text'] = trainDF['text'].apply(lambda x: stem_words(x,stemmer=stemmer))
    trainDF['Sentence'] = trainDF['text'].apply(lambda x: x.strip())
    trainDF.drop(columns = ['text'],inplace=True)
    
    #document numeric informaiton 
    trainDF['txt_lngth'] = trainDF['Sentence'].apply(lambda x: len(x))
    trainDF['txt_words'] = trainDF['Sentence'].apply(lambda x: len(x.split(' ')))
    trainDF['txt_nonstopwords'] = trainDF['Sentence'].apply(lambda x: len([t for t in x.split(' ') if t not in stopwords]))
    trainDF['total_commas'] = data['Sentence'].apply(lambda x: x.count(','))

    #if no target is defined then we are scoring and do not need to create target
    if target !='':
        trainDF['label'] = data[target]
        le = preprocessing.LabelEncoder() 
        le.fit(trainDF['label'])
        trainDF['label_id'] =le.transform(trainDF['label'])
        trainDF.drop(columns = ['label'],inplace=True)
    
    #for each variable that is categoric, tranform to numeric id for model
    if maplabelvars != []:
        for var in maplabelvars: 
            le = preprocessing.LabelEncoder() 
            le.fit(trainDF[var])
            trainDF[var+'_id'] =le.transform(trainDF[var])
            trainDF.drop(columns = [var],inplace=True)
        
    trainDF=trainDF.reset_index(drop=True)
    return trainDF 

#transformer to select a column from dataframe to be used for processing 
class TextSelector(BaseEstimator, TransformerMixin):
    """
    Transformer to select a single column from the data frame to perform additional transformations on
    Use on text columns in the data
    """
    def __init__(self, key):
        self.key = key

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return X[self.key]
    
class NumberSelector(BaseEstimator, TransformerMixin):
    """
    Transformer to select a single column from the data frame to perform additional transformations on
    Use on numeric columns in the data
    """
    def __init__(self, key):
        self.key = key

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return X[[self.key]]
