#ELMO DOCKER RUN AND FUNCTIONALITY 


#create setences to test elmo with (create in directory outside of docker, then link directory to docker) 
echo "The cryptocurrency space is now figuring out to have the highest search on Google globally ." > sentences.txt
echo "Bitcoin alone has a sixty percent share of global search ." >> sentences.txt

#Run Docker Image 
#-p tells docker to bind port 8000 of the container to TCP port 8001 on the local host 
#-v tells docker to mount the drive specified to the container so the local files can be seen/used directly in the container
#-w specifies the name of the working directory in the container 
#-d tells docker to run in background so we can navigate host directory still 
#docker run -it -p 8001:8000 --rm allennlp/allennlp:v0.5.0
#docker run -dti -v /home/docadmin/ZackC/ELMO:/Inputs --name nn_bot_run --net=host nn_bot
#docker run -d -v /home/docadmin/ZackC/ELMO:/stage/allennlp/Inputs -p 8006:8000 -it --rm allennlp/allennlp:v0.5.0
docker run -v /home/docadmin/ZackC/ELMO:/stage/allennlp/Inputs -p 8006:8000 -it --rm allennlp/allennlp:v0.5.0
#ELMO Input: whitespace seperated text , one sentence per line 

#run the allennlp module 
#--average: output the average of the elmo vectors 
python -m allennlp.run elmo sentences.txt elmo_layers.hdf5 --all
python -m allennlp.run elmo ./Inputs/sentences.txt ./Inputs/elmo_layers.hdf5 --all
python -m allennlp.run elmo ./Inputs/sentences.txt ./Inputs/elmo_layers.hdf5 --average
python -m allennlp.run  

#move python test script to folder we want to run python from 
cp ./Inputs/Elmo_test_run.py "/stage/allennlp/"


#interacting with hdf5 files 
#open file containing avergae word embedding 
import h5py
f = h5py.File('/hoome/docadmin/zackC/ELMO/elmo_layers.hdf5','r')
a_group_key = list(f.keys()))[0]
b_group_key = list(f.keys()))[1]

# Get the data
data = list(f[a_group_key])
data = list(f[b_group_key])


