#ELMO PYTHON USAGE 
#NOTE: MUST RUN WITHIN DOCKER 
#https://towardsdatascience.com/elmo-embeddings-in-keras-with-tensorflow-hub-7eb6f0145440
#ELMO ALTNERATIVE: https://github.com/allenai/document-qa
from allennlp.modules.elmo import Elmo, batch_to_ids
import nltk


options_file = "https://s3-us-west-2.amazonaws.com/allennlp/models/elmo/2x4096_512_2048cnn_2xhighway/elmo_2x4096_512_2048cnn_2xhighway_options.json"
weight_file = "https://s3-us-west-2.amazonaws.com/allennlp/models/elmo/2x4096_512_2048cnn_2xhighway/elmo_2x4096_512_2048cnn_2xhighway_weights.hdf5"

#set up elmo weights and options based on above? 
elmo = Elmo(options_file, weight_file, 2, dropout=0)

# use batch_to_ids to convert sentences to character ids
f = open('./Inputs/sentences.txt', 'r')
test = f.read().split('\n')
print(test) 

sentences = [[nltk.word_tokenize(y)for y in x] for x in test]
#sentences = [nltk.word_tokenize(x) for x in test]
print(sentences)
#sentences = [['First', 'sentence', '.'], ['Another', '.']]
character_ids = batch_to_ids(sentences)
#embeddings = elmo(character_ids)
embeddings =allennlp.commands.elmo.ElmoEmbedder
listlen = [len(x) for x in embeddings]

print(embeddings)