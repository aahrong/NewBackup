#####################################
####FDIC NAVIATION THROUGH XPATHS####
#####################################
#https://doc.scrapy.org/en/xpath-tutorial/topics/xpath-tutorial.html
#scrapy shell steps 
#launch shell:scrapy shell 'https://scrapy.org' --nolog
#fetch("https://search.fdic.gov/search?q=Goldman+Sachs&btnG=Search&output=xml_no_dtd&oe=ISO-8859-1&ie=ISO-8859-1&client=press&proxystylesheet=wwwGOV&sort=date%3AD%3AL%3Ad1&wc=200&: wc_mc=1&ud=1&exclude_apps=1&site=press")
#https://search.fdic.gov/search?q=Goldman+Sachs&btnG=Search&output=xml_no_dtd&oe=ISO-8859-1&ie=ISO-8859-1&client=press&proxystylesheet=wwwGOV&sort=date%3AD%3AL%3Ad1&wc=200&:wc_mc=1&ud=1&exclude_apps=1&site=press
#NOTE:When you need to use the text content as argument to an XPath string function, avoid using .//text() and use just . instead.

#create scraper for https://www.federalreserve.gov/feeds/press_all.xml
#relative vs absolute(always use relative) 
#absolute: /a/href
#relative: a/href

#xpath wildcards
	# Match any attribute node:@*
	# Select all elements in doc: //*
	# Select all title elements with at least one attribute: //title[@*]

/html/body/div/div[3]/div/p/a	
//a[@ctype='c']//span[@class='goog-trans-section l']
	
#select href from all a elments in document 
response.xpath('//a/@href').extract()
response.xpath('./a').extract()

#relative vs absolute. absolute will produce the same result for eafch iteration , returning ALL paragraphs in the doc everytime 
#relative will only look at childen 'p' under each div and only one of those div will show haveing paragraphs as shown below
for div in response.xpath('//body//div'):
	print(div.xpath('p'))
for div in response.xpath('//body//div'):
	print(div.xpath('p'))
	
#self (understanding where you are) 
#self abreviated: '.'
first_div = response.xpath('//div')[0]
first_div.xpath('self::*')
first_div.xpath('.')
first_div.xpath('./././') #go down (child)
first_div.xpath('../../../') #go up(parent)

#recurisvilly go up or down the tree 
first_div.xpath('descendant::*') #recurisvilly down
first_div.xpath('ancestor::*') #recursivly up
first_div.xpath('./descendant-or-self::node()/text()')
#select and parse document element as string
response.xpath('string(string(//a/@href))').extract()

#count total number of a specific element 
response.xpath('count(//div[starts-with(@class, "main-results")]//a[contains(@href, "/search?q")]//@href)').extract()
response.xpath('count(//@*)').extract()

#booleen expressions with xpaths(returns 1 if true) 
response.xpath('count(//@*) = 755').extract()

#select all the hrefs pointing the to the URLs with the text versions of the documents being summarized 
response.xpath('//a[starts-with(@href, "/search?")]').extract()
response.xpath('//a[contains(@href, "/search?")]').extract()

#extract text tied to id with name starting snippet-1
#note: use //text() to extract all children text elements (both normal and bold text) 
response.xpath('//span[starts-with(@id, "snippet_1")]//text()').extract()

#extract text tied to any id that starts with "snippet" - all summaries 
response.xpath('//span[starts-with(@id, "snippet")]//text()').extract()

#extracts all text summarizing each article that was returned 
response.xpath('//span[starts-with(@class, "goog")]//text()').extract()

#extract all URLs in main body 
response.xpath('//a[contains(@href, "/search?")]').extract()

#SET OPERATIONS with selctors 
#Note: if you dont specify the type of selctor it is automatically  determined based on the resposne object
#Here we first iterate over class elements, and for each one, we look for all id elements and exclude those that are themselves inside another class.
from scrapy import Selector
sel = Selector(text=response.text, type="html")
for scope in sel.xpath('//div[@class]'):
	print("current scope:", scope.xpath('@id').extract())
	props = scope.xpath('''set:difference(./descendant::*/@id,.//*[@class]/*/@id)''')
	print("    properties:", props.extract())

#using css path and xpath together (use css path when querying by class) 
sel = Selector(text='<div class="hero shout"><time datetime="2014-07-23 19:00">Special date</time></div>')
sel.css('.shout').xpath('./time/@datetime').extract()

#select all URLs in main body containing /search? :
# search?q: in href indicates link to document 
# search?as_sitesearch : in href indicates link to go to additional news associated with the entity, this can be used to get more results for entity within fdic 

# Enforcement Actions: get url -> assign to start_urls in spider -> scrape target URL 
# News: get Associated News Link-> assign to start_urls in spider -> Get all URLs from target -> Scrape all target URLS
##the sequential script for extracting information 

#extract links from current page 
DocumentLinks_v2 = response.xpath('.//div//a[@ctype="c"]')
for article in DocumentLinks_v2:
	Link = article.xpath('.//@href').extract_first()
	print(Link)

#extract dates associated with each article from current page
DocumentDates = response.xpath(".//div//font[3]")
for date in DocumentDates: 
	Date = date.xpath(".//text()").extract_first()
	print(Date)
	



	
#looping through all pages and getting all links 
#https://blog.michaelyin.info/scrapy-tutorial-10-how-build-real-spider/
next_page_url = response.xpath("string(.//span[@class='s']//a[@ctype='nav.next']//@href)").extract_first()
if next_page_url:
	absolute_next_page_url = response.urljoin(next_page_url)
	print(absolute_next_page_url)
	#yield scrapy.Request(absolute_next_page_url)
	
	
	

	
######################################
###########MISC#######################
###########FDIC#######################

ArticleTitles = response.xpath('.//span[starts-with(@class, "goog-trans-section ") and starts-with(@transid, "gadget") ]/text()')
ArticleSummary= response.xpath('.//span[starts-with(@id, "snippet") ]//text()')
DocumentLinks = response.xpath('.//div[starts-with(@class, "main-results")]//a[contains(@href, "/search?q")]//@href')
AssocNewsLink = response.xpath('.//div[starts-with(@class, "main-results")]//a[contains(@href, "/search?as_sitesearch")]//@href')

	
#looping through each results-items 
#https://stackoverflow.com/questions/39249954/scrapy-looping-through-search-results-only-returns-first-item
DocumentLinks =response.xpath('.//div[starts-with(@class, "main-results")]//a[contains(@href, "/search?q")]//@href').extract()
for article in DocumentLinks:
	print(article)

	
#looping through each results-items 
DocumentLinks = response.xpath('.//div[starts-with(@class, "main-results")]')
for article in DocumentLinks:
	Links = article.xpath('//a[contains(@href, "/search?q")]').extract_first()
	NewsLinks =  article.xpath('//a[contains(@href, "/search?as_sitesearch")]/@href').extract_first()
	#Title = article.xpath(".//span[@class = 'goog-trans-section l' and starts-with(@transid, 'gadget') ]/text()").extract_first()
	#Summary = article.xpath(".//span[starts-with(@id, 'snippet') ]/text()").extract_first()
	print(Links)

	
ArticleTitles = response.xpath('.//span[starts-with(@class, "goog-trans-section ") and starts-with(@transid, "gadget") ]')
for article in ArticleTitles:
	title = article.xpath('.//text()').extract_first()
	print(title)

#works: beware of /text() vs .//text()
ArticleSummary= response.xpath('.//span[starts-with(@id, "snippet") ]')
for article in ArticleSummary:
	summary = article.xpath('./text()').extract_first()
	print(summary)

	
DocumentLinks = response.xpath('.//div[starts-with(@class, "main-results")]')
for article in DocumentLinks:
	Links = article.xpath('.//a[contains(@href, "/search?q")]/@href').extract_first()
	NewsLinks =  article.xpath('.//a[contains(@href, "/search?as_sitesearch")]//@href').extract_first()
	print(Links,'zjc',NewsLinks)

	