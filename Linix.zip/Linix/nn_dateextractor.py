# -*- coding: utf-8 -*-
"""
Created on Tue Jul 24 12:43:00 2018

@author: qiyi1
"""

import articleDateExtractor
from newspaper import Article
import datetime
#import string
import sys
import waybackpack
import re
from dateparser.search import search_dates
import dateparser

import nltk
from nltk.corpus import stopwords
stops= set(stopwords.words('english'))
stops.add('%')
stops.add('$')
stops.add('A')
import copy
import numpy as np
###############################Time Out Control#############################################
from functools import wraps
import errno
import os
import signal

##########################################################################################
class TimeoutError(Exception):
    pass

def timeout(seconds=10, error_message=os.strerror(errno.ETIME)):
    def decorator(func):
        def _handle_timeout(signum, frame):
            raise TimeoutError(error_message)

        def wrapper(*args, **kwargs):
            signal.signal(signal.SIGALRM, _handle_timeout)
            signal.alarm(seconds)
            try:
                result = func(*args, **kwargs)
            finally:
                signal.alarm(0)
            return result

        return wraps(func)(wrapper)

    return decorator
#############################################################################################

#extract dates from response object(can be html or the initial parsed text from extract_web_results())
def date_extract(text,datetime_range):
   
    text=text.replace('>',' ').replace('<', ' ').lower()
    #CHANGE THIS TO MAKE FUNCTION WORK IN SHORT TERM (CURRENTLY WILL NOT LEVERAGE DATE PARSER)
    ret = search_dates(text,settings={'STRICT_PARSING': True} ) #None #
    rett=copy.deepcopy(ret)
    if rett != None:
        for k,v in rett:
            if len(k)<5 or ' ' not in k:
                try:
                    ret.remove((k,v))
                except:
                    pass
            else:
                wl=nltk.tokenize.word_tokenize(k)
                for w in wl:
                    if w in stops:
                        try:
                            ret.remove((k,v))
                        except:
                            pass
            if v<datetime_range[0] or v>datetime_range[1]:
                try:
                    ret.remove((k,v))
                except:
                    pass
        return ret
    else:
        return []
    
def waybackRes(URL = 'www.foodlion.com',FromDate = "1999",ToDate= "2019"):
    results=waybackpack.search(URL,to_date= ToDate,from_date=FromDate,uniques_only=True)
    timestamps=[]
    for snapshot in results:
        timestamps.append(snapshot['timestamp'])
    LeastRecentDate = timestamps[0]
    d=re.findall(r'\d+', LeastRecentDate)[0]
    date = datetime.datetime(year=int(d[:4]),month=int(d[4:6]),day=int(d[6:8]),hour=int(d[8:10]),minute=int(d[10:12]),second=int(d[12:14]))
    return date

@timeout(3)
def date_extraction(url,text):
    datetime_range=(datetime.datetime(1999, 1, 1, 3, 6, 7),datetime.datetime(2048, 1, 1, 3, 6, 7))
    res=None
    year_date=None #rough date from url
    wayback_date=None #web estblish date from wayback
    
    #parse url, possible return year/year month/ year month date
    #if only capture year, record and move on
    try:
        m_date = re.search(r'([\./\-_]{0,1}(19|20)\d{2})[\./\-_]{0,1}(([0-3]{0,1}[0-9][\./\-_])|(\w{3,5}[\./\-_]))?([0-3]{0,1}[0-9][\./\-]{0,1})?', url)
        if m_date !=None:
            if len(m_date.group(0))>6:
                print('url extraction return')
                return dateparser.parse(m_date)
            else:
                year_date=dateparser.parse(m_date)
    except:
        pass
    
    #try articleDateExtractor
    try:
        res = articleDateExtractor.extractArticlePublishedDate(url)
        if res!=None:
            print ('articleDateExtractor return')
            return res
    except:
        pass
    
    #try newspaper package
    try:
        article=Article(url)
        article.download()
        article.parse()
        if article.publish_date!=None:
            print ('newspaper return')
            return article.publish_date
    except:
        pass
        
    #try wayback
    #if wayback_date is close enough to url year_date, return wayback_date
    try:
        wayback_date=waybackRes(URL=url)
        if year_date !=None and year_date.year==wayback_date.year: # if year_date is not available, wayback_date need further verification in next step
            print ('wayback return')
            return wayback_date
    except:
        pass
    
    #html dateparser   
    len_dparser=0
    try:
        res=date_extract(text,datetime_range)
        len_dparser=len(res)
        if len_dparser==0:
            if year_date!=None and wayback_date!=None and year_date.year==wayback_date.year:
                print('dtparser wayback return')
                return wayback_date
            else:
                print('dtparser wayback return')
                return year_date
        elif len_dparser==1:
            if year_date !=None and res[0][1].year==year_date.year:
                print ('dparser dp-year return')
                return res[0][1]
            elif wayback_date !=None and res[0][1].year==wayback_date.year:
                print ('dparser dp-wayback return')
                return res[0][1]
            elif wayback_date!=None: # warning: I trust wayback more, but maybe sometimes it is wrong.
                print ('dparser wayback return')
                return wayback_date
            elif year_date!=None:
                print ('dparser year return')
                return year_date
            else:
                return res[0][1] # this step is risky, may be the found date is not publish date at all (may not be relevant to actual date of published) 
            
        else:
            if wayback_date !=None: # warning: I trust wayback more, but maybe sometimes it is wrong.
                diff=[ np.abs(day[1] - wayback_date) for day in res]
                idx=np.argmin(diff)
                #print('diff0',diff[idx])
                if diff[idx]<datetime.timedelta(180):
                #print('idx2',idx)
                    print('dparser multi dp-wayback return')
                    return res[idx][1]
                else:
                    print('dparser multi wayback return')
                    return wayback_date
            elif year_date !=None:
                diff=[ np.abs(day[1] - year_date) for day in res]
                idx=np.argmin(diff)
                #print('diff0',diff[idx])
                if diff[idx]<datetime.timedelta(180):
                #print('idx2',idx)
                    print('dparser multi dp-year return')
                    return res[idx][1]
                else:
                    print('dparser multi year return')
                    return year_date
            
    except:
        pass
    #print(res)
    return None



#finding date using URL and html tags 
#THIS IS USED WITHIN THE SPDIERS THEMSELVES 
#finding date 
import requests
import re
from bs4 import BeautifulSoup

def try_find_date(text,soup2):
    soup = soup2
#     obj=[]
    try:
        obj = soup.find(re.compile(r'meta'), property=re.compile(".*" + text+".*"))
    except:
        pass

    if not obj:
        try:
            obj = soup.find(re.compile(r'meta'), {"name":re.compile(".*" + text+".*")})
        except:
            pass
        
    if not obj:
        try:
            obj = soup.find(re.compile(r'meta'), {"itemprop":re.compile(".*" + text+".*")})
        except:
            pass
        
    if not obj:
        try:
            obj = soup.find(re.compile(r'meta'), {re.compile(".*" + text+".*"):re.compile(".*" + text+".*")})
        except:
            pass
        
    if not obj:
        try:
            obj = soup.find(re.compile(r'.*'), {re.compile(".*" + text+".*"):re.compile(".*" + text+".*")})
        except:
            pass

    if not obj:
        try:
            obj = soup.find(re.compile(r'.*time.*'))
        except:
            pass
        
    if not obj:
        try:
            obj = soup.find(re.compile(r'.*date.*'))
        except:
            pass
        
    return obj

#used in bing spider to extract date from html
def date_searchin(url1):
    response1 = requests.get(url1)
    soup2 = BeautifulSoup(response1.content,"html.parser")
    search_fields = ['date','time','Date','Time']
    out_obj = []
    obj=[]
    for term in search_fields:
        if not obj: 
            obj = try_find_date(term,soup2)
        try: 
            out_obj = obj["content"]
        except:
            pass
        if not out_obj:
            try:
                for objj in obj.attrs:
                    if 'time' in objj:
                        out_obj=obj[objj]
            except:
                pass
        if not out_obj:
            try:
                for objj in obj.attrs:
                    if 'date' in objj:
                        out_obj=obj[objj]
            except:
                pass            
    print(out_obj)
    if not out_obj:
        out_obj = ''

    return(out_obj)



#validate date and get title from html
import dateparser 
import numpy as np
import datetime
#from datetime import datetime
def validate_date(date_text,date_form="%m-%d-%Y"):
    try:
        date_text2=dateparser.parse(str(date_text)).strftime("%m-%d-%Y")
    except Exception: 
        return False
    if date_text2 != datetime.datetime.strptime(dateparser.parse(str(date_text)).strftime("%m-%d-%Y"), date_form).strftime(date_form):
        return False
    else: 
        return True

# from datetime import datetime
# import numpy as np
# def validate_date(date_text,date_form="%m-%d-%Y"):
#     try:
#         if date_text != datetime.strptime(date_text, date_form).strftime(date_form):
#             #raise ValueError
#             return False
#         elif date_text is None: 
#             return False
#         elif np.isnan(date_text):
#             return False
#         else: 
#             return True
#     except Exception: 
#         return False