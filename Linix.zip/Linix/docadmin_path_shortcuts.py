#kafka location 
cd /home/docadmin/Mueller/DTCC_Img/DTCC-demo/kafka_tools/kafka_2.11-2.0.0/

#bing api spider files
/home/docadmin/YQ/spider/RegulatoryNews/RegulatoryNews/spiders/NewsApiSpider.py
/home/docadmin/YQ/spider/RegulatoryNews/RegulatoryNews/pipelines.py
/home/docadmin/YQ/spider/RegulatoryNews/scrapyd_driver_v2.py
/home/docadmin/YQ/spider/RegulatoryNews /spider_main.ipynb

#source directory 
/home/docadmin/Mueller/DTCC_Img/Pykafka 
/home/docadmin/Mueller/DTCC_Img/DTCC-demo/
/home/ZackC/NegNews/SourceFiles/Pymag
cp /home/docadmin/Mueller/DTCC_Img/DTCC-demo/entity_dict.pickle /home/docadmin/ZackC/NegNews_kafka/NN_Kafka/


#scheduling parameters 
if name.IndvOrEntity==1: 
	domain_list = ','.join([domain for domain in domain_list_str])
	scrapyd.schedule(project_name, 'regulatory_news_search', jobid = name.Entity_Name + str(run_id), jobname = run_id
		,entity_name = name.Entity_Name, max_searching_pages = max_searching_pages.RegNews_MaxPages, topic = topic, partition = partition)
	
	scrapyd.schedule(project_name, 'newsapi_search', jobid = name.Entity_Name + str(run_id), jobname = run_id
		, domain_list_str=domain_list, entity_name = name.Entity_Name, max_searching_pages = max_searching_pages.NewsAPI_MaxPages, topic = topic, partition = partition)
	
	scrapyd.schedule(project_name, 'bing_search', jobid = name.Entity_Name + str(run_id), jobname = run_id
		, entity_name = name.Entity_Name, employer='',state='',max_searching_pages = max_searching_pages.Bing_MaxResults,  indvflag=name.IndvOREntity,topic = topic, partition = partition)

if name.IndvOrEntity==0:
	scrapyd.schedule(project_name, 'bing_search', jobid = name.Entity_Name + str(run_id), jobname = run_id, entity_name = name.Entity_Name
		, employer=name.Employer,state=name.Entity_State,max_searching_pages = max_searching_pages.Bing_MaxResults,  indvflag=name.IndvOREntity,topic = topic, partition = partition)


def NamedSearchLimits(list_of_tups):
'''create list of named tuples from raw inputs'''
namedtups = []
result_tuple = namedtuple('result_tuple',['RegNews_MaxPages','NewsAPI_MaxPages','Bing_MaxResults'])
namedtups.append([result_tuple._make(x) for x in list_of_tups])
return namedtups[0]
