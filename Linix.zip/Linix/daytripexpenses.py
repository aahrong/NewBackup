  3 Dec 2018 Ground Transportation - Taxi/Car Service 17886061 0000 30.57 trip to Hoboken for COE 
  3 Dec 2018 Air 17886061 0000 218.39 trip to Hoboken for COE 
  3 Dec 2018 Air 17886061 0000 166.45 trip to Hoboken for COE 
  3 Dec 2018 Meals - Dinner - out-of-town - self 17886061 0000 22.38 trip to Hoboken for COE 
  3 Dec 2018 Meals - Dinner - out-of-town - self 17886061 0000 16.11 trip to Hoboken for COE 
  3 Dec 2018 Meals - Dinner - out-of-town - self 17886061 0000 5.94 trip to Hoboken for COE 
  3 Dec 2018 Meals - Dinner - out-of-town - self 17886061 0000 6.25 trip to Hoboken for COE 
  3 Dec 2018 Meals - Breakfast - out-of-town - self 17886061 0000 10.65 trip to Hoboken for COE 
  3 Dec 2018 Air 17886061 0000 7.00 trip to Hoboken for COE 
  3 Dec 2018 Air 17886061 0000 7.00 trip to Hoboken for COE 
  3 Dec 2018 Meals - Dinner - out-of-town - self 17886061 0000 5.45 trip to Hoboken for COE 
  4 Dec 2018 Meals - Dinner - out-of-town - self 17886061 0000 5.44 trip to Hoboken for COE 
  4 Dec 2018 Air 17886061 0000 7.00 trip to Hoboken for COE 
  4 Dec 2018 Ground Transportation - Mass Transit 17886061 0000 10.00 trip to Hoboken for COE 
  4 Dec 2018 Meals - Dinner - out-of-town - self 17886061 0000 7.60 trip to Hoboken for COE 
  4 Dec 2018 Meals - Breakfast - out-of-town - self 17886061 0000 2.35 trip to Hoboken for COE 
  4 Dec 2018 Meals - Breakfast - out-of-town - self 17886061 0000 5.55 trip to Hoboken for COE 
  4 Dec 2018 Air 17886061 0000 150.08 trip to Hoboken for COE 
  5 Dec 2018 Ground Transportation - Taxi/Car Service 17886061 0000 3.00 trip to Hoboken for COE 
  5 Dec 2018 Ground Transportation - Taxi/Car Service 17886061 0000 15.00 trip to Hoboken for COE 
  5 Dec 2018 Ground Transportation - Taxi/Car Service 17886061 0000 71.35 trip to Hoboken for COE 
  5 Dec 2018 Ground Transportation - Taxi/Car Service 17886061 0000 13.49 trip to Hoboken for COE 
  5 Dec 2018 Ground Transportation - Taxi/Car Service 17886061 0000 6.69 trip to Hoboken for COE 
  5 Dec 2018 Telecommunications - Non Teleworker - Other - Telecommunications 17886061 0000 10.00 WIFI required to work  
  5 Dec 2018 Ground Transportation - Taxi/Car Service 17886061 0000 6.69 trip to Hoboken for COE 
  5 Dec 2018 Meals - Breakfast - out-of-town - self 17886061 0000 4.78 trip to Hoboken for COE 
  5 Dec 2018 Meals - Dinner - out-of-town - self 17886061 0000 23.25 trip to Hoboken for COE 
  5 Dec 2018 Ground Transportation - Mass Transit 17886061 0000 13.07 trip to Hoboken for COE 
  6 Dec 2018 Ground Transportation - Taxi/Car Service 17886061 0000 6.69 trip to Hoboken for COE 
  6 Dec 2018 Lodging 17886061 0000 1,103.28 trip to Hoboken for COE 
  6 Dec 2018 Ground Transportation - Taxi/Car Service 17886061 0000 8.79 trip to Hoboken for COE 
  7 Dec 2018 Meals - Breakfast - out-of-town - self 17886061 0000 11.00 trip to Hoboken for COE 
  7 Dec 2018 Telecommunications - Non Teleworker - Other - Telecommunications 17886061 0000 9.95 Wifi required for work  
  7 Dec 2018 Meals - Breakfast - out-of-town - self 17886061 0000 1.06 trip to Hoboken for COE 
  7 Dec 2018 Meals - Breakfast - out-of-town - self 17886061 0000 7.57 trip to Hoboken for COE 
  7 Dec 2018 Ground Transportation - Taxi/Car Service 17886061 0000 43.51 trip to Hoboken for COE 
  7 Dec 2018 Ground Transportation - Taxi/Car Service 17886061 0000 112.41 trip to Hoboken for COE 
  7 Dec 2018 Ground Transportation - Taxi/Car Service 17886061 0000 173.00 trip to Hoboken for COE 
  8 Dec 2018 Air 17886061 0000 438.90 trip to Hoboken for COE 
  8 Dec 2018 Meals - Breakfast - out-of-town - self 17886061 0000 12.29 trip to Hoboken for COE 
  8 Dec 2018 Meals - Dinner - out-of-town - self 17886061 0000 10.80 trip to Hoboken for COE 
  9 Dec 2018 Air 17886061 0000 439.60 trip to Hoboken for COE 
  9 Dec 2018 Air 17886061 0000 35.00 trip to Hoboken for COE 
  10 Dec 2018 Ground Transportation - Taxi/Car Service 17886061 0000 32.39 trip to Hoboken for COE 
  10 Dec 2018 Ground Transportation - Taxi/Car Service 17886061 0000 10.00 trip to Hoboken for COE 
  10 Dec 2018 Ground Transportation - Taxi/Car Service 17886061 0000 78.02 trip to Hoboken for COE 
  10 Dec 2018 Ground Transportation - Taxi/Car Service 17886061 0000 77.20 trip to Hoboken for COE 
  10 Dec 2018 Telecommunications - Non Teleworker - Other - Telecommunications 17886061 0000 9.95 Wifi required to work  
  10 Dec 2018 Meals - Dinner - out-of-town - self 17886061 0000 5.19 trip to Hoboken for COE 
  10 Dec 2018 Meals - Dinner - out-of-town - self 17886061 0000 6.53 trip to Hoboken for COE 
  10 Dec 2018 Meals - Breakfast - out-of-town - self 17886061 0000 5.08 trip to Hoboken for COE 
  11 Dec 2018 Meals - Dinner - out-of-town - self 17886061 0000 8.52 trip to Hoboken for COE 
  12 Dec 2018 Air 17886061 0000 25.00 trip to Hoboken for COE 
                
