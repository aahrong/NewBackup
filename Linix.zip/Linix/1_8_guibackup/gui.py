import os
import glob
from collections import namedtuple
import logging

from flask import Flask, render_template, request, Response, stream_with_context, send_file
from pymongo import MongoClient
from pymongo.errors import ServerSelectionTimeoutError
import pkg_resources

from negative_news.producer import ScrapyScheduler
from negative_news.mytwisted.config import Config
from negative_news.mytwisted.utils import construct_table_html
from negative_news.gui.app import return_dash_app

logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config["APPLICATION_ROOT"] = os.environ.get('SERVER_CONTEXT_PATH', '/')
APPLICATION_ROOT = os.environ.get('SERVER_CONTEXT_PATH', '/')

dash_app = return_dash_app(app)

# TODO: these constants don't belong here
INDIVIDUAL_FLAG = 0
ENTITY_FLAG = 1
DEFAULT_REGULATORY_SOURCES = [
    'finra.org/newsroom/',
    'occ.gov/news-issuances/news-releases',
    'investor.gov/additional-resources/news-alerts/press-releases',
    'sec.gov/news/press-release',
    'fdic.gov/news/news/press',
    'federalreserve.gov/newsevents/pressreleases',
    'cftc.gov/PressRoom/PressReleases',
]
FLASK_HOST = '127.0.0.1'
FLASK_PORT = 6007
NegativeNewsJob = namedtuple('NegativeNewsEntity', ['entity', 'known_aliases', 'employer', 'state', 'type'])

config = Config()

client = MongoClient(
    host=config.get('bind_address', '127.0.0.1', 'mongo'),
    port=config.get('http_port', '27017', 'mongo'),
    serverSelectionTimeoutMS=config.get('server_selection_timeout', 1000, 'mongo')
)

@app.route('/')     
@app.route('/schedule')
@app.route(APPLICATION_ROOT + '/schedule')
def home():
    return render_template('schedule.html')


@app.route('/monitor')
@app.route(APPLICATION_ROOT + '/monitor')
def monitor():
    html = "<a href='/download{fpath}'>{ftype}</a>"

    try:
        client.server_info()
        queue_database = config.get('queue_database', 'negative_news_queue', 'mongo')
        statuses = ['pending', 'ready', 'started', 'finished']
        data = []
        for s in statuses:
            dict_list = [dict({'status': s.title()}, **d) for d in client[queue_database][s].find({})]

            for d in dict_list:
                fname_pdf = glob.glob(d['output_path'] + '*' + d['entity'] + '*.pdf')
                fname_word = glob.glob(d['output_path'] + '*' + d['entity'] + '*.docx')

                if fname_pdf != [] and fname_word != []:
                    d.update({'Download': html.format(fpath=fname_pdf[0], ftype='PDF') + ' ' + html.format(fpath=fname_word[0], ftype='Word')})
                elif fname_pdf != []:
                    d.update({'Download': html.format(fpath=fname_pdf[0], ftype='PDF')})
                elif fname_word != []:
                    d.update({'Download': html.format(fpath=fname_pdf[0], ftype='WORD')})
                else:
                    if s == 'finished':
                        d.update({'Download': 'No Negative News Found'})
                    else:
                        d.update({'Download': 'Not Available'})

            data.extend(dict_list)
        table = construct_table_html(data)
    except ServerSelectionTimeoutError:
        table = "MongoDB connection error"

    return render_template('monitor.html', table=table)


@app.route('/analytics')
@app.route(APPLICATION_ROOT + '/analytics')
def analytics():
    return render_template('analytics.html', dash_content=dash_app.index())


@app.route(APPLICATION_ROOT + 'engine')
def schedule():

    # TODO: grab search type (single or batch)

    # grab max sentiment
    max_sentiment = request.args.get('maxsentslider', default='', type=float)

    # grab minimum similarity
    min_similarity = request.args.get('minsemslider', default='', type=float)

    # grab search terms
    default_search_terms = request.args.get('dsearchterms', default='', type=str)
    custom_search_terms = request.args.get('csearchterms', default='', type=str)
    total_search_terms = default_search_terms + custom_search_terms

    # grab search result threshold
    search_result_threshold = request.args.get('searchresullimiter', default='', type=int)

    # grab minimum year and minimum month
    yearsubset = request.args.get('yearsubset', default='', type=str)
    year_subset = yearsubset.split('-') if yearsubset != '' else ['', '']
    min_year = int(year_subset[0]) if year_subset[0] != '' else 2000
    min_month = int(year_subset[1]) if year_subset[0] != '' else 1

    # grab additional news sources for NewsAPI
    news_sources = request.args.get('newssource', default='', type=str)

    # grab entity details
    entity_names = request.args.get('entityname', default='', type=str).split(',')
    employer = request.args.get('company', default='', type=str)
    state = request.args.get('state', default='', type=str)
    type_flag = ENTITY_FLAG if request.args.get('spiderselect', default='', type=int) == 1 else INDIVIDUAL_FLAG

    # TODO: grab known aliases from gui
    known_aliases = ''

    # pack tuple with entity details
    jobs = []
    for entity_name in entity_names:
        jobs.append(NegativeNewsJob(entity=entity_name, known_aliases=known_aliases, employer=employer, state=state, type=type_flag))

    scheduler_settings = {
        'spider_settings': {
            'bing_search': {
                'jobs': jobs,
                'additional_arguments': {
                    'searchingterm_list_str': total_search_terms,
                    'domain_list_str': '',
                },
            },
            'bing_regulatory_search': {
                'jobs': jobs,
                'additional_arguments': {
                    'searchingterm_list_str': total_search_terms,
                    'domain_list_str': ','.join(DEFAULT_REGULATORY_SOURCES),
                },
            },
            'newsapi_search': {
                'jobs': jobs,
                'additional_arguments': {
                    'domain_list_str': news_sources,
                },
            },
        },
        'other_ui_settings': {
            'max_sentiment': max_sentiment,
            'min_year': min_year,
            'min_month': min_month,
            'min_similarity': min_similarity,
            'search_terms': total_search_terms,
            'max_search_results': search_result_threshold,
            'language_abbrv': 'EN',
        },
    }

    scheduler = ScrapyScheduler(
        config=config,
        spider_settings=scheduler_settings['spider_settings'],
        other_ui_settings=scheduler_settings['other_ui_settings']
    )

    client = MongoClient(
        host=config.get('bind_address', '127.0.0.1', 'mongo'),
        port=config.get('http_port', '27017', 'mongo'),
        serverSelectionTimeoutMS=config.get('server_selection_timeout', 1000, 'mongo')
    )

    try:
        client.server_info()
    except ServerSelectionTimeoutError:
        return 1

    return 0

@app.route("/download/<path:fpath>")
def download_output(fpath, entity_name=None):
    if entity_name is not None:
        fpath = glob.glob(fpath + '*' + entity_name + '*.docx')[0]

    if fpath is '':
        logger.debug("Canceling output download request for entity '{}' because provided file path is blank .. ".format(entity_name))
        return

    if '.docx' in fpath:
        mimetype = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    elif '.pdf' in fpath:
        mimetype = "application/pdf"
    else:
        mimetype = ""

    fname = os.path.basename(fpath)
    run_id = os.path.basename(os.path.dirname(fpath))
    fpath = pkg_resources.resource_filename('negative_news', 'producer/output/{}/{}'.format(run_id, fname))

    logger.debug("Downloading output at the following file path: {} ".format(fpath))

    return Response(open(fpath, 'rb').read(), mimetype=mimetype)


if __name__ == "__main__":
    app.run(host=FLASK_HOST, port=FLASK_PORT, debug=True, threaded=True)
