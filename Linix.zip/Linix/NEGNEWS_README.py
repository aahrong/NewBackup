#VS Code SSH 
#ssh -R 52698:nlpsomnath:52698 nlpsomnath@10.246.59.29
ssh -R 52698:localhost:52698 nlpsomnath@10.246.59.29
ssh -R 52698:localhost:52698 docadmin@10.246.59.58

#remote VSVT repo:
git remote add origin https://zjc1002@dev.azure.com/EYFSOAdvisory/FinCrime%20CI/_git/NegNews_PythonContainer

#run flask app 
#old:http://localhost:6006/single?name=Wells%20Fargo
#new:http://localhost:6006/single?name=UBS&entity=1&sqlid=1033
#Post2Run:http://localhost:6006
#loation of vsvt repohttps://dev.azure.com/EYFSOAdvisory/FinCrime%20CI/_git/NegNews_PythonContainer?path=%2FREADME.md&version=GBmaster  
#URL TO POST RESULTS TO (FOR KYC TEAM): https://dev.azure.com/EYFSOAdvisory/FinCrime%20CI/_git/NegNews_PythonContainer?path=%2FREADME.md&version=GBmaster    

#root url being used for applications
#also final post request from kyc verifying sucessful transmission 
http://localhost:6006/

#negative News required inputs 
name = request.args.get('name', default='', type=str)
IndvOREntity = request.args.get('entity',default=9, type=int)
sqlid = request.args.get('sqlid',default=9, type=int)
negnewsurl=request.args.get('nnurl',default="https://dev.azure.com/EYFSOAdvisory/FinCrime%20CI/_git/NegNews_PythonContainer?path=%2FREADME.md&version=GBmaster")

#negative News optional inputs
state = request.args.get('state',default='',type=str)
employer = request.args.get('employer',default='',type=str)

#intital Get request: negative News URL string 
http://localhost:6006/single?name=UBS&entity=1&sqlid=1033
curl http://localhost:6006/single?name=UBS&entity=1&sqlid=1033

#final Post request: negative news URL to send results 
https://sentinel.eastus.cloudapp.azure.com/kyc/workflowmgnt/dev/sendNegativeNews


#negative news initial repsonse format (send back to initial URL) 
{"AA ID": "10-08-18-23-22-50", "employer": "", "state": "", "negnewsurl": "https://sentinel.eastus.cloudapp.azure.com/kyc/workflowmgnt/dev/sendNegativeNews", "sqlid": 10, "IndvOREntity": 1, "name": "Wells Fargo"}

#negative news results format sent to sentitnal URL(final post request)  
[{'Entity_Name': 'Center Parcs ', 'JsonFileLocation': '/home/docadmin/Mueller/DTCC_Img/DTCC-demo/output_pdf/10-08-18-23-03-56_Center_Parcs_10-08-2018.json', 'OverallRiskScore': '', 'DateTime_Complete': '2018-10-08-23-04-27', 'w2vSortedOutput': '[{"Person":"Center Parcs_","Doc":1,"Sent":0,"URL":"https:\\/\\/www.nottinghampost.com\\/news\\/local-news\\/center-parcs-prosecuted-after-eight-1337400","Sentence":"center parcs pleaded guilty court yesterday march fined additional costs councillor ian dalgarno executive member community services central bedfordshire council said investigations found inadequate risk assessments place unsafe system work inadequate monitoring ensure tree climbing activity safe","Similarity":0.489813307,"Sentiment":-0.5859,"textsummary":"\\"This prosecution sends a message to businesses that there are serious consequences if health and safety laws are breached, and members of the public placed at risk.\\" He said: \\"We would like to take this opportunity to apologise to the family involved for the distress this incident has caused. \\"We take the health, safety and wellbeing of our guests extremely seriously, and from the outset have co-operated fully and proactively with the investigation undertaken by Central Bedfordshire Council.","date":"01-01-2018","source":"bing","Title":"center-parcs-prosecuted-after-eight-1337400","FinalDocScore":null,"Final_Normalized_Score":0.8401917456,"RegNonReg":"Non Regulatory","NewsSource":"nottinghampost","pdftext":"Center Parcs pleaded guilty in court on yesterday (March 13) and was fined \\u00a3250,000 with additional costs of \\u00a314,000_ Councillor Ian Dalgarno, executive member for community services at Central Bedfordshire Council, said: \\"Our investigations found inadequate risk assessments in place, an unsafe system of work, and inadequate monitoring to ensure that the tree climbing activity was safe."},{"Person":"Center Parcs_","Doc":1,"Sent":1,"URL":"https:\\/\\/www.nottinghampost.com\\/news\\/local-news\\/center-parcs-prosecuted-after-eight-1337400","Sentence":"prosecution sends message businesses serious consequences health safety laws breached members public placed risk","Similarity":0.4154637053,"Sentiment":-0.4215,"textsummary":"\\"This prosecution sends a message to businesses that there are serious consequences if health and safety laws are breached, and members of the public placed at risk.\\" He said: \\"We would like to take this opportunity to apologise to the family involved for the distress this incident has caused. \\"We take the health, safety and wellbeing of our guests extremely seriously, and from the outset have co-operated fully and proactively with the investigation undertaken by Central Bedfordshire Council.","date":"01-01-2018","source":"bing","Title":"center-parcs-prosecuted-after-eight-1337400","FinalDocScore":null,"Final_Normalized_Score":0.8401917456,"RegNonReg":"Non Regulatory","NewsSource":"nottinghampost","pdftext":"\\"This prosecution sends a message to businesses that there are serious consequences if health and safety laws are breached, and
members of the public placed at risk.\\""}]', 'AA_ID': '10-08-18-23-22-50', 'SQL_ID': 10}]




#enter docker image that has already been built
docker run -it newwflask:dockerfile

#read from mongodb store from python 
#The main component of PyMongo is the MongoClient class. In order to connect with the database, you need an instance of the client:
from pymongo import MongoClient 
client = MongoClient()
list(client.negative_news.bing_search.find({}))

#load docker image with specfied port 
docker run -it -p 6006:6006 newwsh:dockerfile 


#git remote location 
git@10.246.59.23:zachary.c/NegNews.git #pass:zackC1002
git@10.246.59.52 #pass:ZachPleaseRemember1

#last stash
Saved working directory and index state WIP on zack_test_vol4: 15ceb2f switched to doker execution view
HEAD is now at 15ceb2f switched to doker execution view

#SET UP SCRAPYD TUNNEL TO ENABLE TROUBLESHOOTING AND PROGRESS VIEW 
Local Port: 6800
Local Host: 0.0.0.0
Server: 10.246.59.58
Server Name: docadmin
Server Port: 22

#list projects 
curl http://localhost:6800/listprojects.json

#list project versions
curl http://localhost:6800/listversions.json?project=deafult

#add new version to project

#list spiders 
curl http://localhost:6800/listspiders.json?project=default
#view deamon status 
curl http://localhost:6800/daemonstatus.json
##spedule spier run 
curl http://localhost:6800/schedule.json -d project='default' -d spider='nn_spider'
#kill scrapyd 
killall scrapyd

#VISUAL CODE FIX FOR WARNING INDICATING PORT FORWARDING FAILED 
sudo netstat -plant  | grep 52698 #find all processes tied to visual code port
sudo kill -9  26635/0#kill all processes (replace xxxxxx with process ids) 
sudo netstat -plant  | grep 6006 #find all processes tied to visual code port

#launch UI for DEMO 
#1.Launch scrapyd in root project directory 
#2.run scrapyd-deploy in same location in new terminal 
#3. run python3 app.py from root (where app.py is located) 
#4.Open google in incognito mode (CTRL+SHT+N) 
#5. Enter: 127.0.0.1:6006 into http bar 
 
#NON API RUN (RUNNING On Docadmin no docker)
1. Change project_dir in config file to : '/home/docadmin/ZackC/NegNews/'
2. Naviate to root folder: ZackC/NegNews/
3A. Run Single Instance: scrapy crawl nn_spider -a id=1 -a entity_name='Citi Group'
3B. Run Batch Instance: a) naviate to batch code folder: cd ./code/ , b)python3 main.py		(NOTE: main.py sources data from the excel file stored in ZackC/NegNews/sourcefile/TestList_V3.xlsx)

#API RUN (NO DOCKER)
#sys.path.insert(0, "//home//docadmin//ZackC//NegNews//")
1. Change project_dir in config file to : '/home/docadmin/ZackC/NegNews/'
2. Navigate to Root: /home/docadmin/ZackC/NegNews
3. run app: python3 app.py 
4. Initalize tunneling to port specified in app.py 
5. open browser and run(PORT WILL LIKLEY NOT BE THE SAME, MUST CHECK APP.PY) : http://localhost:6005/single?name=bolun%20yang
6. batch curl option: curl http://localhost:6006/sql

#DOCKER BUILD
#rebuild docker image(-t name of docker image , . represents that we want it to be built in the current directory) 
#--name : refers to name of the container u want to crate 
# nn_bot_credit is refering to the image you want to base the container from 
#docker run -dti -v /home/docadmin/ZackC/NegNews:/NNfolder --name nn_bot_mvo --net=host nn_bot_credit #spin up a new docker with existing container (MAXIM PROVIDED)
#https://kirankoduru.github.io/python/multiple-scrapy-spiders.html
#https://github.com/kirankoduru/arachne
#https://stackoverflow.com/questions/36109400/run-multiple-spider-sequentially
docker build -t nn_bot_new #must launch docker build within project you want to build docker form (where dockerfile is) 
docker run -dti -v /home/docadmin/ZackC/NegNews:/NNfolder --name alisheka_bot --net=host nn_bot_new 
docker exec -ti alisheka_bot bash

#NON API RUN (RUNNING THROUGH DOCKER)
1. Naviate to root folder: ZackC/NegNews/
2. Launch Docker: docker exec -ti nn_bot_mvo bash 
3. Remove deafult config file, and copy most recent config file into docker root: rm config.py , cp ./NNfolder/config.py ./ 
4. Run Single Instance: scrapy crawl nn_spider -a id=1 -a entity_name='Bank of America'
5. Run Batch Instance: a) naviate to batch code folder: cd ./NNfolder/code/ , b)python3 main.py		(NOTE: main.py sources data from the excel file stored in ZackC/NegNews/sourcefile/TestList_V3.xlsx

#####################
###IDE SETUP#########
#enable microsfot vs in docadmin 
1) Install VSCode
2) Ctrl + ALT + P  ">Remote: Start Server" #YOU HAVE TO RUN THIS EVERYT IME 
3) open bash terminal 
3)ssh -R 52698:localhost:52698 docadmin@10.246.59.58
4) find file you want in termal, type "rmate xx.py"
5)password:ItW!llB3Great78


scrapy crawl FinraLinks -a entity_name='Bank of America'
#################################################
##########STORING ARTIFACTS ON JFROG#############
#################################################
URl: fsoartifactory.northcentralus.cloudapp.azure.com
User: zachary.carideo 
pass: Welcome@123

#Store docker in: aws container registry
#only need to do this one time (note: /tmp/abc/ refers to the location on the local where u want to store the artifat u have curled)
curl -u username:password http://fsoartifactory.northcentralus.cloudapp.azure.com/artifactory/SQL-Test-Data/adc-fincrime-uat-ddl.sql > /tmp/abc



###################LOCATION OF FUNCTIONS TO INCORPORATE 
FINRACRAWL:/home/docadmin/ZackC/NN_Gitlab/adhoc_troubleshoot/FinraLinks/FinraLinks/spiders
scrapy crawl FinLinksCrawl -a -a entity_name='deutsche bank'

NEGNEWS:/home/docadmin/ZackC/NegNews/

SUMY: /home/docadmin/YiYang/word_summarization.ipynb
Date: /home/docadmin/YQ/date_extraction/date_extraction.py


•	Proposed demo flow:
o	Quick overview of our understanding of their problem statement
o	Summary of our solution, its key dependencies, and highlight strong features (such as word embeddings, sentiment models,  language translation, and document summarization)
o	Example outputs we can share on few applications – government websites, Bing results, other
o	Q&A



#####YIKES LEGACY SPIDERS LOCATION 
#bing api spider files
#/home/docadmin/YQ/spider/RegulatoryNews/RegulatoryNews/spiders/NewsApiSpider.py
#/home/docadmin/YQ/spider/RegulatoryNews/RegulatoryNews/pipelines.py
#/home/docadmin/YQ/spider/RegulatoryNews/scrapyd_driver_v2.py
#/home/docadmin/YQ/spider/RegulatoryNews /spider_main.ipynb
