#unix scripting (navigation and execution command history) 


#view all containers running on linux server (command line )
docker ps 

#show all files in directory and display all subdirectories, and list in sorted order 
dir /s /b /o:gn 
tree /f
#list files not folders 
dir ..\myfolder /b /s /A-D /o:gn>list.txt

#find all python verions installed 
 ls -ls /usr/bin/python*

#start jupyter
jupyter notebook --port 57758

#install packages through firewall (EY FIREWALL)
pip install --proxy=http://amweb.ey.net:8080 somepackage
pip install --proxy=http://amweb.ey.net:8080 rsync

#get all python installed packages 
installed_packages = pip.get_installed_distributions()

#detailed file directory information 
ls -l ##extended form of all directory info

ls -a ##show all files including hidden files in directory 

ls -c -l ##show all files in order of creation date 
ls -c -t ##sort all files in order of creation date
ls -m ##show all files in a single comma delimited string
ls -c -x ##sort all files in order of last time accessed or opened

##########
####mv####
##########
#moving files from one directory to another 
#move all jupyter notebook files from CCAR folder to personal folder 
mv /home/docadmin/CCAR_POC/CCAR_OCR_ZJC_10_5_DEMO.ipynb "/home/docadmin/ZackC/Final OCR Scripts/"
mv /home/docadmin/CCAR_POC/*.ipynb "/home/docadmin/ZackC/Final OCR Scripts/OCR_Misc/"
mv "/home/docadmin/CCAR_POC/Final OCR Scripts/"*.ipynb "/home/docadmin/ZackC/Final OCR Scripts/OCR_Misc/"
mv "/home/docadmin/doc_review/"*.ipynb "/home/docadmin/ZackC/Final OCR Scripts/OCR_Misc/"

mv /home/docadmin/ZackC/OCR_2018/OCRScripts.ipynb "/home/docadmin/ZackC/OCR_2018/PythonScripts/"
mv "/home/docadmin/doc_review/"*.ipynb "/home/docadmin/ZackC/Final OCR Scripts/OCR_Misc/"
mv "/home/docadmin/ZackC/OCR_2018/PythonScripts/"*.ipynb "/home/docadmin/ZackC/OCR_2018/PythonScripts/WorkingFiles/WF_Articles_Incorp"

############
#COPY FILES FROM ONE DIRECTORY TO ANOTHER WITH A SPECIFIC EXTENSION#
############
#copy all pdf files from folder 1 to folder 2
cp /home/docadmin/python/ocr/samples/*.pdf /home/docadmin/python/ocr/samples/PDFS/ 
cp "/home/docadmin/doc_review/doc_review/*.ipynb" "/home/docadmin/ZackC/Final OCR Scripts/OCR_Misc/"

mv "/home/docadmin/doc_review/"*.ipynb "/home/docadmin/ZackC/Final OCR Scripts/OCR_Misc/"
mv "/home/docadmin/ZackC/NegNews/"*.xlsx "/home/docadmin/ZackC/"

##########
###GREP###
##########
#search for all files containing the string 'check'
#using * will omit all hidden files that are in the current working directory 
grep ocr_test* -lR 
grep -rl ocr_test . 
grep -rl "ocr_test" .

###############
#find function#
###############
#-c : returns a filename followed by : and a number indicating how many times the search string appears in the given file 
#-v : takes the output from the first grep search, filters out the files with zero results, and print out just the files with non zero - results 
find . -type f | xargs grep -c ocr_test $1 | grep -v ":0" #search from the current directory for the keyword
find . -type f -exec grep -l ocr_test {} +
find / -type f | grep "keyword" * #search from the root directory for keyword 

#find files containing the string 'ocr' in the filename 
#-iname: used to indicate case insensative when searching (i.e. file = File)
find -iname "ocr"

#find all files containing ocr in name that are on the system 
find / -iname "ocr" 

#count total number of files with ocr_test in name 
#pop the output into a counter to get total observations as output instead of all unique values found 
find -name ocr_test.* | wc -l

#find all files ending in .ipynb
find / -type f -name "*cr_test.py"
find / -type f -name "*.git"
find / -type f -name "config_spacy*"
#find all files ending in cr_test.py that are less than 50 meg in size 
find / -size +7M -type f -name "*cr_test.py"

#find all files modified within the last day 
find / -mtime 1 

#find all files modified in last minute 
find / -mmin -1 

#files that have been accessed <24 hours ago 
find / -atime -1 

#find all files with OCR in the name that are at max 2 levels deeper in the file structure then the current directory 
find -maxdepth 23 -iname "OCR_TEST.*"
find -mindepth 10 -maxdepth 23 -iname "OCR_TEST.*"

#USING OR/AND with find
#find any file with ocr_test or nlp in the fle name 
find -mindepth 2 -maxdepth 23 -iname "OCR_TEST.*" -or -iname "nlp_test.*"

############
##FIND END##
############

#creating file structure dynamically 
#create a directory structure in a temporary directory. 
#It will contain three levels of directories, with ten directories at the first level.
#Each directory (including the temp directory) will contain ten files and ten subdirectories.
cd
mkdir -p ~/test/level1dir{1..10}/level2dir{1..10}/level3dir{1..10}
touch ~/test/{file{1..10},level1dir{1..10}/{file{1..10},level2dir{1..10}/{file{1..10},level3dir{1..10}/file{1..10}}}}
cd ~/test


#remove directory and all files associated with directory 
rm -rf mydir 


################################
##checking virtual enviornments#
################################

################################
#############PYTHON#############
################################
#download package and ignore all past / cache installs 
pip install --ignore-installed --upgrade tensorflow 

#function to check if package is installed
from imp import find_module
def checkPythonmod(mod):
    try:
        op = find_module(mod)
        return True
    except ImportError:
        return False