# -*- coding: utf-8 -*-
"""
Created on Fri Aug 17 14:26:33 2018

@author: qiyi1
"""
import scrapy
from fake_useragent import UserAgent
import re
from bs4 import BeautifulSoup
from bs4.element import Comment
import time 
import requests
from itertools import tee, chain, islice
from nltk.tokenize import sent_tokenize
import os
import sys
from nn_base.timeout import timeout

class BingSearchSpider(scrapy.Spider):
    name = 'bing_search'
    custom_settings = {
        #'FEED_URI': '</home/docadmin/ZackC/NN_Gitlab/adhoc_troubleshoot/output/FinraLinks.csv>',
        #, 'FEED_EXPORTERS': {'pickle': 'scrapy.exporters.PickleItemExporter'
        #FEED_EXPORT_FEILDS
        #'FEED_FORMAT': 'csv'
        'ITEM_PIPELINES': {'RegulatoryNews.pipelines.BingsPipeline2json': 300,
                            'RegulatoryNews.pipelines.MongoWriterPipeline' : 350,
                            'RegulatoryNews.pipelines.KafkaProducerPipeline': 400},
        'AUTOTHROTTLE_ENABLED': 'True',
        'AUTOTHROTTLE_TARGET_CONCURRENCY': '1.0',
        'RANDOMIZE_DOWNLOAD_DELAY': 'True',
        'USER_AGENT': UserAgent().random,
        'ROBOTSTXT_OBEY': 'False',
        'HTTPCACHE_ENABLED': 'False',
        'LOG_STDOUT': 'True',
        #'LOG_LEVEL': 'WARNING',
        'LOG_LEVEL': 'DEBUG', 
        'DOWNLOAD_TIMEOUT': str(5),
        'RETRY_ENABLED': False,
        'CLOSESPIDER_TIMEOUT':'500',
        'DOWNLOAD_DELAY':'0.25'
        ,'COOKIES_ENABLED':False
        
        ### rotate proxies### qyk
#        # Retry many times since proxies often fail
#        ,'RETRY_TIMES' : 100
#        # Retry on most error codes since proxies fail for different reasons
#        ,'RETRY_HTTP_CODES': [500, 503, 504, 400, 403, 404, 408]
#
#        ,'DOWNLOADER_MIDDLEWARES' : {
#                'scrapy.downloadermiddlewares.retry.RetryMiddleware': 90,
#                'scrapy_proxies.randomproxy.RandomProxy': 100,
#                'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 110,
#                }
#
#        # Proxy list containing entries like
#        # http://host1:port
#        # http://username:password@host2:port
#        # http://host3:port
#        # ...
#        ,'PROXY_LIST' : './proxies.txt'
#
#        # Proxy mode
#        # 0 = Every requests have different proxy
#        # 1 = Take only one proxy from the list and assign it to every requests
#        # 2 = Put a custom proxy to use in the settings
#        ,'PROXY_MODE' : 0
#
#        # If proxy mode is 2 uncomment this sentence :
#        #CUSTOM_PROXY = "http://host1:port"
        
       }

    def __init__(self, entity_name='',jobname='', employer='',state='',searchingterm_list_str='',count=10, indvflag=1,output_dir='/home/docadmin/Mueller/DTCC_Img/DTCC-demo/output/', topic = None, partition = None, **kwargs):
        self.topic = topic
        self.partition = int(partition)
        self.jobname = jobname
        self.entity=entity_name
        self.indvflag=indvflag
        self.company=employer
        self.state=state
        if searchingterm_list_str=='':
            self.searchingterms=[]
        else:
            #self.searchingterms=searchingterm_list_str.split(',')
            self.searchingterms=searchingterm_list_str
       
        if self.indvflag==0:
            name_trail=entity_name.split()
            self.fname=name_trail[0]
            if len(name_trail)>1:
                self.lname=' '.join(name_trail[1:])
            else: 
                self.lname =''
        else: 
            self.fname=entity_name 
            self.lname = ''
 

        
        self.count=int(count)
        self.output_dir=output_dir
        
        self.start_urls=self.binglinks(name=self.entity, loc=self.state, employer=self.company, searchterms = [self.searchingterms], TotalResults=self.count)[0][0] 
        

        super().__init__(**kwargs)  # python3
    
    def generate_search_query(self,name, slist, entity, common_nouns=[],location='',employer=''):

        namelist = name.split() #split name into list
        qlist = list(map(lambda x: '('+' OR '.join(x)+')',slist)) #join all search terms into a string of OR statements for the queyr 
    
        #if we want to include YEAR
        #if the name has common nouns or the name is refering to an entity then require all part of the name to be a single string instead of 2 (this ensures entities with multi word names are processed correct)
        if employer !='':
            namepart = '("' + ' '.join(namelist) + '")'+ '('+str(employer)+')'
        else: 
            namepart = '("' + ' '.join(namelist) + '")'
        #if the searchis on an individual, we dont want to require the individuals first and last name be together, but we want them both to be found, so the creation of the query is slightly differnt
    
        if location!='':
            locpart = '({})'.format(' '.join(location.strip().split(' ')))
            if locpart == '() ': locpart = ''
        else:
            locpart = ''
    
        query = [namepart + locpart + q for q in qlist]
        return query
    
    def search_on_bing_all_nose(self,query_list,entity_fname, entity_lname , TotalResults):

        ## Query bing based on parameters)        
        def search_on_bing(query, count, offset, searchlang):
            subscription_key ='c759653bb84b490ba06cfcd92b2397e4' 
            assert subscription_key
            search_url = "https://api.cognitive.microsoft.com/bing/v7.0/search"
            bing_params  = {"q": 'language:'+'en' + ' '+query , "count": count, "offset": offset, "responseFilter":'Webpages'}
            headers = {"Ocp-Apim-Subscription-Key" : subscription_key}
            time.sleep(1)
            bing_response = requests.get(search_url, headers=headers, params = bing_params) #raw bing response output generated here
            bing_response.raise_for_status()
            return bing_response

        ## Parse the results from bing search (convert to json , extract the results from each url)
        def parse_bing_response(bing_response):
            search_results = bing_response.json()        
            try:
                bingquery = search_results['webPages']['webSearchUrl'] #search query used by bing
                url_list = [result['url'] for result in search_results['webPages']['value']] #the url found from search and all other response object informaiton 
            except:
                url_list = []
                bingquery = 'https://www.bing.com/search?q=' + search_results['queryContext']['originalQuery']
                print("Error getting results from bing")
            return url_list, bingquery    
    
        all_links = []
        all_url_list = []
        all_bingquery = []
    
        #execute the search query genrated above
        searchquery = query_list[0]
        if searchquery == []:
            links = []
            url_list = []
            bingquery = []
        else:
            #for the first URL we extract the top 50 results (or value specified by config.search_results)
            #search_offset : the number of initial results to skip before returning data(starts as 0 and increments of 50 until offset>=search_results)
            search_offset = 0
            search_lang_short= 'en'#list(map(langname_to_iso639, ['english']))[0]
            
            #response from bing 
            bing_response = search_on_bing(searchquery, TotalResults, search_offset, search_lang_short)
            url_list, bingquery = parse_bing_response(bing_response)
            
            if len(url_list) == 0:
                print("No Results for searching {} {} in {}".format(entity_fname, entity_lname, search_lang_short))
    
            else:
                #for each subsequent iteration of extracting results, enumerate offset in iterations of min(50,config.search_results)
                searchcount=2
                while len(url_list) < TotalResults and searchcount<20:
                    searchcount = searchcount + 1
                    search_offset = search_offset + min(50,TotalResults)
                    bing_response = search_on_bing(searchquery, TotalResults, search_offset, search_lang_short)
                    url_list2, _ = parse_bing_response(bing_response)
                    if len(url_list2)==0:
                        print("Cannot find more than {} results after {} searches".format(TotalResults, searchcount))
                        searchcount = 19
                    else:
                        url_list.extend(url_list2)
            items = ['.pdf','.doc', '.csv', '.docx', '.xls', '.xlsx', '.png', '.jpeg', 
                 '.jpg','.gif','.xml', '.json', '.gz', '.zip', 'ppt','.pptx', '.xlsm','.xlsb', '.txt']
    
            links = url_list
            for i in items:
                links = [link for link in links if i not in link.lower()]
            links = links[0:TotalResults]
        all_links.append(links)
        all_url_list.append(url_list)
        all_bingquery.append(bingquery)
        return all_links, all_url_list, all_bingquery    
    
    def binglinks(self,name, loc='', employer='', searchterms = [], TotalResults=100):
    #entity name 
        name = name
        fname = self.fname
        lname = self.lname
    
        common_nouns=[] ###qykqykqyk
        #generate search terms to include in query
        searching_list = searchterms
    
        #genreate search query to pass to bing API
        if  loc=='':
            query_list = self.generate_search_query(name, searching_list, 1, common_nouns) #generate query qith multi word phrases
        elif loc!='' and employer=='':
            loc = loc 
            query_list = self.generate_search_query(name, searching_list, 1, common_nouns,location=loc) #generate query qith multi word phrases
        elif loc=='' and employer!='':
            query_list = self.generate_search_query(name, searching_list, 1, common_nouns,location=loc,employer=employer)
        else: 
            query_list = self.generate_search_query(name, searching_list, 1, common_nouns,location=loc,employer=employer)
    
        #Generate links from bing 
        all_links, all_url_list, all_bingquery = self.search_on_bing_all_nose(query_list=query_list,entity_fname=fname, entity_lname=lname, TotalResults=TotalResults)
        return all_url_list, all_bingquery, query_list  

    
    def start_requests(self):
        print(self.start_urls)
        for url in self.start_urls:
            yield scrapy.Request(url, self.parse_content)

    def parse_content(self,response):   
        ext_text=self.extract_web_results(response.text,self.fname,self.lname,entity=0)
        clean_text=' '.join(self.OrigTxt_PreProcess([ext_text], self.fname, self.lname, delim ='<!@&>', window=False)[0][0])
        orig_text=' '.join(self.OrigTxt_PreProcess([ext_text], self.fname, self.lname, delim ='<!@&>', window=False)[1][0])
        
        if clean_text!='':
            #yield({'source':'bing','entity':self.entity,'title':'','date':'','content':clean_text,'summary':'','url':response.url,'origtext':orig_text,'jobname':str(self.jobname)+' _ '+self.state+' _ '+self.company})
            yield({'source':'bing','entity':self.entity,'title':'','date':'','content':clean_text,'summary':'','url':response.url,'origtext':orig_text,'jobname':str(self.jobname)+' _ '+self.state+' _ '+self.company})
    @timeout(5)
    def extract_web_results(self,responsetext, fname, lname,entity=0):
        def text_from_html(htmltext, parser):
            def tag_visible(element):
                if element.parent.name in ['style', 'script', 'head', 'title', 'meta', '[document]']:
                    return False
                if isinstance(element, Comment):
                    return False
                return True
            try:
                soup = BeautifulSoup(htmltext, parser)
                texts = soup.findAll(text=True)
                visible_texts = filter(tag_visible, texts)  
                return u" ".join(t.strip() for t in visible_texts)
            except:
                return ''
        
        #clean raw htm text slightly to enable effective windowing 
        text = text_from_html(responsetext, "html") #text to process and manipulate 
        text = text.strip()
        text = re.sub("\.{2,}" , ".",text)
            
        #apply windowing critera
        extracted_text = self.window_search_regex(text, fname, lname, entity) #extract relevant text from URL (and convert to lwoer)
        
        ## Now try with lxml parser, if extracted text is blank
        if extracted_text == '':
            text = text_from_html(responsetext,"lxml")
            text = text.strip()
            text = re.sub("\.{2,}" , ".",text)
            extracted_text = self.window_search_regex(text, fname, lname,entity)
        return extracted_text

    @timeout(5)
    def window_search_regex(self,text, fname, lname,entity,left_num=2,right_num=2):
        try:
            if lname!='':
                
                if entity==1:
                    regex_name = ('{} {}'.format(fname, lname)).lower().strip()
                else:
                    regex_name = ('{}|{}'.format(fname, lname)).lower().strip()
                    
            else:
                regex_name=fname.lower().strip()
            
            text=text.replace('U.S.','USA').replace('www.','').replace('.com','').replace('.org','').replace('.gov','').replace('Inc.','Inc').replace('Co.','Co').replace('Mr.','').replace('Mrs.','').replace('Dr.','').replace('Feb.','February').replace('Jan.','January').replace('Aug.','August').replace('Sep.','September').replace('Oct.','October').replace('Nov.','November').replace('Dec.','December').replace('0.','0_').replace('1.','1_').replace('2.','2_').replace('3.','3_').replace('4.','4_').replace('5.','5_').replace('6.','6_').replace('7.','7_').replace('8.','8_').replace('9.','9_')
    
            text_for_regex=text 
            text_for_regex = 'the. ' + text + ' the. the.' 
            extracted_text_list =[]
            p = re.compile(r'(([^\.]*\.){'+str(left_num)+'}[^\.]*(' + regex_name + r')[^\.]*\.([^\.]*\.){'+str(right_num)+'})',re.IGNORECASE) #original critera 1,2   
            
            for name_i in p.findall(text_for_regex,re.IGNORECASE):
                extracted_text_list.append(name_i[0])
            extracted_text_list = list(set(extracted_text_list))
            extracted_text_list = [x[0:2000] for x in extracted_text_list if 10 <= len(x) <= 2000]
            extracted_text = '<!@&>'.join(extracted_text_list)
            return extracted_text
        except:
            return ''

    def OrigTxt_PreProcess(self,origtextlist, fname, lname, delim ='<!@&>', window=False):
    
    #######################################################
    ################FUNCTION DEFINITIONS###################
    #######################################################
    #check if name is in sentences surrounding the sentence being processed (applied same way for entity and individual because all conditions are OR)  
        def name_in_sent(s1,s2,s3,fname,lname):
            return True if fname in s1 or fname in s2 or fname in s3 or (lname!='' and (lname in s1 or lname in s2 or lname in s3)) else False
    
    #extracts all sentences before and after the sentence being processed 
        def previous_and_next(some_iterable):
            prevs, items, nexts = tee(some_iterable, 3)
            prevs = chain([''], prevs)
            nexts = chain(islice(nexts, 1, None), [''])
            return zip(prevs, items, nexts) 

    ##################################################################
    ########################EXECUTION START###########################
    ##################################################################
    
    #pre-process the original text and assign it back to original text 
    #if text is not se object it is assumed to be long string 
        test = origtextlist
    
    #if the delimiter is not defined, then we assume the doc is already delimited in some way so we do not split the doucment further(until sentence tokenization)
        if delim !="":
            #process text for use in word embedding models 
            test2 = [x.split(delim) for x in test] #split based on custom delimiter
            test3 = [[y.replace('\n',' ') for y in x] for x in test2] #replace all new line characters 
            test4 = [[sent_tokenize(y)for y in x] for x in test3] #sentence tokenize remaining text 
            test5 = [[re.sub('[^A-Za-z ]+', ' ', y) for y in x[0]] for x in test4] #remove all numbers *SKETCH
            test6 = [[y.strip() for y in x if x] for x in test5] #strip trailing and leading white space 
            test7 = [[y for y in x if not y ==''] for x in test6] #remove blank strings from list of strings 
            test8 = [[y for y in x if len(y) > 9] for x in test7] #remove blank strings from list of strings 
            test81= [[re.sub("\.{2,}" , ".",y) for y in x ] for x in test8] #replace multiple period with single period
            test9 = [[re.sub(' +',' ',y) for y in x ] for x in test81] #replace multiple spaces with single space 
            test10 = [[y.lower() for y in x ] for x in test9] #replace multiple spaces with single space 
            
            #process text for output to pdf 
            origtext_delim = [x.split(delim) for x in test] #split based on custom delimiter
            origtext_delim = [[y.replace('\n',' ') for y in x] for x in origtext_delim] #replace all new line characters 
            origtext_delim = [[sent_tokenize(y)for y in x] for x in origtext_delim] #sentence tokenize remaining text 
            origtext_delim = [[y.strip() for y in x[0] if x[0]] for x in origtext_delim] #strip trailing and leading white space  *SKETCH
            origtext_delim = [[y for y in x if not y ==''] for x in origtext_delim] #remove blank strings from list of strings 
            origtext_delim= [[y for y in x if len(y) > 9] for x in origtext_delim] #remove blank strings from list of strings 
            origtext_delim= [[re.sub("\.{2,}" , ".",y) for y in x ] for x in origtext_delim] #replace multiple period with single period
            origtext_delim= [[re.sub(' +',' ',y) for y in x ] for x in origtext_delim] #replace multiple spaces with single space 
            origtext_delim= [[y.strip() for y in x if x] for x in origtext_delim] #strip trailing and leading white space 
    
        else: 
            #process text for use in word embedding models 
            test1 = test 
            test2 = [y.replace('\n',' ') for y in test1] #replace all new line characters 
            test3=  [re.sub(' +',' ',y) for y  in test2] #replace multiple spaces with single space 
            test4 = [sent_tokenize(y)for y in  test3] #sentence tokenize remaining text 
            test5 = [[re.sub('[^A-Za-z ]+', ' ', y) for y in x] for x in test4] #remove all numbers 
            test6 = [[y.strip() for y in x if x] for x in test5] #strip trailing and leading white space 
            test7 = [[y for y in x if not y ==''] for x in test6] #remove blank strings from list of strings 
            test8= [[y for y in x if len(y) > 9] for x in test7] #remove blank strings from list of strings 
            test81= [[re.sub("\.{2,}" , ".",y) for y in x ] for x in test8] #replace multiple periods with single period 
            test9= [[re.sub(' +',' ',y) for y in x ] for x in test81] #replace multiple spaces with single space 
            test10 = [[y.lower() for y in x ] for x in test9] #replace multiple spaces with single space 
            
            #process text for output to pdf 
            origtext_delim = [y.replace('\n',' ') for y in test1] #replace all new line characters 
            origtext_delim=  [re.sub(' +',' ',y) for y  in origtext_delim] #replace multiple spaces with single space 
            origtext_delim = [sent_tokenize(y)for y in  origtext_delim] #sentence tokenize remaining text 
            origtext_delim = [[y.strip() for y in x if x] for x in origtext_delim] #strip trailing and leading white space 
            origtext_delim = [[y for y in x if not y ==''] for x in origtext_delim] #remove blank strings from list of strings 
            origtext_delim= [[y for y in x if len(y) > 9] for x in origtext_delim] #remove blank strings from list of strings 
            origtext_delim= [[re.sub("\.{2,}" , ".",y) for y in x ] for x in origtext_delim] #replace multiple periods with single period 
            origtext_delim= [[re.sub(' +',' ',y) for y in x ] for x in origtext_delim] #replace multiple spaces with single space 
            
      
        #create list of original text with or without windowing depending on option specs
        origtext_delimlist = []
        for doc in origtext_delim:
            if window==False:
                origtext_delimlist.append(doc)
            if window==True: 
                origtext_delimlist.append([X[1] for X in list(previous_and_next(doc)) if name_in_sent(X[0].lower(),X[1].lower(),X[2].lower(),fname.lower(),lname.lower())])
        
        #identify window of sentences around teh first and last name of the individual being processed 
        test11= []
        for doc in test10:
            if window==True: 
                 #if the entity name is sound in the string 
                #extract the sentence before, the sentence, and the sentence after the sentence 
                test11.append([X[1] for X in list(previous_and_next(doc)) if name_in_sent(X[0].lower(),X[1].lower(),X[2].lower(),fname.lower(),lname.lower())])
            else: 
                test11.append(doc)
        return test11 , origtext_delimlist