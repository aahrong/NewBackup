# -*- coding: utf-8 -*-
"""
Created on Tue Jan 22 10:05:37 2019

@author: caridza
"""
import numpy as np 
import pandas as pd 
#https://jakevdp.github.io/PythonDataScienceHandbook/03.04-missing-values.html
#overview of missing data in python 
#Pandas chose to use sentinels for missing data, and further chose to use two already-existing Python null values: the special floating-point NaN value, and the Python None object.

#Representation of missing values with None
#None: Because it is a Python object, None cannot be used in any arbitrary NumPy/Pandas array, but only in arrays with data type 'object'
#Impact on Operations: any operations on the data will be done at the Python level, with much more overhead than the typically fast operations seen for arrays with native types:
#Impact on Aggregations: The use of Python objects in an array also means that if you perform aggregations like sum() or min() across an array with a None value you will get an error 
vals1 = np.array([1,None,3,4])
vals1.sum()

#Representation of missing values with NaN
#NaN:a special floating-point value recognized by all systems that use the standard IEEE floating-point representation
#Impact on Operations:  np chooses a native floating-point type for this array which supports fast operations pushed into compiled code.
#Impact on Aggregations: NaN is a bit like a data virus–it infects any other object it touches. Regardless of the operation, the result of arithmetic with NaN will be another NaN
#Impact on Aggregations: Aggregates over the values are well defined (i.e., they don't result in an error) but not always useful:
#Excluding Missing Data from Aggregations: NumPy does provide some special aggregations that will ignore these missing values np.nanmax(),np.nanmin(),np.nansum()
#WARNING: NaN is specifically a floating-point value; there is no equivalent NaN value for integers, strings, or other types.
vals2 = np.array([1, np.nan, 3, 4]) 
1 + np.nan
0* np.nan
vals2.sum(), vals2.min(), vals2.max()
np.nansum(vals2), np.nanmin(vals2), np.nanmax(vals2)


#NAN and None in Pandas 
# Pandas is built to handle the two of them nearly interchangeably, converting between them where appropriate
# For types that don't have an available sentinel value, Pandas automatically type-casts when NA values are present
# Ex.if we set a value in an integer array to np.nan, it will automatically be upcast to a floating-point type to accommodate the NA
# in addition to casting the integer array to floating point, Pandas automatically converts the None to a NaN
#Note: in Pandas string data is always stored with an object dtype
pd.Series([1, np.nan, 2, None])
x = pd.Series(range(2), dtype=int)
x
x[0]=None

#Opeating on NULL values 
#methods for detecting, removing, and replacing null values in Pandas data structures
#isnull(): Generate a boolean mask indicating missing values
#notnull(): Opposite of isnull()
#dropna(): Return a filtered version of the data
#fillna(): Return a copy of the data with missing values filled or imputed

########################
#detecting NULL values## 
########################
#Note:Boolean masks can be used directly as a Series or DataFrame index
data = pd.Series([1, np.nan, 'hello', None])
data.isnull()
#use mask to eliminate null data values 
data[data.notnull()]

########################
#dropping null values 
########################
df = pd.DataFrame([[1,      np.nan, 2],
                   [2,      3,      5],
                   [np.nan, 4,      6]])

#Note:dropna() will drop all rows in which any null value is present
df.dropna()
df.dropna(axis='columns') #drop all columns with any NA values 

#dropping data based on how much NA is present using how or thresh parameters
#defaults: how = 'any' : any row or column with Na will be dropped
#how = 'all': only drop rows/oclumns that are all Null values 
df.dropna(axis='columns', how='all')

#thresh: used to provide more granular control over what information is dropped from df based on NANs 
df.dropna(axis='rows',thresh =3) #drop all rows with 2 or more NA values 

########################
#Filling Null values####
########################
#Pandas provides the fillna() method, which returns a copy of the array with the null values replaced.
data = pd.Series([1, np.nan, 2, None, 3], index=list('abcde'))
data.fillna(0)

#specify forward or back fill to use the previous value in the row that is not NA as the NA value 
data.fillna(method='ffill')
data.fillna(method='bfill')
df.fillna(method='ffill', axis=1)

