# -*- coding: utf-8 -*-
"""
Created on Thu Apr 11 13:48:15 2019

@author: caridza
"""
#STEP1: IDENTIFY OUTLIERS USING ISOFOREST
#STEP2: VISUALIZE OUTLIERS USING PCA 

#ISOLATION FOREST 
#The IsolationForest ‘isolates’ observations by randomly selecting a feature and then randomly 
#selecting a split value between the maximum and minimum values of the selected feature.

#Since recursive partitioning can be represented by a tree structure, the number of splittings required to isolate 
#a sample is equivalent to the path length from the root node to the terminating node.

#This path length, averaged over a forest of such random trees, is a measure of normality and our decision function.

#OUTLIER CRITERA:Random partitioning produces noticeable shorter paths for anomalies. Hence, when a forest of random trees collectively
#produce shorter path lengths for particular samples, they are highly likely to be anomalies.
#NOTE: isolation forest selects features at random and splits the data at random
from sklearn.ensemble import IsolationForest
from collections import Counter

def isoforest_out(df =DocData,stratifyOn='entity',cols2exclude = ['keep','year','date','p_outlier,iqr_outlier,z_outlier','knn_outlier'],returnFull=True ):
    DocData_NO = df.copy()
    Row_idxs = []
    Row_idxs_info = []
    
    numcols = DocData_NO.describe().T.index
    numcols = [col for col in numcols if col not in cols2exclude]
    
    for i, ent in enumerate(DocData_NO[stratifyOn].unique()):
        df_sub =DocData_NO[DocData_NO[stratifyOn]==ent][numcols]
        X_train=X_test = df_sub
        
        clf = IsolationForest(n_jobs=6,n_estimators=500, max_samples=256, random_state=23)
        clf.fit(X_train)
        y_pred_train = clf.predict(X_train)
        df_sub['iso_outlier'] = y_pred_train
        print(ent,'/n ',Counter(y_pred_train))
        
        #identify the index of the row/col combination associated with each outlier 
        Row_idxs.append(df_sub[df_sub['iso_outlier']==-1].index.values)
        
    #create list of row indcies to remove across all groups  
    idxs2remove = list(set([item for sublist in Row_idxs for item in sublist]))

    if returnFull == False:
            DocData_NO.drop(idxs2remove, inplace=True)    
            print('Origal DF Shape:{}'.format(DocData_NO.shape),'/n','Outlier Removed DF Shape: {}'.format(DocData_NO.shape))

        #run if you want the entire df with an outlier column flagging outliers 
    else: 
            DocData_NO['iso_outlier'] = 0
            for idx in idxs2remove:
                DocData_NO.loc[idxs2remove, 'iso_outlier'] = 1
            print('Total Outliers Flagged:{}'.format(DocData_NO[DocData_NO['iso_outlier']==1].shape[0]))

    return(DocData_NO)

DocData = isoforest_out(df =DocData,stratifyOn='entity',cols2exclude = ['keep','year','date','p_outlier,iqr_outlier,z_outlier','knn_outlier'],returnFull=True )
#PCA
###EXPLORING OUTLIERS FROM ISOLATION FOREST THROUGH PCA 
import numpy as np 
from sklearn.decomposition import PCA 
import matplotlib.pyplot as plt
rng = np.random.RandomState(1)
X =DocData[DocData['entity']=='Wells Fargo'][numcols]#.to_numpy(copy=True)

#fit pca
pca=PCA(3)
projected = pca.fit_transform(X)
#pca = PCA().fit(X)

#cumulative variance explained by PC 
plt.plot(np.cumsum(pca.explained_variance_ratio_))
plt.xlabel('number of components');plt.ylabel('cumulative explained variance');plt.show()

#join the pca projections to original data
X = X.assign(pc1 = projected[:,0],pc2 =projected[:,1],pc3 = projected[:,2])
X['univ_outlier']=DocData[DocData['entity']=='Wells Fargo'].apply(lambda x: min(1,x.p_outlier + x.z_outlier), axis=1)
X['multiv_outlier']=DocData[DocData['entity']=='Wells Fargo'].apply(lambda x: min(1,x.iso_outlier + x.knn_outlier), axis=1)

outlier2use = 'multiv_outlier'

#plot the principle components
for i in range(0,len(projected.T)):
    if i!=0:
        plt.scatter(projected[:, 0], projected[:, i],
                    c=X[outlier2use], edgecolor='none', alpha=0.5,
                    cmap=plt.cm.get_cmap('Spectral', 2))

        plt.xlabel('component {}'.format(0))
        plt.ylabel('component {}'.format(i))
        plt.colorbar()
        plt.show()
    if i==0:
        for j in [0,2]:
            plt.scatter(projected[:, 1], projected[:, j],
                        c=X[outlier2use], edgecolor='none', alpha=0.5,
                        cmap=plt.cm.get_cmap('Spectral', 2))

            plt.xlabel('component {}'.format(1))
            plt.ylabel('component {}'.format(j))
            plt.colorbar()
            plt.show()
            
plotting_3d(x=projected[:, 0],y=projected[:, 1],z=projected[:, 2],color=X[outlier2use])





pca = PCA(n_components=2, svd_solver = 'full')
pca.fit(X[:,[0,1]])
print(pca.explained_variance_ratio_) 
print(pca.singular_values_)  
print(pca.components_ )

def draw_vector(v0, v1, ax=None):
    ax = ax or plt.gca()
    arrowprops=dict(arrowstyle='->',
                    linewidth=2,
                    shrinkA=0, shrinkB=0)
    ax.annotate('', v1, v0, arrowprops=arrowprops)

# plot data
plt.scatter(X[:,0], X[:,1], alpha=0.2)
plt.scatter(X_pca[:,0], X_pca[:,1], alpha=0.2)

for length, vector in zip(pca.explained_variance_, pca.components_):
    v = vector * 3 * np.sqrt(length)
    draw_vector(pca.mean_, pca.mean_ + v)
#plt.axis('equal');
    
    
    

def plotting_3d(x=projected[:, 0],y=projected[:, 1],z=projected[:, 2],color=X['iso_outlier']):
    # Import dependencies
    import plotly
    import plotly.graph_objs as go

    # Configure Plotly to be rendered inline in the notebook.
    plotly.offline.init_notebook_mode()

    # Configure the trace.
    trace = go.Scatter3d(
        x=x,
        y=y,
        z=z,
        mode='markers',
        marker={
            'color':color,
            'colorscale':'Viridis',
            'size': 10,
            'opacity': 0.8,
        },

    )

    # Configure the layout.
    layout = go.Layout(
        margin={'l': 0, 'r': 0, 'b': 0, 't': 0}
    )

    data = [trace]
    plot_figure = go.Figure(data=data, layout=layout)

    # Render the plot.
    plotly.offline.iplot(plot_figure)
