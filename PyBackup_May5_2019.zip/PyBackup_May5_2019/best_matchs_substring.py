# -*- coding: utf-8 -*-
"""
Created on Mon Dec 10 10:15:23 2018

@author: caridza
"""

from difflib import SequenceMatcher
import sys
from functools import reduce
import re
import numpy as np
import pandas as pd
from nltk import word_tokenize
from nltk import edit_distance
from nltk.stem.snowball import SnowballStemmer
import json_lines
import spacy
import pickle
from xlrd import XLRDError
from pickle import UnpicklingError
from fuzzywuzzy import process
import logging
from collections import defaultdict


entity_name='Wells Fargo'
known_alias = {'CitiGroup':('citi','citigroup','citi group')
               ,'Wells Fargo':('wells fargo','wellsfargo','wfs','wells')} #ref first known alias tied to citi : known_alias['citi'][1]

entity_dict = load_entity_dict('C:\\Users\\caridza\\Downloads\\WPy32-3662\\ZacksScripts\\entity_dict.pickle')
nlp = spacy.load('en_core_web_sm')

title = 'wells fargo bank has been fined $1000.00 for corruption. wells fargo has pleaded guilty to fraud'
content= ['citi was found dead near the group and then Citigroup was fined $200 million','wells fargo bank has been fined $100 million for corruption and wells fargo was fined $392 million for trafficing, and they will now be placed on jail leave rulling','They cannot interact with Merril lynch','Bank of America got fined $30 million and Wells Fargo was safe and only fined $10 million','the $10 million dollar fine is an issue for Wells Fargo','Wells Fargo claims the $392 million fine was not merrited']
content_str= '.'.join(content)

summary = ['wells fargo was fined january 12 2018 for malpractice of loan']

#count total occurances of entity name in string(and any knwon aliasses)
#list of strings version 
totalcounts=max([[content[i].lower().count(x.lower()) for i in range(0,len(content))] for x in known_alias[entity_name]])
entsindoc=sum(totalcounts)

#string version 
totalcountsstr=max([content_str.lower().count(x.lower()) for x in known_alias[entity_name]])

#fines in title
finesInTitle= [generate_report_tuple(title, entity_name = entity_name, content = ''.join(content[i]), entity_dict = entity_dict, nlp = nlp, default_pickle_path = 'entity_dict.pickle', verbose = False, debug = False) for i in range(0,len(content))]
objective_ouput_set = {item for item in finesInTitle}





    
def generate_report_tuple(title, entity_name = '', content = '', entity_dict = None, tagged_text = None, nlp = None, default_pickle_path = 'entity_dict.pickle', verbose = False, debug = False):
    """Generates a fine report string from an article title
    
    Arguments:
        title {str} -- article title text for which to generate fine report
    
    Keyword Arguments:
        entity_name {str} -- an optional entity name with which we will perform a naive search
                             if the spaCy NER tagger does not find this name first. this parameter essentially
                             acts as a fail safe to try to patch any obvious errors in the spaCy NER tagger (default: {''})
        entity_dict {dict} -- entity dictionary utilized to perform fuzzy lookup (default: {None})
        tagged_text {spaCy.Doc} -- spaCy-processed article text (default: {None})
        nlp {spaCy.English} -- if tagged_text is not provided, utilized to create spaCy.Doc object from title (default: {None})
        default_pickle_path {str} -- if no entity_dict provided, default path at which to look for entity_dict pickle (default: {'entity_dict.pickle'})
        verbose {bool} -- if True, include NO_FINE_INFORMATION results. otherwise, exclude NO_FINE_INFORMATION results (default: {False})
        debug {bool} -- if True, generate log file (default: {False})
    Raises:
        Exception
    
    Returns:
        list -- a list of strings representing the fine report
    """
    if entity_dict is None:
        try:
            entity_dict = load_entity_dict(default_pickle_path)
        except FileNotFoundError:
            raise Exception("Entity dictionary could not be loaded from pickle at path: {}.".format(default_pickle_path))

    if nlp is not None:
        company_tokens = word_tokenize(content)
        tagged_text = nlp(transform_article_title(title, company_tokens))
    elif tagged_text is None: 
        raise Exception("Either tagged_text or nlp argument must be provided.")

    orgs_from_title, total_fine, generate_flag = get_data_from_article_title(entity_dict, tagged_text, entity_name=entity_name)
    
    return ','.join(orgs_from_title), total_fine, generate_flag 

















######NEXT STEPS: POC##############

#fines in sentence (note it adds all fines up from each sentence)
finesInTitle=[]
finesInTitle= [generate_report_tuple(title, entity_name = entity_name, content = ''.join(content[i]), entity_dict = entity_dict, nlp = nlp, default_pickle_path = 'entity_dict.pickle', verbose = False, debug = False) for i in range(0,len(content))]
finesInTitle= [generate_report_tuple(title, entity_name = entity_name, entity_dict = entity_dict, nlp = nlp, default_pickle_path = 'entity_dict.pickle', verbose = False, debug = False)]

generate_report_tuple(' '.join(content), entity_name = entity_name
, entity_dict = entity_dict, nlp = nlp, default_pickle_path = 'entity_dict.pickle', verbose = False, debug = False)
finesIncontent=[]
finesIncontent= [generate_report_tuple(x, entity_name = entity_name
                                     , entity_dict = entity_dict, nlp = nlp
                                     , default_pickle_path = 'entity_dict.pickle', verbose = False, debug = False) for x in content]


finesIncontent= [generate_report_tuple(content[i], entity_name = entity_name
                                     , entity_dict = entity_dict, nlp = nlp
                                     , default_pickle_path = 'entity_dict.pickle', verbose = False, debug = False) for i in range(0,len(content))]


tagged_text = nlp(transform_article_title(' '.join(content).lower(), word_tokenize(entity_name.lower())))

