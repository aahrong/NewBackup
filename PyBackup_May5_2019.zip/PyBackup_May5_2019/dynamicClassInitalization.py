# -*- coding: utf-8 -*-
"""
Created on Tue Dec  4 15:01:04 2018

@author: caridza
"""


import datetime
import pickle

#KYC METADATA CLASS
#NOTE: SAVE helper functions save_obj and load_obj in unique module
#mixed dictonary and positional 
#for each kwarg defined, we add that kward to the attributes assoicated with the class, both there attribute name and value are sourced 
#from the input parameters passed to the function(they can be anything!)
class kyc_meta(object):
    
    def __init__(self, **kwargs):
        for key in kwargs:
            setattr(self, key, kwargs[key])
        saved_args = locals()
        print(saved_args)    
    
    def savemeta(self,path="C:\\Users\\caridza\\Downloads\\WPy-3662\\tempdata\\"):
        '''
         #extract stored parameter values from class dict
         #identify the value associated with the runid key in the dictonary 
         #save the metadata dictonary down to pickle
        '''
        d = {} 
        for key,value in self.__dict__.items():
            d.update({key:value})   
            
        ent = self.__dict__.get('runid')        
        file=save_obj(path,d,'{}_{}'.format('kyc_metadic',ent))
        return(file)
        
    def getmeta(runid,path="C:\\Users\\caridza\\Downloads\\WPy-3662\\tempdata\\"):

        meta_dic= load_obj(path,'{}_{}'.format('kyc_metadic',runid)) 
        return(meta_dic)
    
    def save_obj(path,obj, name ):
        with open(path + name + '.pkl', 'wb') as f:
            pickle.dump(obj, f, pickle.HIGHEST_PROTOCOL)
            return(f)
    
    def load_obj(path, name ):
        with open(path + name + '.pkl', 'rb') as f:
            return pickle.load(f)
    
    
#CLASS USAGE
#you can reference a mix of attributes, but they are saved in different obejcts *initial_data vs **Kwargs
kycmeta=kyc_meta({'runid':1032,'date':datetime.datetime.now()},entity_name='jim jones', kycORci='KYC')
kycmeta=kyc_meta(runid=1032,date=datetime.datetime.now(),entity_name='jim jones', kycORci='KYC')
kyc=kycmeta.savemeta(path="C:\\Users\\caridza\\Downloads\\WPy-3662\\Data\\")
kyc_dat = kycmeta.getmeta(path="C:\\Users\\caridza\\Downloads\\WPy-3662\\Data\\")





################################################
#ALTERNATE APPROACHES TO INIALIZING VARIABELS###
################################################

import datetime
class kyc_meta():
    def __init__(self, *initial_data, **kwargs):
        for key, value in initial_data.items():
            self.__dict__.update({key: value})
 
    def get(self,**kwargs):
        return(self.entity_name)
        
        
#substationating inputs from a dictonary
class kyc_meta():
    def __init__(self, initial_data, **kwargs):
        for key, value in initial_data.items():
            self.__dict__.update({key: value})
 
    def get(self,**kwargs):
        return(self.entity_name)


#mixed dictonary and positional 
class kyc_meta(object):
    def __init__(self, *initial_data, **kwargs):
        for dictionary in initial_data:
            for key in dictionary:
                setattr(self, key, dictionary[key])
        for key in kwargs:
            setattr(self, key, kwargs[key])
        
        
        saved_args = locals()
        print(saved_args)    
        
    def get(self,**kwargs):
        saved_args = locals()
        print(saved_args)
        out=[getattr(self,key,None) for key in kwargs]
        return(out)
