# -*- coding: utf-8 -*-
"""
Created on Wed Feb  6 13:39:39 2019

@author: caridza
"""

##ASYNC IO 
#https://realpython.com/async-io-python/

'''KEY CONCEPTS'''
#Asynchronous IO (async IO): a language-agnostic paradigm (model) that has implementations across a host of programming languages
#async/await: two new Python keywords that are used to define coroutines
#asyncio: the Python package that provides a foundation and API for running and managing coroutines

'''SHELL COMMANDS FOR INSTALLING AND ACTIVATING VM'''
#python3.7 -m venv ./py37async
#source ./py37async/bin/activate  # Windows: .\py37async\Scripts\activate.bat
#pip install --upgrade pip aiohttp aiofiles  # Optional: aiodns

'''ASync IO Core Functionalty'''
#Async IO leverages cooperative multitasking , which means that a program’s event loop (more on that later) communicates with multiple tasks to let each take turns running at the optimal time.
#Async IO takes long waiting periods in which functions would otherwise be blocking and allows other functions to run during that downtime.

'''async/await Syntax and Native Coroutines'''
#At the heart of async IO are coroutines. 
#A coroutine is a specialized version of a Python generator function. A coroutine is a function that can suspend its execution before reaching return
#and it can indirectly pass control to another coroutine for some time.

'''RULES: When you can and cannot use async/await'''


'''FIRST EXAMPLE'''
import asyncio

async def count():
    print("One")
    await asyncio.sleep(1)
    print("Two")

async def main():
    await asyncio.gather(count(), count(), count())

if __name__ == "__main__":
    import time
    s = time.perf_counter()
    asyncio.run(main())
    elapsed = time.perf_counter() - s
    print(f"{__file__} executed in {elapsed:0.2f} seconds.")
    
    
'''FIRST EXAMPLE EXPLAINED'''
#Note: Save example to .py and execute from shell
#The order of this output is the heart of async IO. 
#Talking to each of the calls to count() is a single event loop, or coordinator. gather() is acting as the event loop/cordinator in the above 
#When each task reaches await asyncio.sleep(1), the function yells up to the event loop and gives control back to it,
#saying, “I’m going to be sleeping for 1 second. Go ahead and let something else meaningful be done in the meantime.”
#Note:the benefit of awaiting something, including asyncio.sleep(), is that the surrounding function can temporarily cede control 
#to another function that’s more readily able to do something immediately
#WARNING: BLOCKING calls are not compatable with asyncIO code becuase they prevent the coordinator from initializing a new processes on the same thread (becuase its blocking until complete)

    
'''async/await Deffinitions'''
# The syntax async def introduces either a native coroutine or an asynchronous generator.
# The expressions async with and async for are also valid, and you’ll see them later on.
# The keyword await passes function control back to the event loop. (It suspends the execution of the surrounding coroutine.) 
# If Python encounters an await f() expression in the scope of g(), this is how await tells the event loop,
# “Suspend execution of g() until whatever I’m waiting on—the result of f()—is returned. In the meantime, go let something else run.”
#In code, that looks roughly like this:
async def g():
    # Pause here and come back to g() when f() is ready
    r = await f()
    return r



'''rules of async/await'''
#1.A function that you introduce with async def is a coroutine. It may use await, return, or yield, but all of these are optional
#2.Using await and/or return creates a coroutine function. To call a coroutine function, you must await it to get its results.
#3.Anything defined with async def may not use yield from
#4.it is a SyntaxError to use await outside of an async def coroutine. You can only use await in the body of coroutines.
#examples of above rules
async def f(x):
    y = await z(x)  # OK - `await` and `return` allowed in coroutines
    return y

async def g(x):
    yield x  # OK - this is an async generator

async def m(x):
    yield from gen(x)  # No - SyntaxError

def m(x):
    y = await z(x)  # Still no - SyntaxError (no `async def` here)
    return y


'''Example 2'''
#!/usr/bin/env python3
# rand.py

import asyncio
import random

# ANSI colors
c = (
    "\033[0m",   # End of color
    "\033[36m",  # Cyan
    "\033[91m",  # Red
    "\033[35m",  # Magenta
)

async def randint(a: int, b: int) -> int:
    return random.randint(a, b)

#MAIN COROUTINE
async def makerandom(idx: int, threshold: int = 6) -> int:
    print(c[idx + 1] + f"Initiated makerandom({idx}).")
    i = await randint(0, 10)
    while i <= threshold:
        print(c[idx + 1] + f"makerandom({idx}) == {i} too low; retrying.")
        await asyncio.sleep(idx + 1)
        i = await randint(0, 10)
    print(c[idx + 1] + f"---> Finished: makerandom({idx}) == {i}" + c[0])
    return i

#RUNs COROUTINE concurrently across 3 different inputs 
async def main():
    res = await asyncio.gather(*(makerandom(i, 10 - i - 1) for i in range(3)))
    return res

if __name__ == "__main__":
    random.seed(444)
    r1, r2, r3 = asyncio.run(main())
    print()
    print(f"r1: {r1}, r2: {r2}, r3: {r3}")


'''Example 2 Explained'''
#Most programs will contain small, modular coroutines and one wrapper function that serves to chain each of the smaller coroutines together
# main() is then used to gather tasks (futures) by mapping the central coroutine across some iterable or pool(range(3) in the example above)
















    