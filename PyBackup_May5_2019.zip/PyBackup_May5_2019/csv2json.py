# -*- coding: utf-8 -*-
"""
Created on Tue Dec  4 08:41:08 2018

@author: caridza
"""
import csv  
import json  
import os 

#testing functionality
#test = csv2json(path,file,suffix)
#test2 = pd_csv2json(path,file,suffix)

# Open the CSV  
path = 'C://Users//caridza//Desktop//EY//AI//COE//AA COE//NegNews'
file = "testcsv"
suffix = ".csv"

#csv2json using DictReader
def csv2json(path,file,suffix):
    with open( os.path.join(path,file+suffix), 'r' ) as f:
        reader = csv.DictReader( f, fieldnames = ( "Name","EntityType","State","Employer" ))
        next(reader,None) #skip header when reading in csv 
        out = json.dumps( [row for row in reader])
        #remove lsit syntax from string of jsons
        out2 = out[1:-1]
        return(out2)

#csv 2 json using pandas wrappers
def pd_csv2json(path,file,suffix):
    df = pd.read_csv(os.path.join(path,file+suffix), na_values=[''])
    json = df.to_json( orient='records')
    output= json[1:-1]
    return output

#manually parse csv into json using dictonaries
with open( os.path.join(path,file+suffix), 'rb' ) as f:
    ff = f.read()
    text = ff.decode(encoding='utf-8',errors='ignore')
    lines = text.split("\n")

    #initialize empty dictonary 
    inputdic ={}
    
    #fill the dictonary 
    for num, line in enumerate(lines):
        #split lines
        l=line.strip().split("\t")

        if num==0:
            #get names of feild headers
            names = l[0].split(',')
        
        else:
            #get values of feilds
            lineval = l[0].split(',')
            
            #check total values in list == total feilds in headers
            if len(lineval)==len(names):
                #dic comprehension to populate the values for each key(row)
                inputdic[str(num)] = {names[i]:lineval[i] for i in range(len(names))}
      


