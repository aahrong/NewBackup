'''
This file contains all code necessary for performing Negative News database operations.
'''

import logging
import os

from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import MongoClient

logger = logging.getLogger(__name__)

# sets the MongoDB host and port based on
# whether the execution occurs within Docker
# or in the native environment
if os.environ.get("IS_DOCKER", False):
    MONGO_ADDRESS = "mongodb://mongodb:27017"
else:
    MONGO_ADDRESS = "127.0.0.1:27017"


class BaseRecordWriter:
    '''Base class for wrapping basic database operations'''
    def __init__(self):
        raise NotImplementedError

    async def insert_one(self, record):
        raise NotImplementedError

    async def insert_many(self, records):
        raise NotImplementedError

    async def find_one(self, criteria):
        raise NotImplementedError

    async def find(self, criteria):
        raise NotImplementedError

    async def delete_many(self, criteria):
        raise NotImplementedError


class AsyncRecordWriter(BaseRecordWriter):
    '''Implementation for asynchronous database actions'''
    def __init__(self, handle):
        self.handle = handle

    async def insert_one(self, record):
        return await self.handle.insert_one(record)

    async def insert_many(self, records, **kwargs):
        return await self.handle.insert_many(records, **kwargs)

    async def find_one(self, criteria):
        return await self.handle.find_one(criteria)

    async def find(self, criteria, *args):
        return await self.handle.find(criteria, *args).to_list(None)

    async def delete_many(self, criteria):
        return await self.handle.delete_many(criteria)


class SyncRecordWriter(BaseRecordWriter):
    '''Implementation for synchronous database actions'''
    def __init__(self, handle):
        self.handle = handle

    def insert_one(self, record):
        return self.handle.insert_one(record)

    def insert_many(self, records, **kwargs):
        return self.handle.insert_many(records, **kwargs)

    def find_one(self, criteria):
        return self.handle.find_one(criteria)

    def find(self, criteria, *args):
        return list(self.handle.find(criteria, *args))

    def delete_many(self, criteria):
        return self.handle.delete_many(criteria)


def get_scrape_feed_handle(loop=None):
    '''Retrieves handle for scrape feed collection'''
    logger.debug("Creating handle for 'scrape_feed' .. ")

    if loop is None:
        return SyncRecordWriter(MongoClient(MONGO_ADDRESS)["negative_news"]["scrape_feed"])
    else:
        return AsyncRecordWriter(AsyncIOMotorClient(MONGO_ADDRESS, io_loop=loop)["negative_news"]["scrape_feed"])


def get_processed_results_handle(loop=None):
    '''Retrieves handle for processed results collection'''
    logger.debug("Creating handle for 'processed_results' .. ")

    if loop is None:
        return SyncRecordWriter(MongoClient(MONGO_ADDRESS)["negative_news"]["processed_results"])
    else:
        return AsyncRecordWriter(AsyncIOMotorClient(MONGO_ADDRESS, io_loop=loop)["negative_news"]["processed_results"])


def get_rss_feed_handle(loop=None):
    '''Retrieves handle for RSS feed data'''
    logger.debug("Creating handle for 'rss_feed' .. ")

    if loop is None:
        return SyncRecordWriter(MongoClient(MONGO_ADDRESS)["negative_news"]["rss_feed"])
    else:
        return AsyncRecordWriter(AsyncIOMotorClient(MONGO_ADDRESS, io_loop=loop)["negative_news"]["rss_feed"])


def get_bc_owners_feed_handle(loop=None):
    '''Retrieves handle for FINRA Broker Check direct owners and executives'''
    logger.debug("Creating handle for 'broker_check_owners' feed .. ")

    if loop is None:
        return SyncRecordWriter(MongoClient(MONGO_ADDRESS)["negative_news"]["broker_check_owners"])
    else:
        return AsyncRecordWriter(AsyncIOMotorClient(MONGO_ADDRESS, io_loop=loop)["negative_news"]["broker_check_owners"])


def get_bc_disclosures_feed_handle(loop=None):
    '''Retrieves handle for FINRA Broker Check disclosures'''
    logger.debug("Creating handle for 'broker_check_disclosures' feed .. ")

    if loop is None:
        return SyncRecordWriter(MongoClient(MONGO_ADDRESS)["negative_news"]["broker_check_disclosures"])
    else:
        return AsyncRecordWriter(AsyncIOMotorClient(MONGO_ADDRESS, io_loop=loop)["negative_news"]["broker_check_disclosures"])


def get_bc_meta_feed_handle(loop=None):
    '''Retrieves handle for the FINRA Broker Check metadata'''
    logger.debug("Creating handle for 'broker_check_meta' .. ")

    if loop is None:
        return SyncRecordWriter(MongoClient(MONGO_ADDRESS)["negative_news"]["broker_check_meta"])
    else:
        return AsyncRecordWriter(AsyncIOMotorClient(MONGO_ADDRESS, io_loop=loop)["negative_news"]["broker_check_meta"])
