import logging.config

import pkg_resources
import yaml

fname = pkg_resources.resource_filename(__package__, "logging/logging.yaml")
with open(fname, "rb") as f:
    config = yaml.load(f)
logging.config.dictConfig(config)

logging.getLogger("readability.readability").setLevel(logging.WARNING)
logging.getLogger("articleDateExtractor").setLevel(logging.WARNING)
logging.getLogger("chardet.charsetprober").setLevel(logging.WARNING)
