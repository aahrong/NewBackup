'''
This file contains the Flask application code for Negative News.
'''

import asyncio
from datetime import datetime
import os
import glob
import logging

from flask import Flask, render_template, request, Response, abort
import pandas as pd

from .manager import NegativeNewsManager
from .entity_job import NegativeNewsEntityJob
from .entity_search import NegativeNewsEntitySearch
from .scrapers.general_search import BingAPIScraper
from .scrapers.newsapi import NewsAPIScraper, DEFAULT_NEWS_SOURCES
from .scrapers.regulatory import RegulatoryScraper

app = Flask(__name__, static_folder="gui/static", template_folder="gui/templates")
logger = logging.getLogger(__name__)

# Manager object that facilitates end-to-end Negative News process
manager = NegativeNewsManager()

# Address at which to host Flask application
FLASK_HOST = "0.0.0.0"

# Port on which to host Flask application
FLASK_PORT = 6007

# Status to send for a bad download request
BAD_REQUEST_STATUS = 404

# Path at which to store run output
OUTPUT_PATH = f"{os.path.dirname(__file__)}/output"

# Default number of request batches that each scraper will make
DEFAULT_MAX_REQUESTS = 2


@app.route("/")
@app.route("/schedule")
def home():
    '''Endpoint for Negative News scheduling GUI'''
    return render_template("schedule.html")


@app.route("/monitor")
def monitor():
    '''Endpoint for Negative News monitoring GUI'''
    table = construct_table_html(manager.get_job_info())
    return render_template("monitor.html", table=table)


@app.route("/analytics")
def analytics():
    '''Endpoint for Negative News analytics GUI'''
    return render_template("schedule.html")


@app.route("/engine")
def schedule():
    '''Endpoint that starts Negative News process'''
    job = create_job_from_dict(request.args)
    manager.add_job(job)

    loop = asyncio.new_event_loop()
    loop.run_until_complete(manager.async_start())

    fpath_pdf = glob.glob(f"{job.postprocess_kwargs['output_path']}*.docx")[0][1:]

    return fpath_pdf


@app.route("/download/<path:fpath>")
def download_output(fpath):
    '''Endpoint that allows PDF/DOCX downloads'''
    if fpath.endswith(".docx"):
        mimetype = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    elif fpath.endswith(".pdf"):
        mimetype = "application/pdf"
    else:
        abort(BAD_REQUEST_STATUS)

    return Response(open("/" + fpath, "rb").read(), mimetype=mimetype)


def create_job_from_dict(args_dict):
    '''Creates a NegativeNewsEntityJob object from a dictionary'''

    # grab language
    language_abbrv = "EN"

    # grab max sentiment
    max_sentiment = args_dict.get("maxsentslider", default=0.0, type=float)

    # grab minimum similarity
    min_similarity = args_dict.get("minsemslider", default=0.1, type=float)

    # grab search terms
    default_search_terms = args_dict.get("dsearchterms", default="", type=str).split(",")
    custom_search_terms = args_dict.get("csearchterms", default="", type=str).split(",")
    search_term_list = default_search_terms + custom_search_terms

    # grab search result threshold
    max_search_results = args_dict.get("searchresullimiter", default=100, type=int)

    # grab minimum year and minimum month
    yearsubset = args_dict.get("yearsubset", default="", type=str)
    yearsubset = yearsubset.split("-") if yearsubset != "" else ["", ""]
    min_year = int(yearsubset[0]) if yearsubset[0] != "" else 2000
    min_month = int(yearsubset[1]) if yearsubset[0] != "" else 1

    # grab news sources for NewsAPI
    allowed_sources_list = args_dict.get("newssource", default="", type=str).split(",")
    allowed_sources_list = list(filter(lambda source: source != "", allowed_sources_list))

    # grab entity details
    is_org = args_dict.get("isorg", default=1, type=int)
    entity_name = args_dict.get("entityname", default="", type=str).split(",")[0]
    known_aliases_list = args_dict.get("entityaliasname", default="", type=str).split(",")
    known_aliases_list = list(filter(lambda alias: alias != "", known_aliases_list))
    employment = args_dict.get("company", default="", type=str)
    crd = args_dict.get("crd", default="", type=str)

    if is_org:
        location = args_dict.get("baddress", default="", type=str)
    else:
        location = " ".join(
            [
                args_dict.get("city", default="", type=str),
                args_dict.get("state", default="", type=str),
                args_dict.get("entityaddress", default="", type=str),
            ]
        )

    # set run date and job name
    run_datetime = str(datetime.strftime(datetime.utcnow(), "%m-%d-%y-%H-%M-%S"))
    job_name = f"{entity_name}_{run_datetime}"

    # list to hold search objects for
    # each search object is responsible for querying
    # a different type of source (e.g., Bing API, NewsAPI, etc.)
    search_obj_list = []

    # append search object for querying Bing search API
    search_obj_list.append(
        NegativeNewsEntitySearch(
            BingAPIScraper,
            entity_name,
            job_name=job_name,
            known_aliases_list=known_aliases_list,
            search_term_list=search_term_list,
            max_requests=DEFAULT_MAX_REQUESTS,
        )
    )

    # append search object for querying NewsAPI
    search_obj_list.append(
        NegativeNewsEntitySearch(
            NewsAPIScraper,
            entity_name,
            job_name=job_name,
            known_aliases_list=known_aliases_list,
            search_term_list=search_term_list,
            allowed_sources_list=DEFAULT_NEWS_SOURCES,
            max_requests=DEFAULT_MAX_REQUESTS,
        )
    )

    # if the entity represents an organization, append a search object
    # for scraping regulatory sources from Bing
    if is_org:
        search_obj_list.append(
            NegativeNewsEntitySearch(
                RegulatoryScraper,
                entity_name,
                job_name=job_name,
                known_aliases_list=known_aliases_list,
                search_term_list=search_term_list,
                allowed_sources_list=allowed_sources_list,
                max_requests=DEFAULT_MAX_REQUESTS,
            )
        )

    # path at which to store final Negative News reports and
    # any intermediate products
    output_path = f"{OUTPUT_PATH}/{run_datetime}/{job_name}/"

    # this dictionary of keyword arguments will be leveraged to
    # perform processing on scraped data
    postprocess_kwargs = {
        "is_org": is_org,
        "max_sentiment": max_sentiment,
        "min_year": min_year,
        "min_month": min_month,
        "min_similarity": min_similarity,
        "search_terms": search_term_list,
        "max_search_results": max_search_results,
        "output_path": output_path,
        "entity_name": entity_name,
        "entity_name_translated": entity_name,
        "known_aliases": known_aliases_list,
        "language_abbrv": language_abbrv,
        "location": location,
        "employment": employment,
        "crd": crd,
    }

    # job to manage the search process for the specified entity
    entity_job = NegativeNewsEntityJob(job_name, run_datetime, search_obj_list, postprocess_kwargs)

    return entity_job


def construct_table_html(dict_list=None):
    '''Utility function that creates an HTML table from a Pandas dataframe'''
    df = pd.DataFrame(dict_list)
    df.index.rename("Row", inplace=True)
    df.columns = [col.replace("_", " ").title() for col in df.columns]
    pd.set_option("display.max_colwidth", -1)
    return df.to_html(classes="table table-striped table-bordered", table_id="postpro", index_names=False, escape=False)


if __name__ == "__main__":
    app.run(host=FLASK_HOST, port=FLASK_PORT, debug=True)
