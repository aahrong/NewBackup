import re
import binascii
import random
from collections import defaultdict

PUNCTUATION = re.compile(r"[\.!?,:;]\s|[()]")
MAX_SHINGLE_ID = (2 ** 32) - 1
NEXT_PRIME = 4294967311

DEFAULT_SHINGLE_LEN = 3
DEFAULT_DUPE_SIM_THRESHOLD = 0.8
DEFAULT_NUM_HASHES = 50


class MinHash:
    """Class for modularizing minhash algorithm

    Arguments:
        docs {list} -- list of strings representing the documents to compare

    Keyword Arguments:
        threshold {int} -- similarity threshold to utilize for flagging duplicates (default: {DEFAULT_DUPE_SIM_THRESHOLD})
        num_hashes {int} -- number of hash functions to utilize (default: {DEFAULT_NUM_HASHES})
        shingle_len {int} -- length of shingles to utilize (default: {DEFAULT_SHINGLE_LEN})

    Attributes:
        docs {list} -- list of strings representing the documents to compare
        hash_funcs {list} -- list of randomly generated hash functions utilized to compute hash values from shingle ids
        shingle_ids {list} -- list of hashed shingles representing the n-grams or shingle tuples from each document
        minhash_sigs {list} -- list of minimum hash values for each document computed from the shingle ids for each hash function
        dupe_dict {collections.defaultdict} -- dictionary storing duplicate document indices for each document index
                                               for which duplicate documents exist
        idx_to_remove {list} -- list of duplicate document indexes
    """

    def __init__(self, docs, threshold=DEFAULT_DUPE_SIM_THRESHOLD, num_hashes=DEFAULT_NUM_HASHES, shingle_len=DEFAULT_SHINGLE_LEN):
        """Initializes MinHash object

        Arguments:
            docs {list} -- list of strings representing the documents to compare

        Keyword Arguments:
            threshold {int} -- similarity threshold to utilize for flagging duplicates (default: {DEFAULT_DUPE_SIM_THRESHOLD})
            num_hashes {int} -- number of hash functions to utilize (default: {DEFAULT_NUM_HASHES})
            shingle_len {int} -- length of shingles to utilize (default: {DEFAULT_SHINGLE_LEN})
        """

        self.docs = docs
        self.hash_funcs = self.generate_hash_functions(num_hashes)
        self.shingle_ids = [set(self.get_shingle_ids(shingle_len, d)) for d in docs]
        self.minhash_sigs = [self.get_minhash_signatures(ids_, self.hash_funcs) for ids_ in self.shingle_ids]
        self.dupe_dict = defaultdict(list)

        for i in range(0, len(self.docs)):
            for j in range(i + 1, len(self.docs)):
                count = sum([self.minhash_sigs[i][k] == self.minhash_sigs[j][k] for k in range(0, num_hashes)])

                sim = count / num_hashes

                if sim >= threshold:
                    self.dupe_dict[i].append(j)

        self.idx_to_remove = list(set([idx for idx_list in self.dupe_dict.values() for idx in idx_list]))

    def generate_random_coeff(self, num_coeff, seed=0):
        """Returns a list of random integer coefficients

        Arguments:
            num_coeff {int} -- number of unique random integer coefficients to return

        Keyword Arguments:
            seed {int} -- for testing purposes, seed value to provide to random number generator (default: {0})

        Returns:
            list -- list of random integer coefficients between 0 and the MAX_SHINGLE_ID (2**32 - 1)
        """

        coeff = set()

        if seed != 0:
            random.seed(seed)

        while len(coeff) != num_coeff:
            coeff.add(random.randint(0, MAX_SHINGLE_ID))

        return list(coeff)

    def generate_hash_functions(self, n_hashes):
        """Returns a list of randomly generated hash functions

        Arguments:
            n_hashes {int} -- number of hash functions to return

        Returns:
            list -- randomly generated hash functions as lambdas
        """

        coeff_A = self.generate_random_coeff(n_hashes)
        coeff_B = self.generate_random_coeff(n_hashes)
        return [(lambda i: lambda x: sum([coeff_A[i] * x, coeff_B[i]]) % NEXT_PRIME)(i) for i in range(0, n_hashes)]

    def get_shingle_ids(self, size, doc):
        """Returns the shingle ids for a single document

        Arguments:
            size {int} -- length of shingle ids to return
            doc {str} -- string representing document

        Yields:
            int -- shingle ids for a single document
        """

        doc = PUNCTUATION.sub(" ", str(doc))
        tokens = [word for word in doc.split(" ") if word != ""]

        for i in range(0, len(tokens) - size + 1):
            yield (binascii.crc32(bytes(" ".join(tokens[i: i + size]), "utf-8")) & 0xFFFFFFFF)

    def get_minhash_signatures(self, shingle_ids, hash_funcs):
        """Returns the minhash signatures for a single set of shingle ids

        Arguments:
            shingle_ids {list} -- list of shingle ids from a single document
            hash_funcs {list} -- list of randomly generated hash functions

        Returns:
            list -- minimum hash values computed from the shingle ids for each hash function
        """

        return [min([hash_func(id_) for id_ in shingle_ids]) for hash_func in hash_funcs]

    def jaccard_similarity(self, idx1, idx2):
        """Return the Jaccard similarity between any two documents
        This statistic acts as the 'ground truth' to which the minhash estimate can be compared

        Arguments:
            idx1 {int} -- index of first document in docs
            idx2 {int} -- index of second document in docs

        Returns:
            int -- Jaccard similarity between any two documents
        """

        s1 = self.shingle_ids[idx1]
        s2 = self.shingle_ids[idx2]
        return len(s1.intersection(s2)) / len(s1.union(s2))
