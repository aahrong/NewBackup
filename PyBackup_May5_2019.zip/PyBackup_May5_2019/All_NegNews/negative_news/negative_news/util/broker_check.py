import regex
from six.moves.urllib.request import urlopen
import io
import re
import logging
import json
import time
import hashlib
from datetime import datetime

import pdftotext
import requests

logger = logging.getLogger(__name__)

REQUIRED_KEYS = [
    "Reporting Source",
    "Current Status",
    "Allegations",
    "Initiated By",
    "Date Initiated",
    "Docket/Case Number",
    "Principal Product Type",
    "Other Product Type(s)",
    "Principal Sanction(s)/Relief Sought",
    "Other Sanction(s)/Relief Sought",
    "Resolution Date",
    "Resolution",
    "Other Sanctions Ordered",
    "Sanctions Ordered",
    "Sanction Details",
]

OPTIONAL_KEY_DICT = {
    "Final Order Flag": "No",
    "URL for Regulatory Action": "",
}

IGNORE_ENSURE_NEW_LINE = [
    "Sanctions Ordered"
]

HASH_ENCODING = "utf-8"

DISCLOSURE_KEY_NAMES = ["Regulatory Event", "Civil Event", "Bond", "Arbitration"]

def parse_finra_broker_check_report(crd):
    '''Parses FINRA Broker Check PDF
    
    Sample response:
             {'Reporting Source': 'Regulator',
              'Current Status': 'Final',
              'Allegations': '...'
              'Initiated By': 'NASDAQ STOCK MARKET',
              'Date Initiated': '12/10/2018',
              'Docket/Case Number': '2016051145501',
              'Principal Product Type': 'Other',
              'Other Product Type(s)': 'UNSPECIFIED SECURITIES',
              'Principal Sanction(s)/Relief Sought': '',
              'Other Sanction(s)/Relief Sought': '',
              'Resolution': 'Acceptance, Waiver & Consent(AWC)',
              'Resolution Date': '12/10/2018',
              'Final Order Flag': 'No',
              'Sanctions Ordered': 'Censure Monetary/Fine $15,000.00 OtherFINRA. reserved.',
              'Other Sanctions Ordered': 'UNDERTAKING',
              'Sanction Details': 'THE FIRM WAS CENSURED, FINED $15,000, AND REQUIRED TO REVISE ITS WRITTEN SUPERVISORY PROCEDURES (WSPS). i',
              'URL for Regulatory Action': ''},
        ],
    '''
    
    pdf_url = "https://files.brokercheck.finra.org/firm/firm_{crd}.pdf"
    
    all_keys = REQUIRED_KEYS + [str(key) for key in OPTIONAL_KEY_DICT.keys()]
    
    def _log(msg, lvl=logging.WARNING):
        logger.log(lvl, "Potential FINRA BC parse error: " + str(msg))

    def preprocess_pdf_page_txt(page_txt):
        page_txt = page_txt.replace("User Guidance", "")
        page_txt = page_txt.replace("Sought:", "")
        page_txt = page_txt.replace("Sanction(s)/Relief", "Sanction(s)/Relief Sought:")
        page_txt = page_txt.replace("Does the order constitute a", "Final Order Flag:")
        page_txt = page_txt.replace("final order based on", "")
        page_txt = page_txt.replace("violations of any laws or", "")
        page_txt = page_txt.replace("regulations that prohibit", "")
        page_txt = page_txt.replace("fraudulent, manipulative, or", "")
        page_txt = page_txt.replace("deceptive conduct?", "")
        page_txt = re.sub("©.*\n", "", page_txt)
        page_txt = re.sub("All rights.*\n", "", page_txt)
        page_txt = re.sub("Report about .*\n", "", page_txt)
        page_txt = re.sub("www.finra.org/brokercheck.*\n", "", page_txt)
        page_txt = re.sub(" +", " ", page_txt).strip()
        
        for key in all_keys:
            if key not in IGNORE_ENSURE_NEW_LINE:
                page_txt = page_txt.replace(key + ":", "\n" + key + ":")
        
        return page_txt
        
    def filter_dict_list(dict_list):
        filtered_dict_list = []
        for idx, event_dict_list in enumerate(dict_list):
            _dict_to_parse = {}
            if len(event_dict_list) > 1:
                for entry in event_dict_list:
                    if entry.get('Reporting Source', "").lower() == 'regulator':
                        _dict_to_parse = entry
                        break
                    else:
                        _log("No 'Regulator' value found in 'Reporting Source' field for multi-entry event at index {idx} ..".format(idx))
            else:
                try:
                    _dict_to_parse = event_dict_list[0]
                except Exception:
                    _log("Empty entry occurred at index {idx} in parsed Broker Check report ..".format(idx))
                    _dict_to_parse = {}

            filtered_dict_list.append(_dict_to_parse)
        
        return filtered_dict_list

    remote_file = urlopen(pdf_url.format(crd=crd)).read()

    with io.BytesIO(remote_file) as memory_file:
        pdf = pdftotext.PDF(memory_file)

    start_idx = 0
    pdf_text = ' '.join([preprocess_pdf_page_txt(page) for page in list(pdf)[start_idx:]])

    result = regex.findall(r"(?<=Disclosure \d+ of \d.*\n)[\w\W]*?(?=Disclosure \d+ of \d+.*\n|$)", pdf_text)

    for idx, item in enumerate(result):
        for key in REQUIRED_KEYS:
            if key + ":" not in item:
                # _log("Key '{}' not in item #{}".format(key, idx))
                pass
    
    results_aggregated = [item for item in result if all([key in item for key in REQUIRED_KEYS])]

    result_reporting_source_separated = [[item for item in regex.findall(r"(?=Reporting Source:)[\w\W]*?(?=Reporting Source:|$)", r) if item.strip() != ""] for r in results_aggregated]

    disclosure_dict_pairs_list = []

    for idx_i, result_pair in enumerate(result_reporting_source_separated):
        _list = []
        for idx_j, r in enumerate(result_pair):
            data_dict = {}
            current_key = None

            for line in r.split('\n'):
                for key in all_keys:
                    if key + ':' in line:
                        # if we have already encounter a key
                        if current_key is not None:
                            data_dict[current_key] = val.strip()
                            val = ""

                        current_key = key
                        val = line[line.find(key + ":") + len(key + ":"):]

                        break
                else:
                    val += line

            data_dict[current_key] = val.strip()

            for key in all_keys:
                if key not in data_dict.keys():
                    default_val = OPTIONAL_KEY_DICT.get(key)
                    if default_val is None:
                        break
                    else:
                        data_dict[key] = default_val
            else:
                _list.append(data_dict)
        disclosure_dict_pairs_list.append(_list)
        
    filtered_dict_list = filter_dict_list(disclosure_dict_pairs_list)
    
    return filtered_dict_list


def get_finra_broker_check_summary(crd, feed_handle_owners, feed_handle_disclosures, feed_handle_meta):
    '''Returns metadata from FINRA Broker Check page

    Sample response:
        {'basicInformation': {'firmId': 877,
          'firmName': 'WEDBUSH SECURITIES INC.',
          'otherNames': ['WEDBUSH MORGAN SECURITIES INC.',
           'WEDBUSH SECURITIES INC.',
           'WEDBUSH SECURITIES, INC.',
           'WEDBUSH, NOBLE, COOKE, INC'],
          'bcScope': 'ACTIVE',
          'iaScope': 'ACTIVE',
          'isLegacy': 'N',
          'finraRegistered': 'Y',
          'districtName': 'Los Angeles',
          'firmType': 'Corporation',
          'formedState': 'California',
          'firmSize': 'Large',
          'firmStatus': 'Approved',
          'regulator': 'SEC',
          'firmStatusDate': '10/20/1966',
          'formedDate': '07/08/1966',
          'fiscalMonthEndCode': 'June',
          'legacyReportStatus': 'Not Requested',
          'iaSECNumber': '6358',
          'iaSECNumberType': '801',
          'bdSECNumber': '12987'},
         'firmAddressDetails': {'officeAddress': {'street1': '1000 WILSHIRE BLVD. SUITE 900',
           'street2': 'ATTN: BUSINESS CONDUCT',
           'city': 'LOS ANGELES',
           'state': 'CA',
           'country': 'UNITED STATES',
           'postalCode': '90017-2457'},
          'mailingAddress': {'street1': 'P.O. BOX 30014',
           'city': 'LOS ANGELES',
           'state': 'CA',
           'country': 'UNITED STATES',
           'postalCode': '90030-0014'},
          'businessPhoneNumber': '(213) 688-8090'},
         'iaFirmAddressDetails': {'officeAddress': {'street1': 'ATTN: BUSINESS CONDUCT',
           'street2': '1000 WILSHIRE BLVD. SUITE 900',
           'city': 'LOS ANGELES',
           'state': 'CA',
           'country': 'United States',
           'postalCode': '90017'}},
         'bdDisclosureFlag': 'Y',
         'disclosures': [{'type': 'Regulatory Event',
           'entity': 'WEDBUSH SECURITIES INC.',
           'crd': 877,
           'count': 107,
           'change': 0,
           '_id': ObjectId('5c8bec328f19d7c8441a4c78')},
          {'type': 'Civil Event',
           'entity': 'WEDBUSH SECURITIES INC.',
           'crd': 877,
           'count': 2,
           'change': 0,
           '_id': ObjectId('5c8bec328f19d7c8441a4c79')},
          {'type': 'Bond',
           'entity': 'WEDBUSH SECURITIES INC.',
           'crd': 877,
           'count': 1,
           'change': 0,
           '_id': ObjectId('5c8bec328f19d7c8441a4c7a')},
          {'type': 'Arbitration',
           'entity': 'WEDBUSH SECURITIES INC.',
           'crd': 877,
           'count': 60,
           'change': 0,
           '_id': ObjectId('5c8bec328f19d7c8441a4c7b')}],
         'disclosure_detail': [
             {'Reporting Source': 'Regulator',
              'Current Status': 'Final',
              'Allegations': '...'
              'Initiated By': 'NASDAQ STOCK MARKET',
              'Date Initiated': '12/10/2018',
              'Docket/Case Number': '2016051145501',
              'Principal Product Type': 'Other',
              'Other Product Type(s)': 'UNSPECIFIED SECURITIES',
              'Principal Sanction(s)/Relief Sought': '',
              'Other Sanction(s)/Relief Sought': '',
              'Resolution': 'Acceptance, Waiver & Consent(AWC)',
              'Resolution Date': '12/10/2018',
              'Final Order Flag': 'No',
              'Sanctions Ordered': 'Censure Monetary/Fine $15,000.00 OtherFINRA. reserved.',
              'Other Sanctions Ordered': 'UNDERTAKING',
              'Sanction Details': 'THE FIRM WAS CENSURED, FINED $15,000, AND REQUIRED TO REVISE ITS WRITTEN SUPERVISORY PROCEDURES (WSPS). i',
              'URL for Regulatory Action': ''},
        ],
         'registrations': {'approvedFinraRegistrationCount': 1,
          'approvedSECRegistrationCount': 1,
          'approvedSRORegistrationCount': 22,
          'approvedStateRegistrationCount': 52,
          'stateList': [{'state': 'Alabama'},
           {'state': 'Alaska'},
           {'state': 'Arizona'},
           {'state': 'Arkansas'},
           {'state': 'California'}],
          'businessTypeCount': 18,
          'hasAffliation': 'Y',
          'referOtherBd': 'N'},
         'directOwners': [{'legalName': 'WEDBUSH, INC.',
           'position': 'CORPORATE PARENT',
           'bcScope': 'NotInScope',
           'crdNumber': '',
           '_id': 'b1bf04821933470fe1b1f1e27dee8ab884dd812a',
           'new': False,
           'entity': 'WEDBUSH SECURITIES INC.',
           'entity_crd': 877},
          {'legalName': 'BILLINGS, DANIEL ERIC',
           'position': 'EXECUTIVE VICE PRESIDENT, CFO',
           'bcScope': 'Active',
           'crdNumber': '4568232',
           'url': 'https://brokercheck.finra.org/firm/summary/4568232',
           '_id': '903e8c55d44ac5e82905832d8b295189ec2c08e9',
           'new': False,
           'entity': 'WEDBUSH SECURITIES INC.',
           'entity_crd': 877},
          {'legalName': 'FITZSIMMONS, ROBERT GERARD',
           'position': 'EXECUTIVE VICE PRESIDENT',
           'bcScope': 'Active',
           'crdNumber': '1878661',
           'url': 'https://brokercheck.finra.org/firm/summary/1878661',
           '_id': '61ee72288d2f3bdfde88fbaf3b7293aa3b273801',
           'new': False,
           'entity': 'WEDBUSH SECURITIES INC.',
           'entity_crd': 877},
          {'legalName': 'HULTGREN, DONALD WAYNE',
           'position': 'DIRECTOR, E.V.P., CHIEF ADMINISTRATIVE OFFICER',
           'bcScope': 'Active',
           'crdNumber': '1475369',
           'url': 'https://brokercheck.finra.org/firm/summary/1475369',
           '_id': 'e56dae0d8df35503d931705dd3bea0b9ca090812',
           'new': False,
           'entity': 'WEDBUSH SECURITIES INC.',
           'entity_crd': 877},
          {'legalName': 'JABLONSKI, RICHARD MICHAEL',
           'position': 'CO-PRESIDENT, COO, DIRECTOR',
           'bcScope': 'Active',
           'crdNumber': '2916358',
           'url': 'https://brokercheck.finra.org/firm/summary/2916358',
           '_id': '5dd1fcbc1019bb27d65913843fff2c9069c3bcd8',
           'new': False,
           'entity': 'WEDBUSH SECURITIES INC.',
           'entity_crd': 877},
          {'legalName': 'MOY, VINCENT JOHN',
           'position': 'SENIOR VICE PRESIDENT, CO-CHIEF COMPLIANCE OFFICER, ROSFP',
           'bcScope': 'Active',
           'crdNumber': '2469335',
           'url': 'https://brokercheck.finra.org/firm/summary/2469335',
           '_id': 'df6cf4cdaac86f44337c8cb01aa17db391d774d3',
           'new': False,
           'entity': 'WEDBUSH SECURITIES INC.',
           'entity_crd': 877},
          {'legalName': 'NADALALICEA, DANIEL ANTONIO',
           'position': 'EXECUTIVE VICE PRESIDENT, CIO',
           'bcScope': 'NotInScope',
           'crdNumber': '2908676',
           'url': 'https://brokercheck.finra.org/firm/summary/2908676',
           '_id': '40cda0bfb5bb1d43db446fb8b9c129224d8c7c5a',
           'new': False,
           'entity': 'WEDBUSH SECURITIES INC.',
           'entity_crd': 877}],
         'days_elapsed_since_last_run': 0,
         'last_run_ts': 1552673512.9339416}
    '''
    start_ts = time.time()
    
    api_url = "https://api.brokercheck.finra.org/firm/{crd}"
    summary_url = "https://brokercheck.finra.org/individual/summary/{crd}"

    params = {
        "json.wrf": "angular.callbacks._0",
        "wt": "json",
    }

    r = requests.get(url=api_url.format(crd=crd), params=params)

    if r.status_code != requests.codes.ALL_GOOD:
        raise Exception(f"Received bad request status from Broker Check API: {r.status_code}. Validate CRD# ({crd}) and try again ..")

    data = json.loads(r.text[len("/**/angular.callbacks._0("):-2])
    data = json.loads(data['hits']['hits'][0]['_source']['content'])

    firm_name = data.get("basicInformation", {}).get("firmName", "")

    direct_owners_dict_list = data.get("directOwners", [])

    if len(direct_owners_dict_list):

        cached_direct_owner_hashes = feed_handle_owners.find({"crd": crd}, {"_id": True})
        cached_direct_owner_hashes = [item["_id"] for item in cached_direct_owner_hashes]

        for _dict in direct_owners_dict_list:

            # add broker check page link (if applicable)
            crd_str = _dict.get("crdNumber", "")
            if crd_str != "":
                _dict.update({
                    "url": summary_url.format(crd=crd_str)
                })

            # add unique '_id' to dict
            _hash = hashlib.sha1()
            _hash.update(firm_name.encode(HASH_ENCODING))
            _hash.update(_dict.get("legalName", "").encode(HASH_ENCODING))
            _hash.update(_dict.get("position", "").encode(HASH_ENCODING))
            hash_value = _hash.hexdigest()
            _dict.update({"_id": hash_value})

            # add 'new' flag to dict
            new_flag = (hash_value in cached_direct_owner_hashes)
            _dict.update({"new": new_flag})

            # add 'entity' to dict
            _dict.update({
                "entity": firm_name
            })

            # add 'crd' to dict
            _dict.update({
                "entity_crd": str(crd)
            })

        # update API response with enriched data
        data.update({
            "directOwners": direct_owners_dict_list
        })

        # update database
        feed_handle_owners.delete_many({'entity_crd': str(crd)})
        feed_handle_owners.insert_many(data["directOwners"])

    scraped_disclosure_count_dict = {item["disclosureType"]: item["disclosureCount"] for item in data.get("disclosures", [])}

    if len(scraped_disclosure_count_dict):

        cached_disclosure_count_dict = {item["type"]: item["count"] for item in feed_handle_disclosures.find({"crd": crd})}
        new_disclosure_dict_list = []

        for key in DISCLOSURE_KEY_NAMES:
            _dict = {}
            
            # add 'type' to dict
            _dict.update({
                "type": key
            })
            
            # add 'entity' to dict
            _dict.update({
                "entity": firm_name
            })

            # add 'crd' to dict
            _dict.update({
                "crd": str(crd)
            })
            
            # add 'count' to dict
            new_value = scraped_disclosure_count_dict.get(key, 0)
            _dict.update({
                "count": new_value
            })

            # add 'change' to dict
            cached_value = cached_disclosure_count_dict.get(key, 0)
            _dict.update({
                "change": (new_value - cached_value)
            })
            
            new_disclosure_dict_list.append(_dict)
            
        # update API response with enriched data
        data.update({
            "disclosures": new_disclosure_dict_list
        })

        # update database
        feed_handle_disclosures.delete_many({'crd': str(crd)})
        feed_handle_disclosures.insert_many(new_disclosure_dict_list) 

    days_elapsed_since_last_run = 0
    meta_dict = feed_handle_meta.find_one({"crd": crd})
    last_run_ts = meta_dict.get("last_run_ts") if meta_dict is not None else None

    if last_run_ts is not None:
        start_dt = datetime.fromtimestamp(start_ts)
        last_run_dt = datetime.fromtimestamp(last_run_ts)
        days_elapsed_since_last_run = (start_dt - last_run_dt).days

    # update API response with time elapsed
    data.update({
        "days_elapsed_since_last_run": days_elapsed_since_last_run,
        "last_run_ts": last_run_ts
    })
    
    # update API response with disclosure detail from PDF report
    try:
        disclosure_detail_dict_list = parse_finra_broker_check_report(crd)
    except Exception:
        logger.warning("Exception occurred while parsing Broker Check report. Defaulting to detail list to empty ..")
        disclosure_detail_dict_list = []
    
    data.update({
        "disclosure_detail": disclosure_detail_dict_list
    })

    # update last run date in database
    feed_handle_meta.delete_many({"crd": str(crd)})
    feed_handle_meta.insert_one({"crd": str(crd), "last_run_ts": start_ts})

    return data
