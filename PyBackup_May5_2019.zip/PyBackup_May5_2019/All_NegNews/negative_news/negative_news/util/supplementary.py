import logging
from datetime import datetime, timezone
import re
import string

import requests
import dateparser
import pandas as pd
from bs4 import BeautifulSoup
import feedparser

from .misc import clean_text

logger = logging.getLogger(__name__)

# Default headers to use for API requests
HEADERS = requests.utils.default_headers()


def get_nyse_disciplinary_actions(entity_name, year, max_results=25, offset=0, sort_type="up"):
    '''If bad request or empty response, returns an empty list. 
       Otherwise, returns a list of dictionaries representing the extracted API results with
       the following keys:
           entity {str} -- Name of the entity associated with the action
           action_type {str} -- Description of the action
           date {datetime.datetime} -- Date on which action occurred
           file_name {str} -- URL at which PDF can be found
    '''
    # API URL for NYSE disciplinary actions
    url = "https://www.nyse.com/api/regulatory/disciplinary-actions/filter"

    # Domain name to prepend to NYSE PDF URLs
    domain_to_prepend = "https://nyse.com"

    # make request
    params = {
        "market": "",
        "year": year,
        "sortType": sort_type,
        "filterToken": entity_name,
        "max": max_results,
        "offset": offset,
    }
    r = requests.get(url=url, headers=HEADERS, params=params)

    if r.status_code == requests.codes.ALL_GOOD:
        _json = r.json()

        num_found = _json.get('totalCount')
        if num_found is None:
            raise Exception(f"Could not extract key 'totalCount' from the following JSON response: {_json}. Aborting ..")

        if num_found:
            results = []
            for result in _json.get('results'):
                # convert timestamp integer to datetime
                timestamp = result.get('masterDateField')
                try:
                    date = datetime.fromtimestamp(timestamp / 1000)
                except Exception:
                    logger.error(f"Error occurred while parsing date from the following timestamp: {timestamp}. Skipping result ..")
                    continue

                # grab associated entity
                entity = result.get('name')
                if entity is None:
                    logger.error(f"Error occurred while parsing 'name' from result: {result}. Skipping result ..")
                    continue

                # grab action type
                action_type = result.get('actionType', '')
                if action_type is None:
                    logger.error(f"Error occurred while parsing 'actionType' from result: {result}. Skipping result ..")
                    continue

                # grab PDF file name
                file_name = domain_to_prepend + result.get('fileName', '')
                if file_name is None:
                    logger.error(f"Error occurred while parsing 'fileName' from result: {result}. Skipping result ..")
                    continue

                # grab doc reference number
                doc_ref = result.get('number', 'N/A')

                # append to results list
                results.append({
                    "date": date,
                    "entity": entity,
                    "action_type": action_type,
                    "file_name": file_name,
                    "doc_ref": doc_ref,
                })

            return results            
        else:
            logger.info(f"Received empty response from NYSE API for entity '{entity_name}' ..")
    else:
        logger.error(f"Received bad request status from NYSE API: {r.status_code} ..")

    return []


def get_occ_disciplinary_actions(entity_name, date_str, max_results=100, offset=0, sort_type="StartDateDescending"):
    '''If bad request or empty response, returns None. 
       Otherwise, returns a dictionary with keys "num_found" and "results",
       where "results" is a list of dictionaries representing the extracted API results with
       the following keys:
           name {str} -- Name of the entity associated with the action
           action_type {str} -- Description of the action
           date {datetime.datetime} -- Date on which action occurred
           file_name {str} -- URL at which PDF can be found
           
       Parameters:
           entity_name {str} -- name of entity to search
           date_str {str} -- minimum date for which to include results (format="MM/DD/YYYY")
       
       Keyword Arguments:
           max_results {int} -- max number of items to display per page (default=100)
           offset {int} -- page number to display (default=0)
           sort_type {str} -- method by which to sort results (default="StartDateDescending")
           
       Sample API Response:
            [{'Amount': 0.0,
              'BankName': 'MUFG Bank, Ltd. Chicago Branch',
              'CharterNumber': 80140,
              'CityName': 'Chicago',
              'CompanyName': '',
              'CompleteDate': '2019-02-21T00:00:00-05:00',
              'DocketNumber': 'AA-EC-2019-7',
              'DocumentNumber': '2019-004',
              'HasPdf': True,
              'EnforcementTypeCode': 'C&D',
              'EnforcementTypeDescription': 'Cease & Desist Orders',
              'FirstName': '',
              'LastName': '',
              'StateAbbreviation': 'IL',
              'StateName': 'ILLINOIS            ',
              'TerminationDate': None,
              'TerminationDocumentNumber': '',
              'HasTerminationPdf': False},
            ]
    '''
    document_url = "https://www.occ.gov/static/enforcement-actions/ea{doc_ref}.pdf"
    url = "https://apps.occ.gov/EASearch/Search/ExportToJSON"
    params = {
        "Search": entity_name,
        "StartDateMinimum": date_str,
        "StartDateMaximum": "",
        "TerminationDateMinimum": "",
        "TerminationDateMaximum": "",
        "Category": "BankName",
        "Sort": sort_type,
        "AutoCompleteSelection": "",
        "CurrentPageIndex": offset,
        "ItemsPerPage": max_results,
        "ShowTerminatedActionsOnly": False,
        "ShowActiveOnly": False,
        "view": "Table",
        "InstitutionTypeEnums": "All",
    }

    r = requests.get(url=url, headers=HEADERS, params=params)

    results = []

    if r.status_code == requests.codes.ALL_GOOD:
        _json = r.json()

        for item in _json:
            # convert date str to datetime
            date_str = item.get('CompleteDate')
            try:
                date = dateparser.parse(date_str).replace(tzinfo=None)
            except Exception:
                logger.error(f"Error occurred while parsing date from the following date string: {date_str}. Skipping result ..")
                continue

            # grab associated entity
            entity = item.get('BankName')
            if entity is None:
                logger.error(f"Error occurred while parsing 'BankName' from result: {item}. Skipping result ..")
                continue

            # grab action type
            action_type = item.get('EnforcementTypeDescription')
            if action_type is None:
                logger.error(f"Error occurred while parsing 'EnforcementTypeDescription' from result: {item}. Skipping result ..")
                continue

            # grab document number
            doc_ref = item.get('DocumentNumber')
            if doc_ref is None:
                logger.error(f"Error occurred while parsing 'DocumentNumber' from result: {item}. Skipping result ..")
                continue
            else:
                file_name = document_url.format(doc_ref=doc_ref)

            # grab fine amount
            fine_amt = item.get('Amount')
            if fine_amt is None:
                logger.warning(f"Error occurred while parsing 'Amount' from result: {item}. Default to zero ..")
                fine_amt = 0.0

            # append to results list
            results.append({
                "date": date,
                "entity": entity,
                "action_type": action_type,
                "file_name": file_name,
                "doc_ref": doc_ref,
                "fine_amt": fine_amt,
            })
    else:
        logger.error(f"Received bad request status from NYSE API: {r.status_code} ..")

    return results


def get_finra_disciplinary_actions(entity_name, date_str):
    
    def get_href(soup, text_to_search):
        for link in soup.findAll("a"):
            if link.text == text_to_search:
                return link.get("href")
        return ""

    # if we return a non-empty list, each element
    # in the returned list should have these keys.
    # otherwise, we will log an error message
    # and return an empty list. this bit will alert us
    # to any change in website format 
    expected_col_names = [
        'case_id',
        'case_summary',
        'document_type',
        'firms_individuals',
        'action_date',
        'file_name',
    ]

    url = "http://www.finra.org//industry/disciplinary-actions/finra-disciplinary-actions-online"
    df_master = pd.DataFrame()
    page = 0

    while True:
        params = {
            "firms": entity_name,
            "field_core_official_dt_value[min][date]": date_str,
            "field_core_official_dt_value[max][date]": "03/07/2019",
            "page": page,
        }
        r = requests.get(url=url, headers=HEADERS, params=params)

        # check to ensure we receive good response
        if r.status_code != requests.codes.ALL_GOOD:
            logger.error(f"Received bad request status from FINRA API: {r.status_code}. Aborting additional requests ..")
            break

        # try to extract table
        try:
            df = pd.read_html(r.text)[0]
        except Exception:
            break

        # each column name gets copied into each of its cells
        # this function removes the column names
        df = df.apply(lambda series: series.str.replace(series.name, ""))

        # strip all white space from column strings
        df = df.apply(lambda series: series.str.strip())

        # extract all links
        soup = BeautifulSoup(r.text, "lxml")
        df["File Name"] = df["Case ID"].apply(lambda val: get_href(soup, val))

        df_master = pd.concat([df_master, df], ignore_index=True)

        page += 1
    
    if len(df_master):
        # rename all columns
        df_master.rename(columns=lambda x: re.sub("(?<=[a-z])([ {}])*(?=[A-Z])".format(string.punctuation), "_", x).lower(), inplace=True)

        # convert to dates to datetime
        df_master['action_date'] = df_master['action_date'].apply(dateparser.parse)
        df_master['action_date'] = df_master['action_date'].dt.to_pydatetime()

        # if the column names do not match what we expect to return,
        # log an error message and return an empty list
        if any([col_name not in df_master.columns for col_name in expected_col_names]):
            logger.error("Not all expected column names found in extracted FINRA column names: {}. Returning empty list ..".format(', '.join(df_master.columns)))
            return []

        # convert to list of dictionaries
        return df_master.to_dict("records")
    else:
        # log a message acknowledging we did not return any results with this set of parameters
        logger.debug(f"Aggregated response from FINRA API was empty (entity={entity_name}, date_str={date_str}). Returning empty list ..")
        return []


def get_nydfs_disciplinary_actions(entity_name_list):
    COL_IDX_DATE = 0
    COL_IDX_TITLE = 1
    document_url = "https://dfs.ny.gov{href}"
    results = []

    r = requests.get("https://www.dfs.ny.gov/industry_guidance/enforcement_actions_lfs")
    
    if r.status_code == requests.codes.ALL_GOOD:
        soup = BeautifulSoup(r.text, "lxml")
        table = soup.find('table')
        table_body = table.find('tbody')
        rows = table_body.find_all('tr')

        for row in rows:
            data = {}
            cols = row.find_all('td')
            text_content = [ele.text for ele in cols if ele]

            if not len(text_content):
                continue

            data['action_type'] = clean_text(text_content[COL_IDX_TITLE])

            for name in entity_name_list:
                if name.lower() in text_content[COL_IDX_TITLE].lower():
                    data['entity'] = name.upper()
                    break
            else:
                continue

            data['action_date'] = dateparser.parse(text_content[COL_IDX_DATE])

            links = row.find_all("a")
            href_list = []
            for l in links:
                href = l.get("href")
                if href is not None:
                    href_list.append(document_url.format(href=href))

            data['file_names'] = href_list

            results.append(data)
    else:
        logger.error(f"Received bad request status from NYDFS API: {r.status_code}. Returning empty list ..")
        return []
    
    return results


def get_sec_litigation_releases(entity_name_list):
    url = "https://www.sec.gov/rss/litigation/admin.xml"

    if not isinstance(entity_name_list, list):
        raise ValueError(f"'entity_name_list' should be of type list, but got type {type(entity_name_list)}")

    try:
        entries = feedparser.parse(url)["entries"]
    except Exception as e:
        logger.warning(f"Exception occurred while retrieving entries from SEC litigation feed: {str(e)}")
        return []

    entries = [item for item in entries if any(name in item["title"] for name in entity_name_list)]

    results = []
    for item in entries:
        entity = item.get("title", "")
        if entity is None:
            logger.error(f"Error occurred while parsing 'title' from result: {item}. Skipping result ..")
            continue

        action_type = item.get("summary", "")
        if action_type is None:
            logger.error(f"Error occurred while parsing 'summary' from result: {item}. Skipping result ..")
            continue

        doc_ref = item.get("id", "N/A")
        if doc_ref is None:
            logger.error(f"Error occurred while parsing 'doc_ref' from result: {item}. Defaulting to 'N/A' ..")
        
        file_name = item.get("link")
        if file_name is None:
            logger.error(f"Error occurred while parsing 'file_name' from result: {item}. Skipping result ..")
            continue

        # date
        time_struct = item.get('published_parsed')
        if time_struct is not None:
            date = datetime(year=time_struct.tm_year, month=time_struct.tm_mon, day=time_struct.tm_mday)
        else:
            time_str = item.get('published')
            if time_str is not None:
                date = dateparser.parse(time_str)

        results.append({
            "date": date,
            "entity": entity,
            "action_type": action_type,
            "file_name": file_name,
            "doc_ref": doc_ref,
        })

    return results