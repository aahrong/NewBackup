from functools import reduce
import re
import logging
import pickle
import string

import pandas as pd
from nltk import word_tokenize
from nltk import edit_distance
from nltk.stem.snowball import SnowballStemmer
from fuzzywuzzy import process

logger = logging.getLogger(__name__)

FINE_ERROR = -1
FINE_CAP = 1000000000000
NO_FINE_INFORMATION = "No fine information."
MATCH_SCORE_THRESHOLD = 95
EDIT_DISTANCE_THRESHOLD = 10
RELEVANT_STEMS = "fine penalize penalty levy pay paid repay repaid assess reimburse settlement".split()
MUST_BE_LOWER = ["bank", "and"]
DEFAULT_CAPITALIZED_TOKENS = [
    "morgan stanley",
    "etrade",
    "guggenheim",
    "ubs",
    "credit suisse",
    "charles schwab",
    "deutsche",
    "merrill lynch",
    "citi",
    "citigroup",
    "citibank",
    "wells fargo",
    "bank of america",
    "jpmorgan",
    "j.p. morgan",
    "raymond james",
    "hsbc",
    "suntrust",
    "goldman",
    "goldman sachs",
    "pnc",
    "bb&t",
    "fifth third",
    "huntington",
]


# insert tuple of fines found in doc, output max fine as % equity
def max_marketshare(fine_tuples_aggregated, mktshare_tuploc=4):
    # empty list to hold market share values
    mkt_list = []

    # loop through each fine tuple for the article
    for fine_tuple in fine_tuples_aggregated:

        # extract the fine element from the tuple
        mkt = fine_tuple[mktshare_tuploc]

        # append the max fine amount in the fine(s) to the list
        mkt_list.append(max(mkt, default=0))

    # normalize all fines to ensure max fine >10% = 10%
    mkt_list = [0.1 if x > 0.1 else x for x in mkt_list]
    return max(mkt_list, default=0.1)


def transform_article_title(title, company_tokens=None):
    """Transforms the text in an article title by capitalizing words matching one of the
    company tokens (for NER purposes) and stemming all other words.

    Arguments:
        title {str} -- original article title text

    Keyword Arguments:
        company_tokens {list} -- overrides default list of tokens to capitalize for NER purposes (default: {[]})

    Returns:
        str -- newly formatted article title text
    """
    if company_tokens is None:
        company_tokens = []

    title = str(title).replace("*", "").replace("-", "")

    article_tokens = word_tokenize(title)

    if company_tokens != []:
        article_tokens = [word if word in company_tokens else word.lower() for word in article_tokens]

    stemmer = SnowballStemmer("english")
    article_tokens = [stemmer.stem(word) if word.islower() else word for word in article_tokens]

    try:
        new_title = reduce(lambda agg, x: agg + " " + x, article_tokens[1:], article_tokens[0]).replace("bank of", "Bank Of")
    except IndexError:
        new_title = ""

    for token in DEFAULT_CAPITALIZED_TOKENS:
        new_title = new_title.replace(
            " {} ".format(" ".join([stemmer.stem(word) for word in token.lower().split()])), " {} ".format(token.title())
        )
        new_title = new_title.replace(
            "{} ".format(" ".join([stemmer.stem(word) for word in token.lower().split()])), "{} ".format(token.title())
        )
        new_title = new_title.replace(
            " {}".format(" ".join([stemmer.stem(word) for word in token.lower().split()])), " {}".format(token.title())
        )

    return new_title


def fuzzy_lookup_org_name(name_from_text, entity_dict_keys, error_value=FINE_ERROR):
    """Performs a fuzzy lookup on an entity name from an article to an entity dictionary

    Arguments:
        name_from_text {str} -- entity name to fuzzy lookup
        entity_dict_keys {list} -- keys of entity dictionary utilized to perform fuzzy lookup

        entity dict must be of the form:
        {
            'CommonName1' :
                {
                    'OfficialName' : 'official_name',
                    'MarketCap' : 1000000
                },
            'CommonName2' :
                {
                    'OfficialName' : 'official_name',
                    'MarketCap' : 1000000
                },
            ...
        }

    Returns:
        str -- the fuzzy lookup value if edit distance between the closest match and the provided text is less than or equal
        to the distance threshold. otherwise, default error message (FINE_ERROR)
    """
    name_from_text = name_from_text.title().strip()

    if name_from_text != "" and name_from_text not in string.punctuation:
        closest_match, match_score = process.extractOne(name_from_text, entity_dict_keys)
        edit_dist = edit_distance(name_from_text, closest_match)

        if match_score >= MATCH_SCORE_THRESHOLD and edit_dist <= EDIT_DISTANCE_THRESHOLD:
            return closest_match

    return error_value


def transform_money_text(money_ent, default_units=1):
    """Transforms text tagged as a 'MONEY' entity into a float

    Arguments:
        money_ent {str} -- text representing spaCy-tagged 'MONEY' entity

    Keyword Arguments:
        default_units {int} -- if the value is less than 1000 and does not appear in billions, millions, or thousands;
        this argument is used to multiply the coefficient into the correct units (default: {1})

    Returns:
        float -- 'MONEY" entity text as a float

    Usage:
        transform_money_text('100') - 100.0
        transform_money_text('$100.0') - 100.0
        transform_money_text('$ 1000') - 1000.0
        transform_money_text('$1 million') - 1000000.0
        transform_money_text('$1B') - 1000000000.0
    """

    text = money_ent.lower()

    try:
        val = float(re.findall(r"\d+\.?\d?\d?", text.replace(",", ""))[0])
    except Exception:
        return -1

    if val < 1000:
        if "tr" in text:
            return val * 1000000000000
        elif "b" in text:
            return val * 1000000000
        elif "m" in text:
            return val * 1000000
        elif "thou" in text or "k" in text:
            return val * 1000
        else:
            return val * default_units
    else:
        return val


def get_data_from_article_title(entity_dict, tagged_text, entity_name="", use_stemmer=True):
    """Extracts relevant fine data from tagged article text

    Arguments:
        entity_dict {dict} -- entity dictionary utilized to perform fuzzy lookup

        must be of the form:
        {
            'CommonName1' :
                {
                    'OfficialName' : 'official_name',
                    'MarketCap' : 1000000
                },
            'CommonName2' :
                {
                    'OfficialName' : 'official_name',
                    'MarketCap' : 1000000
                },
            ...
        }

        tagged_text {spaCy.Doc} -- spaCy-processed article text

        entity_name {str} -- an optional entity name with which we will perform a naive search
                             if the spaCy NER tagger does not find this name first. this parameter essentially
                             acts as a fail safe to try to patch any obvious errors in the spaCy NER tagger (default: {''})

    Returns:
        tuple -- a tuple of the form (org_matches, total_money, generate_flag)

        org_matches - a unique list of entity name matches
        total_money - the sum of the monetary values in the article title
        generate_flag - a boolean which determines whether a fine report should be generated
                        true if all criteria are met:
                            1) relevant stem matches are found
                            2) relevant entity name matches are found
                            3) monetary values are found
    """
    if use_stemmer:
        stemmer = SnowballStemmer("english")
        stem_list = [stemmer.stem(word) for word in RELEVANT_STEMS]
    else:
        stem_list = RELEVANT_STEMS

    stem_found = any(stem == word for stem in stem_list for word in word_tokenize(tagged_text.text))

    # create list of money amounts
    total_money_list = []
    for ent in tagged_text.ents:
        if ent.label_ == "MONEY":
            extracted_money_amount = transform_money_text(ent.text, 1000000)
            if extracted_money_amount < FINE_CAP:
                total_money_list.append(extracted_money_amount)
    total_money_list = list(set(total_money_list))
    total_money = sum(total_money_list)

    # create list of org matches
    org_matches = []
    if stem_found and len(total_money_list) == 1:
        entity_dict_keys = list(entity_dict.keys())

        for ent in tagged_text.ents:
            if ent.label_ == "ORG" or ent.label_ == "PERSON":
                org_name_fuzzy_match = fuzzy_lookup_org_name(ent.text, entity_dict_keys)
                if org_name_fuzzy_match != FINE_ERROR and \
                edit_distance(org_name_fuzzy_match.lower(), entity_name.lower()) <= EDIT_DISTANCE_THRESHOLD:
                    org_matches.append(org_name_fuzzy_match)
        org_matches = list(set(org_matches))

        # if we specify a 'fail safe' entity name AND
        # if we do not return any org_matches in the first pass (above) or the entity for which we are searching is not
        # already in any of the of the matches, perform a naive check to see whether the entity name is in the text through
        # which we are searching
        if entity_name != "" and (org_matches == [] or not any(entity_name.lower() in match.lower() for match in org_matches)):
            if entity_name.lower() in tagged_text.text.lower():
                org_matches.append(fuzzy_lookup_org_name(entity_name.upper(), entity_dict_keys, error_value=entity_name.upper()))

    generate_flag = len(org_matches) >= 1

    # TODO: comment here
    org_and_mkt_cap = []
    for org in org_matches:
        official_name, market_cap = entity_dict_lookup(org, entity_dict)
        org_and_mkt_cap.append((official_name, market_cap, total_money / market_cap))

    # TODO: comment here
    if org_and_mkt_cap != []:
        org_matches, market_caps, pct_equity = zip(*org_and_mkt_cap)
    else:
        org_matches = []
        market_caps = []
        pct_equity = []

    return org_matches, total_money, generate_flag, market_caps, pct_equity


def entity_dict_lookup(org, entity_dict):
    if entity_dict.get(org, FINE_ERROR) != FINE_ERROR:
        official_name = entity_dict[org].get("OfficialName")
        market_cap = entity_dict[org].get("MarketCap")
    else:
        official_name = org.upper()
        market_cap = FINE_ERROR

    return official_name, market_cap


def generate_report_string(
    title="",
    entity_name="",
    content="",
    entity_dict=None,
    tagged_text=None,
    fine_tuple=None,
    nlp=None,
    default_pickle_path="entity_dict.pickle",
    verbose=False,
    debug=False,
):
    """Generates a fine report string from an article title

    Arguments:
        title {str} -- article title text for which to generate fine report

    Keyword Arguments:
        entity_name {str} -- an optional entity name with which we will perform a naive search
                             if the spaCy NER tagger does not find this name first. this parameter essentially
                             acts as a fail safe to try to patch any obvious errors in the spaCy NER tagger (default: {''})
        entity_dict {dict} -- entity dictionary utilized to perform fuzzy lookup (default: {None})
        tagged_text {spaCy.Doc} -- spaCy-processed article text (default: {None})
        nlp {spaCy.English} -- if tagged_text is not provided, utilized to create spaCy.Doc object from title (default: {None})
        default_pickle_path {str} -- if no entity_dict provided,
                                     default path at which to look for entity_dict pickle (default: {'entity_dict.pickle'})
        verbose {bool} -- if True, include NO_FINE_INFORMATION results.
                          otherwise, exclude NO_FINE_INFORMATION results (default: {False})
        debug {bool} -- if True, generate log file (default: {False})
    Raises:
        Exception

    Returns:
        list -- a list of strings representing the fine report
    """
    if entity_dict is None:
        try:
            entity_dict = load_entity_dict(default_pickle_path)
        except FileNotFoundError:
            raise Exception("Entity dictionary could not be loaded from pickle at path: {}.".format(default_pickle_path))

    if nlp is not None:
        company_tokens = word_tokenize(content)
        tagged_text = nlp(transform_article_title(title, company_tokens))

    if tagged_text is not None:
        fine_tuple = get_data_from_article_title(entity_dict, tagged_text, entity_name)

    if fine_tuple is None:
        raise Exception(
            "An error occurred while extracting metadata or at least one the following arguments should have been"
            + "provided: 'nlp', 'tagged_text', or 'fine_tuple'."
        )

    try:
        orgs_from_title, total_fine, generate_flag, market_caps, pct_equity = fine_tuple
    except ValueError:
        raise Exception("'fine_tuple' should be a tuple with three elements of the following form: (list of str, float or int, bool).")

    org_and_mkt_cap = set(zip(orgs_from_title, market_caps, pct_equity))

    if generate_flag:
        report_str = []
        for org, mkt_cap, pct_equity in org_and_mkt_cap:
            if mkt_cap != FINE_ERROR:
                report_str.append(
                    "Fine in the amount of ${:,.0f} found for {}. ".format(total_fine, org)
                    + "The percent impact to the company's ${:,.0f} equity share is {:.4f}%.".format(mkt_cap, pct_equity * 100)
                )
            else:
                report_str.append("Fine in the amount of ${:,.0f} found for {}. ".format(total_fine, org))
    else:
        report_str = [NO_FINE_INFORMATION] if verbose else []

    if debug:
        print("######\nTEXT:\n{}".format(title))
        print("CONTENT:\n{}".format(content))
        print("TRANSFORMED TEXT:\n{}".format(tagged_text.text))
        print("ENTITIES RECOGNIZED:\n{}".format(tagged_text.ents))
        print("EXTRACTED DATA:\n{} (Orgs) {} (Total Fine) {} (Generate Flag)".format(orgs_from_title, total_fine, generate_flag))
        print("FINE REPORT(S):\n{}".format(report_str))
        print("######\n")

    return report_str


def update_entity_dict(
    path_to_xlsx="target_entities.xlsx", sheet_name="Names", use_cols="B:D", index_col=1, pickle_path="entity_dict.pickle"
):
    """Updates entity_dict pickle and returns updated entity_dict as a dict

    Keyword Arguments:
        path_to_xlsx {str} -- path to Excel input (default: {'target_entities.xlsx'})
        sheet_name {str} -- sheet name of Excel input data (default: {'Names'})
        use_cols {str} -- column range as string to read into dataframe (default: {"B:D"})
        index_col {int} -- index of column to use as index. should point to entity common name (default: {1})
        pickle_path {str} -- path at which to save updated pickle (default: {'entity_dict.pickle'})

    Raises:
        Exception

    Returns:
        dict -- dictionary containing entity information
    """

    entity_dict = None

    try:
        entity_dict = pd.read_excel(path_to_xlsx, sheet_name, usecols=use_cols, index_col=index_col).to_dict(orient="index")
    except FileNotFoundError:
        raise Exception("File not found: {}".format(path_to_xlsx))
    except Exception:
        raise
    finally:
        if entity_dict is not None:
            with open(pickle_path, "wb") as f:
                pickle.dump(entity_dict, f)

        return entity_dict


def load_entity_dict(pickle_path=""):
    """Loads dictionary containing entity information from pickle

    Keyword Arguments:
        pickle_path {str} -- path from which to load entity_dict pickle (default: {''})

    Raises:
        FileNotFoundError

    Returns:
        dict -- dictionary containing entity information
    """

    entity_dict = None

    try:
        with open(pickle_path, "rb") as f:
            entity_dict = pickle.load(f)
    except FileNotFoundError:
        raise

    return entity_dict
