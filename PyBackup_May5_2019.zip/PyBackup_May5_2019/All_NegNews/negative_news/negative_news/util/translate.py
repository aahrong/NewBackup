import sys
import traceback

from mstranslator import Translator

from .misc import generate_batches

BING_TRANSLATE_API_KEY = "9d44b25f4d2d43c9823f2caa53c7097c"


def translate_text(translator, sentence, lang_from, lang_to):
    if translator is None:
        translator = Translator(BING_TRANSLATE_API_KEY)

    translate_batches = generate_batches(sentence, batch_size=1500)

    try:
        return " ".join([translator.translate(batch, lang_from, lang_to) for batch in translate_batches])
    except Exception:
        exc_info = sys.exc_info()
        raise ValueError(
            "An error occurred while translating '{sentence}' from '{lang_from}' to '{lang_to}': {exception}".format(
                sentence=sentence, lang_from=lang_from, lang_to=lang_to, exception="".join(traceback.format_exception(*exc_info))
            )
        )


def translate_text_list(sentence_list, lang_from, lang_to):
    translator = Translator(BING_TRANSLATE_API_KEY)
    return [translate_text(translator, sentence, lang_from, lang_to) for sentence in sentence_list]


def threaded_translate_text(idx, text, lang_from, lang_to, shared_list):
    translation = translate_text(None, text, lang_from, lang_to)
    shared_list.append((idx, translation))
