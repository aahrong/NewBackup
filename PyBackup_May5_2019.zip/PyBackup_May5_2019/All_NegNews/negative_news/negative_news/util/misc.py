from multiprocessing import Manager, Process
import time
import logging
import re
import os
import pickle
from datetime import datetime

import pandas as pd
import requests

from sumy.parsers.plaintext import PlaintextParser
from sumy.summarizers.luhn import LuhnSummarizer
from sumy.nlp.tokenizers import Tokenizer

logger = logging.getLogger(__name__)

DOMAIN_NAME_REGEX = re.compile(r"(?<=://)(.*?)(?:/)")

PICKLE_PATH_USER_AGENT_LIST = f"{os.path.dirname(__file__)}/../resources/user_agent_list.pk"

USER_AGENT_REFRESH_DAYS = 7

ALLOWED_PROXY_COUNTRY_ABBRV = ["US", "GB", "CA"]


def generate_batches(iterable, batch_size=1):
    """Generates batches of the specified size from the passed list or other iterable.
    Will not work with generators or other iterable types incompatible with len()

    Arguments:
        iterable {list} -- iterable from which to create batches

    Keyword Arguments:
        batch_size {int} -- batch size to create (default: {1})
    """

    length = len(iterable)
    for ndx in range(0, length, batch_size):
        yield iterable[ndx: (ndx + batch_size)]


def clean_text(text):
    text = text.replace("\n", " ").replace("\t", " ").replace("\r", " ")
    text = re.sub(r" +", " ", text)
    text = text.strip()
    return text


def generate_sumy_summary(content, language_abbrv, num_sentences_to_generate=3):
    if language_abbrv.lower() == "en":
        parser = PlaintextParser.from_string(content, Tokenizer("english"))
        summarizer = LuhnSummarizer()
        return " ".join([str(s) for s in summarizer(parser.document, num_sentences_to_generate)])
    else:
        return ""


def extract_url_domain_name(url, default=""):
    try:
        return DOMAIN_NAME_REGEX.findall(url)[0].replace("www.", "").capitalize()
    except IndexError as e:
        logger.debug(f"IndexError occurred while extracting domain name: {str(e)}")
        return default


def get_latest_user_agent_list(os_name_list=["linux"]):
    # check if pickled user agent list exists
    if not os.path.isfile(PICKLE_PATH_USER_AGENT_LIST) or \
        (datetime.now() - datetime.fromtimestamp(os.path.getmtime(PICKLE_PATH_USER_AGENT_LIST))).days > USER_AGENT_REFRESH_DAYS:

        logger.debug("Attempting to fetch new user agent list ..")

        url_base = "https://developers.whatismybrowser.com/useragents/explore/operating_system_name/{os_name}/"
        user_agent_list = []

        for os_name in os_name_list:
            url = url_base.format(os_name=os_name)
            r = requests.get(url)

            if r.status_code != requests.codes.ALL_GOOD:
                raise Exception(f"Received bad request status < {url} >: {r.status_code}")

            try:
                _user_agents = list(pd.read_html(r.text)[0]['User agent'])
            except Exception as e:
                logger.warning(f"Error occurred while extracting table from response: {str(e)}")
                continue

            user_agent_list.extend(_user_agents)

        try:
            with open(PICKLE_PATH_USER_AGENT_LIST, "wb") as f:
                pickle.dump(user_agent_list, f)

            logger.debug(f"Saved user agent list to file < {PICKLE_PATH_USER_AGENT_LIST} > ..")
        except Exception as e:
            logger.warning(f"Error occurred while saving user agent list: {str(e)}")
    else:
        logger.debug(f"Loading user agent list from file < {PICKLE_PATH_USER_AGENT_LIST} > ..")

        try:
            with open(PICKLE_PATH_USER_AGENT_LIST, "rb") as f:
                user_agent_list = pickle.load(f)
        except Exception as e:
            logger.warning(f"Error occurred while loading user agent list: {str(e)}")
            user_agent_list = []

    return user_agent_list


def get_latest_proxy_list():
    logger.debug("Attempting to fetch new proxy list ..")

    url = "https://free-proxy-list.net/"
    proxy_list = []

    r = requests.get(url)

    if r.status_code != requests.codes.ALL_GOOD:
        raise Exception(f"Received bad request status < {url} >: {r.status_code}")

    try:
        df = pd.read_html(r.text)[0]
    except Exception as e:
        logger.warning(f"Error occurred while extracting table from response: {str(e)}")
        return []

    try:
        df = df[[any([code == val for code in ALLOWED_PROXY_COUNTRY_ABBRV]) for val in df["Code"]]]
        df = df[df["Https"] == "no"]
        proxy_list = ["http://{}:{}".format(ip, int(port)) for ip, port in list(zip(df['IP Address'], df['Port']))]
    except Exception as e:
        logger.warning(f"Error occurred while parsing table received from response: {str(e)}")
        return []

    return proxy_list

