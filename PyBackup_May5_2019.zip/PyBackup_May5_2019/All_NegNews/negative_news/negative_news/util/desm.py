import math
import logging

import scipy
import numpy as np

DEFAULT_EMBEDDING_LENGTH = 300

logger = logging.getLogger(__name__)


def get_all_embeddings(model, phrase_tokenized):
    """Returns list of Word2Vec (PyMagnitude) input embeddings for all words in a given phrase

    Arguments:
        model {pymagnitude} -- Word2Vec (PyMagnitude) object to query for word embeddings
        phrase {list} -- List of strings representing phrase

    Returns:
        list -- a list representing the Word2Vec (PyMagnitude) input embeddings for each token in phrase
    """
    return model.query(phrase_tokenized)


def get_document_centroids(model, doc_tokens):
    """Returns the centroids of the input and output embeddings as a tuple for a single document

    Arguments:
        model {pymagnitude} -- Word2Vec (PyMagnitude) object to query for word embeddings
        doc_tokens {list} -- List of tokens representing a single document

    Returns:
        tuple -- a tuple representing the centroids of the input and output embeddings for the provided tokens
                of the form (input_centroid, output_centroid)
    """
    if doc_tokens != []:
        input_centroid = np.mean(get_all_embeddings(model, doc_tokens), axis=0)
    else:
        input_centroid = np.zeros(DEFAULT_EMBEDDING_LENGTH)

    # 'OUT' embeddings not available for pre-trained Google embeddings
    output_centroid = np.zeros(DEFAULT_EMBEDDING_LENGTH)
    return (input_centroid, output_centroid)


def get_all_document_centroids(model, all_doc_tokens):
    """Returns the the input and output centroids for all documents as a dictionary

    Arguments:
        model {pymagnitude} -- Word2Vec (PyMagnitude) object to query for word embeddings
        all_doc_tokens {list} -- List of lists of tokens representing all documents

    Returns:
        dict -- a dictionary representing the input and output centroids of all documents
                of the form {doc_index : (input_centroid, output_centroid)}
    """
    centroid_dict = {i: get_document_centroids(model, all_doc_tokens[i]) for i in range(0, len(all_doc_tokens))}

    centroid_dict = {k: v for k, v in centroid_dict.items() if not np.isnan(v[0]).any()}

    return centroid_dict


def score_document(query_embeds, doc_centroid):
    """Returns the DESM score for a single document given query embedddings and document centroid

    Arguments:
        query_embeds {list} -- list of numpy.ndarrays representing the word embeddings for all tokens in the query
        doc_centroid {np.ndarray} -- np.ndarray representing the average embedding of the document tokens

    Returns:
        int -- DESM score for document
    """

    cos_similarities = [(1 - scipy.spatial.distance.cosine(query_embed, doc_centroid)) for query_embed in query_embeds]
    return sum(cos_similarities) / len(query_embeds)


def score_all_documents(model, query, all_doc_tokens, sort=True):
    """Returns the DESM score for a set of documents given a query and a list of document tokens

    Arguments:
        model {pymagnitude} -- Word2Vec (PyMagnitude) object to query for word embeddings
        query {list} -- List of strings representing query with which to produce DESM score
        all_doc_tokens {list} -- List of lists of strings containing word tokenized documents

    Keyword Arguments:
        sort {bool} -- if true, sort the DESM scores in descending fashion (default: {True})

    Returns:
        tuple -- tuple of lists of the form (scores_in_in, scores_in_out); each of these tuple elements
        is a list of tuples of the form (doc_index, desm_score) sorted in a descending fashion
    """
    C_IN = 0  # flag for 'IN' word embeddings
    # C_OUT = 1  # flag for 'OUT' word embeddings

    if type(query) == str:
        query = [query]

    query_embeddings = get_all_embeddings(model, query)
    centroid_dict = get_all_document_centroids(model, all_doc_tokens)

    scores_in_in = []
    # 'OUT' embeddings not available for pre-trained Google embeddings
    scores_in_out = []

    for doc_index, centroid_tuple in centroid_dict.items():
        in_score = score_document(query_embeddings, centroid_tuple[C_IN])
        # out_score = score_document(query_embeddings, centroid_tuple[C_OUT])

        if not math.isnan(in_score):
            # doc = ' '.join(all_doc_tokens[doc_index])
            scores_in_in.append((doc_index, in_score))

        # if not math.isnan(out_score):
        #     scores_in_out.append((doc_index, in_score))

    if sort:
        scores_in_in = sorted(scores_in_in, key=lambda x: x[1], reverse=True)
        # scores_in_out = sorted(scores_in_out, key = lambda x: x[1], reverse = True)

    return (scores_in_in, scores_in_out)


def desm_pandas_wrapper(wv, query_list, row, norm=False, avg_top_n=3, num_best_docs_to_yield=3, best_doc_char_threshold=50):
    """DESM score wrapper for pandas
        Flow:

        BEGIN LOOP
        0) For each query in the query list ..
        1) Calculate a DESM score for each sentence in the document based on the query
        2) Take the top {avg_top_n} scoring sentences and average their DESM scores
        END LOOP

        3) For the top scoring query; return the score, the top sentences, and the query

    Arguments:
        wv {pymagnitude} -- Word2Vec (PyMagnitude) object to query for word embeddings
        query_list {list} -- list of strings with which to produce DESM scores
        df {pandas.Series} -- Pandas dataframe row on which to perform DESM analysis

    Keyword Arguments:
        col_name_for_content {str} -- [description] (default: {'content'})
        word_tokenizer {callable} -- callable utilized to word tokenize sentences;
        must accept sentence as single parameter (default: {nltk.tokenize.word_tokenize})
        sent_tokenizer {callable} -- callable utilized to sentence tokenize documents;
        must accept document as single parameter (default: {nltk.tokenize.sent_tokenize})
        norm {bool} -- if true, normalize the DESM scores (default: {False})
        avg_top_n {int} -- max number of sentences with which to produce average DESM score for whole document
                           (default: {3})

    Raises:
        ValueError -- if the query list has a length of 0
        KeyError -- if 'col_name_for_content' does not exist as a column in 'df'

    Returns:
        tuple -- (best DESM score across all queries, corresponding top sentences, corresponding query)
    """
    best_score = 0
    best_term = ""
    best_docs = []
    best_doc_idx = []
    score_dict = {}

    if len(query_list) == 0:
        raise ValueError("Query list must contain at least one search term .. ")

    for q in query_list:
        scores_in_in = list(score_all_documents(wv, q, row["sentence_tokenized_word_tokenized"], norm)[0])
        score_dict[q] = scores_in_in

        try:
            doc_idx, scores = zip(*scores_in_in)
            top_avg = np.mean(scores[:avg_top_n])

            if top_avg > best_score:
                best_score = top_avg
                best_doc_idx = doc_idx
                best_term = q
        except ValueError:
            logger.debug('Error occurred while unpacking "scores_in_in": {}'.format(scores_in_in))

    for idx in best_doc_idx:
        if len(row["sentence_tokenized"][idx]) >= best_doc_char_threshold:
            best_docs.append(row["sentence_tokenized"][idx])
        if len(best_docs) == num_best_docs_to_yield:
            break

    return best_score, best_docs, best_term, score_dict
