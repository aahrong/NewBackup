from functools import reduce
import time
import html
from collections import Counter
import logging
from datetime import datetime

from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, PageBreak
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
import docx
from docx import Document
from docx.shared import Pt

logger = logging.getLogger(__name__)

# in each article metadata dictionary, 
# these key names hold the binned value information
BINNED_VALUE_KEY_NAMES = ["similarity_rank", "fine_rank", "date_rank", "entity_count_rank", "sentiment_rank"]


def create_pdf_summary(output_args):
    """Create pdf summary takes in the output args from runner and sends them to create_nn_page if data exists.
        It is then returned the filename of the saved pdf and the unsaved Word doc. It then saves the Word doc.

    Returns:
        [str] -- [output file name of the saved pdf (including output path)]
    """

    output_path = output_args["output_path"]
    entity_name = output_args["entity_name_translated"]
    finalW_fname = output_path + entity_name + "_" + time.strftime("%m-%d-%Y") + ".docx"

    num_report_items = len(output_args.get("article_dict_list", [])) + \
                        output_args.get("disciplinary_action_info", {}).get('num_actions', 0)
    if not num_report_items:
        fname, word = create_empty_page(output_path, entity_name)
    else:
        fname, word = create_nn_page(**output_args)

    word.save(finalW_fname)
    return fname


def create_empty_page(output_path, entity_name):
    """Creates an empty negative news page. This is used if there is no data available or if there
        are errors in the pdf creation process. Check output data if this page is created, if
        output data exists, there is an error in the code post data-generation.

    Arguments:
        output_path {str} -- [path for pdf to be saved to]
        entity_name {[str]} -- [name searched for in Negative News application]

    Returns:
        [str, word document] -- [returns string of pdf created and the Word Document needing to be saved]
    """
    pdf_fname = output_path + str(entity_name) + time.strftime("%m-%d-%Y") + ".pdf"
    styles = getSampleStyleSheet()
    doc = SimpleDocTemplate(pdf_fname, leftMargin=0.75 * inch, rightMargin=0.75 * inch, topMargin=1 * inch, bottomMargin=1 * inch)
    Story = []
    h1_1 = Paragraph(str(entity_name), styles["Title"])
    Story.append(h1_1)
    h2_2 = Paragraph("No negative links found", styles["Heading2"])
    Story.append(h2_2)
    doc.build(Story)

    # Word doc
    word_doc = Document()
    word_doc.add_heading("Entity Searched: " + str(entity_name), level=0)
    word_doc.add_heading("No negative links found")
    # fnames_list.append(fname)
    return pdf_fname, word_doc


def create_nn_page(
    output_path,
    entity_name,
    entity_name_translated,
    known_aliases,
    location,
    employment,
    indv_flag,
    max_sentiment,
    min_year,
    min_month,
    min_similarity,
    max_search_results,
    language_abbrv,
    disciplinary_action_info={},
    finra_broker_check_info={},
    article_dict_list=[],
    normalized_risk_score=0,
    max_links_for_score=0,
    total_fine_amt=0,
    name_fuzzy_score=0,
    location_fuzzy_score=0,
    employment_fuzzy_score=0,
    NumStartUrls=0,
    num_reg_sites=0,
    entity_querylist=[],
    all_search_terms=[],
    model_weights={},
    **kwargs
):
    links_after_filter = len(article_dict_list)

    # Footer notes
    note2_1 = "1. The 'Total Negative News Score' represents a risk assessment between 0-100 in which a higher value indicates greater risk."
    note1_1 = "4. The 'Search Terms Used In Analysis' displays the search terms leveraged to query the search APIs this tool implements."
    note3_1 = (
        "2. The tool utilizes several methodologies with which it performs link filtering, such as document similarity, domain black lists, etc."
    )
    note4_1 = (
        "3. Note that the above confidence score for 'Name' will generally be high due to the search methodology of the tool. "
        + "The confidence score for 'Location'"
    )
    note4_2 = (
        " represents the result of an approximate or partial match between the input location information and the "
        + "location identified via third-party geolocation service."
    )
    note4_3 = " A value of 'N/A' implies the user did not specify location / employment."

    # Setup initialization for Word and Pdf Docs
    styles = getSampleStyleSheet()
    # output file name for pdf and empty page creation
    outfn = output_path + (entity_name + " " + time.strftime("%Y-%m-%d-%H-%M-%S") + ".pdf").replace(" ", "_")
    pdf_filename = outfn
    doc = SimpleDocTemplate(
        pdf_filename, pagesize=letter, leftMargin=0.75 * inch, rightMargin=0.75 * inch, topMargin=1 * inch, bottomMargin=2 * inch
    )
    Story = []
    # Create the empty word Doc
    word_doc = Document()

    # BEGIN Word doc first page
    # Heading for negative news overall score
    p = word_doc.add_heading("Entity Searched: " + str(entity_name), level=0)
    p = word_doc.add_heading("Total Negative News Score")
    super_text = p.add_run("1")
    super_text.font.superscript = True
    p.add_run(": ")
    p.add_run(str(round(normalized_risk_score, 2)) + "%")

    # "Searched Links Details" table
    p = word_doc.add_heading("Searched Links Details", level=1)
    super_text = p.add_run("2")
    super_text.font.superscript = True
    table = word_doc.add_table(1, 2)
    table.style = "LightList-Accent1"

    heading_cells = table.rows[0].cells
    heading_cells[0].text = "Detail Type"
    heading_cells[1].text = "Count"

    rows = [
        ("Total links returned", NumStartUrls),
        ("Links remaining after filtering", links_after_filter),
        ("Links utilized for risk scoring", max_links_for_score),
        ("Links displayed", min(max_search_results, max_links_for_score)),
        ("Total fines found", "${:,}".format(total_fine_amt)),
        ("Regulatory site articles", num_reg_sites),
    ]

    for row in rows:
        cells = table.add_row().cells
        for idx, item in enumerate(row):
            cells[idx].text = str(item)

    # "Average Relevance Scores" table
    p = word_doc.add_heading("Average Relevance Scores", level=1)
    super_text = p.add_run("3")
    super_text.font.superscript = True
    table = word_doc.add_table(1, 2)
    table.style = "LightList-Accent1"

    heading_cells = table.rows[0].cells
    heading_cells[0].text = "Relevance Type"
    heading_cells[1].text = "Score"

    rows = [
        ("Name", str(round(name_fuzzy_score, 2)) + "%"),
        ("Location", str(round(location_fuzzy_score, 2)) + "%"),
        ("Employment", str(round(employment_fuzzy_score, 2)) + "%"),
    ]

    for row in rows:
        cells = table.add_row().cells
        for idx, item in enumerate(row):
            cells[idx].text = str(item)

    # "Article Type Summary" table
    top_search_terms_info = Counter([item["desm_term"] for item in article_dict_list]).most_common()
    if len(top_search_terms_info):
        p = word_doc.add_heading("Article Type Summary", level=1)
        table = word_doc.add_table(len(top_search_terms_info) + 1, 3)
        table.style = "LightList-Accent1"

        heading_cells = table.rows[0].cells
        heading_cells[0].text = "Top Search Terms"
        heading_cells[1].text = "Article Count"
        heading_cells[2].text = "Percent"

        for idx, info in enumerate(top_search_terms_info):
            term, count = info
            table.cell(idx + 1, 0).text = term.title()
            table.cell(idx + 1, 1).text = str(count)
            table.cell(idx + 1, 2).text = str(int((count / links_after_filter) * 100)) + "%"

    # "Model weights" table
    if len(model_weights):
        p = word_doc.add_heading("Document Ranking Weights", level=1)
        table = word_doc.add_table(len(model_weights) + 1, 2)
        table.style = "LightList-Accent1"

        heading_cells = table.rows[0].cells
        heading_cells[0].text = "Ranking Type"
        heading_cells[1].text = "Weight"

        for idx, (k, v) in enumerate(model_weights.items()):
            table.cell(idx + 1, 0).text = k.replace("_", " ").title()
            table.cell(idx + 1, 1).text = str(v)

    # "Article Classification" table
    document_categories = [item["document_categories"] for item in article_dict_list]
    aggregated_document_categories = reduce(lambda agg, x: agg + x, document_categories, [])
    top_document_cat_info = Counter(aggregated_document_categories).most_common()
    if len(top_document_cat_info):
        p = word_doc.add_heading("Article Classification Summary", level=1)
        table = word_doc.add_table(len(top_document_cat_info) + 1, 3)
        table.style = "LightList-Accent1"

        heading_cells = table.rows[0].cells
        heading_cells[0].text = "Top Document Categories"
        heading_cells[1].text = "Article Count"
        heading_cells[2].text = "Percent"

        for idx, info in enumerate(top_document_cat_info):
            cat, count = info
            table.cell(idx + 1, 0).text = cat
            table.cell(idx + 1, 1).text = str(count)
            table.cell(idx + 1, 2).text = str(int((count / links_after_filter) * 100)) + "%"

    # "Search terms used" printout
    if len(all_search_terms):
        p = word_doc.add_heading("Search Terms Used In Analysis", level=1)
        super_text = p.add_run("4")
        super_text.font.superscript = True
        p = word_doc.add_paragraph(" ")
        p.add_run(", ".join(all_search_terms))

    # 'Domains Searched' printout
    if len(entity_querylist):
        p = word_doc.add_heading("Domains Searched", level=1)
        p = word_doc.add_paragraph(" ")
        p.add_run(", ".join(entity_querylist))

    # "Input Parameters" table
    p = word_doc.add_heading("User Input Parameters", level=1)
    table = word_doc.add_table(1, 2)
    table.style = "LightList-Accent1"

    heading_cells = table.rows[0].cells
    heading_cells[0].text = "Parameter"
    heading_cells[1].text = "Value"

    rows = [
        ("Entity Name", str(entity_name)),
        ("Known Aliases", str(known_aliases)),
        ("Location", str(location)),
        ("Employment", str(employment)),
        ("Individual/Entity Flag", str(indv_flag)),
        ("Language Searched", str(language_abbrv)),
        ("Minimum Similarity", str(min_similarity)),
        ("Maximum Sentiment", str(max_sentiment)),
        ("Month Filter cutoff", str(min_month)),
        ("Year Filter cutoff", str(min_year)),
        ("Maximum Search Resullts", str(max_search_results)),
    ]

    for row in rows:
        cells = table.add_row().cells
        for idx, item in enumerate(row):
            cells[idx].text = str(item)

    # footer
    p = word_doc.add_heading("Notes: ")
    Fstyle = word_doc.styles["Quote"]
    font = Fstyle.font
    font.size = Pt(9)
    p = word_doc.add_paragraph(" ")
    p.style = Fstyle

    p.add_run(note2_1 + '\n')
    p.add_run(note3_1 + '\n')
    p.add_run(note4_1 + note4_2 + note4_3 + '\n')
    p.add_run(note1_1 + '\n')

    word_doc.add_page_break()
    # END WORD FIRST PAGE

    # disciplinary actions
    num_disciplinary_actions = disciplinary_action_info.get('num_actions')
    if num_disciplinary_actions is None:
        logger.warning("'num_actions' key not provided in 'disciplinary_action_info' dictionary. Defaulting to 0 ..")
        num_disciplinary_actions = 0

    p = word_doc.add_heading(f"Total Disciplinary Actions: {str(num_disciplinary_actions)}", level=1)

    if num_disciplinary_actions:

        # "NYSE Disciplinary Actions" table
        nyse_disciplinary_action_info = disciplinary_action_info.get('nyse', [])

        p = word_doc.add_heading("NYSE Disciplinary Actions", level=1)

        column_header_list = ["Date", "Entity", "Action Type", "Reference"]
        table = word_doc.add_table(len(nyse_disciplinary_action_info) + 1, len(column_header_list))
        table.style = "LightList-Accent1"

        heading_cells = table.rows[0].cells
        for idx, column_header in enumerate(column_header_list):
            heading_cells[idx].text = column_header

        for idx, info in enumerate(nyse_disciplinary_action_info):
            table.cell(idx + 1, 0).text = str(info["date"].date())
            table.cell(idx + 1, 1).text = str(info["entity"])
            table.cell(idx + 1, 2).text = str(info["action_type"])
            add_hyperlink(table.cell(idx + 1, 3), str(info["file_name"]), str(info["doc_ref"]), "222AFF", False)

        # "OCC Disciplinary Actions" table
        occ_disciplinary_action_info = disciplinary_action_info.get('occ', [])

        p = word_doc.add_heading("OCC Disciplinary Actions", level=1)

        column_header_list = ["Date", "Entity", "Action Type", "Fine Amount", "Reference"]
        table = word_doc.add_table(len(occ_disciplinary_action_info) + 1, len(column_header_list))
        table.style = "LightList-Accent1"

        heading_cells = table.rows[0].cells
        for idx, column_header in enumerate(column_header_list):
            heading_cells[idx].text = column_header

        for idx, info in enumerate(occ_disciplinary_action_info):
            table.cell(idx + 1, 0).text = str(info["date"].date())
            table.cell(idx + 1, 1).text = str(info["entity"])
            table.cell(idx + 1, 2).text = str(info["action_type"])
            table.cell(idx + 1, 3).text = "${:,}".format(info["fine_amt"])
            add_hyperlink(table.cell(idx + 1, 4), str(info["file_name"]), str(info["doc_ref"]), "222AFF", False)
        
        # "FINRA Disciplinary Actions" table
        finra_disciplinary_action_info = disciplinary_action_info.get('finra', [])

        p = word_doc.add_heading("FINRA Disciplinary Actions", level=1)

        column_header_list = ["Date", "Entity", "Action Type", "Reference"]
        table = word_doc.add_table(len(finra_disciplinary_action_info) + 1, len(column_header_list))
        table.style = "LightList-Accent1"

        heading_cells = table.rows[0].cells
        for idx, column_header in enumerate(column_header_list):
            heading_cells[idx].text = column_header

        for idx, info in enumerate(finra_disciplinary_action_info):
            table.cell(idx + 1, 0).text = str(info["action_date"].date())
            table.cell(idx + 1, 1).text = str(info["firms_individuals"])
            table.cell(idx + 1, 2).text = str(info["document_type"])
            add_hyperlink(table.cell(idx + 1, 3), str(info["file_name"]), str(info["case_id"]), "222AFF", False)

        # "NYDFS Disciplinary Actions" table
        nydfs_disciplinary_action_info = disciplinary_action_info.get('nydfs', [])

        p = word_doc.add_heading("NYDFS Disciplinary Actions", level=1)

        column_header_list = ["Date", "Entity", "Action Type", "Reference"]
        table = word_doc.add_table(len(nydfs_disciplinary_action_info) + 1, len(column_header_list))
        table.style = "LightList-Accent1"

        heading_cells = table.rows[0].cells
        for idx, column_header in enumerate(column_header_list):
            heading_cells[idx].text = column_header

        for idx, info in enumerate(nydfs_disciplinary_action_info):
            table.cell(idx + 1, 0).text = str(info["action_date"].date())
            table.cell(idx + 1, 1).text = str(info["entity"])
            table.cell(idx + 1, 2).text = str(info["action_type"])
            for idx_f, file_name in enumerate(info["file_names"]):
                add_hyperlink(table.cell(idx + 1, 3), str(file_name), f"Document #{idx_f + 1}", "222AFF", False)

        # "SEC Litigation Releases" table
        sec_litigation_releases_info = disciplinary_action_info.get('sec_lit', [])

        p = word_doc.add_heading("SEC Litigation Releases", level=1)

        column_header_list = ["Date", "Entity", "Action Type", "Reference"]
        table = word_doc.add_table(len(sec_litigation_releases_info) + 1, len(column_header_list))
        table.style = "LightList-Accent1"

        heading_cells = table.rows[0].cells
        for idx, column_header in enumerate(column_header_list):
            heading_cells[idx].text = column_header

        for idx, info in enumerate(sec_litigation_releases_info):
            table.cell(idx + 1, 0).text = str(info["date"].date())
            table.cell(idx + 1, 1).text = str(info["entity"])
            table.cell(idx + 1, 2).text = str(info["action_type"])
            add_hyperlink(table.cell(idx + 1, 3), str(info["file_name"]), info["doc_ref"], "222AFF", False)

    word_doc.add_page_break()

    # FINRA Broker Check summary page
    if len(finra_broker_check_info):
        p = word_doc.add_heading("Basic Firm Information", level=1)

        basic_info = finra_broker_check_info.get("basicInformation")

        table = word_doc.add_table(1, 2)
        table.style = "LightList-Accent1"

        heading_cells = table.rows[0].cells
        heading_cells[0].text = "Attribute"
        heading_cells[1].text = "Value"

        rows = [
            ("Firm Name", basic_info.get("firmName")),
            ("Other Names", ', '.join(basic_info.get("otherNames"))),
            ("Firm Type", basic_info.get("firmType")),
            ("FINRA CRD", basic_info.get("firmId")),
            ("SEC ID", "-".join([basic_info.get("iaSECNumberType", ""), basic_info.get("iaSECNumber", "")])),
            ("Broker Check Status", basic_info.get("bcScope")),
            ("FINRA Registered", basic_info.get("finraRegistered", "N")),
            ("FINRA District", basic_info.get("districtName", "")),
            ("Formed State", basic_info.get("formedState", "")),
            ("Formed Date", basic_info.get("formedDate", "")),
        ]

        for row in rows:
            cells = table.add_row().cells
            for idx, item in enumerate(row):
                cells[idx].text = str(item)

        p = word_doc.add_heading("Disclosures", level=1)

        last_run_date_str = finra_broker_check_info.get("last_run_ts")
        if last_run_date_str is not None:
            last_run_date_str = datetime.fromtimestamp(last_run_date_str).strftime("%c")
        else:
            last_run_date_str = "N/A"

        p = word_doc.add_paragraph("")
        p.add_run("Last disclosure check date:").underline = True
        p.add_run(f" {last_run_date_str}")

        p = word_doc.add_paragraph("")
        p.add_run("Time elapsed since last check:").underline = True
        days_elapsed = finra_broker_check_info.get("days_elapsed_since_last_run")
        p.add_run(f" {str(days_elapsed)} days")

        num_new_disclosures = 0
        disclosure_info = finra_broker_check_info.get("disclosures")
        for item in disclosure_info:
            num_new_disclosures += item["change"]

        p = word_doc.add_paragraph("")
        p.add_run("New disclosures since last check:").underline = True
        p.add_run(f" {str(num_new_disclosures)} disclosures")

        p = word_doc.add_heading("Disclosure Type Detail", level=1)

        table = word_doc.add_table(len(disclosure_info) + 1, 3)
        table.style = "LightList-Accent1"

        heading_cells = table.rows[0].cells
        heading_cells[0].text = "Disclosure Type"
        heading_cells[1].text = "Event Count"
        heading_cells[2].text = "Net Change"

        for idx, info in enumerate(disclosure_info):
            table.cell(idx + 1, 0).text = info["type"]
            table.cell(idx + 1, 1).text = str(info["count"])
            table.cell(idx + 1, 2).text = str(info["change"])

        disclosure_detail_dict_list = finra_broker_check_info.get("disclosure_detail", [])
        word_doc.add_paragraph("")
        p = word_doc.add_paragraph(f"Latest final regulatory disclosures (successfully parsed {str(len(disclosure_detail_dict_list))} total events):")

        disclosure_detail_dict_list = disclosure_detail_dict_list[:5]

        table = word_doc.add_table(len(disclosure_detail_dict_list) + 1, 4)
        table.style = "LightList-Accent1"

        heading_cells = table.rows[0].cells
        heading_cells[0].text = "Date"
        heading_cells[1].text = "Initiated By"
        heading_cells[2].text = "Event Outcome"
        heading_cells[3].text = "Reference"

        for idx, info in enumerate(disclosure_detail_dict_list):
            table.cell(idx + 1, 0).text = info["Date Initiated"]
            table.cell(idx + 1, 1).text = info["Initiated By"]
            table.cell(idx + 1, 2).text = info["Sanctions Ordered"]
            table.cell(idx + 1, 3).text = info["Docket/Case Number"]

        p = word_doc.add_heading("Direct Owners and Executive Officers", level=1)

        last_run_date_str = finra_broker_check_info.get("last_run_ts")
        if last_run_date_str is not None:
            last_run_date_str = datetime.fromtimestamp(last_run_date_str).strftime("%c")
        else:
            last_run_date_str = "N/A"

        p = word_doc.add_paragraph("")
        p.add_run("Last disclosure check date:").underline = True
        p.add_run(f" {last_run_date_str}")

        p = word_doc.add_paragraph("")
        p.add_run("Time elapsed since last check:").underline = True
        days_elapsed = finra_broker_check_info.get("days_elapsed_since_last_run")
        p.add_run(f" {str(days_elapsed)} days")

        num_mgmt_changes = 0
        direct_owner_dict_list = finra_broker_check_info.get("directOwners")
        for item in direct_owner_dict_list:
            num_mgmt_changes += item["new"]

        p = word_doc.add_paragraph("")
        p.add_run("Management changes since last check:").underline = True
        p.add_run(f" {str(num_mgmt_changes)}")

        table = word_doc.add_table(len(direct_owner_dict_list) + 1, 3)
        table.style = "LightList-Accent1"

        heading_cells = table.rows[0].cells
        heading_cells[0].text = "Name"
        heading_cells[1].text = "Position"
        heading_cells[2].text = "Change Flag"

        for idx, info in enumerate(direct_owner_dict_list):
            if info.get("url", "") == "":
                table.cell(idx + 1, 0).text = info["legalName"]
            else:
                add_hyperlink(table.cell(idx + 1, 0), str(info["url"]), str(info["legalName"]), "222AFF", False)
            
            table.cell(idx + 1, 1).text = info["position"]
            table.cell(idx + 1, 2).text = str(info["new"])

        word_doc.add_page_break()

    # BEGIN PDF first page
    # Heading for overall negative news score
    h1_1 = Paragraph("Entity Searched: " + entity_name, styles["Title"])
    Story.append(h1_1)
    p1 = Paragraph(
        "<para align=center><br/><font size=11><b><u>Total Negative News Score</u></b></font><font size=8><sup>1</sup></font>: "
        + str(round(normalized_risk_score, 2))
        + "%"
        + "</para>",
        styles["Heading2"],
    )
    Story.append(p1)

    # "Searched Links Details" table
    t_h = Paragraph(
        "<para align=center><br/><font size=11><b><u>Search Links Details</u></b></font><font size=8><sup>2</sup></font> </para>",
        styles["Heading2"],
    )
    Story.append(t_h)

    row0 = Paragraph("<para align=center><b>Detail Type </b></para>", styles["Normal"])
    row1 = Paragraph("<para align=center>Total links returned </para>", styles["Normal"])
    row2 = Paragraph("<para align=center>Links remaining after filtering</para>", styles["Normal"])
    row3 = Paragraph("<para align=center>Links utilized for risk scoring</para>", styles["Normal"])
    row31 = Paragraph("<para align=center>Links displayed</para>", styles["Normal"])
    row4 = Paragraph("<para align=center>Total fines found</para>", styles["Normal"])
    row0_2 = Paragraph("<para align=center><b>Count </b></para>", styles["Normal"])
    row1_2 = Paragraph("<para align=center>" + str(NumStartUrls) + "</para>", styles["Normal"])
    row2_2 = Paragraph("<para align=center>" + str(links_after_filter) + "</para>", styles["Normal"])
    row3_2 = Paragraph("<para align=center>" + str(max_links_for_score) + "</para>", styles["Normal"])
    row3_2_2 = Paragraph("<para align=center>" + str(min(max_search_results, max_links_for_score)) + "</para>", styles["Normal"])
    row4_2 = Paragraph("<para align=center>" + "$" + str(total_fine_amt) + "</para>", styles["Normal"])
    data = [[row0, row0_2], [row1, row1_2], [row2, row2_2], [row3, row3_2], [row31, row3_2_2], [row4, row4_2]]
    t = Table(data, hAlign="CENTER")
    t.setStyle(TableStyle([("INNERGRID", (0, 0), (-1, -1), 0.25, colors.black), ("BOX", (0, 0), (-1, -1), 0.25, colors.black)]))
    Story.append(t)

    # "Average Relevance Scores" table
    p3 = Paragraph(
        "<para align=center><font size=11><b><u>Average Relevance Scores</u></b></font><font size=8><sup>3</sup></font> </para>",
        styles["Heading2"],
    )
    Story.append(p3)
    p4_0 = Paragraph("<para align=center><b>Relevance Type </b></para>", styles["Normal"])
    p4_1 = Paragraph("<para align=center>Name</para>", styles["Normal"])
    p4_2 = Paragraph("<para align=center>Location</para>", styles["Normal"])
    p4_3 = Paragraph("<para align=center>Employment</para>", styles["Normal"])
    p5_0 = Paragraph("<para align=center><b>Score </b></para>", styles["Normal"])
    p5_1 = Paragraph("<para align=center>" + str(round(name_fuzzy_score, 2)) + "</para>", styles["Normal"])
    p5_2 = Paragraph("<para align=center>" + str(round(location_fuzzy_score, 2)) + "</para>", styles["Normal"])
    p5_3 = Paragraph("<para align=center>" + str(round(employment_fuzzy_score, 2)) + "</para>", styles["Normal"])
    data2 = [[p4_0, p5_0], [p4_1, p5_1], [p4_2, p5_2], [p4_3, p5_3]]
    t2 = Table(data2, hAlign="CENTER")
    t2.setStyle(TableStyle([("INNERGRID", (0, 0), (-1, -1), 0.25, colors.black), ("BOX", (0, 0), (-1, -1), 0.25, colors.black)]))
    Story.append(t2)

    # "Article Type Summary" table
    p4 = Paragraph("<para align=center><font size=11><b><u>Article Type Summary</u></b></font> </para>", styles["Heading2"])
    Story.append(p4)
    p0_1 = Paragraph("<para align=center>Top Search Terms</para>", styles["Normal"])
    p0_2 = Paragraph("<para align=center>Article Count</para>", styles["Normal"])
    p0_3 = Paragraph("<para align=center>Percent</para>", styles["Normal"])

    row_list = [[p0_1, p0_2, p0_3]]
    for idx, info in enumerate(top_search_terms_info):
        term, count = info
        p0 = Paragraph("<para align=center>" + term + "</para>", styles["Normal"])
        p1 = Paragraph("<para align=center>" + str(count) + "</para>", styles["Normal"])
        p2 = Paragraph("<para align=center>" + str(int((count / links_after_filter) * 100)) + "%" + "</para>", styles["Normal"])
        row_list.append([p0, p1, p2])

    t22 = Table(row_list, hAlign="CENTER")
    t22.setStyle(TableStyle([("INNERGRID", (0, 0), (-1, -1), 0.25, colors.black), ("BOX", (0, 0), (-1, -1), 0.25, colors.black)]))
    Story.append(t22)

    # "Model weights" table
    p4 = Paragraph("<para align=center><font size=11><b><u>Document Ranking Weights</u></b></font> </para>", styles["Heading2"])
    Story.append(p4)
    p0_1 = Paragraph("<para align=center>Ranking Type</para>", styles["Normal"])
    p0_2 = Paragraph("<para align=center>Weight</para>", styles["Normal"])

    row_list1 = [[p0_1, p0_2]]
    for idx, (k, v) in enumerate(model_weights.items()):
        p0 = Paragraph("<para align=center>" + k + "</para>", styles["Normal"])
        p1 = Paragraph("<para align=center>" + str(v) + "</para>", styles["Normal"])
        row_list1.append([p0, p1])

    t23 = Table(row_list1, hAlign="CENTER")
    t23.setStyle(TableStyle([("INNERGRID", (0, 0), (-1, -1), 0.25, colors.black), ("BOX", (0, 0), (-1, -1), 0.25, colors.black)]))
    Story.append(t23)

    # "Search terms used" printout
    h2_22 = Paragraph(
        "<para align=center><font size=11><b><u>Search Terms Used In Analysis</u></b></font><font size=8><sup>4</sup></font></para>",
        styles["Heading2"],
    )
    Story.append(h2_22)
    address1 = '<para align=center><link href="' + '">' + ", ".join(all_search_terms) + "</link></para>"
    a_22 = Paragraph(address1, styles["Normal"])
    Story.append(a_22)

    h2_1 = Paragraph(
        "<para align=center><font size=11><b><u>Domains Searched</u></b></font><font size=8></font> </para>", styles["Heading2"]
    )
    Story.append(h2_1)
    address = '<para align=center><link href="' + '">' + ", ".join(entity_querylist) + "</link></para>"
    a_1 = Paragraph(address, styles["Normal"])
    Story.append(a_1)

    # "Input Parameters" table
    p39 = Paragraph(
        "<para align=center><font size=11><b><u>User Input Parameters</u></b></font><font size=8></font> </para>", styles["Heading2"]
    )
    Story.append(p39)
    p4_0 = Paragraph("<para align=center><b>Parameter </b></para>", styles["Normal"])
    p4_1 = Paragraph("<para align=center>Entity Name</para>", styles["Normal"])
    p4_2 = Paragraph("<para align=center>Known Aliases</para>", styles["Normal"])
    p4_3 = Paragraph("<para align=center>Location</para>", styles["Normal"])
    p4_4 = Paragraph("<para align=center>Employment</para>", styles["Normal"])
    p4_5 = Paragraph("<para align=center>Individual Entity Flag</para>", styles["Normal"])
    p4_6 = Paragraph("<para align=center>Language Searched</para>", styles["Normal"])
    p4_7 = Paragraph("<para align=center>Minimum Similarity</para>", styles["Normal"])
    p4_8 = Paragraph("<para align=center>Maximum Sentiment</para>", styles["Normal"])
    p4_9 = Paragraph("<para align=center>Month Filter cutoff</para>", styles["Normal"])
    p4_10 = Paragraph("<para align=center>Year Filter cutoff</para>", styles["Normal"])
    p4_11 = Paragraph("<para align=center>Maximum Search Resullts</para>", styles["Normal"])
    p5_0 = Paragraph("<para align=center><b>Value </b></para>", styles["Normal"])
    p5_1 = Paragraph("<para align=center>" + str(entity_name) + "</para>", styles["Normal"])
    p5_2 = Paragraph("<para align=center>" + str(known_aliases) + "</para>", styles["Normal"])
    p5_3 = Paragraph("<para align=center>" + str(location) + "</para>", styles["Normal"])
    p5_4 = Paragraph("<para align=center>" + str(employment) + "</para>", styles["Normal"])
    p5_5 = Paragraph("<para align=center>" + str(indv_flag) + "</para>", styles["Normal"])
    p5_6 = Paragraph("<para align=center>" + str(language_abbrv) + "</para>", styles["Normal"])
    p5_7 = Paragraph("<para align=center>" + str(min_similarity) + "</para>", styles["Normal"])
    p5_8 = Paragraph("<para align=center>" + str(max_sentiment) + "</para>", styles["Normal"])
    p5_9 = Paragraph("<para align=center>" + str(min_month) + "</para>", styles["Normal"])
    p5_10 = Paragraph("<para align=center>" + str(min_year) + "</para>", styles["Normal"])
    p5_11 = Paragraph("<para align=center>" + str(max_search_results) + "</para>", styles["Normal"])
    data29 = [
        [p4_0, p5_0],
        [p4_1, p5_1],
        [p4_2, p5_2],
        [p4_3, p5_3],
        [p4_4, p5_4],
        [p4_5, p5_5],
        [p4_6, p5_6],
        [p4_7, p5_7],
        [p4_8, p5_8],
        [p4_9, p5_9],
        [p4_10, p5_10],
        [p4_11, p5_11],
    ]

    t29 = Table(data29, hAlign="CENTER")
    t29.setStyle(TableStyle([("INNERGRID", (0, 0), (-1, -1), 0.25, colors.black), ("BOX", (0, 0), (-1, -1), 0.25, colors.black)]))
    Story.append(t29)

    # Add footer
    p39 = Paragraph("<para align=center><font size=11><b><u>Notes </u></b></font><font size=8></font> </para>", styles["Heading2"])
    Story.append(p39)

    style_footer = ParagraphStyle(name="right", parent=styles["Normal"], fontName="Helvetica", fontSize=9)

    footer = Paragraph(note2_1, style_footer)
    footer1 = Paragraph(note3_1, style_footer)
    footer2 = Paragraph(note4_1 + " " + note4_2 + " " + note4_3, style_footer)
    footer3 = Paragraph(note1_1, style_footer)

    Story.append(footer)
    Story.append(footer1)
    Story.append(footer2)
    Story.append(footer3)

    Story.append(PageBreak())

    # END PDF FIRST PAGE

    # Add Links heading to Top of first page with article details
    h2_4 = Paragraph("<para align=center><font size = 11><u>Links</u></font> </para>", styles["Heading2"])
    Story.append(h2_4)

    if links_after_filter:
        article_dict_list_rss = [item for item in article_dict_list if item["scraper"] == "rss"]
        if len(article_dict_list_rss):
            p = word_doc.add_heading("Regulatory News Headlines", level=1)
            word_doc, Story, doc = create_link_detail_section(article_dict_list_rss, entity_name, word_doc, Story, doc, styles)

        article_dict_list_not_rss = [item for item in article_dict_list if item["scraper"] != "rss"]
        if len(article_dict_list_not_rss):
            p = word_doc.add_heading("Other Negative News", level=1)
            word_doc, Story, doc = create_link_detail_section(article_dict_list_not_rss, entity_name, word_doc, Story, doc, styles)

    return pdf_filename, word_doc 

def create_link_detail_section(article_dict_list, entity_name, word_doc, Story, doc, styles):
    # Iterate through the URLs and add summary for each article to Word and Pdf
    for idx, item in enumerate(article_dict_list):
        # WORD
        # Number and Doc Title
        p = word_doc.add_paragraph("", style="List Number")
        p.add_run(str(item["title"])).underline = True
        p.bold = True

        # Binned ranking values
        table = word_doc.add_table(2, len(BINNED_VALUE_KEY_NAMES) + 1)
        table.style = "LightList-Accent1"
        table.cell(0, 0).text = "Doc Score"
        table.cell(1, 0).text = str(round(item["final_score"], 3))
        for idx, key in enumerate(BINNED_VALUE_KEY_NAMES):
            table.cell(0, idx + 1).text = key.replace("_", " ").title()
            table.cell(1, idx + 1).text = str(item[key])

        # Entity name/type/search term/source
        p = word_doc.add_paragraph(" ")
        p.add_run("Site Type:").underline = True
        if item["regulatory_flag"]:
            p.add_run(" Regulatory")
        else:
            p.add_run(" Non-Regulatory")
        p = word_doc.add_paragraph(" ")
        p.add_run("Entity Name:").underline = True
        p.add_run(" " + str(entity_name).upper())
        p = word_doc.add_paragraph(" ")
        p.add_run("Article Type:").underline = True
        p.add_run(" " + str(", ".join(item["document_categories"])))
        p = word_doc.add_paragraph(" ")
        p.add_run("Top Search Term:").underline = True
        p.add_run(" " + item["desm_term"].title())
        p = word_doc.add_paragraph(" ")
        p.add_run("Source:").underline = True
        p.add_run(" " + str(item["source"]))

        # site name hyperlinked
        p = word_doc.add_paragraph(" ")
        p.add_run("URL:").underline = True
        p.add_run(" ")
        add_hyperlink(p, html.escape(item["url"]), html.escape(item["url"]), "222AFF", False)

        # Date published
        p = word_doc.add_paragraph(" ")
        p.add_run("Date:").underline = True
        p.add_run(" " + str(item["date"].date()))

        # Text summary
        p = word_doc.add_paragraph(" ")
        p.add_run("Article Summary:").underline = True
        p = word_doc.add_paragraph(str(item["summary"]))

        # Top sentences
        p = word_doc.add_paragraph(" ")
        p.add_run("Key Findings:").underline = True
        for w in item["desm_sentences"]: # w2vtopsent[t]
            p = word_doc.add_paragraph(w, style="List Bullet")

        # Fines
        if len(item["fine_report_strings"]) > 0:
            p = word_doc.add_paragraph(" ")
            p.add_run("Actions Taken: ").underline = True
            for fine_report in item["fine_report_strings"]:
                p = word_doc.add_paragraph(" ")
                p.add_run(fine_report)

        p = word_doc.add_paragraph(" ")

        if item["semantic_duplicate_info"] != {}:
            p = word_doc.add_paragraph(" ")
            p.add_run("Similar Articles: ").underline = True
            # for item in semantic_duplicate_metadata:
            for _item in item["semantic_duplicate_info"]:
                p = word_doc.add_paragraph(" ")
                add_hyperlink(p, _item["url"], _item["title"], "222AFF", False)

        # PDF
        # Number and Doc Title
        tempR = Paragraph(str(idx + 1) + ". " + "<u>" + str(item["title"]) + "</u>", styles["Normal"])
        Story.append(tempR)

        # Binned ranking values
        p00 = Paragraph("<para align=center>Doc Score</para>", styles["Normal"])
        p11 = Paragraph("<para align=center>" + str(round(item["final_score"], 2)) + "</para>", styles["Normal"])
        row_list2 = [[p00, p11]]
        for idx, key in enumerate(BINNED_VALUE_KEY_NAMES):
            p0 = Paragraph("<para align=center>" + key.replace("_", " ").title() + "</para>", styles["Normal"])
            p1 = Paragraph("<para align=center>" + str(item[key]) + "</para>", styles["Normal"])
            row_list2.append([p0, p1])
        row_list2 = list(map(list, zip(*row_list2)))
        t24 = Table(row_list2, hAlign="CENTER")
        t24.setStyle(TableStyle([("INNERGRID", (0, 0), (-1, -1), 0.25, colors.black), ("BOX", (0, 0), (-1, -1), 0.25, colors.black)]))
        Story.append(t24)

        # Entity name/type/search term/source
        tempE = Paragraph("<para lindent=11> " + "<u>Entity Name:</u> " + str(entity_name).upper() + "</para>", styles["Normal"])
        Story.append(tempE)
        tempA = Paragraph("<para lindent=11> Article Type: " + str(" ".join(item["document_categories"])) + "</para>", styles["Normal"])
        Story.append(tempA)
        tempTS = Paragraph("<para lindent=11> Top Search Term: " + str(item["desm_term"].title()) + "</para>", styles["Normal"])
        Story.append(tempTS)
        tempSRC = Paragraph("<para lindent=11> Source: " + str(item["source"]) + "</para>", styles["Normal"])
        Story.append(tempSRC)

        # site name hyperlinked
        tempN = Paragraph(
            "<para lindent=11>" + str(item["source"]) + " Press Release: " + html.escape(item["url"]) + "</para>", styles["Normal"]
        )
        Story.append(tempN)

        # Date published
        tempDate = Paragraph(
            "<para lindent=11>" + "<u>" + str(item["date"].date()) + " - " + str(item["title"]) + "</u></para>", styles["Normal"]
        )
        Story.append(tempDate)

        # Text summary
        tempSum = Paragraph("<para lindent=11> " + "<br/>" + "Article Summary: " + "</para>", styles["Normal"])
        Story.append(tempSum)
        tempS = Paragraph("<para lindent=45> " + str(item["summary"]) + "<br/>" + "</para>", styles["Normal"])
        Story.append(tempS)

        # Top sentences
        tempx = Paragraph("<para lindent=11> " + "<br/>" + "Key Findings: " + "</para>", styles["Normal"])
        Story.append(tempx)

        for w in item["desm_sentences"]:
            tempx = Paragraph("<para lindent=45> " + "\n\u2022" + str(w) + "<br/>" + "</para>", styles["Normal"])
            Story.append(tempx)

        temp5 = Paragraph("<para><br/><br/></para>", styles["Normal"])
        if len(item["fine_report_strings"]) > 0:
            fine_pdf_info = (
                reduce(lambda agg, x: agg + x + "<br/>", item["fine_report_strings"], "<para lindent=11><u>Actions Taken:</u><br/>") + "<br/></para>"
            )
            temp5 = Paragraph(fine_pdf_info, styles["Normal"])
        Story.append(temp5)

        temp4 = Paragraph("<para lindent=11></para>", styles["Normal"])
        Story.append(temp4)

    # Build the word Story
    doc.build(Story)

    # Add story to the word document
    word_doc.add_paragraph(Story)

    return word_doc, Story, doc


# defining footer for pdf
class FooterCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        canvas.Canvas.__init__(self, *args, **kwargs)
        self.pages = []

    def showPage(self):
        self.pages.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        page_count = len(self.pages)
        for page in self.pages:
            self.__dict__.update(page)
            self.draw_canvas(page_count)
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)

    def draw_canvas(self, page_count):
        page = "Page %s of %s" % (self._pageNumber, page_count)
        note2_1 = "The above Total Negative News Score is the a percentage between 0-100 with higher % representing higher risk."
        note1_1 = "The above Search Clause searches the input first name and last name with up to three word in between. The"
        note1_2 = (
            "included quotes ensures that the searched name will appear in every result. In addition, at least one term"
            + " from the above negative news "
        )
        note1_3 = "list will appear in every result analyzed. "
        note3_1 = "Links are filtered out by a pre-determined blacklist which includes, for example, links from LinkedIn or Facebook. "
        note4_1 = (
            "Note that the above Name score will always be high due to the structure of the search clause. "
            + "The confidence score for location"
        )
        note4_2 = (
            "is the result of an approximate or partial match between the input location information and "
            + "the location that was found on the google "
        )
        note4_3 = "search results. N/A implies location / Employment was not explicitly provided. "
        x = 128
        self.saveState()
        self.setStrokeColorRGB(0, 0, 0)
        self.setLineWidth(0.5)
        self.line(66, 150, letter[0] - 66, 150)
        self.setFont("Helvetica", 5)
        self.drawString(66, 140, "1")
        self.drawString(66, 130, "2")
        self.drawString(66, 120, "3")
        self.drawString(66, 90, "4")
        self.setFont("Helvetica", 8)
        self.drawString(69, 140, note2_1)
        self.drawString(69, 130, note3_1)
        self.drawString(69, 120, note4_1)
        self.drawString(69, 110, note4_2)
        self.drawString(69, 100, note4_3)
        self.drawString(69, 90, note1_1)
        self.drawString(69, 80, note1_2)
        self.drawString(69, 70, note1_3)
        self.drawString(letter[0] - x, 65, page)
        self.restoreState()


def add_hyperlink(paragraph, url, text, color, underline):
    """
    A function that places a hyperlink within a paragraph object.

    :param paragraph: The paragraph we are adding the hyperlink to.
    :param url: A string containing the required url
    :param text: The text displayed for the url
    :return: The hyperlink object
    """

    # This gets access to the document.xml.rels file and gets a new relation id value
    part = paragraph.part
    r_id = part.relate_to(url, docx.opc.constants.RELATIONSHIP_TYPE.HYPERLINK, is_external=True)

    # Create the w:hyperlink tag and add needed values
    hyperlink = docx.oxml.shared.OxmlElement("w:hyperlink")
    hyperlink.set(docx.oxml.shared.qn("r:id"), r_id)

    # Create a w:r element
    new_run = docx.oxml.shared.OxmlElement("w:r")

    # Create a new w:rPr element
    rPr = docx.oxml.shared.OxmlElement("w:rPr")

    # Add color if it is given
    if color is not None:
        c = docx.oxml.shared.OxmlElement("w:color")
        c.set(docx.oxml.shared.qn("w:val"), color)
        rPr.append(c)

    # Remove underlining if it is requested
    if not underline:
        u = docx.oxml.shared.OxmlElement("w:u")
        u.set(docx.oxml.shared.qn("w:val"), "none")
        rPr.append(u)

    # Join all the xml elements together add add the required text to the w:r element
    new_run.append(rPr)
    new_run.text = text
    hyperlink.append(new_run)

    try:
        paragraph._p.append(hyperlink)
    except AttributeError as e:
        # handling for when 'paragraph' is a table cell
        paragraph._tc.p_lst[0].append(hyperlink)

    return hyperlink
