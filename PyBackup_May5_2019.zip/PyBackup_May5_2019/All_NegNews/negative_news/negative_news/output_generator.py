'''
This file contains functionality to execute output generation in a separate Python process.
'''

import logging
import time
import asyncio
import pickle
from multiprocessing import Process

from .util.output import create_pdf_summary

logger = logging.getLogger(__name__)


class NegativeNewsOutputGenerator:
    async def start(self, job_name, pk_path_output_args):
        logger.debug(f'NegativeNewsOutputGenerator starting for job "{job_name}" ..')

        generate_output_job = GenerateOutputJob(job_name, pk_path_output_args)
        generate_output_job.start()

        tock = time.perf_counter()
        await generate_output_job.join()
        tick = time.perf_counter()

        logger.debug(f"NegativeNewsOutputGenerator finished for job '{job_name}'." + f"Operation took {round(tick - tock, 2)}s ..")


class GenerateOutputJob(Process):
    def __init__(self, job_name, pk_path_output_args):
        super().__init__()

        self.job_name = job_name

        with open(pk_path_output_args, "rb") as f:
            self.output_args = pickle.load(f)

    async def join(self):
        '''Performs process clean-up on GenerateOutputJob exit. Overrides the 'join' method of the 'Process' class.'''
        while self.is_alive():
            logger.debug(f'GenerateOutputJob for job "{self.job_name}" is still alive. Going to sleep ..')
            await asyncio.sleep(3)
        super().join()
        logger.debug('GenerateOutputJob completed for job "{self.job_name}" ..')

    def run(self):
        '''Executes output generation in a separate process. Overrides the 'run' method of the 'Process' class.'''
        create_pdf_summary(self.output_args)

