'''
This file contains code describing data and behavior for NegativeNewsManager,
the object responsible for managing the end-to-end Negative News process for
each submitted entity job.
'''

import logging
import asyncio
import time
import os
from datetime import datetime

from .entity_job import NegativeNewsEntityJob
from .postprocessor import NegativeNewsPostprocessor
from .output_generator import NegativeNewsOutputGenerator
from .scrapers.rss import RSSFeedScraper, RSS_LAST_RUN_DATE_FPATH, RSS_REFRESH_THRESHOLD_SECONDS
from .constants import STATUS_PENDING, STATUS_SCRAPING, STATUS_PROCESSING, STATUS_GENERATING, STATUS_DONE

logger = logging.getLogger(__name__)


class NegativeNewsManager:
    def __init__(self, jobs=None):
        if jobs is not None and not isinstance(jobs, list):
            raise ValueError('"jobs" must be of type list')

        if jobs is None:
            jobs = []

        # list to hold all entity jobs added to manager
        self.jobs = []
        
        for job in jobs:
            self.add_job(job)
        
        # object that handles all postprocessing activities
        self.postprocessor = NegativeNewsPostprocessor()

        # object that handles all output generation activities
        self.output_generator = NegativeNewsOutputGenerator()

    def add_job(self, job):
        '''Adds a job to the manager and sets its status to pending'''
        if not isinstance(job, NegativeNewsEntityJob):
            raise ValueError('"job" must be of type NegativeNewsEntityJob')
        job.set_status(STATUS_PENDING)
        self.jobs.append(job)

    def get_job_info(self):
        '''Returns information for each submitted job as a list of dictionaries'''
        return [job.to_dict() for job in self.jobs]

    def load_jobs_from_xlsx(self, fname):
        '''Loads NegativeNewsEntity job objects into manager from XLSX and sets status to pending'''
        # TODO: write load jobs from xlsx
        pass

    async def async_start(self):
        '''Starts all pending entity jobs that have been added to the manager'''
        # refresh RSS information feed if necessary
        if not os.path.isfile(RSS_LAST_RUN_DATE_FPATH) or \
        (datetime.now() - datetime.fromtimestamp(os.path.getmtime(RSS_LAST_RUN_DATE_FPATH))).seconds > RSS_REFRESH_THRESHOLD_SECONDS:
            logger.debug("Refreshing RSS feed database ..")
            rss_feed_scraper = RSSFeedScraper()

            tock = time.perf_counter()
            await rss_feed_scraper.start()
            tick = time.perf_counter()

            logger.debug(f"RSS refresh completed successfully. Took {round(tick - tock, 2)}s ..")
        else:
            logger.debug("Skipping RSS refresh ..")

        # create coroutine tasks representing the end-to-end negative news process for each pending job
        tasks = [asyncio.create_task(self.end_to_end(job)) for job in self.jobs if job.status == STATUS_PENDING]
        # execute the end-to-end coroutine tasks
        await asyncio.gather(*tasks)

    async def end_to_end(self, job):
        '''Asynchronous wrapper for the end-to-end Negative News process'''
        tock = time.perf_counter()

        # start scraping process and await completion
        logger.debug(f'NegativeNewsManager is about to await scrape for job "{job.job_name}" ..')
        job.set_status(STATUS_SCRAPING)
        await job.parallel_start()

        # start postprocessing and await completion
        logger.debug(f'NegativeNewsManager finished awaiting scrape for job "{job.job_name}". ' + "Awaiting postprocessing ..")
        job.set_status(STATUS_PROCESSING)
        await self.postprocessor.start(job.job_name, job.postprocess_kwargs)

        # start output generation and await completion
        logger.debug(
            f'NegativeNewsManager finished awaiting postprocessing for job "{job.job_name}".' + "Awaiting output generation .."
        )
        job.set_status(STATUS_GENERATING)
        await self.output_generator.start(job.job_name, f"{job.postprocess_kwargs['output_path']}/output_args.pk")
        tick = time.perf_counter()

        job.set_status(STATUS_DONE)
        logger.debug(f"NegativeNewsManager finished job {job.job_name}. Job took {round(tick - tock, 2)}s ..")

