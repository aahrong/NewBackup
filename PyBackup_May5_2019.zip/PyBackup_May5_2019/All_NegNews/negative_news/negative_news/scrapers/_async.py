import asyncio
import logging
import time
import hashlib
from multiprocessing import Pool

import aiohttp
import requests
from pymongo.errors import BulkWriteError

from ..database import get_scrape_feed_handle
from ..schema import schemas, validate_schema, SchemaException

HASH_ENCODING = "utf-8"

logger = logging.getLogger(__name__)

# max number processes leveraged to extract metadata in parallel
MAX_EXTRACT_PROCESSES = 10

# chunk size of iterable passed to metadata extraction worker processes
EXTRACT_CHUNK_SIZE = 3


class AsyncAPIHelper:

    url = ""
    headers = {}

    def __init__(self, job_name=None, method=None, max_requests=20, timeout=5, max_links_to_scrape=350):
        if job_name is None:
            self.job_name = ""
        else:
            self.job_name = job_name

        if self.url == "":
            raise TypeError("Child class must implement 'url' class constant")

        if self.headers == {}:
            self.headers = requests.utils.default_headers()

        if method is None:
            method = "GET"

        self.api_kwargs = {
            "url": self.url,
            "method": method,
            "headers": self.headers,
        }

        self.max_requests = max_requests
        self.timeout = timeout
        self.max_links_to_scrape = max_links_to_scrape

    def log(self, msg, lvl=logging.DEBUG):
        logger.log(lvl, f"{type(self).__name__} - {msg}")

    async def start(self):
        # set feed handle
        self.feed_handle = get_scrape_feed_handle(asyncio.get_event_loop())

        # create new aiohttp session
        self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=self.timeout))

        # set API query
        self.query = self.build_query()

        # make API request tasks
        api_request_tasks = [asyncio.create_task(self.make_api_request(i, **self.api_kwargs)) for i in range(self.max_requests)]

        # execute API request tasks
        api_response_list = await asyncio.gather(*api_request_tasks)

        # make HTML extraction tasks to add HTML to each response item
        get_html_tasks = [asyncio.create_task(self.get_html(r_idx, i_idx, item)) for r_idx, r in enumerate(api_response_list) for i_idx, item in enumerate(r)]

        # execute HTML extraction tasks
        await asyncio.gather(*get_html_tasks)

        # filter out items from each response list in the API response for which
        # we were unable to extract HTML
        api_response_list = [[item for item in response_list if item.get("html", "") != ""] for response_list in api_response_list]

        # extract features from each item in each response list in the API response
        enriched_response_list = self.enrich_response(api_response_list)

        # push results to database
        await self.push_to_database(enriched_response_list)

        # close aiohttp session
        await self.session.close()

    async def make_api_request(self, task_idx, **kwargs):
        self.log(f"Making API request #{task_idx} ..")

        # update API request params
        self.update_request_params(task_idx)

        # make initial API request
        tock = time.perf_counter()
        response = await self.session.request(params=self.params, **kwargs)
        tick = time.perf_counter()
        self.log(f"Finished API request #{task_idx}. Took {round(tick - tock, 2)}s ..")

        # convert API response to JSON and parse
        response = await response.json()
        response = self.parse_api_response(task_idx, response)

        # filter out URLs that already exist in scrape feed
        original_len = len(response)
        for item in response:
            _hash = hashlib.sha1()
            _hash.update(item["url"].encode(HASH_ENCODING))
            _hash.update(self.entity_name.encode(HASH_ENCODING))
            item.update({"_id": _hash.hexdigest()})
        cached_hashes = await self.feed_handle.find({"entity": self.entity_name}, {"_id": True})
        cached_hashes = [item["_id"] for item in cached_hashes]
        response = [item for item in response if item["_id"] not in cached_hashes]
        self.log(f"Removed {original_len - len(response)} duplicate URLs from API response #{task_idx} ..")

        return response

    def enrich_response(self, api_response_list):
        p = Pool(processes=MAX_EXTRACT_PROCESSES)
        temp = []
        for response_idx, metadata_dict_list in enumerate(api_response_list):
            tock = time.perf_counter()
            url_idx = 0
            temp = []
            results = p.imap(self.extract_metadata, metadata_dict_list, chunksize=EXTRACT_CHUNK_SIZE)
            while True:
                try:
                    metadata_dict = next(results)
                    self.modify_metadata(metadata_dict)
                    validate_schema(metadata_dict, schemas["scraped_data"])
                    temp.append(metadata_dict)
                except StopIteration:
                    break
                except SchemaException as e:
                    self.log(f"SchemaException raised after extracting feautures for URL #{url_idx} for API response #{response_idx}: {str(e)}", logging.ERROR)
                except Exception as e:
                    url = metadata_dict_list[url_idx].get("url", "")
                    self.log(f"Unexpected error occurred while extracting features for URL #{url_idx} ({url}) for API response #{response_idx}: {str(e)}", logging.ERROR)
                    
                url_idx += 1

            api_response_list[response_idx] = temp
            tick = time.perf_counter()
            self.log(f"Finished enriching API response #{response_idx}. Took {round(tick - tock, 2)}s ..")

        return api_response_list

    async def push_to_database(self, result):
        self.log(f"Aggregating scraped data and pushing to storage ..")

        result = [_dict for dict_list in result for _dict in dict_list if _dict.get("content", "") != ""]

        # do not push an empty result
        if result == []:
            self.log("Detected empty result. Aborting push ..")
            return result

        # do not push a result without a job name
        if self.job_name is None or self.job_name == "":
            raise Exception()

        try:
            inserted_info = await self.feed_handle.insert_many(result, ordered=False)
            num_inserted = len(inserted_info.inserted_ids)
            num_duplicates = 0
        except BulkWriteError as e:
            # if one or more of the result items represents a
            # duplicate, a BulkWriteError will be thrown, but any
            # unique documents will still be written to the database
            num_inserted = e.details["nInserted"]
            num_duplicates = len(e.details["writeErrors"])

        self.log(f"Pushed {num_inserted} results to scrape feed. Detected {num_duplicates} duplicates ..")

        return result

    def build_query(self):
        raise NotImplementedError

    def update_request_params(self, task_idx):
        raise NotImplementedError

    def parse_api_response(self, task_idx, response):
        raise NotImplementedError

    async def get_html(self, response_idx, url_idx, metadata_dict):
        raise NotImplementedError

    @staticmethod
    def extract_metadata(metadata_dict):
        raise NotImplementedError

    def modify_metadata(self, metadata_dict):
        raise NotImplementedError

