import asyncio
import logging
from datetime import datetime, timedelta
from random import randint
import time

import requests
from readability import Document
from bs4 import BeautifulSoup
from fake_useragent import UserAgent

from ..util.misc import clean_text, generate_sumy_summary
from ._async import AsyncAPIHelper

logger = logging.getLogger(__name__)

DEFAULT_NEWS_SOURCES = [
    'associated-press',
    'bloomberg',
    'business-insider',
    'cbs-news',
    'cnbc',
    'cnn',
    'fortune',
    'fox-news',
    'google-news',
    'msnbc',
    'nbc-news',
    'newsweek',
    'politico',
    'reuters',
    'the-economist',
    'the-new-york-times',
    'the-wall-street-journal',
    'the-washington-post',
    'the-washington-times',
    'usa-today',
]


API_KEY_PREMIUM = "774fd37c1f92472ba76cf60ba6099043" 


HTML_NOT_APPLICABLE = "N/A"


class NewsAPIScraper(AsyncAPIHelper):

    url = "https://newsapi.org/v2/everything"
    api_key_list = [
        # "46dec96f34944b88afd74c49cf22c053",
        # "03d3a2eadce6429397a965c4ad02dcdb",
        # "4182a7a8eb864ad390b6a314695b8a7f",
        # "3baacb0543f54f96915a1ee22a4b84cf",
        # "64c3f05de84f466ebab86e9a8e357091",
        # "774fd37c1f92472ba76cf60ba6099043",
        "774fd37c1f92472ba76cf60ba6099043"
    ]

    def __init__(
        self,
        entity_name,
        known_aliases_list=None,
        search_term_list=None,
        allowed_sources_list=None,
        results_per_page=100,
        exclusion_list=[".pdf", "?"],
        language_abbrv="en",
        sort_by="relevancy",
        method="GET",
        max_requests=5,
        **kwargs,
    ):
        api_key = self.generate_random_api_key()
        self.headers = {"Content-Type": "Application/JSON", "Authorization": api_key}

        super().__init__(method=method, max_requests=max_requests, **kwargs)

        self.entity_name = entity_name

        self.results_per_page = results_per_page
        self.sort_by = sort_by

        if known_aliases_list is None:
            self.known_aliases_list = []
        else:
            self.known_aliases_list = known_aliases_list

        if search_term_list is None:
            self.search_term_list = []
        else:
            self.search_term_list = search_term_list

        if allowed_sources_list is None:
            self.allowed_sources_str = ""
        else:
            self.allowed_sources_str = ",".join(allowed_sources_list)

        self.language_abbrv = language_abbrv

    def update_request_params(self, task_idx):
        self.params = {
            "q": self.query,
            "sources": self.allowed_sources_str,
            "language": self.language_abbrv,
            "sortBy": self.sort_by,
            "pageSize": self.results_per_page,
            "page": task_idx + 1,
        }

    def build_query(self):
        """Constructs NewsAPI search query"""
        if self.language_abbrv == "EN":
            entity_name = '"' + self.entity_name + '"'
            terms = ['"' + term + '"' for term in self.search_term_list]
        else:
            entity_name = self.entity_name
            terms = self.search_term_list

        entity_part = "({})".format(" OR ".join([entity_name] + self.known_aliases_list))

        term_part = "({})".format(" OR ".join(terms))

        return "{} AND {}".format(entity_part, term_part)

    def parse_api_response(self, task_idx, response):
        logger.debug(f"Handling response for request #{task_idx} ..")

        if response.get("status", "") == "error":
            raise Exception("Unexpected error occurred while querying NewsAPI. Code='{}' .. ".format(response.get("code", "")))

        try:
            response = response["articles"]
        except KeyError as e:
            logger.error(f"KeyError occurred while handling response for request #{task_idx}: {str(e)}")
            response = []

        return response

    async def get_html(self, response_idx, url_idx, metadata_dict):
        if self.headers["Authorization"] == API_KEY_PREMIUM:
            metadata_dict["html"] = HTML_NOT_APPLICABLE
        else:
            self.log(f"Retrieving HTML for URL #{url_idx} in response #{response_idx} ..")
 
            tock = time.perf_counter()

            try:
                try:
                    response = await self.session.request(url=metadata_dict["url"], method="GET", headers=headers)
                    metadata_dict["html"] = await response.text()
                except asyncio.TimeoutError:
                    self.log(f"Timeout occurred while retrieving HTML for URL #{idx} for API request #{task_idx} ..")
                    raise
                except Exception as e:
                    url = metadata_dict.get("url", "")
                    self.log(
                        f"Unexpected error occurred while retrieving HTML for URL #{idx} ({url}) "
                        + f"for API request #{task_idx}: {str(e)}",
                        lvl=logging.ERROR
                    )
                    raise
            except Exception:
                metadata_dict["html"] = ""
           
            tick = time.perf_counter()

            self.log(f"Successfully retrieved HTML for URL #{url_idx} in response #{response_idx}. Took {round(tick - tock, 2)}s ..")

    @staticmethod
    def extract_metadata(metadata_dict):       
        # get content
        if metadata_dict["html"] != HTML_NOT_APPLICABLE:
            doc = Document(metadata_dict["html"])
            soup = BeautifulSoup(doc.summary(), "lxml")
            article_text = " ".join(soup.findAll(text=True))
        else:
            doc = None
            article_text = metadata_dict["content"]
        
        if not isinstance(article_text, str): 
            raise Exception(f"'article_text' was expected to be of type 'str', but got {type(article_text)}")
        
        article_text_clean = clean_text(article_text)

        # get summary
        summary = metadata_dict.get("description", "")

        # get title
        title = metadata_dict.get("title", "")
        if title == "" and doc is not None:
            title = doc.short_title()

        url_content = {
            "_id": metadata_dict["_id"],
            "scraper": "NewsAPI",
            "source": metadata_dict["source"]["name"],
            "title": title,
            "date": metadata_dict["publishedAt"],
            "content": article_text_clean,
            "summary": summary,
            "url": metadata_dict["url"],
            "origtext": article_text,
        }

        return url_content

    def modify_metadata(self, metadata_dict):
        summary = metadata_dict.get("summary", "")
        content = metadata_dict.get("content", "")
        if summary == "" and content != "":
            summary = generate_sumy_summary(content, self.language_abbrv)

        metadata_dict.update({
            "entity": self.entity_name,
            "jobname": self.job_name,
            "summary": summary,
        })

    def generate_random_api_key(self, not_this_one=None, max_retries=5):
        if not_this_one is None:
            api_key = self.api_key_list[randint(0, len(self.api_key_list) - 1)]
        else:
            attempts = 0
            api_key = not_this_one
            while attempts < max_retries and api_key == not_this_one:
                api_key = self.api_key_list[randint(0, len(self.api_key_list) - 1)]
                attempts += 1

        return api_key
