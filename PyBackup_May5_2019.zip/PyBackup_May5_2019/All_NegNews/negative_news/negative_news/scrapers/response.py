from lxml import html


class NegativeNewsResponse:
    def __init__(self, url, html_str):
        self.html_str = html_str
        self._url = url

    @property
    def url(self):
        return self._url

    def xpath(self, xpath):
        self.content_list = html.fromstring(self.html_str).xpath(xpath)
        return self

    def extract(self):
        return self.content_list

    def extract_first(self):
        try:
            return self.content_list[0]
        except IndexError:
            return ""
