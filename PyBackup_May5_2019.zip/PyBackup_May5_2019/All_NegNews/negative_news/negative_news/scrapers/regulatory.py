import asyncio

import articleDateExtractor

from .general_search import BingAPIScraper
from .response import NegativeNewsResponse
from ..util.misc import clean_text, generate_sumy_summary


class RegulatoryScraper(BingAPIScraper):
    def __init__(self, *args, **kwargs):
        kwargs.update({"allowed_sources_list": DEFAULT_REGULATORY_SOURCES})
        super().__init__(*args, **kwargs)
    
    @staticmethod
    def extract_metadata(metadata_dict):
        response = NegativeNewsResponse(metadata_dict["url"], metadata_dict["html"])

        content = {}
        for base_url in REGULATORY_SITE_XPATHS.keys():
            if base_url in metadata_dict["url"]:
                for url_extension in REGULATORY_SITE_XPATHS[base_url].keys():
                    if url_extension in metadata_dict["url"]:
                        for k, v in REGULATORY_SITE_XPATHS[base_url][url_extension].items():
                            content.update({k: v(response)})

        article_text_clean = clean_text(content["content"])

        date = metadata_dict.get("date", "")
        if date == "":
            date = articleDateExtractor.extractArticlePublishedDate(metadata_dict["url"], metadata_dict["html"])

        summary = metadata_dict.get("snippet", "")

        content.update(
            {
                "_id": metadata_dict["_id"],
                "scraper": "BingRegulatory",
                "summary": summary,
                "content": article_text_clean,
                "origtext": content["content"],
            }
        )

        return content


DEFAULT_REGULATORY_SOURCES = [
    "finra.org/newsroom/",
    "occ.gov/news-issuances/news-releases",
    "investor.gov/additional-resources/news-alerts/press-releases",
    "sec.gov/news/press-release",
    "fdic.gov/news/news/press",
    "federalreserve.gov/newsevents/pressreleases",
    "cftc.gov/PressRoom/PressReleases",
]


REGULATORY_SITE_XPATHS = {
    "www.finra.org": {
        "newsroom": {
            "source": lambda r: "FINRA (Press Releases)",
            "title": lambda r: r.xpath('.//div[@class="l-main"]//h1[@class="core-title"]/text()').extract_first(),
            "date": lambda r: r.xpath('.//div[@class="l-main"]//span[@class="date-display-single"]/@content').extract_first(),
            "content": lambda r: " ".join(r.xpath('.//div[@role="article"]//*[self::li or self::p or self::a]/text()').extract()),
            "url": lambda r: r.url,
        }
    },
    "occ.gov": {
        "news-issuances/news-releases": {
            "source": lambda r: "OCC",
            "title": lambda r: r.xpath('.//div[@class="div-nr-title"]//h2/text()').extract_first(),
            "date": lambda r: r.xpath('.//div[@class="articleDateline"]/text()[preceding-sibling::br]').extract_first(),
            "content": lambda r: " ".join(
                r.xpath('.//div[@class="articleHeading"]/following-sibling::div//*[self::li or self::p or self::a]/text()').extract()
            ),
            "url": lambda r: r.url,
        }
    },
    "www.investor.gov": {
        "nadditional-resources/news-alerts/press-releases": {
            "source": lambda r: "Investor.gov (SEC)",
            "title": lambda r: "",
            "date": lambda r: "",
            "content": lambda r: "",
            "url": lambda r: r.url,
        }
    },
    "www.sec.gov": {
        "news/press-release": {
            "source": lambda r: "SEC (Press Releases)",
            "title": lambda r: r.xpath('.//h1[@class="article-title"]/text()').extract_first(),
            "date": lambda r: "",
            "content": lambda r: " ".join(
                r.xpath('.//div[@class="article-body"]//*[self::li or self::p or self::a]/text()').extract()
            ),
            "url": lambda r: r.url,
        }
    },
    "www.fdic.gov": {
        "news/news/press": {
            "source": lambda r: "FDIC (Press Releases)",
            "title": lambda r: "",
            "date": lambda r: "",
            "content": lambda r: "",
            "url": lambda r: r.url,
        }
    },
    "www.federalreserve.gov": {
        "newsevents/pressreleases": {
            "source": lambda r: "Federal Reserve (Press Releases)",
            "title": lambda r: r.xpath('.//h3[@class="title"]/text()').extract_first(),
            "date": lambda r: r.xpath('.//p[@class="article__time"]/text()').extract_first(),
            "content": lambda r: " ".join(
                r.xpath(
                    './/div[@id="article"]/div[not(contains(@class,"heading"))]//*[self::li or self::p or self::a]/text()'
                ).extract()
            ),
            "url": lambda r: r.url,
        }
    },
    "cftc.gov": {
        "PressRoom/PressReleases": {
            "source": lambda r: "CFTC (Press Releases)",
            "title": lambda r: r.xpath('.//div[@class="press-release"]//h1/text()').extract_first(),
            "date": lambda r: r.xpath('.//div[@class="press-release"]//p//text()').extract_first(),
            "content": lambda r: " ".join(
                r.xpath('.//div[@class="press-release"]//h1/following-sibling::*[self::li or self::p or self::a]/text()').extract()
            ),
            "url": lambda r: r.url,
        }
    },
}
