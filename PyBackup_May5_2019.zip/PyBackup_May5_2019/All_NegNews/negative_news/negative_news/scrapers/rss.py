import asyncio
import requests
import logging
from datetime import datetime
import re
import random
import pickle
import time
import os

import feedparser
import dateparser
import aiohttp
import requests
from pymongo.errors import BulkWriteError
from readability import Document
from bs4 import BeautifulSoup

from ..database import get_rss_feed_handle
from ..util.misc import clean_text, extract_url_domain_name, get_latest_user_agent_list, get_latest_proxy_list


logger = logging.getLogger(__name__)

RSS_METADATA_DICT_LIST = [
    # the below RSS feed is fine, but it only gives us a link at which
    # we can find a link to the monthly disciplinary action report as
    # opposed to a direct link. may need special handling
    # {
    #     "feed_name": "finra_monthly_disciplinary_actions",
    #     "feed_url": "http://feeds.finra.org/MonthlyDisciplinaryActions",
    #     "extract_content_func": "",
    # },
    {
        "feed_name": "finra_news",
        "feed_url": "http://feeds.finra.org/FINRANews",
        "extract_content_func": "",
    },
    {
        "feed_name": "occ_news",
        "feed_url": "https://www.occ.treas.gov/rss/occ_news.xml",
        "extract_content_func": "",
    },
    {
        "feed_name": "occ_alerts",
        "feed_url": "https://www.occ.treas.gov/rss/occ-alerts.xml",
        "extract_content_func": "",
    },
    {
        "feed_name": "sec_news",
        "feed_url": "https://www.sec.gov/news/pressreleases.rss",
        "extract_content_func": "",
    },
    {
        "feed_name": "sec_trade_suspensions",
        "feed_url": "https://www.sec.gov/rss/litigation/suspensions.xml",
        "extract_content_func": "",
    },
    {
        "feed_name": "sec_litigation",
        "feed_url": "https://www.sec.gov/rss/litigation/litreleases.xml",
        "extract_content_func": "",
    },
    {
        "feed_name": "frb_news",
        "feed_url": "https://www.federalreserve.gov/feeds/press_all.xml",
        "extract_content_func": "",
    },
    {
        "feed_name": "frb_enforcement_actions",
        "feed_url": "https://www.federalreserve.gov/feeds/press_enforcement.xml",
        "extract_content_func": "",
    },
    {
        "feed_name": "fdic_news",
        "feed_url": "https://public.govdelivery.com/topics/USFDIC_26/feed.rss",
        "extract_content_func": "",
    },
    {
        "feed_name": "cftc_enforcement_actions",
        "feed_url": "https://www.cftc.gov/RSS/RSSENF/rssenf.xml",
        "extract_content_func": "",
    },
    {
        "feed_name": "cboe_news",
        "feed_url": "http://www.cboe.com/rss/RSSACNews.aspx",
        "extract_content_func": "",
    },
]

URL_EXCLUSION_LIST = [".pdf"]

RSS_LAST_RUN_DATE_FPATH = f"{os.path.dirname(__file__)}/../resources/rss_last_run_ts.dat"

RSS_REFRESH_THRESHOLD_SECONDS = 3600


class RSSFeedScraper:

    def __init__(self, timeout=3, debug=False):
        self.feed_handle = get_rss_feed_handle(asyncio.get_event_loop())
        self.debug = debug
        self.user_agent_list = get_latest_user_agent_list()
        self.proxy_list = get_latest_proxy_list()
        self.timeout = timeout

    async def start(self):
        with open(RSS_LAST_RUN_DATE_FPATH, 'w') as f:
            self.log(f"Updating RSS last run date < {RSS_LAST_RUN_DATE_FPATH} > ..")
            f.write(str(time.time()))

        await self.aggregate_rss_info()
        await self.make_http_requests()

        self.results = []
        for item in self.article_dict_list:

            try:
                result = self.extract_article_features(item)
                self.results.append(result)
            except Exception as e:
                self.log(f"Exception occurred while extracting features < {item['link']} >: {str(e)}", logging.WARNING)

        self.results = [result for result in self.results if result["content"] != ""]

        if len(self.results):
            await self.push_results()
        else:
            self.log("Empty result list detected for RSSFeedScraper. Aborting push ..")

    def log(self, msg, lvl=logging.DEBUG):
        if self.debug:
            print(f"{type(self).__name__} - {msg}")
        else:
            logger.log(lvl, f"{type(self).__name__} - {msg}")

    async def aggregate_rss_info(self):
        # get all articles from feeds and aggregate into single list of dictionaries
        self.article_dict_list = [article_dict for item in RSS_METADATA_DICT_LIST for article_dict in feedparser.parse(item['feed_url'])['entries']]

        # remove any previously cached URLs
        cached_urls = await self.feed_handle.find({}, {"_id": False, "url": True})
        cached_urls = [item["url"] for item in cached_urls]
        self.article_dict_list = [
            item for item in self.article_dict_list
            if item["link"] not in cached_urls and 
            not any([i in item["link"] for i in URL_EXCLUSION_LIST])
        ]

    async def make_http_requests(self):
        # make requests to article URLs and update metadata
        session = aiohttp.ClientSession(cookie_jar=aiohttp.DummyCookieJar(), timeout=aiohttp.ClientTimeout(total=self.timeout))
        headers = requests.utils.default_headers()
        tasks = [
            asyncio.create_task(self.update_article_dict(session, headers, article_dict))
            for article_dict in self.article_dict_list
        ]
        await asyncio.gather(*tasks)
        await session.close()

        # filter out articles for which we received errors
        self.article_dict_list = [item for item in self.article_dict_list if item.get("code", requests.codes.BAD) == requests.codes.ALL_GOOD]

    async def update_article_dict(self, session, headers, article_dict, proxy=None, retry_on_fail=True):
        headers.update({
            "User-Agent": random.choice(self.user_agent_list),
        })

        try:
            response = await session.request(url=article_dict["link"], method="GET", headers=headers, proxy=proxy)
            response_status = response.status
            html = await response.text()

            article_dict.update({
                "html": html,
                "code": response_status
            })

            self.log(f"Scrape successful < {article_dict['link']} >")
        except Exception as e:
            if retry_on_fail:
                self.log(f"Reattempting scrape due to exception < {article_dict['link']} >: {str(e)}", logging.WARNING)
                proxy = random.choice(self.proxy_list)
                await self.update_article_dict(session, headers, article_dict, proxy=proxy, retry_on_fail=False)
            else:
                self.log(f"Aborting scrape. Exception occurred while making/parsing request < {article_dict['link']} >: {str(e)}", logging.WARNING)

    def extract_article_features(self, item):
        # scraper
        scraper = "rss"

        # source
        source = extract_url_domain_name(item["link"], default="RSS")

        # entity
        entity = ""

        # title
        title = clean_text(re.sub("(?=<).*?(?<=>)", "", item["title"]))

        # date
        time_struct = item.get('published_parsed')
        if time_struct is not None:
            date = datetime(year=time_struct.tm_year, month=time_struct.tm_mon, day=time_struct.tm_mday)
        else:
            time_str = item.get('published')
            if time_str is not None:
                date = dateparser.parse(time_str)
            else:
                raise Exception(f"Unable to parse valid date: {str(e)}")

        # content
        try:
            doc = Document(item["html"])
            soup = BeautifulSoup(doc.summary(), "lxml")
            article_text = " ".join(soup.findAll(text=True))
            content = clean_text(article_text)
        except Exception as e:
            raise Exception(f"Exception occurred while parsing content: {str(e)}")

        # summary
        summary = clean_text(re.sub("(?=<).*?(?<=>)", "", item["summary"]))

        # url
        url = item["link"]

        return {
            "scraper": scraper,
            "source": source,
            "entity": entity,
            "title": title,
            "date": date,
            "summary": summary,
            "url": url,
            "content": content,
            "origtext": article_text
        }

    async def push_results(self):
        try:
            inserted_info = await self.feed_handle.insert_many(self.results, ordered=False)
            num_inserted = len(inserted_info.inserted_ids)
            num_duplicates = 0
        except BulkWriteError as e:
            # if one or more of the result items represents a
            # duplicate, a BulkWriteError will be thrown, but any
            # unique documents will still be written to the database
            num_inserted = e.details["nInserted"]
            num_duplicates = len(e.details["writeErrors"])

        self.log(f"Pushed {num_inserted} results to scrape feed. Detected {num_duplicates} duplicates ..")
