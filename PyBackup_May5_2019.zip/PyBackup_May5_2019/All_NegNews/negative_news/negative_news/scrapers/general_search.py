import asyncio
import logging
import re
from datetime import datetime
import time

import requests
from readability import Document
from bs4 import BeautifulSoup
import articleDateExtractor
from fake_useragent import UserAgent

from ..util.misc import clean_text, generate_sumy_summary, extract_url_domain_name
from ._async import AsyncAPIHelper

logger = logging.getLogger(__name__)

# the max number of results that can be returned per page
# from BingSearchAPI according to the API documentation
MAX_RESULTS_PER_PAGE = 50


class BingAPIScraper(AsyncAPIHelper):

    url = "https://api.cognitive.microsoft.com/bing/v7.0/search?"
    headers = {"Ocp-Apim-Subscription-Key": "c759653bb84b490ba06cfcd92b2397e4"}
    

    def __init__(
        self,
        entity_name,
        known_aliases_list=None,
        search_term_list=None,
        allowed_sources_list=None,
        results_per_page=50,
        exclusion_list=[".pdf", "?"],
        language_abbrv="EN",
        max_requests=20,
        method="GET",
        **kwargs,
    ):
        super().__init__(method=method, max_requests=max_requests, **kwargs)

        self.entity_name = entity_name

        if results_per_page > MAX_RESULTS_PER_PAGE:
            raise ValueError(f"'results_per_page' may not exceed {MAX_RESULTS_PER_PAGE}")
        else:
            self.results_per_page = results_per_page

        self.exclusion_list = exclusion_list

        if known_aliases_list is None:
            self.known_aliases_list = []
        else:
            self.known_aliases_list = known_aliases_list

        if search_term_list is None:
            self.search_term_list = []
        else:
            self.search_term_list = search_term_list

        if allowed_sources_list is None:
            self.allowed_sources_list = []
        else:
            self.allowed_sources_list = allowed_sources_list

        self.language_abbrv = language_abbrv

    def update_request_params(self, task_idx):
        self.params = {
            "q": self.query,
            "mkt": "en-us",
            "responseFilter": "Webpages",
            "count": self.results_per_page,
            "offset": task_idx * self.results_per_page,
        }

    def build_query(self):
        """Constructs Bing search query"""
        if self.language_abbrv == "EN":
            entity_part = '("{}")'.format(self.entity_name)
        else:
            entity_part = "({})".format(self.entity_name)

        if len(self.search_term_list) > 0:
            terms_part = "({})".format(
                " OR ".join([term if len(term.split(" ")) == 1 else '"{}"'.format(term) for term in self.search_term_list])
            )
        else:
            terms_part = ""

        if len(self.allowed_sources_list) > 0:
            sources_part = "({})".format(" OR ".join(["site:{}".format(s) for s in self.allowed_sources_list]))
        else:
            sources_part = ""

        return entity_part + terms_part + sources_part

    def parse_api_response(self, task_idx, response):
        logger.debug(f"Parsing API response for API request #{task_idx} ..")

        try:
            response = [
                result for result in response["webPages"]["value"] if all(el not in result["url"] for el in self.exclusion_list)
            ]
        except KeyError as e:
            logger.debug(f"KeyError occurred while handling response for request #{task_idx}: {str(e)}")
            response = []

        return response

    async def get_html(self, response_idx, url_idx, metadata_dict):
        self.log(f"Retrieving HTML for URL #{url_idx} in response #{response_idx} ..")

        tock = time.perf_counter()

        headers = requests.utils.default_headers()
        headers.update({"User-Agent": UserAgent().random})

        try:
            try:
                response = await self.session.request(url=metadata_dict["url"], method="GET", headers=headers)
                metadata_dict["html"] = await response.text()
            except asyncio.TimeoutError:
                self.log(f"Timeout occurred while retrieving HTML for URL #{idx} for API request #{task_idx} ..", lvl=logging.ERROR)
                raise
            except Exception as e:
                url = metadata_dict.get("url", "")
                self.log(
                    f"Unexpected error occurred while retrieving HTML for URL #{idx} ({url}) "
                    + f"for API request #{task_idx}: {str(e)}",
                    lvl=logging.ERROR
                )
                raise
        except Exception:
            metadata_dict["html"] = ""

        tick = time.perf_counter()

        self.log(f"Successfully retrieved HTML for URL #{url_idx} in response #{response_idx}. Took {round(tick - tock, 2)}s ..")

    @staticmethod
    def extract_metadata(metadata_dict):
        doc = Document(metadata_dict["html"])
        soup = BeautifulSoup(doc.summary(), "lxml")
        article_text = " ".join(soup.findAll(text=True))
        article_text_clean = clean_text(article_text)

        date = articleDateExtractor.extractArticlePublishedDate(metadata_dict["url"], html=metadata_dict["html"])

        summary = metadata_dict.get("snippet", "")

        source = extract_url_domain_name(metadata_dict["url"], default="Bing")

        url_content = {
            "_id": metadata_dict["_id"],
            "scraper": "BingSearchAPI",
            "source": source,
            "title": doc.short_title(),
            "date": date,
            "content": article_text_clean,
            "summary": summary,
            "url": metadata_dict.get("url", ""),
            "origtext": article_text,
        }

        return url_content

    def modify_metadata(self, metadata_dict):
        summary = metadata_dict.get("summary", "")
        content = metadata_dict.get("content", "")
        if summary == "" and content != "":
            summary = generate_sumy_summary(content, self.language_abbrv)
        
        metadata_dict.update({
            "entity": self.entity_name,
            "jobname": self.job_name,
            "summary": summary
        })

