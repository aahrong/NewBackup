'''
This file describes data and behavior for NegativeNewsEntityJob, which is the
object responsible for managing the individual searches (NegativeNewsEntitySearch objects) 
associated with one particular entity. 

For example, a NegativeNewsEntityJob with two NegativeNewsEntitySearch objects 
could complete searches for a single entity on both Google and Bing.
'''

import logging
import asyncio
import os
from datetime import datetime
from collections import OrderedDict
import glob

from .entity_search import NegativeNewsEntitySearch
from .schema import schemas, validate_schema
from .constants import STATUS_PENDING, STATUS_SCRAPING, STATUS_PROCESSING, STATUS_GENERATING, STATUS_DONE

logger = logging.getLogger(__name__)


class NegativeNewsEntityJob:
    def __init__(self, job_name, run_datetime, search_obj_list, postprocess_kwargs):
        if not isinstance(job_name, str):
            raise ValueError(f'"job_name" must be of type str, but got type "{type(job_name)}"')

        if not isinstance(run_datetime, str):
            raise ValueError(f'"run_datetime" must be of type str, but got type "{type(run_datetime)}"')

        if not isinstance(postprocess_kwargs, dict):
            raise ValueError(f'"postprocess_kwargs" must be of type dict, but got type "{type(postprocess_kwargs)}"')

        if not isinstance(search_obj_list, list):
            raise ValueError(f'"search_obj_list" must be of type list, but got type "{type(search_obj_list)}"')

        if not len(search_obj_list) > 0:
            raise ValueError('"search_obj_list" must contain at least one instance of NegativeNewsEntitySearch')

        if any([not isinstance(search_obj, NegativeNewsEntitySearch) for search_obj in search_obj_list]):
            raise ValueError('all members of "search_obj_list" must be of type NegativeNewsEntitySearch')

        if any([search_obj_list[0].entity_name != search_obj.entity_name for search_obj in search_obj_list[1:]]):
            raise ValueError('All instances of NegativeNewsEntitySearch must have the same "entity_name" attribute')

        # keyword arguments that will be used to perform postprocessing on entity data
        self.postprocess_kwargs = postprocess_kwargs
        # make the output directory in the postprocess keyword arguments if it does not exist already
        os.makedirs(self.postprocess_kwargs["output_path"], exist_ok=True)
        # validate that the postprocess keyword arguments conform to the appropriate schema
        validate_schema(postprocess_kwargs, schemas["postprocess_kwargs"])

        # unique job identifier
        self.job_name = job_name

        # timestamp recorded (as string) at the start of the run
        # to which this job belongs
        self.run_datetime = run_datetime

        # timestamp recorded (as datetime) when this job actually
        # starts to scrape
        self.start_datetime = None

        # time spent in STATUS_PENDING
        self.pending_duration = None
        # time spent in STATUS_SCRAPING
        self.scrape_duration = None
        # time spent in STATUS_PROCESSING
        self.processing_duration = None
        # time spent in STATUS_GENERATING
        self.generating_duration = None
        # total time spent in all stages
        self.total_duration = None

        # list to hold all NegativeNewsEntitySearch objects associated with this entity job
        self.search_obj_list = search_obj_list
        # total number of searches associated with this entity job
        self.num_total_searches = len(search_obj_list)

        self.num_finished_searches = 0
        # string indicating status of entity job
        self.status = None

        for search_obj in search_obj_list:
            search_obj.job_name = self.job_name

    async def parallel_start(self):
        '''Starts each search associated with this job in its own process'''
        # record time we actually began to start searches
        self.start_datetime = datetime.now()
        # start each search in its own process
        for idx, search_obj in enumerate(self.search_obj_list):
            logger.debug(f"NegativeNewsEntityJob starting search #{idx} ..")
            search_obj.start()
        # wait for each search to complete
        for search_obj in self.search_obj_list:
            await search_obj.join()

    async def async_start(self):
        tasks = [asyncio.create_task(s.async_start()) for s in self.search_obj_list]
        await asyncio.gather(*tasks)

    def to_dict(self):
        '''Returns information about this job as a dictionary'''
        if self.status != STATUS_DONE and self.start_datetime is not None:
            logger.debug("Updating total duration ..")
            self.total_duration = str(datetime.now() - self.start_datetime)

        output_fpaths = self.get_output_file_paths()
        download_html = " ".join([f"<a href='/download/{fpath}'>{ftype}</a>" for ftype, fpath in output_fpaths.items()])
        if download_html == "":
            download_html = "Not Available"

        return OrderedDict(
            {
                "job_name": self.job_name,
                "download": download_html,
                "run_date": datetime.strftime(self.start_datetime, "%m-%d-%y %H:%M:%S"),
                "status": self.status,
                "total_duration": self.total_duration,
                "scrape_duration": str(self.scrape_duration),
                "processing_duration": str(self.processing_duration),
                "generating_duration": str(self.generating_duration),
            }
        )

    def get_output_file_paths(self):
        '''Attempts to return the file paths of any generated PDF/Word reports associated with this job as a dictionary''' 
        file_types = [".docx"]
        return {ftype: fpath[1:] for ftype in file_types for fpath in glob.glob(f"{self.postprocess_kwargs['output_path']}*{ftype}")}

    def set_status(self, new_status):
        '''Updates the status of this job'''
        if new_status == STATUS_PENDING:
            self.start_datetime = datetime.now()
        elif new_status == STATUS_SCRAPING:
            self.pending_duration = str(datetime.now() - self.last_update)
        elif new_status == STATUS_PROCESSING:
            self.scrape_duration = str(datetime.now() - self.last_update)
        elif new_status == STATUS_GENERATING:
            self.processing_duration = str(datetime.now() - self.last_update)
        elif new_status == STATUS_DONE:
            self.generating_duration = str(datetime.now() - self.last_update)
            self.total_duration = str(datetime.now() - self.start_datetime)
        else:
            raise ValueError(f"Invalid status update: {new_status}")

        logger.debug(f"Setting status to {new_status}")
        self.status = new_status
        self.last_update = datetime.now()

