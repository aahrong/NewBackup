'''
This file contains a class for overseeing postprocess execution (NegativeNewsPostprocessor) and
another class that executes a postprocessing in a separate Python process (PostprocessJob).

In general, the objective of postprocessing is to add additional features to the scraped data from the
scraping process and generate arguments that will be passed to output generation.
'''

import os
import logging
import pickle
import traceback
import time
import sys
import asyncio
from multiprocessing import Process
from datetime import datetime, timedelta

import pymagnitude
import spacy

from .database import get_scrape_feed_handle, get_rss_feed_handle, get_processed_results_handle, \
                      get_bc_owners_feed_handle, get_bc_disclosures_feed_handle, get_bc_meta_feed_handle
from .util.postprocess import postprocess, generate_output_args
from .util.supplementary import get_nyse_disciplinary_actions, get_occ_disciplinary_actions, get_finra_disciplinary_actions, \
                                get_nydfs_disciplinary_actions, get_sec_litigation_releases
from .util.broker_check import get_finra_broker_check_summary

logger = logging.getLogger(__name__)

# path to Magnitude word embedding file 
WORD_EMBEDDING_FPATH_EN = f"{os.path.dirname(__file__)}/resources/crawl-300d-2M.magnitude"

# in situations where we have at least month-level
# search granularity, we will pull back disciplinary actions
# in an N-week window of the specified month/year threshold.
DISCIPLINARY_ACTION_WEEK_BUFFER = 15


class NegativeNewsPostprocessor:
    '''This class is responsible for starting postprocessing for a job in a separate process'''
    def __init__(
        self,
        spacy_model_name="en_core_web_sm",
        spacy_disabled_components=["tagger", "parser"],
        fpath_word_embedding=WORD_EMBEDDING_FPATH_EN,
    ):
        logger.info(f"NegativeNewsPostprocessor is loading spaCy model ..")
        self.nlp = spacy.load(spacy_model_name, disable=spacy_disabled_components)
        logger.info(f"NegativeNewsPostprocessor successfully loaded spaCy model ..")

        self.fpath_word_embedding = fpath_word_embedding

    async def start(self, job_name, postprocess_kwargs):
        '''Instantiates a new instance of PostprocessJob and starts it in its own process'''
        processing_job = PostprocessJob(job_name, postprocess_kwargs, self.fpath_word_embedding, self.nlp)
        processing_job.start()
        await processing_job.join()


class PostprocessJob(Process):
    '''This class contains the functionality for executing each step of postprocessing'''
    def __init__(self, job_name, postprocess_kwargs, fpath_word_embedding, nlp):
        super().__init__()

        self.job_name = job_name
        self.entity_name = postprocess_kwargs["entity_name"]
        self.output_path = postprocess_kwargs["output_path"]
        self.postprocess_kwargs = postprocess_kwargs
        self.nlp = nlp

        logger.info(f"PostprocessJob is loading word embedding model ..")
        self.wv = pymagnitude.Magnitude(fpath_word_embedding)
        logger.info(f"PostprocessJob successfully loaded word embedding model ..")

    async def join(self):
        '''Performs process clean-up after PostprocessJob exits. Overrides 'join' method of 'Process' class'''
        while self.is_alive():
            logger.debug(f'PostprocessJob for job "{self.job_name}" is still alive. Going to sleep ..')
            await asyncio.sleep(3)
        super().join()
        logger.debug("PostprocessJob is notifying observers .. ")

    def run(self):
        '''Function that executes postprocessing in a separate process. Overrides 'run' method of 'Process' class'''
        logger.info(f'NegativeNewsPostprocessor starting for job "{self.job_name}" ..')

        logger.info(f"NegativeNewsPostprocessor is loading data ..")

        # grab data from scrape feed
        # TODO: only grab most recent data (jobname)
        feed_handle = get_scrape_feed_handle()
        data = feed_handle.find({"entity": self.entity_name})

        # grab data from rss feed
        # TODO: move after postprocessing
        feed_handle = get_rss_feed_handle()
        rss_data = feed_handle.find({})

        # combine scraped and rss feed data
        # TODO: move after postprocessing
        data.extend(rss_data)

        logger.info(f"NegativeNewsPostprocessor successfully loaded {len(data)} data entries ..")
        
        # combine data to process and the postprocess keyword arguments into a single dictionary
        # that will be passed to postprocess function
        postprocess_args = {"scraped_data": data, **self.__dict__["postprocess_kwargs"]}

        # save down postprocess arguments to output path for testing purposes
        try:
            with open(self.output_path + "postprocess_args.pk", "wb") as f:
                pickle.dump(postprocess_args, f)
            logger.info(f"Saved postprocess arguments: {self.output_path}postprocess_args.pk")
        except Exception:
            logger.error(
                f"Exception occurred while saving postprocess arguments for job '{self.job_name}': "
                + "".join(traceback.format_exception(*sys.exc_info()))
            )

        logger.info(f'NegativeNewsPostprocessor is calling "postprocess" ..')

        # initiate postprocessing
        # TODO: this step should probably only include the following:
        # 1) sentence tokenization
        # 2) word tokenization
        # 3) calculate average embedding for each sentence
        # 4) push back up to database
        try:
            tock = time.perf_counter()
            data = postprocess(wv=self.wv, nlp=self.nlp, **postprocess_args)
            tick = time.perf_counter()
            logger.info(f"NegativeNewsPostprocessor successfully processed scraped data." + f"Took {round(tick - tock, 2)}s ..")
        except Exception:
            logger.error(
                f"Exception occurred while completing postprocessing for job '{self.job_name}': "
                + "".join(traceback.format_exception(*sys.exc_info()))
            )

        logger.info(f'NegativeNewsPostprocessor is calling "generate_output_args". Loading all entity data ..')

        # TODO: following on comments above, we need to put something here that allows us to pull cached average embeddings

        # generate arguments for output generation based on processed data
        try:
            tock = time.perf_counter()
            self.output_args = generate_output_args(self.wv, data, **self.__dict__["postprocess_kwargs"])
            tick = time.perf_counter()
            logger.info(f"NegativeNewsPostprocessor successfully generated output arguments." + f"Took {round(tick - tock, 2)}s ..")
        except Exception:
            self.output_args = {}
            logger.error(
                f"Exception occurred while generating output arguments for job '{self.job_name}': "
                + "".join(traceback.format_exception(*sys.exc_info()))
            )

        # update output generation arguments with all postprocess keyword arguments
        self.output_args.update(self.postprocess_kwargs)

        # TODO: change the name of 'indv_flag' to 'is_org' in downstream functions
        # and then delete this line
        self.output_args["indv_flag"] = self.output_args.pop("is_org")

        logger.info(f'NegativeNewsPostprocessor is scraping disciplinary action information ..')

        # create dictionary to hold disciplinary action information from various regulatory bodies
        disciplinary_actions_dict = {}
        disciplinary_actions_dict["num_actions"] = 0

        # get NYSE disciplinary actions
        years_to_search = [year for year in range(self.postprocess_kwargs["min_year"], datetime.now().year + 1)]
        nyse_actions = [
            actions for year in years_to_search for actions in get_nyse_disciplinary_actions(self.postprocess_kwargs["entity_name"], year)
        ]
        logger.info(f'NegativeNewsPostprocessor scraped {len(nyse_actions)} disciplinary action from NYSE ..')
        if len(nyse_actions):
            disciplinary_actions_dict["nyse"] = nyse_actions
            disciplinary_actions_dict["num_actions"] += len(nyse_actions)

        # get OCC disciplinary actions
        date_str = datetime(year=self.postprocess_kwargs["min_year"], month=self.postprocess_kwargs["min_month"], day=1)
        date_str = (date_str - timedelta(weeks=DISCIPLINARY_ACTION_WEEK_BUFFER)).strftime("%m/%d/%Y")

        occ_actions = get_occ_disciplinary_actions(self.postprocess_kwargs["entity_name"], date_str)
        logger.info(f'NegativeNewsPostprocessor scraped {len(occ_actions)} disciplinary action from OCC ..')
        if len(occ_actions):
            disciplinary_actions_dict["occ"] = occ_actions
            disciplinary_actions_dict["num_actions"] += len(occ_actions)

        # get FINRA disciplinary actions
        finra_actions = get_finra_disciplinary_actions(self.postprocess_kwargs["entity_name"], date_str)
        logger.info(f'NegativeNewsPostprocessor scraped {len(finra_actions)} disciplinary action from FINRA ..')
        if len(finra_actions):
            disciplinary_actions_dict["finra"] = finra_actions
            disciplinary_actions_dict["num_actions"] += len(finra_actions)

        # get NYDFS disciplinary actions
        all_entity_names = [self.postprocess_kwargs["entity_name"]] + self.postprocess_kwargs["known_aliases"]
        nydfs_actions = get_nydfs_disciplinary_actions(all_entity_names)
        logger.info(f'NegativeNewsPostprocessor scraped {len(nydfs_actions)} disciplinary action from NYDFS ..')
        if len(nydfs_actions):
            disciplinary_actions_dict["nydfs"] = nydfs_actions
            disciplinary_actions_dict["num_actions"] += len(nydfs_actions)

        # get SEC litigation releases
        sec_lit_actions = get_sec_litigation_releases(all_entity_names)
        logger.info(f'NegativeNewsPostprocessor scraped {len(sec_lit_actions)} disciplinary action from SEC litigation releases ..')
        if len(sec_lit_actions):
            disciplinary_actions_dict["sec_lit"] = sec_lit_actions
            disciplinary_actions_dict["num_actions"] += len(sec_lit_actions)

        self.output_args.update({"disciplinary_action_info": disciplinary_actions_dict})

        # analyze FINRA Broker Check if valid CRD provided
        finra_broker_check_info = {}
        crd = self.postprocess_kwargs["crd"]
        if crd != "":
            fh_owners = get_bc_owners_feed_handle()
            fh_disclosures = get_bc_disclosures_feed_handle()
            fh_meta = get_bc_meta_feed_handle()
            try:
                finra_broker_check_info = get_finra_broker_check_summary(crd, fh_owners, fh_disclosures, fh_meta)
            except Exception as e:
                logger.warning(str(e))
        else:
            logger.debug("No CRD# provided. Skipping FINRA Broker Check step ..")

        self.output_args.update({"finra_broker_check_info": finra_broker_check_info})

        # save down output generation arguments to output path for testing purposes
        try:
            with open(self.output_path + "output_args.pk", "wb") as f:
                pickle.dump(self.output_args, f)
            logger.info(f"Saved output arguments: {self.output_path}output_args.pk")
        except Exception:
            logger.error(
                f"Exception occurred while saving output arguments for job '{self.job_name}': "
                + "".join(traceback.format_exception(*sys.exc_info()))
            )

