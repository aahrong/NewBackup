'''
This file contains code describing data and behavior for NegativeNewsEntitySearch,
which is the object responsible for instantiating a crawler and running it in its own process.
'''

import logging
from multiprocessing import Process
import asyncio

from .database import get_scrape_feed_handle

logger = logging.getLogger(__name__)


class NegativeNewsEntitySearch(Process):
    def __init__(self, crawler_cls, entity_name, **kwargs):
        super().__init__()

        job_name = kwargs.get("job_name", "")
        if not isinstance(job_name, str) or job_name == "":
            raise ValueError(f'"job_name" must be of type str and not blank, but got type="{type(job_name)}", value="{job_name}"')
        self.job_name = job_name

        if not isinstance(entity_name, str) or entity_name == "":
            raise ValueError(
                f'"entity_name" must be of type str and not blank, but got type="{type(entity_name)}", value="{entity_name}"'
            )
        self.entity_name = entity_name

        # for the kwargs in the list, check type and remove all blank list items
        list_kwargs = ["search_term_list", "known_aliases_list", "allowed_sources_list"]
        for kwarg_name in list_kwargs:
            kwarg_val = kwargs.get(kwarg_name, [])

            if not isinstance(kwarg_val, list):
                raise ValueError(f'"{kwarg_val}" must be of type list, but got type "{type(kwarg_val)}"')

            kwarg_val = [list_item.strip() for list_item in kwarg_val if list_item.strip() != ""]
            logger.debug(f"Updating '{kwarg_name}' for job '{job_name}' to: {kwarg_val}")
            kwargs[kwarg_name] = kwarg_val

        # instantiate an instance of the crawler class passed to the constructor
        # which will be used to execute the search
        self.crawler_cls = crawler_cls(entity_name, **kwargs)

    def run(self):
        '''Starts the crawler associated with this search in its own process. Overrides the 'run' method in the 'Process' class'''
        asyncio.run(self.crawler_cls.start())

    async def join(self):
        '''Performs process clean-up after crawler exits. Overrides the 'join' method in 'Process' class'''
        while self.is_alive():
            logger.debug(
                f'NegativeNewsEntitySearch for job "{self.job_name}" on '
                + f"{type(self.crawler_cls).__name__} crawler is still alive. Going to sleep .."
            )
            await asyncio.sleep(5)
        super().join()
        logger.debug(
            f'NegativeNewsEntitySearch for job "{self.job_name}" on '
            + f"{type(self.crawler_cls).__name__} crawler completed .."
        )

    async def async_start(self):
        self.crawler_cls.feed_handle = get_scrape_feed_handle(asyncio.get_event_loop())
        await self.crawler_cls.start()

