'''
This file contains code for keyword argument validation, which is performed through a sequence of boolean tests.
'''

import logging
from collections import namedtuple
import os
from datetime import datetime

logger = logging.getLogger(__name__)

# namedtuple representing the validation rules for an individual keyword argument
# .type (type or tuple of types) -- a type (e.g., int) or tuple of types that are valid for the keyword argument
# .callable (callable) -- a function to which the keyword argument value will be passed. returns true on success.
# .optional (boolean) -- a boolean value indicating whether the keyword argument is optional
SchemaEntry = namedtuple("SchemaEntry", ["type", "callable", "optional"], defaults=[lambda val: True, False])

# alias for NoneType
NoneType = type(None)


class SchemaException(Exception):
    '''Custom exception for schema errors'''
    def __init__(self, message):
        super().__init__(message)


def validate_schema(kwargs_to_validate, kwargs_schema):
    '''Validates the dictionary 'kwargs_to_validate' against the provided 'kwargs_schema'.'''
    logging.debug("Validating schema ..")
    for schema_arg_name, schema_entry in kwargs_schema.items():
        # throw a SchemaException if the schema keyword argument does not exist in the actual arguments passed and
        # the schema keyword argument is not flagged as optional
        if schema_arg_name not in kwargs_to_validate.keys() and not schema_entry.optional:
            raise SchemaException(f"Keyword arguments missing required key: {schema_arg_name}")
        elif schema_arg_name in kwargs_to_validate.keys():
            # throw a SchemaException if the schema keyword arguments exists in the actual arguments passed,
            # but is of the incorrect type
            if not isinstance(kwargs_to_validate[schema_arg_name], schema_entry.type):
                raise SchemaException(
                    f"Keyword argument '{schema_arg_name}' expected to be of type {schema_entry.type},"
                    f"but got {type(kwargs_to_validate[schema_arg_name])}"
                )
            # throw a SchemaException if the schema keyword argument exists in the actual arguments passed,
            # but fails the callable evaluation
            if not schema_entry.callable(kwargs_to_validate[schema_arg_name]):
                raise SchemaException(f"Keyword argument failed callable evaluation: {schema_arg_name}")
        # log a message indicating that an optional schema keyword argument is missing from the actual keyword arguments passed
        else:
            logging.debug(f"Keyword arguments missing optional key: {schema_arg_name}")

# dictionary containing keyword argument schemas
schemas = {
    "postprocess_kwargs": {
        "is_org": SchemaEntry(type=int, callable=lambda val: val in [0, 1]),
        "max_sentiment": SchemaEntry(type=(int, float), callable=lambda val: val >= -1 and val <= 1),
        "min_year": SchemaEntry(type=int, callable=lambda val: val >= 1900 and val <= 2020),
        "min_month": SchemaEntry(type=int, callable=lambda val: val >= 1 and val <= 12),
        "min_similarity": SchemaEntry(type=(int, float), callable=lambda val: val >= 0 and val <= 1),
        "search_terms": SchemaEntry(type=list, callable=lambda val: all([isinstance(item, str) for item in val])),
        "max_search_results": SchemaEntry(type=int, callable=lambda val: val >= 1 and val <= 100),
        "output_path": SchemaEntry(type=str, callable=lambda val: os.path.isdir(val)),
        "entity_name": SchemaEntry(type=str, callable=lambda val: val != ""),
        "entity_name_translated": SchemaEntry(type=str, callable=lambda val: val != ""),
        "known_aliases": SchemaEntry(type=list, callable=lambda val: all([isinstance(item, str) for item in val])),
        "location": SchemaEntry(type=str),
        "employment": SchemaEntry(type=str),
        "language_abbrv": SchemaEntry(type=str, callable=lambda val: val in ["EN"]),
        "crd": SchemaEntry(type=str),
    },
    "scraped_data": {
        "source": SchemaEntry(type=str),
        "entity": SchemaEntry(type=str),
        "title": SchemaEntry(type=str),
        "date": SchemaEntry(type=(str, datetime, NoneType)),
        "content": SchemaEntry(type=str),
        "summary": SchemaEntry(type=str),
        "url": SchemaEntry(type=str),
        "origtext": SchemaEntry(type=str),
        "jobname": SchemaEntry(type=str),
    },
}
