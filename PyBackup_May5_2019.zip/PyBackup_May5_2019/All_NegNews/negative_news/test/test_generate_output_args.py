import time
import logging

# import asyncio
import pickle

import pymagnitude

from negative_news_dev.postprocessor import (
    NegativeNewsPostprocessor,
    WORD_EMBEDDING_FPATH_EN,
)
from negative_news_dev.util.postprocess import generate_output_args

logger = logging.getLogger(__name__)

test_output_path = "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/test-files/"

pk_path_postprocess_args = (
    "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/output/"
    + "02-05-19-02-09-16/Wells Fargo_02-05-19-02-09-16/postprocess_args.pk"
)


async def main():
    job_name = "Brighthouse Financial_01-30-19-23-58-39"

    entity_name = "Brighthouse Financial"
    entity_name_translated = entity_name
    is_org = 1
    employment = ""
    location = ""
    max_sentiment = 0.0  # currently disabled
    min_similarity = 0.1  # currently disabled
    min_year = 2000
    min_month = 1
    max_search_results = 100
    language_abbrv = "EN"
    known_aliases_list = ["Brighthouse"]
    search_term_list = ["crime", "fraud", "penalty", "fine"]

    postprocess_kwargs = {
        "is_org": is_org,
        "max_sentiment": max_sentiment,
        "min_year": min_year,
        "min_month": min_month,
        "min_similarity": min_similarity,
        "search_terms": search_term_list,
        "max_search_results": max_search_results,
        "output_path": test_output_path,
        "entity_name": entity_name,
        "entity_name_translated": entity_name_translated,
        "known_aliases": known_aliases_list,
        "language_abbrv": language_abbrv,
        "location": location,
        "employment": employment,
    }

    tock = time.perf_counter()
    postprocessor = NegativeNewsPostprocessor()
    await postprocessor.start(job_name, postprocess_kwargs)
    tick = time.perf_counter()

    logger.debug(f"Successfully generated output arguments. Took {tick - tock}s ..")


def main_alt():
    with open(pk_path_postprocess_args, "rb") as f:
        args = pickle.load(f)

    wv = pymagnitude.Magnitude(WORD_EMBEDDING_FPATH_EN)
    postprocessor = NegativeNewsPostprocessor()

    tock = time.perf_counter()
    generate_output_args(**{"wv": wv, "nlp": postprocessor.nlp, **args})
    tick = time.perf_counter()

    logger.debug(f"Successfully generated output arguments. Took {tick - tock}s ..")


if __name__ == "__main__":
    # asyncio.run(main())
    main_alt()
