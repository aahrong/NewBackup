import logging

from negative_news_dev.schema import schemas, validate_schema, SchemaException

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# valid postprocess kwargs
postprocess_valid_inputs = [
    {
        "is_org": 0,
        "max_sentiment": 0,
        "min_year": 2000,
        "min_month": 11,
        "min_similarity": 0.1,
        "search_terms": ["test1", "test2"],
        "max_search_results": 50,
        "output_path": "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/test-files/",
        "entity_name": "Test Entity",
        "entity_name_translated": "Test Entity",
        "known_aliases": ["alias1", "alias2"],
        "language_abbrv": "EN",
    }
]

# invalid postprocess kwargs
postprocess_invalid_inputs = [
    {
        "is_org": -1,
        "max_sentiment": 0,
        "min_year": 2000,
        "min_month": 11,
        "min_similarity": 0.1,
        "search_terms": ["test1", "test2"],
        "max_search_results": 50,
        "output_path": "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/test-files/",
        "entity_name": "Test Entity",
        "entity_name_translated": "Test Entity",
        "known_aliases": ["alias1", "alias2"],
        "language_abbrv": "EN",
    },
    {
        "is_org": 0,
        "max_sentiment": -1.1,
        "min_year": 2000,
        "min_month": 11,
        "min_similarity": 0.1,
        "search_terms": ["test1", "test2"],
        "max_search_results": 50,
        "output_path": "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/test-files/",
        "entity_name": "Test Entity",
        "entity_name_translated": "Test Entity",
        "known_aliases": ["alias1", "alias2"],
        "language_abbrv": "EN",
    },
    {
        "is_org": 0,
        "max_sentiment": 1.1,
        "min_year": 2000,
        "min_month": 11,
        "min_similarity": 0.1,
        "search_terms": ["test1", "test2"],
        "max_search_results": 50,
        "output_path": "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/test-files/",
        "entity_name": "Test Entity",
        "entity_name_translated": "Test Entity",
        "known_aliases": ["alias1", "alias2"],
        "language_abbrv": "EN",
    },
    {
        "is_org": 0,
        "max_sentiment": 1,
        "min_year": 1899,
        "min_month": 11,
        "min_similarity": 0.1,
        "search_terms": ["test1", "test2"],
        "max_search_results": 50,
        "output_path": "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/test-files/",
        "entity_name": "Test Entity",
        "entity_name_translated": "Test Entity",
        "known_aliases": ["alias1", "alias2"],
        "language_abbrv": "EN",
    },
    {
        "is_org": 0,
        "max_sentiment": 1,
        "min_year": 2021,
        "min_month": 11,
        "min_similarity": 0.1,
        "search_terms": ["test1", "test2"],
        "max_search_results": 50,
        "output_path": "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/test-files/",
        "entity_name": "Test Entity",
        "entity_name_translated": "Test Entity",
        "known_aliases": ["alias1", "alias2"],
        "language_abbrv": "EN",
    },
    {
        "is_org": 0,
        "max_sentiment": 1,
        "min_year": 2020,
        "min_month": 0,
        "min_similarity": 0.1,
        "search_terms": ["test1", "test2"],
        "max_search_results": 50,
        "output_path": "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/test-files/",
        "entity_name": "Test Entity",
        "entity_name_translated": "Test Entity",
        "known_aliases": ["alias1", "alias2"],
        "language_abbrv": "EN",
    },
    {
        "is_org": 0,
        "max_sentiment": 1,
        "min_year": 2020,
        "min_month": 13,
        "min_similarity": 0.1,
        "search_terms": ["test1", "test2"],
        "max_search_results": 50,
        "output_path": "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/test-files/",
        "entity_name": "Test Entity",
        "entity_name_translated": "Test Entity",
        "known_aliases": ["alias1", "alias2"],
        "language_abbrv": "EN",
    },
    {
        "is_org": 0,
        "max_sentiment": 1,
        "min_year": 2020,
        "min_month": 12,
        "min_similarity": -0.1,
        "search_terms": ["test1", "test2"],
        "max_search_results": 50,
        "output_path": "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/test-files/",
        "entity_name": "Test Entity",
        "entity_name_translated": "Test Entity",
        "known_aliases": ["alias1", "alias2"],
        "language_abbrv": "EN",
    },
    {
        "is_org": 0,
        "max_sentiment": 1,
        "min_year": 2020,
        "min_month": 12,
        "min_similarity": 1.1,
        "search_terms": ["test1", "test2"],
        "max_search_results": 50,
        "output_path": "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/test-files/",
        "entity_name": "Test Entity",
        "entity_name_translated": "Test Entity",
        "known_aliases": ["alias1", "alias2"],
        "language_abbrv": "EN",
    },
    {
        "is_org": 0,
        "max_sentiment": 1,
        "min_year": 2020,
        "min_month": 12,
        "min_similarity": 1,
        "search_terms": "test1",
        "max_search_results": 50,
        "output_path": "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/test-files/",
        "entity_name": "Test Entity",
        "entity_name_translated": "Test Entity",
        "known_aliases": ["alias1", "alias2"],
        "language_abbrv": "EN",
    },
    {
        "is_org": 0,
        "max_sentiment": 1,
        "min_year": 2020,
        "min_month": 12,
        "min_similarity": 1,
        "search_terms": 1,
        "max_search_results": 50,
        "output_path": "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/test-files/",
        "entity_name": "Test Entity",
        "entity_name_translated": "Test Entity",
        "known_aliases": ["alias1", "alias2"],
        "language_abbrv": "EN",
    },
    {
        "is_org": 0,
        "max_sentiment": 1,
        "min_year": 2020,
        "min_month": 12,
        "min_similarity": 1,
        "search_terms": ["test1", "test2"],
        "max_search_results": -1,
        "output_path": "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/test-files/",
        "entity_name": "Test Entity",
        "entity_name_translated": "Test Entity",
        "known_aliases": ["alias1", "alias2"],
        "language_abbrv": "EN",
    },
    {
        "is_org": 0,
        "max_sentiment": 1,
        "min_year": 2020,
        "min_month": 12,
        "min_similarity": 1,
        "search_terms": ["test1", "test2"],
        "max_search_results": 101,
        "output_path": "/bad_dir/",
        "entity_name": "Test Entity",
        "entity_name_translated": "Test Entity",
        "known_aliases": ["alias1", "alias2"],
        "language_abbrv": "EN",
    },
    {
        "is_org": 0,
        "max_sentiment": 1,
        "min_year": 2020,
        "min_month": 12,
        "min_similarity": 1,
        "search_terms": ["test1", "test2"],
        "max_search_results": 101,
        "output_path": "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/test-files/",
        "entity_name": 1,
        "entity_name_translated": "Test Entity",
        "known_aliases": ["alias1", "alias2"],
        "language_abbrv": "EN",
    },
    {
        "is_org": 0,
        "max_sentiment": 1,
        "min_year": 2020,
        "min_month": 12,
        "min_similarity": 1,
        "search_terms": ["test1", "test2"],
        "max_search_results": 101,
        "output_path": "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/test-files/",
        "entity_name": "",
        "entity_name_translated": "Test Entity",
        "known_aliases": ["alias1", "alias2"],
        "language_abbrv": "EN",
    },
]


def main():
    for _input in postprocess_valid_inputs:
        try:
            validate_schema(_input, schemas["postprocess_kwargs"])
        except SchemaException as e:
            logger.debug(
                f"Schema validation failed for the following valid input: {_input}"
            )
            logger.debug(str(e))
            raise
        except Exception as e:
            logger.debug(str(e))
            raise

    for _input in postprocess_invalid_inputs:
        try:
            validate_schema(_input, schemas["postprocess_kwargs"])
            raise Exception(
                f"Schema validation failed for the following invalid input: {_input}"
            )
        except SchemaException:
            continue

    logger.debug("Schema validation tests finished successfully ..")


if __name__ == "__main__":
    main()
