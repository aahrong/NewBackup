import pickle
import time
import logging
import asyncio

from negative_news.negative_news.util.output import create_pdf_summary
from negative_news.negative_news.output_generator import NegativeNewsOutputGenerator

logger = logging.getLogger(__name__)

fpath_output_args = (
    "/negative_news/negative_news/"
    + "output/03-17-19-16-48-50/Wedbush Securities_03-17-19-16-48-50/output_args.pk"
)


def main():
    logger.debug('Beginning "test_output" ..')

    with open(fpath_output_args, "rb") as f:
        args = pickle.load(f)

    tock = time.perf_counter()
    create_pdf_summary(args)
    tick = time.perf_counter()

    logger.debug(f'Beginning "test_output". Took {round(tick - tock, 2)}s ..')


async def main_alt():
    logger.debug('Beginning "test_output" ..')

    job_name = "MUFG_03-12-19-15-25-49"
    pk_path_output_args = (
        "/negative_news/negative_news/"
        + "output/03-12-19-15-25-49/MUFG_03-12-19-15-25-49/output_args.pk"
    )

    output_generator = NegativeNewsOutputGenerator()
    await output_generator.start(job_name, pk_path_output_args)


if __name__ == "__main__":
    main()
    # asyncio.run(main_alt())
