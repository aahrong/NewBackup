import time
import asyncio

from negative_news_dev.entity_search import NegativeNewsEntitySearch

# from negative_news_dev.scrapers.general_search import BingAPIScraper
from negative_news_dev.scrapers.newsapi import NewsAPIScraper

test_output_path = "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/test-files/"


async def main():
    entity_name = "Bank of America"
    known_aliases_list = ["BOA", "BAC", "BofA", "Merrill Lynch"]
    search_term_list = ["crime", "fraud", "penalty", "fine"]
    allowed_sources_list = None

    entity_search = NegativeNewsEntitySearch(
        NewsAPIScraper,
        entity_name,
        known_aliases_list=known_aliases_list,
        search_term_list=search_term_list,
        allowed_sources_list=allowed_sources_list,
        max_requests=1,
    )

    tock = time.perf_counter()
    entity_search.start()
    entity_search.join()
    tick = time.perf_counter()

    print("Successfully completed entity search ..")
    print("Operation took {} seconds .. ".format(tick - tock))


if __name__ == "__main__":
    asyncio.run(main())
