import pickle

from negative_news_dev.output_generator import NegativeNewsOutputGenerator

fpath_output_args = "/home/nlpsomnath/NegNews/nn_env/lib/python3.7/site-packages/negative_news_dev/test-files/output_args.pk"


def main():
    with open(fpath_output_args, "rb") as f:
        args = pickle.load(f)

    output_generator = NegativeNewsOutputGenerator()
    output_generator.start("test", args)


if __name__ == "__main__":
    main()
