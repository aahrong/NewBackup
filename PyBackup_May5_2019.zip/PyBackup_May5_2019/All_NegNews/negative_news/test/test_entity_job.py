import time
import logging

from constants import entity_job

logger = logging.getLogger(__name__)


def main():
    logger.debug('Beginning "test_entity_job" ..')

    tock = time.perf_counter()
    entity_job.start()
    tick = time.perf_counter()

    logger.debug("Successfully completed entity job ..")
    logger.debug("Operation took {} seconds .. ".format(tick - tock))

    assert (
        entity_job.num_finished_searches == entity_job.num_total_searches
    ), f"Expected {entity_job.num_finished_searches}, but got {entity_job.num_total_searches}"


if __name__ == "__main__":
    main()
