import asyncio
import logging
import time

from negative_news_dev.scrapers.general_search import BingAPIScraper
from negative_news_dev.scrapers.newsapi import NewsAPIScraper
from negative_news_dev.scrapers.regulatory import RegulatoryScraper
from negative_news_dev.database import get_scrape_feed_handle

logger = logging.getLogger(__name__)


async def main():
    loop = asyncio.get_event_loop()
    feed_handle = get_scrape_feed_handle(loop)

    entity_name = "Bank of America"
    known_aliases_list = ["BOA", "BAC", "BofA", "Merrill Lynch"]
    search_term_list = ["crime", "fraud", "penalty", "fine"]
    allowed_sources_list = None

    job_name = "test_scrapers_async"

    entity_search_regulatory = RegulatoryScraper(
        entity_name,
        job_name=job_name,
        feed_handle=feed_handle,
        known_aliases_list=known_aliases_list,
        search_term_list=search_term_list,
        max_requests=2,
    )

    entity_search_newsapi = NewsAPIScraper(
        entity_name,
        job_name=job_name,
        feed_handle=feed_handle,
        known_aliases_list=known_aliases_list,
        search_term_list=search_term_list,
        allowed_sources_list=allowed_sources_list,
        max_requests=2,
    )

    entity_search_bing = BingAPIScraper(
        entity_name,
        job_name=job_name,
        feed_handle=feed_handle,
        known_aliases_list=known_aliases_list,
        search_term_list=search_term_list,
        allowed_sources_list=allowed_sources_list,
        max_requests=2,
    )

    search_list = [entity_search_regulatory, entity_search_newsapi, entity_search_bing]

    tasks = [asyncio.create_task(s.start()) for s in search_list]

    logger.debug('Beginning "entity_search_async" test ..')

    tock = time.perf_counter()
    result = await asyncio.gather(*tasks)
    tick = time.perf_counter()

    result = [record for result_list in result for record in result_list]

    logger.debug(
        f'Finished "entity_search_async" test. Operation took {tick - tock}s ..'
    )

    logger.debug(f"Result length is {len(result)} ..")

    logger.debug(f"Sample:\n{result[0]}")


if __name__ == "__main__":
    asyncio.run(main())
