import time
import logging
import asyncio

from constants import entity_job

logger = logging.getLogger(__name__)


async def main():
    logger.debug('Beginning "test_entity_job_async" ..')

    tock = time.perf_counter()
    await entity_job.async_start()
    tick = time.perf_counter()

    logger.debug('Successfully completed "test_entity_job_async" ..')
    logger.debug("Operation took {} seconds .. ".format(tick - tock))

    assert (
        entity_job.num_finished_searches == entity_job.num_total_searches
    ), f"Expected {entity_job.num_finished_searches}, but got {entity_job.num_total_searches}"


if __name__ == "__main__":
    asyncio.run(main())
