from datetime import datetime
import os

from negative_news.negative_news.entity_search import NegativeNewsEntitySearch
from negative_news.negative_news.entity_job import NegativeNewsEntityJob
from negative_news.negative_news.scrapers.general_search import BingAPIScraper
from negative_news.negative_news.scrapers.newsapi import NewsAPIScraper
from negative_news.negative_news.scrapers.regulatory import RegulatoryScraper

entity_name = "Bank of America"
entity_name_translated = entity_name
is_org = 1
employment = ""
location = ""
max_sentiment = 0.0  # currently disabled
min_similarity = 0.1  # currently disabled
min_year = 2018
min_month = 1
max_search_results = 100
language_abbrv = "EN"
known_aliases_list = ["BofA", "BAC", "BOA"]
search_term_list = ["crime", "fraud", "penalty", "fine"]
allowed_sources_list = []

run_datetime = str(datetime.strftime(datetime.utcnow(), "%m-%d-%y-%H-%M-%S"))
job_name = f"{entity_name}_{run_datetime}"
test_output_path = os.path.join(
            os.path.abspath(os.path.join(__file__, os.path.pardir, os.path.pardir)),
            f"negative_news/output/{run_datetime}/{job_name}/"
)

entity_search_newsapi = NegativeNewsEntitySearch(
    NewsAPIScraper,
    entity_name,
    job_name=job_name,
    known_aliases_list=known_aliases_list,
    search_term_list=search_term_list,
    allowed_sources_list=allowed_sources_list,
    max_requests=5,
)

entity_search_bing = NegativeNewsEntitySearch(
    BingAPIScraper,
    entity_name,
    job_name=job_name,
    known_aliases_list=known_aliases_list,
    search_term_list=search_term_list,
    allowed_sources_list=allowed_sources_list,
    max_requests=5,
)

entity_search_reg = NegativeNewsEntitySearch(
    RegulatoryScraper,
    entity_name,
    job_name=job_name,
    known_aliases_list=known_aliases_list,
    search_term_list=search_term_list,
    max_requests=5,
)

search_list = [entity_search_newsapi, entity_search_bing, entity_search_reg]
postprocess_kwargs = {
    "is_org": is_org,
    "max_sentiment": max_sentiment,
    "min_year": min_year,
    "min_month": min_month,
    "min_similarity": min_similarity,
    "search_terms": search_term_list,
    "max_search_results": max_search_results,
    "output_path": test_output_path,
    "entity_name": entity_name,
    "entity_name_translated": entity_name_translated,
    "known_aliases": known_aliases_list,
    "language_abbrv": language_abbrv,
    "location": location,
    "employment": employment,
}
entity_job = NegativeNewsEntityJob(
    job_name, run_datetime, search_list, postprocess_kwargs
)
