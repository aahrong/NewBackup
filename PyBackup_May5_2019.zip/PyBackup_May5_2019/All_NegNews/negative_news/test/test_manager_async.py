import time
import asyncio
import logging

from negative_news.negative_news.manager import NegativeNewsManager
from constants import entity_job as entity_job1
from constants_alt import entity_job as entity_job2


logger = logging.getLogger(__name__)


async def main():
    logger.debug('Beginning "test_manager_async" ..')

    job_list = [entity_job1, entity_job2]
    manager = NegativeNewsManager(job_list)

    tock = time.perf_counter()
    await manager.async_start()
    tick = time.perf_counter()

    assert manager.num_job_notifications == len(
        job_list
    ), f"Expected {len(job_list)}, but got {manager.num_job_notifications}"

    logger.debug("Test finished successfully ..")
    logger.debug(f"Operation took {round(tick - tock, 2)} seconds .. ")


if __name__ == "__main__":
    # asyncio.run(main())
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())
