from datetime import datetime
import time
import asyncio
import os

from negative_news.negative_news.manager import NegativeNewsManager
from negative_news.negative_news.entity_search import NegativeNewsEntitySearch
from negative_news.negative_news.entity_job import NegativeNewsEntityJob
from negative_news.negative_news.scrapers.general_search import BingAPIScraper
from negative_news.negative_news.scrapers.newsapi import NewsAPIScraper, DEFAULT_NEWS_SOURCES
from negative_news.negative_news.scrapers.regulatory import RegulatoryScraper

DEFAULT_MAX_REQUESTS = 2


async def main():
    entity_list = [
        ("UBS AG", ["UBS"]),
        ("Wells Fargo", []),
        ("JPMorgan Chase Bank", ["JPMorgan"]),
        ("J.P. Morgan Securities", ["J.P. Morgan"]),
        ("Deutsche Bank", []),
        ("Brighthouse Life Insurance", ["Brighthouse"]),
        ("Legg Mason Inc", ["Legg Mason"]),
        ("LPL Financial", []),
        ("Lek Securities", []),
        ("Wedbush Securities", ["Wedbush"]),
        ("CFD Investments", []),
        ("Tradition Securities and Derivatives", []),
        ("Cetera", ["Cetera Advisor Networks"]),
        ("Rabobank", []),
        ("MUFG", []),
        ("Barclays", ["Barclays PLC"]),
        ("Standard Chartered Bank", []),
        ("Jes Stanley",[]),
        ("David Lubin",[]),
    ]

    run_datetime = str(datetime.strftime(datetime.utcnow(), "%m-%d-%y-%H-%M-%S"))

    entity_job_list = []

    for entity_str, known_alias_list in entity_list:
        entity_name = entity_str
        entity_name_translated = entity_str
        is_org = 1
        employment = ""
        location = ""
        max_sentiment = 0.05
        min_similarity = 0.35
        min_year = 2018
        min_month = 12
        max_search_results = 100
        language_abbrv = "EN"
        known_aliases_list = known_alias_list
        search_term_list = ["violation", "fraud", "corrupt", "fined", "sanction", "penalty"]
        allowed_sources_list = []

        job_name = f"{entity_name}_{run_datetime}"
        test_output_path = os.path.join(
            os.path.abspath(os.path.join(__file__, os.path.pardir, os.path.pardir)),
            f"negative_news/output/{run_datetime}/{job_name}/"
        )

        entity_search_newsapi = NegativeNewsEntitySearch(
            NewsAPIScraper,
            entity_name,
            job_name=job_name,
            known_aliases_list=known_aliases_list,
            search_term_list=search_term_list,
            allowed_sources_list=DEFAULT_NEWS_SOURCES,
            max_requests=DEFAULT_MAX_REQUESTS,
        )

        entity_search_bing = NegativeNewsEntitySearch(
            BingAPIScraper,
            entity_name,
            job_name=job_name,
            known_aliases_list=known_aliases_list,
            search_term_list=search_term_list,
            allowed_sources_list=allowed_sources_list,
            max_requests=DEFAULT_MAX_REQUESTS,
        )

        entity_search_reg = NegativeNewsEntitySearch(
            RegulatoryScraper,
            entity_name,
            job_name=job_name,
            known_aliases_list=known_aliases_list,
            search_term_list=search_term_list,
            max_requests=DEFAULT_MAX_REQUESTS,
        )

        search_list = [entity_search_newsapi, entity_search_bing, entity_search_reg]
        postprocess_kwargs = {
            "is_org": is_org,
            "max_sentiment": max_sentiment,
            "min_year": min_year,
            "min_month": min_month,
            "min_similarity": min_similarity,
            "search_terms": search_term_list,
            "max_search_results": max_search_results,
            "output_path": test_output_path,
            "entity_name": entity_name,
            "entity_name_translated": entity_name_translated,
            "known_aliases": known_aliases_list,
            "language_abbrv": language_abbrv,
            "location": location,
            "employment": employment,
        }
        entity_job = NegativeNewsEntityJob(
            job_name, run_datetime, search_list, postprocess_kwargs
        )

        entity_job_list.append(entity_job)

    print('Beginning "test_bulk_job" ..')

    manager = NegativeNewsManager(entity_job_list)

    tock = time.perf_counter()
    await manager.async_start()
    tick = time.perf_counter()

    print("Test finished successfully ..")
    print(f"Operation took {round(tick - tock, 2)} seconds .. ")


if __name__ == "__main__":
    asyncio.run(main())
