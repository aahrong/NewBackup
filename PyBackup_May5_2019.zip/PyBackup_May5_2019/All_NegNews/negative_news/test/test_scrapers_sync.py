import asyncio
import time

from negative_news.negative_news.scrapers.general_search import BingAPIScraper
from negative_news.negative_news.scrapers.regulatory import RegulatoryScraper
from negative_news.negative_news.scrapers.newsapi import NewsAPIScraper, DEFAULT_NEWS_SOURCES
async def main():
    entity_name = "UBS"
    job_name = "test"
    search_term_list = ["fine"]
    max_requests = 3

    print("Starting synchronous scraper test ..")

    tock = time.perf_counter()

    scraper = NewsAPIScraper(entity_name, job_name=job_name, search_term_list=search_term_list, allowed_sources_list=DEFAULT_NEWS_SOURCES, max_requests=max_requests)
    await scraper.start()

    scraper = RegulatoryScraper(entity_name, max_requests=max_requests, job_name=job_name, search_term_list=search_term_list)
    await scraper.start()

    scraper = BingAPIScraper(entity_name, max_requests=max_requests, job_name=job_name, search_term_list=search_term_list)
    await scraper.start()

    tick = time.perf_counter()    

    print(f"Test complete. Took {round(tick - tock, 2)}s .. ")

if __name__ == "__main__":
    asyncio.run(main())
