import asyncio
import time

from negative_news.negative_news.scrapers.rss import RSSFeedScraper


async def main():
	rss_scraper = RSSFeedScraper(debug=True)
	await rss_scraper.start()

if __name__ == "__main__":
	print("Starting test for 'RSSFeedScraper' ..")

	tock = time.perf_counter()
	asyncio.run(main())
	tick = time.perf_counter()

	print(f"Successfully finished test for 'RSSFeedScraper'. Took {round(tick - tock, 2)}s ..")