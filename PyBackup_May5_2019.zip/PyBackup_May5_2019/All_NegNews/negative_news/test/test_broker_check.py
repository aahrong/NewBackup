import time

from negative_news.negative_news.util.broker_check import get_finra_broker_check_summary
from negative_news.negative_news.database import get_bc_owners_feed_handle, get_bc_disclosures_feed_handle, \
													get_bc_meta_feed_handle

def main():
	crd = 877
	fh_owners = get_bc_owners_feed_handle()
	fh_disclosures = get_bc_disclosures_feed_handle()
	fh_meta = get_bc_meta_feed_handle()

	print("Starting 'test_broker_check' ..")

	tock = time.perf_counter()
	print(get_finra_broker_check_summary(crd, fh_owners, fh_disclosures, fh_meta))
	tick = time.perf_counter()

	print(f"Finished 'test_broker_check'. Operation took {round(tick - tock, 2)}s ..")

if __name__ == "__main__":
	main()