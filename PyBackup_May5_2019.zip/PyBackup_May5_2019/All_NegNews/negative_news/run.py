from negative_news.gui import app, FLASK_HOST, FLASK_PORT


if __name__ == "__main__":
    app.run(host=FLASK_HOST, port=FLASK_PORT, debug=True)
