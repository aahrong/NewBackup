# -*- coding: utf-8 -*-
"""
Created on Wed Feb 14 16:26:52 2018

@author: yangbo
"""
#import os
#scraper_dir = 'C:\\Users\\yangbo\\Documents\\Engagements\\04 INTAML\\Negative_News\\'
#os.chdir(scraper_dir)
from flask import Flask, request
import sys
import time
import os
#import subprocess
import config as config
from nn_base.nn_namefinder import static_search_setup
from nn_base.nn_namefinder import static_search_name
from nn_base.load_source_data import sqlpulldata
from nn_base.load_source_data import loadExcel
from scrapyd_api import ScrapydAPI
import json


#subprocess.Popen('scrapyd')
app = Flask(__name__)
app.config["APPLICATION_ROOT"] = os.environ.get('SERVER_CONTEXT_PATH', '/')
APPLICATION_ROOT = os.environ.get('SERVER_CONTEXT_PATH', '/')

@app.route(APPLICATION_ROOT)
def main():
    return "Testing new flask is running @ default entrypoint"
    
#Note: Must update below parameters in config.py to run sql api (before executing app.py)
#config.sqlload = 1, entity = 0 
@app.route(APPLICATION_ROOT + "sql")
def negative_news_sql():
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    datevar = request.args.get('datevar', default='')

    data = sqlpulldata(config.connection_string
        ,  config.start_date
        ,  config.end_date
        ,  config.datevar
        )
    #rename to match original columns 
    data = data.rename(index = str, columns = {"party_key":"id"
        ,"party_f_name":"FirstName"
        ,"party_m_name":"MiddleName"
        ,"party_l_name":"LastName"
        ,"city":"City"
        ,"state_province":"State"
        ,"country_cd":"Country"
        ,"occupation":"Occupation"
        ,"employer":"Company"
        })

    
    #static search setup info to pass to deamons 
    sites_all, sites_names = static_search_setup()

    #kick off scrapyd API to pass all subsequent scrapy jobs to for execution managment 
    from scrapyd_api import ScrapydAPI
    scrapyd = ScrapydAPI('http://localhost:6800')
    print(scrapyd.list_spiders('default'))

    #create batch id, to be saved in set of tuples called records=[] describing each iteration 
    batch_id = config.start_date +':'+ config.end_date+':'+ time.strftime("%Y-%m-%d-%H-%M-%S")
    records = []

    for idx, val in data.iterrows():
        if int(idx) >= 0:
            jobid = str(val.id) + '_' + val.FirstName + '_' + val.LastName + '_' + time.strftime("%Y-%m-%d-%H-%M-%S")
            static_result = static_search_name(0,val.FirstName, val.LastName, sites_all, sites_names)
            names = val.FirstName + ' ' + val.LastName
            print(names)
            scrapyd.schedule('default','nn_spider',jobid=jobid, id=str(val.id), entity_name = names, static_result = static_result)
            print('starting job  - '  + jobid)

            #create record to store results
            records.append(tuple((jobid,batch_id, config.project_dir + config.pdf_path+jobid+'.json'))) #append job to records

            #print message to indicate completion of batch job 
            if int(idx)== int(data.shape[0])-1:
                print("Batch Job Complete", batch_id, ' ', "files stored in", config.project_dir + config.pdf_path)
                #create dictonary of all results and output to enpoint at end of batch
                dic_of_tuples = {key: values for key, *values in records}
                print(dic_of_tuples)
            time.sleep(1)
    #return "{} was sent to negative news engine with the filename {}_{} {}.pdf \n".format(names, str(val.id), names, time.strftime("%Y-%m-%d"))
    return json.dumps(dic_of_tuples)

@app.route(APPLICATION_ROOT + "single")
def negative_news_single():
    id = request.args.get('id',default = '', type=str)
    name = request.args.get('name', default='', type=str)
    city = request.args.get('city', default='', type=str)
    state = request.args.get('state', default='', type=str)
    company = request.args.get('company', default='', type=str)
    occupation = request.args.get('occupation', default='', type=str)

    if name=='':
        return 'name is a required argument for single search'
    else:
        scrapyd = ScrapydAPI('http://localhost:6800')
        print(scrapyd.list_spiders('default'))

        sites_all, sites_names = static_search_setup()
        jobid = str(id) + '_' + name + '_' + time.strftime("%Y-%m-%d-%H-%M-%S")
        if len(name.split())>1: static_result = static_search_name(0,name.split()[0], name.split()[1], sites_all, sites_names)
        scrapyd.schedule('default','nn_spider',jobid=jobid, id=id, entity_name = name, static_result = static_result, city=city, state=state, company=company, occupation=occupation)
        return "{} was sent to negative news engine with the filename {}_{} {}.pdf \n".format(name, str(id), name, time.strftime("%Y-%m-%d"))

if __name__=="__main__":
    #subprocess.Popen(['scrapyd'])
    app.run(host='0.0.0.0',port=6006,debug=True)
