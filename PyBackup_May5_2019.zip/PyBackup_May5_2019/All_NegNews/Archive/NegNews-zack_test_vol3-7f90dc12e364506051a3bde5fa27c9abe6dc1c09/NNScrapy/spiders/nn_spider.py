# -*- coding: utf-8 -*-
"""
Created on Wed Feb 14 16:29:33 2018

@author: yangbo
"""
import numpy as np
import pandas as pd
import pickle
import os
import time
import re
import csv
import sys 
#sys.path.insert(0, "//home//docadmin//ZackC//NegNews//") #only include this if you are running from local ???(WHY DOES IT REFERENCE A DIFFERENT CONFIG FILE IF I DONT USE THIS???)

##from nn_base.nn_webprocess import extract_bing_results
from nn_base.nn_webprocess import extract_web_results
from nn_base.nn_webprocess import search_on_bing_all
from nn_base.nn_webprocess import identify_whitelist
from nn_base.nn_webprocess import generate_search_query
from nn_base.nn_webprocess import add_black_list
from nn_base.nn_textprocess import force_near_filter
from nn_base.nn_textprocess import entity_match_score
from nn_base.nn_textprocess import entity_stem_match
from nn_base.nn_textprocess import clean_paragraph
from nn_base.nn_textprocess import LSA_function
from nn_base.nn_textprocess import normalize_LSA
from nn_base.nn_textprocess import rerank_searchresults
from nn_base.nn_textprocess import summary_scores
from nn_base.nn_textprocess import OrigTxt_PreProcess
from nn_base.nn_textprocess import w2v_SortOutput
from nn_base.nn_textprocess import w2v_se2
from nn_base.nn_classes import search_entity as SE
from nn_base.nn_translate import langname_to_iso639
from nn_base.nn_translate import translate_searchterms
from nn_base.nn_translate import translate_text
import config as config
import scrapy
import pymagnitude
from fake_useragent import UserAgent
from nn_base.nn_pdf import create_empty_page
from nn_base.nn_pdf import create_nn_page
from nn_base.nn_pdf import create_pdf_summary
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter

import html

#USE: when scrapy.schedule() is called from main.py or scrapy crawl is called from command line(referencing nn_spider) , webScrap_bing() class if loaded , 
# which includes the scrapy name, and the custom settrings. Scrapy knows to load webScrap_bing inherently becuase webscrape_bing inherents scrapy.spider class 
# and the scrapy spider specified in the job scheduled in main.py has the name nn_spider. then the weScrap_bing class goes through initalizaiton __init__, then executes the commands in the class below.

class webScrap_bing(scrapy.Spider):  

    name='nn_spider'    
    
    #scrapy settings
    #log_level : Debug , gives you a tono of details (3 levels of details: Debug -> Info -> Error)
    #UserAgent().random : tells scrapy to use a random user agent to interact with the Heads of the URLS 
    #CLOSESPIDER_TIMEOUT: closes spider out if it gets hung, should increase this is we want to run > 1000 results 
    #RETRY_ENABLED: some websites allow you to re-try entering the link you want to crawl 
    custom_settings = {
        'AUTOTHROTTLE_ENABLED': 'True',
        'AUTOTHROTTLE_TARGET_CONCURRENCY': '1.0',
        'RANDOMIZE_DOWNLOAD_DELAY': 'True',
        'USER_AGENT': UserAgent().random,
        'ROBOTSTXT_OBEY': 'False',
        'HTTPCACHE_ENABLED': 'False',
        'LOG_STDOUT': 'True',
        #'LOG_LEVEL': 'WARNING',
        'LOG_LEVEL': 'DEBUG', 
        'DOWNLOAD_TIMEOUT': str(config.timeout),
        'RETRY_ENABLED': False,
        'CLOSESPIDER_TIMEOUT':'500',
        'DOWNLOAD_DELAY':'0.25'
    }

    #id: some unique identifier for each individual / entity ran
    #entity_name: the first and last name of the entity being processed 
    #**kwargs: optional arguments such as city , state, occupation, etc...
    #def __init__ is a constructor , every time you create an object of the class webScrap_bing(scrapy.Spider)
    #all the calls to the functions within the __init__ function will be compiled before anything is executed
    def __init__(self, id, entity_name, **kwargs):
        self.transcount = 0
        name = entity_name
        #Read the pickle file containing full processing list
        #print('initializing spiders',id,':', entity_name)
        #loads common-nouns, used for determining whether to use 'A' 'B' or 'A B' when searching for a person's name
        with open(config.source_path + config.common_noun) as f:  #1500 words
            reader = csv.reader(f, delimiter="\t")
            d = list(reader)
        common_nouns=[x[0].lower() for x in d]

        #creates searchterm_list, a list of search terms in various languages based on config.search_lang
        #output si a list of list, where each list represents the search terms in a different launge as specified by config
        #print('Config Search Terms: ',config.searchterms)
        searchterm_list, _  = translate_searchterms(config.searchterms2) if config.termlist==2 else translate_searchterms(config.searchterms1)
        #creates a list of search queries that will be sent to the search engine(must indicate locaiton and entity parameters as positional if u dont want defaults)
        query_list = generate_search_query(name, searchterm_list, config.entity, common_nouns)
        # add blacklist to querylists
        query_list = add_black_list(query_list)

        #identify fname and lname (to be removed eventually)
        fname = name.split()[0] if config.entity == 0 else name 
        lname = name.split()[1] if len(name.split()) > 1 & config.entity==0 else ''

        #map over any optional PII arguments
        #kwargs are optional(syntax, _init_(self,id,name, city='raliegh',etc...))
        if kwargs is not None:
            city = kwargs['city'] if 'city' in kwargs.keys() else ''
            state = kwargs['state'] if 'state' in kwargs.keys() else ''
            state2 = kwargs['state2'] if 'state2' in kwargs.keys() else ''
            country = kwargs['country'] if 'country' in kwargs.keys() else ''
            occupation = kwargs['occupation'] if 'occupation' in kwargs.keys() else '' 
            company = kwargs['company'] if 'company' in kwargs.keys() else ''

        #Construct SearchEntity Object
        #searchid is an index for the row / person being processed 
        self.se = SE(search_lang = config.search_lang, searchid = id, fname = fname, lname=lname, mname='', 
            city=city, state=state, state2 = state2, country=country,
            occupation=occupation, company=company, company2='',
            querylist = query_list, searchtermlist = searchterm_list)     
        self.se.search_lang_short = list(map(langname_to_iso639, self.se.search_lang))
        #dictonary of optinoal parameters, by using self.kwargs, you make these optional parameters throughout the spider 
        self.kwargs = kwargs 
    
    def start_requests(self):
        print('spider start on {} {}'.format(self.se.entity_fname,self.se.entity_lname))
        #Search on Bing
        links, _ , bingquery = search_on_bing_all(self.se)
        self.se.querylisturl = bingquery
        #Loop through each link returned by Bing - call secondary_scrape
       	out = ''.join(['{}:{}'.format(x,len(y)) for (x,y) in zip(self.se.search_lang, links)])
        print('Bing Search Completed on {} Languages: {}'.format(len(self.se.search_lang),out))

        for lang_idx, lang in enumerate(links): #lang is representing the list of URLs for each language
            #Added 2018/03/19 per Rocky's email - adds static whitelist item to english search
            if self.se.search_lang[lang_idx] == 'english' and config.whitelist_search == 1:
                whitelist = identify_whitelist(self.se)
                lang.extend(whitelist)
            lang = list(set(lang))
           # print('lang: ',lang)

            #for each URL for the language being processed go to each url and return a response object 
            #dont_redirect: there are sites that will auto redirect you into an infinite loop because they knwo u are trying to scrape them, this option prevents this
            #callback: the result of the scrapy.request fucntion is then passed to the callback function secondary_scrape()
            for url in lang:
                yield scrapy.Request(url, callback=self.secondary_scrape, meta={'lang_idx':lang_idx, 'dont_redirect':True})

    #repsonse here is reprsenting the output of yield scrapy.Result                
    #this is saving the result response into the se object 
    #creates a dictonary of all URL's to text (key: URL, value: response) / this is why json files are so large
    def secondary_scrape(self,response):
        #print('{} received from {}'.format(response.status, response.url))
        #Extract language, url, responsetext from response object
        lang_idx = response.meta.get('lang_idx') #the languge index (english or spanish)
        url = response.url
        responsetext = response.text
        #Save origtext-url keypair into dictionary
        if responsetext != '':
            #if url is not in the keys of the dictonary mapping the url text to the key, then append it as a new key , value pair 
            if url not in self.se.origtextlist[lang_idx].keys():
                self.se.origtextlist[lang_idx][url] = responsetext
                self.se.lastsearchdate[lang_idx][url] = time.strftime("%m-%d-%Y")
               # print('New Text Added to se object at: ',lang_indx,url)
        print('scrapping completed on url - {}'.format(url))

    #reason: reason why spider is closed 
    def closed(self, reason):

        #For each language (tracking language itself and language index), do the following:
        for idx, _ in enumerate(self.se.search_lang):
            #1) extract webresults(origtextlist is scrapy response object, convert that into text)
            textlist = []
            urllist = []
            for k,v in self.se.origtextlist[idx].items():
                #extract_web_results(): extracts the text from the response object
                extracted_text = extract_web_results(v, self.se.entity_fname, self.se.entity_lname, config.entity)
                if config.translate_search_to_english == 1:
                    translated, tcount = translate_text(extracted_text.split('<!@&>'), lang_from=self.se.search_lang[idx])
                    self.transcount = self.transcount + tcount
                    textlist.append('<!@&>'.join(translated))
                else:
                    textlist.append(extracted_text)
                urllist.append(k)

            #print(textlist)
            #2) apply a near filter to it if config parameter is >= 0
            #note: if lname is not present this filter forces the 'entity' or fname simply to be found near anything(' ')
	    #print('Total Texts Before Filter: ',len(textlist))
            if config.near_filter_distance >= 0:
                textlist = [force_near_filter(text, self.se.entity_fname, self.se.entity_lname, config.near_filter_distance, config.entity) for text in textlist]
            #print('Total Texts After Filter: ',len(textlist))

            #print(textlist)
            #3) clean up the texts using clean_paragraph function
            ##W2V Cleanup Function:
            #print(textlist)
            textlist , origtext = OrigTxt_PreProcess(textlist, self.se.entity_fname, self.se.entity_lname, delim ='<!@&>', window=False)
            #print(textlist)
            textlist_zip = list(zip(textlist, origtext, urllist))
            textlist_clean = [x[0] for x in textlist_zip if len(x[0]) != 0] #first element in ziped textlist
            self.se.pdftext[idx] = [x[1] for x in textlist_zip if len(x[0]) != 0] #first element in ziped textlist
            urllist = [x[2] for x in textlist_zip if len(x[0]) != 0] #second element in zipped textlist

            #4) Calculate relevancy scores(THESE NEED TO BE UPDATED)
            scoreslist = [entity_match_score(text, self.se, idx) for text in textlist_clean]
            #5) Find stem matches
            stemmatchlist = [entity_stem_match(' '.join(text).split(), self.se, idx) for text in textlist_clean]
            #print(self.se.origtextlist[idx])
            #6) Save the processed results (cleaned text, fuzzyscores, details, and matched stems) into appropriate se slot
            self.se.urllist[idx] = urllist
            self.se.textlist[idx] = textlist_clean
            self.se.list_fuzzyscore[idx] = [np.mean([x for x in scores if x > 0]) if len([x for x in scores if x > 0])>0 else 0 for scores in scoreslist]
            self.se.list_fuzzyscoredetail[idx] = scoreslist
            self.se.list_matchedstems[idx] = stemmatchlist
            print('TotalURLs',len(urllist))



        #print('===========================================================')
        #print('===================THIS IS THE FIRST LIST==================')
        #print(list(zip(self.se.urllist[0],self.se.textlist[0])))
        for idx, text in enumerate(self.se.textlist):
            if text == []: self.se.urllist[idx]=[]
        searchresults = ' '.join(['{}:{}'.format(x,len(y)) for (x,y) in zip(self.se.search_lang, self.se.urllist)])
        print('Searched {} languages total. The results are: {}'.format(self.se.search_lang_ct, searchresults))     
        print(self.kwargs)
        
        if self.kwargs is not None:
            if 'static_result' in self.kwargs.keys(): 
                print('static_result is:' + self.kwargs['static_result'])
                static_result = self.kwargs['static_result']
                if static_result == '0' and config.static_spider == 1:
                    static_match_path = config.working_path + "static_matches/" + '{}_{}_{}'.format(self.searchid, self.se.entity_fname, self.se.entity_lname)
                    print(static_match_path)
                    self.se.static_search_result = pickle.load(open(static_match_path+'.pkl', 'rb'))       
                    print(static_match_path)

        #if self.se.static_search_result != '': 
        #    print(self.se.static_search_result)
        #else:
        #    print('static search not found or not enabled')

        #load word embeddings for vectorizing sentences and key risk terms 
        wv = pymagnitude.Magnitude(config.word_embedding)

        #Execute W2V and transform sentences into sentences of embeddings 
        self.se = w2v_se2(self.se, wv, entity=config.entity ,ndoc=config.search_results, nsent=1000, sent_max =config.max_sent , min_sim = 0.1, delim = '')
                  
        print('========================THIS IS THE SORTED LIST======================')
        print(list(zip(self.se.urllist[0],self.se.textlist[0])))
        #print(self.se.w2vInfo[0])

        self.se = w2v_SortOutput(self.se, config.entity, max_sent = config.max_sent)
        print(self.se.w2vDfSorted[0])
        self.se = LSA_function(self.se)
        self.se = rerank_searchresults(self.se, config.LSA_score_filter)
        self.se = summary_scores(self.se, config.search_results)
        
        #print(self.se.textlist)
        #this is not used for anything other than creating a pickle verison of the se object for testing new funcitnality 
        print('exporting results to pickle, which can then be loaded statically for testing new funcitonality using load_results() in text_processing')
        pickle.dump(self.se, open(config.working_path + self.se.entity_fname + ' ' + self.se.entity_lname+ ' ' + time.strftime("%m-%d-%Y") + '.pk', 'wb'))

        #fname: filename of pdf created , failed: list of languages that failed to create a pdf 
        fname, failed = create_pdf_summary(self.se)
        print('PDF file stored at - {}'.format(os.path.basename(fname)))
        for x in failed:
            print('PDF creation failed on language - {}'.format(x))
        jsonname = os.path.splitext(fname)[0]+'.json'
        dataout = self.se.to_json(jsonname)
        if dataout == 0: #to_json() will return a 0 if sucsesful 
            print('Data saved at {}'.format(os.path.basename(jsonname)))
        else: 
            print('Data Not Saved')
        print('total chars translated {}'.format(self.transcount))
        #pickle.dump(self.se, open(config.working_path + self.se.entity_fname + ' ' + self.se.entity_lname+ ' ' + time.strftime("%m-%d-%Y") + '.pk', 'wb'))
            
#        print("there are {} number of links in final url".format(len(self.se.urllist)))
#        if len(self.se.urllist)==0:
#            create_empty_page(self.se)
#        else:
#            ## Get the LSA score for all the links and sort
#            self.se.LSA_score = LSA_function(self.se)
#            ## Getting how many links have LSA > 0.01
#            max_links_for_score = len([a for a in self.se.LSA_score if a >= 0.01])
#            if max_links_for_score == 0:
#                create_empty_page(self.se)
#            else:
#                self.se = rerank_searchresults(self.se)
#                self.se = summary_scores(self.se, config.search_results)
#                x = create_nn_page(self.se)
#                if x == 0:
#                    print("PDF Successfully completed")
#                else:'
#                    print("Error encountered during one of the steps")
#                yield scrapy.http.Request('www.bing.com', callback=self.next_request)
                
##                
##
#import sys
#sys.path.insert(0, 'C:\\Users\\yangbo\\Documents\\Engagements\\04 INTAML\\Negative_News\\Negativenews\\website_scraper_multilang\\')
##
#import pandas as pd
#import numpy as np
#import nn_base.nn_config as config
#from scrapy.crawler import CrawlerRunner
#from scrapy import log
##
#from crochet import setup
#setup()
#crawler = CrawlerRunner()
#spider = webScrap_bing(i=6)
#crawler.crawl(spider,i=6) 
###    
#input('Press ENTER to exit')
#
##se = pickle.load(open(config.working_path + 'Sameer Gupta 03-14-2018.pk','rb'))
