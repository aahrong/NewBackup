### -*- coding: utf-8 -*-
"""
Created on Wed Feb 14 16:26:52 2018

@author: yangbo
"""
#import os
#scraper_dir = 'C:\\Users\\yangbo\\Documents\\Engagements\\04 INTAML\\Negative_News\\'
#os.chdir(scraper_dir)


import sys
import time
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))) #docker use

#location of nn_base (this is a total hack will have to change every time you change the config file )
#sys.path.insert(0, "//home//docadmin//ZackC//NegNews//")

import pandas as pd
#import numpy as np
import config 
#from nn_base.nn_classes import search_entity as SE
#from website_scraper.website_scraper.spiders.spider_webscraper_google_v1 import webScrap_google
#from website_scraper.website_scraper.spiders.spider_webscraper_bing_v1 import webScrap_bing
#from nn_base.nn_query_generator_v2 import query_generation
from nn_base.nn_namefinder import static_search_setup
from nn_base.nn_namefinder import static_search_name
from nn_base.load_source_data import sqlpulldata
from nn_base.load_source_data import loadExcel



"""
MAIN CODE: OUTLINE
WARNING: Scrapyd deamons must be up and running prior to execution!

1) Query generation: craft query based on an input list (nn_config.py). This includes options below:
    - multiple search engine (Google, Bing)
    - multiple languages (translation via google / deepl)
    - additional search criteria support

2) Main Query: Call search engine specified and retrieve url list of interest

3) For each person searched, perform the following:
    1) call a spider to crawl all of the websites on the url list
    2) for each website returned, extract the texts
    
4) Once all texts are returned, filter and rank the pages

5) Once filtered / ranked, produce output

"""
#load initital data 
if config.sqlload == 1: 
    data = sqlpulldata(config.connection_string
        ,  config.start_date
        ,  config.end_date
        ,  config.datevar
        )
    print(data)
    #rename to match original columns 
    data = data.rename(index = str, columns = {"party_key":"id"
        ,"party_f_name":"FirstName"
        ,"party_m_name":"MiddleName"
        ,"party_l_name":"LastName"
        ,"city":"City"
        ,"state_province":"State"
        ,"country_cd":"Country"
        ,"occupation":"Occupation"
        ,"employer":"Company"
        })
#    print(data)
else: 
    data = loadExcel(config.source_path
        , config.source_excel_file
        , config.source_excel_names
        )
#    print(data)

#file = query_generation()
#file = pd.read_pickle(config.working_path + config.query_picklename)


sites_all, sites_names = static_search_setup()


from scrapyd_api import ScrapydAPI
scrapyd = ScrapydAPI('http://localhost:6800')
print(scrapyd.list_spiders('default'))

# #scrapyd.schedule('default', 'web_scraper', query="hello world", sr='2')
# #
# #egg = open('C:\\Users\\yangbo\\Documents\\Engagements\\04 INTAML\\Negative_News\\Negativenews\\nn_scrape\\nnscrape_2.1.egg', 'rb')
# #scrapyd.add_version('nn_scrape', '2.1', egg)
# #egg.close()
# #scrapyd.list_spiders('nn_scrape')
# 
# #scrapyd.schedule('default', 'webScrape_bing', jobid='hellotest', i='1')
# # 
i = 20000 
#create batch id, to be saved in set of tuples called records=[] describing each iteration 
batch_id = config.start_date +':'+ config.end_date+':'+ time.strftime("%Y-%m-%d-%H-%M-%S")
records = []

for idx, val in data.iterrows():
    if int(idx) >= 0:
        jobid = str(val.id) + '_' + val.FirstName + '_' + val.LastName + '_' + time.strftime("%Y-%m-%d-%H-%M-%S")
     
        if config.static_spider == 1 or val.FirstName == '' or val.LastName == '':
            static_result = static_search_name(0,val.FirstName, val.LastName, sites_all, sites_names)
        else:
            static_result = ''
        names = val.FirstName + ' ' + val.LastName
 #       print(names)
        scrapyd.schedule('default','nn_spider',jobid=jobid, id=str(val.id), entity_name = names, static_result = static_result)
        print('starting job  - '  + jobid)
        
        #create record to store results 
        records.append(tuple((jobid,batch_id, config.pdf_path+jobid+'.json'))) #append job to records 
        


        #print message to indicate completion of batch job 
        if int(idx)== int(data.shape[0])-1:
            print("Batch Job Complete", batch_id, ' ', "files stored in", config.project_dir + config.pdf_path)
            
            #create dictonary of all results and output to enpoint at end of batch 
            dic_of_tuples = {key: values for key, *values in records}
            print(dic_of_tuples)
            
        time.sleep(1)

        #break
   # break
#        i = i - 1
#        if i == 0:
#            break
# for idx, val in file.iterrows():
#     jobid = str(idx) + '_' + val.FirstName + '_' + val.LastName
#     scrapyd.cancel('nn_scrape',jobid)
# #    time.sleep(1)
# #    
#     
# file = pd.read_pickle(config.working_path + config.query_picklename)
