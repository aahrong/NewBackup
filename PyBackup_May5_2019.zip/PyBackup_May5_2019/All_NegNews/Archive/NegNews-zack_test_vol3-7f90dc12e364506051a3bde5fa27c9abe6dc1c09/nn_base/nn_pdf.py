# -*- coding: utf-8 -*-
"""
Created on Tue Feb 20 13:00:13 2018

@author: yangbo
"""

import os, errno
import time
import html
import pdb
import cgi
from nn_base.nn_classes import search_entity as SE
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
import config as config
from PyPDF2 import PdfFileMerger

#used to replace an existing pdf file with the same name of a new pdf being generated in this process
def remove_if_exist(filename):
    try:
        os.remove(filename)
    except OSError as e:
        raise e

#create output pdf         
def create_pdf_summary(se):

    #empty list where each list element represents a filename
    fnames_list = []

    #pdf file name (line 66)
    final_fname = config.pdf_path + str(se.entity_id) + '_' + se.entity_fname + ' ' + se.entity_lname+ ' ' + time.strftime("%m-%d-%Y") + '.pdf'

    #loop through each language
    for idx in range(0,se.search_lang_ct):
        #if the urllist for the language being processed is empty then create a an empty page and append the 
        #create_empty_page and create_nn_page will return -1 if they fail
        if se.urllist[idx] == []:
            fname = create_empty_page(se, idx)
            fnames_list.append(fname)
        else:
            fname = create_nn_page(se, idx)
            fnames_list.append(fname)

    #initiating and pdffile merger to merge all pdf pages together 
    merger = PdfFileMerger()
    toremove=[]
    failed = []
    
    #loop through each file above, if pdf failed then -1 and append to failed.
    for idx, pdf in enumerate(fnames_list):
        if pdf != -1:
            #open the file that was sucessfully created and append to merge, which generates the aggregated pdf 
            #merge and toremove include actual file contents, not just the file name 
            temp = open(pdf,'rb')
            merger.append(temp)
            toremove.append(temp)
        else:
            failed.append(se.search_lang[idx])

    #open final file and write the merged pages generated above into a single pdf 
    with open(final_fname, 'wb') as finalout:
        merger.write(finalout)
    #each pdf page is an individual file, we have already merged all these pages into a single file, so we have way to many pdf files , we only need the merged one, 
    #remove all pdf files except the final merged pdf file. 
    for pdf in toremove:
        pdf.close()

    #if the pdf failed, remove it 
    for pdf in fnames_list:
        if pdf!= -1:
            remove_if_exist(pdf)
    
    #return the final pdf file name, and a list of pdfs that failed  
    return final_fname, failed
    
          

def create_empty_page(se, idx):
##    pdb.set_trace()
#    os.chdir(config.pdf_path)
    #try:

    #pdf file name 
    pdf_fname = config.pdf_path + str(se.entity_id) + '_' + se.entity_fname + ' ' + se.entity_lname+ ' ' + time.strftime("%m-%d-%Y") + '_' + str(idx) + '.pdf'
    
    #pdf styles to be selected and used in below story
    styles = getSampleStyleSheet()
    
    #set up document margins and generate template for the pdf to be created / generated from doc.build()
    doc = SimpleDocTemplate(pdf_fname, leftMargin = 0.75*inch, rightMargin = 0.75*inch, topMargin = 1*inch, bottomMargin = 1*inch)
    
    #blank list to hold the pdf meat 
    Story=[] 

    #first header element appended to story, the first name, last name, languge, and the style of the title 
    h1_1=Paragraph(se.entity_fname + ' ' + se.entity_lname + ' - ' + se.search_lang[idx][0].upper() + se.search_lang[idx][1:], styles['Title'])
    Story.append(h1_1)
    
    #second header element appeneded to story, the bing search link, heading2 used to left justify 
    h2_1=Paragraph("Search link", styles['Heading2'])
    Story.append(h2_1)
    print(se.querylisturl[idx])

    #third element (the bing query generated)
    #cgi.escape is used to create the hovering link in the pdf 
    #when bing query is generated there are spaces, these spaces have to be removed, 
    #and bing requires %20 in there place. this enables you to copy the full bing query and paste it in browser
    p_1 = Paragraph(cgi.escape(se.querylisturl[idx].replace(' ','%20')), styles['Normal'])    
    #this is the same as above, but only works in python3, this may be better than the line used above
   #p_1 = '<para align=left><link href="' + html.escape(se.querylisturl[idx]) + '">' + se.entity_querylist[idx] + '</link></para>'
    Story.append(p_1)
    
    #create sentence to indicate no links found  se.search_lang[idx]
    h2_2=Paragraph("No negative links found", styles['Heading2'])
    Story.append(h2_2)

    #doc build generates the physical document given the arguments compiled into story[] list
    doc.build(Story)
    return pdf_fname
   # except:
   #     print('ERROR CREATING EMPTY PDF FOR LANGUAGE {}'.format(se.search_lang[idx]))
   #     return -1
    
#create pdf of non blank results 
def create_nn_page(se, idx):

    #set up all variables you will use throughout the pdf
    #need to include the total links removed due to positive sentiment 
    final_links = se.urllist[idx]
    max_links_for_score =  se.LSA_filter_count[idx]
    links_after_filter = len(se.urllist[idx])
    
    #determines the total number of results we want to include the pdf 
    if links_after_filter > config.search_results_maxoutput:
        max_links_for_score = config.search_results_maxoutput
        
    #scores for each article , each list will have a length equal to the total number of articles (and they are in line)
#    result_LSA  = se.LSA_score[idx]
    avg_identity_scores = se.list_fuzzyscore[idx]
    matched_stems_list  = se.list_matchedstems[idx]
    normalized_risk_score = se.riskscore_final[idx]
    name_fuzzy_score = se.name_fuzzy_all[idx]
    location_fuzzy_score = se.location_fuzzy_all[idx]
    employment_fuzzy_score = se.employment_fuzzy_all[idx]
    queryurl = se.querylisturl[idx]
    w2vtopsent = se.w2vTopSent[idx] #this is the top 3 sentences per doc, need to include the scores associated with these sentences (found in nn_textprocess.py)

    #pdf template to populate 
    styles = getSampleStyleSheet()
    #output file name 
    outfn = config.pdf_path + se.entity_fname + ' ' + se.entity_lname+ ' ' + time.strftime("%m-%d-%Y") + '_' + str(idx) + '.pdf'
    
    #try:
    pdf_merge_list =[]
    ## Overview pdf generations
    pdf_filename = config.pdf_path + se.entity_fname + '_'+se.entity_lname + '_Overview.pdf'

    #pdf layout 
    doc = SimpleDocTemplate(pdf_filename, pagesize=letter, leftMargin = 0.75*inch, rightMargin = 0.75*inch, topMargin = 1*inch, bottomMargin = 2*inch)
    Story=[] 
    h1_1=Paragraph(se.entity_fname + ' ' + se.entity_lname, styles['Title'])
    Story.append(h1_1)
    #no longer use default styles, so html tags must be used 
    #<sup>1</sup>: this represents the exponent/hyperscript found on Total Negative News Score, and is also found in the footer
    p1=Paragraph("<para align=center><br/><font size=11><b><u>Total Negative News Score</u></b></font><font size=8><sup>1</sup></font>: " + str(int(round(normalized_risk_score))) + "%" + "</para>", styles['Heading2']) 
    Story.append(p1)
    
    #if a hit was found on a static search list / HR entity list, the info is populated below 
    #static_search_result si a dic, .items() , check out static_search_result() function form NN_namefinder.py
    if se.static_search_result != '':
        totallist = [item for searchlist in [list(x[1].keys()) for x in se.static_search_result.items() if len(x[1].keys())>0] for item in searchlist]
        px = Paragraph("<para align=center><font size=10><b><u>Warning: Name Found on targeted search list:</u></b></font></para>", styles['Heading2'])
        Story.append(px)
        
        #loop thorugh all the lsits a hit was found on and concatenate them into a string and populate them below the header 
        for res in totallist:
            px = Paragraph("<para lindent=10><font size=9>"+res+ "</font></para>", styles['Normal'])
            Story.append(px)


    t_h=Paragraph("<para align=center><br/><font size=11><b><u>Details on Links Searched</u></b></font><font size=8><sup>2</sup></font> </para>", styles['Heading2'])
    Story.append(t_h)        

    #create the 6 elmeents to be populated into a 3*2 table , the first 3 elements are the value's description, the llsat 3 are the actual values 
    #headers
    row1 = Paragraph("<para align=center>Links returned </para>", styles['Normal'])
    row2 = Paragraph("<para align=center>Remaining after filtering</para>", styles['Normal'])
    row3 = Paragraph("<para align=center>Negative links used for risk scoring</para>", styles['Normal'])
    #values
    row1_2 = Paragraph('<para align=center>' + str(config.search_results) + '</para>', styles['Normal'])
    row2_2 = Paragraph('<para align=center>' + str(links_after_filter) + '</para>', styles['Normal'])
    row3_2 = Paragraph('<para align=center>' + str(max_links_for_score) + '</para>', styles['Normal'])
    #create a list  of 6 elements to hold above infomration in order needed to generate table from  
    data= [[row1, row1_2],
           [row2, row2_2],
           [row3,row3_2]]
    #put ilst of elements into table in the center of the pagee
    t=Table(data, hAlign='CENTER')
    #sets up the grid the data in t will be put into and append it onto the story 
    t.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                          ('BOX', (0,0), (-1,-1), 0.25, colors.black)]))
    Story.append(t)

    #repeat the same process taken above for the Average Relevance Scores 
    p3=Paragraph("<para align=center><font size=11><b><u>Average Relevance Scores</u></b></font><font size=8><sup>3</sup></font> </para>", styles['Heading2'])
    Story.append(p3)
    p4_1 = Paragraph("<para align=center>Name</para>",styles['Normal'])
    p4_2 = Paragraph("<para align=center>Location</para>",styles['Normal'])
    p4_3 = Paragraph("<para align=center>Employement</para>",styles['Normal'])
    p5_1 = Paragraph("<para align=center>" + str(name_fuzzy_score) + '</para>', styles['Normal'])
    p5_2 = Paragraph("<para align=center>" + str(location_fuzzy_score) + '</para>', styles['Normal'])
    p5_3 = Paragraph("<para align=center>" + str(employment_fuzzy_score) + '</para>', styles['Normal'])
    data2= [[p4_1, p5_1],
            [p4_2, p5_2],
            [p4_3, p5_3]]
    t2=Table(data2, hAlign='CENTER')
    t2.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                           ('BOX', (0,0), (-1,-1), 0.25, colors.black)]))
    Story.append(t2)
    h2_1=Paragraph("<para align=center><font size=11><b><u>Search Clause</u></b></font><font size=8><sup>4</sup></font> </para>", styles['Heading2'])
    Story.append(h2_1)

    #wrao the bing search clause , and enable hover visual of query
    address = '<para align=center><link href="' + cgi.escape(queryurl) + '">' + se.entity_querylist[idx] + '</link></para>'
    a_1 = Paragraph(address, styles['Normal'])
    Story.append(a_1)

    #generate footer object to be populated using FooterCanvas function (below)
    #may need to modify text in the function to reflect use case
    doc.multiBuild(Story, canvasmaker=FooterCanvas)

    #insert the first page into the pdfmerge list 
    pdf_merge_list.insert(0, pdf_filename)

    ## Overview pdf generation
    pdf_filename2 = config.pdf_path + se.entity_fname + '_'+se.entity_lname + '_Overview2.pdf'
    doc = SimpleDocTemplate(pdf_filename2, pagesize=letter, leftMargin = 0.75*inch, rightMargin = 0.75*inch, topMargin = 1*inch, bottomMargin = 1*inch)
    Story=[]         
    h2_4 = Paragraph("<para align=center><font size = 11><u>Links</u></font> </para>", styles['Heading2'])
    Story.append(h2_4)        

    #this loop builds info for the links pulled back and the sentences associated with each link(rank ordered)
    for t in range(0,max_links_for_score):  
        temp1 = Paragraph(str(t+1) +". " + "<i>" + cgi.escape(final_links[t])+"</i>" + "<br/>",styles['Normal'])
        Story.append(temp1)
        tempx = Paragraph("<para lindent=40><u>Top Sentences:</u> " + "<br/>" + '</para>', styles['Normal'])
        Story.append(tempx)
        for sent in w2vtopsent[t]:
            tempx = Paragraph("<para lindent=45> - " + str(sent) + "<br/>" + '</para>', styles['Normal'])
            Story.append(tempx)
        temp2 = Paragraph("<para lindent=40><u>Stems matched:</u> " + str(matched_stems_list[t]) + "<br/>" + '</para>' ,styles['Normal'])
        Story.append(temp2)
        temp3 = Paragraph("<para lindent=40><u>Average Relevance Score for Identity Match:</u> " + str(int(round(avg_identity_scores[t],1))) +"%" + "<br/><br/>" + '</para>',styles['Normal'])
        Story.append(temp3) 
    doc.build(Story)  
    pdf_merge_list.insert(1, pdf_filename2)
    ## Merging all pdfs to generate final
    inputs = pdf_merge_list
    merger = PdfFileMerger()
    temppdfs = []
    for pdf in inputs:
        temp = open(pdf,'rb')
        merger.append(temp)
        temppdfs.append(temp)
    with open(outfn, 'wb') as fout:
        merger.write(fout)    
#    merger.close()
    for pdf in temppdfs:
        pdf.close()
    for pdf in inputs:
        remove_if_exist(pdf)
#    with open(se.entity_fname + ' ' + se.entity_lname + '.txt', 'w') as file:
#       file.write(','.join([str(round(x,5)) for x in result_LSA]))
    return outfn
    #except:
    #    return -1
    
    
### defining footer for pdf   
class FooterCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        canvas.Canvas.__init__(self, *args, **kwargs)
        self.pages = []
    def showPage(self):
        self.pages.append(dict(self.__dict__))
        self._startPage()
    def save(self):
        page_count = len(self.pages)
        for page in self.pages:
            self.__dict__.update(page)
            self.draw_canvas(page_count)
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)
    def draw_canvas(self, page_count):
        page = "Page %s of %s" % (self._pageNumber, page_count)        
        note2_1 = "The above Total Negative News Score is the a percentage between 0-100 with higher % representing higher risk."
        note1_1 = "The above Search Clause searches the input first name and last name with up to three word in between. The"
        note1_2 = "included quotes ensures that the searched name will appear in every result. In addition, at least one term from the above negative news " 
        note1_3 = "list will appear in every result analyzed. "
        note3_1 = "Links are filtered out by a pre-determined ‘black-list’ which includes, for example, links from LinkedIn or Facebook. "
        note4_1 = "Note that the above Name score will always be high due to the structure of the search clause. The confidence score for location"
        note4_2 = "is the result of an approximate or partial match between the input location information and the location that was found on the google "
        note4_3 = "search results. N/A implies location / Employment was not explicitly provided. "
        x = 128
        self.saveState()
        self.setStrokeColorRGB(0, 0, 0)
        self.setLineWidth(0.5)
        self.line(66, 150, letter[0] - 66, 150)
        self.setFont('Helvetica', 5)
        self.drawString(66, 140, '1')
        self.drawString(66, 130, '2')
        self.drawString(66, 120, '3')
        self.drawString(66, 90, '4')           
        self.setFont('Helvetica', 8)
        self.drawString(69, 140, note2_1)
        self.drawString(69, 130, note3_1)
        self.drawString(69, 120, note4_1)
        self.drawString(69, 110, note4_2)
        self.drawString(69, 100, note4_3)
        self.drawString(69, 90, note1_1)
        self.drawString(69, 80, note1_2)
        self.drawString(69, 70, note1_3)     
        self.drawString(letter[0]-x, 65, page)
        self.restoreState()
