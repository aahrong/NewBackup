#AURTHER: ZACHARY CARIDEO 
#DATE: 7/19//2018
#DESCRIPTION: CUSTOM FUNCTIONS TO GENERATE THE URL QUERY REQUIRED TO SEARCH AD-HOC SITES 

#Note: We only search the first page of each of these sites, we can incorporate searching multiple pages 
def finra_search(se):
    namesplit = []
    name = se.entity_fname.strip() if se.entity_lname == '' else se.entity_fname.strip()+' '+se.entity_lname.strip()
    namesplit = name.split()
    safe_dict ={}
    safe_dict['namesplit'] = namesplit
    namelen= len(namesplit)
    formatset = "{}%2520"*(namelen-1)+"{}"
    Finra = str("https://www.finra.org/search/global/"+ name if namelen ==1 else "https://www.finra.org/search/global/"+formatset).format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
    return Finra


def dockets_search(se):
    namesplit = []
    name = se.entity_fname.strip() if se.entity_lname == '' else se.entity_fname.strip()+' '+se.entity_lname.strip()
    namesplit = name.split()
    safe_dict ={}
    safe_dict['namesplit'] = namesplit
    namelen= len(namesplit)
    formatset = "{}+"*(namelen-1)+"{}"
    dockets = str("https://dockets.justia.com/search?parties={}&cases=mostrecent".format(name) if namelen ==1 else "https://dockets.justia.com/search?parties="+formatset+"&cases=mostrecent").format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
    return dockets

def colombian_search(se):
    namesplit = []
    name = se.entity_fname.strip() if se.entity_lname == '' else se.entity_fname.strip()+' '+se.entity_lname.strip()
    namesplit = name.split()
    safe_dict ={}
    safe_dict['namesplit'] = namesplit
    namelen= len(namesplit)
    formatset = "{}+"*(namelen-1)+"{}"
    colombian = str("https://www.fiscalia.gov.co/colombia/?s={}".format(name) if namelen ==1 else "https://www.fiscalia.gov.co/colombia/?s="+formatset).format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
    return colombian

def fdic_search(se):
    namesplit = []
    name = se.entity_fname.strip() if se.entity_lname == '' else se.entity_fname.strip()+' '+se.entity_lname.strip()
    namesplit = name.split()
    safe_dict ={}
    safe_dict['namesplit'] = namesplit
    namelen= len(namesplit)
    formatset = "{}+"*(namelen-1)+"{}"
    fdic = str("https://search.fdic.gov/search?q={}&btnG=Search&output=xml_no_dtd&oe=ISO-8859-1&ie=ISO-8859-1&client=press&proxystylesheet=wwwGOV&sort=date%3AD%3AL%3Ad1&wc=200&wc_mc=1&ud=1&exclude_apps=1&site=press".format(name) if namelen ==1 else "https://search.fdic.gov/search?q="+formatset+"&btnG=Search&output=xml_no_dtd&oe=ISO-8859-1&ie=ISO-8859-1&client=press&proxystylesheet=wwwGOV&sort=date%3AD%3AL%3Ad1&wc=200&wc_mc=1&ud=1&exclude_apps=1&site=press").format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
    return fdic

def fdic_name_search(se):
    namesplit = []
    name = se.entity_fname.strip() if se.entity_lname == '' else se.entity_fname.strip()+' '+se.entity_lname.strip()
    name = name.strip()
    namesplit = name.split()
    safe_dict ={}
    safe_dict['namesplit'] = namesplit
    namelen= len(namesplit)
    formatset = "{}+"*(namelen-1)+"{}"
    fdic = str("https://search.fdic.gov/search?q={}&btnG=Search&output=xml_no_dtd&oe=ISO-8859-1&ie=ISO-8859-1&client=press&proxystylesheet=wwwGOV&wc=200&:%20wc_mc=1&ud=1&wc_mc=1&exclude_apps=1&site=press&ulang=en&ip=10.30.1.36&access=p&entqr=0&entqrm=0&filter=0&sort=date%3AD%3AS%3Ad1".format(name) if namelen ==1 else
     "https://search.fdic.gov/search?q="+formatset+"&btnG=Search&output=xml_no_dtd&oe=ISO-8859-1&ie=ISO-8859-1&client=press&proxystylesheet=wwwGOV&wc=200&:%20wc_mc=1&ud=1&wc_mc=1&exclude_apps=1&site=press&ulang=en&ip=10.30.1.36&access=p&entqr=0&entqrm=0&filter=0&sort=date%3AD%3AS%3Ad1").format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
   #root_url = "search.fdic.gov"
    return fdic

#note this is a dynamic ajax site, does not work with scrapy
def occ_search(se):
    namesplit = []
    name = se.entity_fname.strip() if se.entity_lname == '' else se.entity_fname.strip()+' '+se.entity_lname.strip()
    namesplit = name.split()
    safe_dict ={}
    safe_dict['namesplit'] = namesplit
    namelen= len(namesplit)
    formatset = "{}+"*(namelen-1)+"{}"
    occ = str("https://apps.occ.gov/EASearch/?Search={}&Category=&ItemsPerPage=1000&Sort=StartDateDescending&AutoCompleteSelection=".format(name) if namelen ==1 else "https://apps.occ.gov/EASearch/?Search="+formatset+"&Category=&ItemsPerPage=1000&Sort=StartDateDescending&AutoCompleteSelection=").format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
    return occ


