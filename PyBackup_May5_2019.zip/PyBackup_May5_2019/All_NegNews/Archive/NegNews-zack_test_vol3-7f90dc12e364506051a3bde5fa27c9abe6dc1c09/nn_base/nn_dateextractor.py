# -*- coding: utf-8 -*-
"""
Created on Tue Jul 24 12:43:00 2018

@author: qiyi1
"""

import articleDateExtractor
from newspaper import Article
import datetime
#import string
import sys
import waybackpack
import re
from dateparser.search import search_dates
import dateparser

import nltk
from nltk.corpus import stopwords
stops= set(stopwords.words('english'))
stops.add('%')
stops.add('$')
stops.add('A')
import copy
import numpy as np

#extract dates from response object(can be html or the initial parsed text from extract_web_results())
def date_extract(text,datetime_range):
   
    text=text.replace('>',' ').replace('<', ' ').lower()
    ret=search_dates(text,settings={'STRICT_PARSING': True} )
    rett=copy.deepcopy(ret)
    if rett != None:
        for k,v in rett:
            if len(k)<5 or ' ' not in k:
                try:
                    ret.remove((k,v))
                except:
                    pass
            else:
                wl=nltk.tokenize.word_tokenize(k)
                for w in wl:
                    if w in stops:
                        try:
                            ret.remove((k,v))
                        except:
                            pass
            if v<datetime_range[0] or v>datetime_range[1]:
                try:
                    ret.remove((k,v))
                except:
                    pass
        return ret
    else:
        return []
    
def waybackRes(URL = 'www.foodlion.com',FromDate = "--from-date 1999",ToDate= "--to-date 2018"):
    from subprocess import Popen, PIPE
    #command to compile
    cmd = 'waybackpack '+URL+' '+'--list '+ FromDate +' '+ ToDate 
    #execute command from shell 
    p= Popen(cmd, shell=True, stdout=PIPE)
    #read output to python object
    output = p.stdout.read()
    #convert bytes object to string and split on new line delimiter
    waybackresult = str(output).split('\\n')
    #extract the most recent date associated with the URL 
    #MostRecentDate = waybackresult[len(waybackresult)-2]
    #d=re.findall(r'\d+', MostRecentDate)[0]
    LeastRecentDate = waybackresult[0]
    d=re.findall(r'\d+', LeastRecentDate)[0]
    date = datetime.datetime(year=int(d[:4]),month=int(d[4:6]),day=int(d[6:8]),hour=int(d[8:10]),minute=int(d[10:12]),second=int(d[12:14]))
    return(date)

def date_extraction(url,text):
    datetime_range=(datetime.datetime(1999, 1, 1, 3, 6, 7),datetime.datetime(2048, 1, 1, 3, 6, 7))
    res=None
    year_date=None #rough date from url
    wayback_date=None #web estblish date from wayback
    
    #parse url, possible return year/year month/ year month date
    #if only capture year, record and move on
    try:
        m_date = re.search(r'([\./\-_]{0,1}(19|20)\d{2})[\./\-_]{0,1}(([0-3]{0,1}[0-9][\./\-_])|(\w{3,5}[\./\-_]))?([0-3]{0,1}[0-9][\./\-]{0,1})?', url)
        if m_date !=None:
            if len(m_date.group(0))>6:
                print('url extraction return')
                return dateparser.parse(m_date)
            else:
                year_date=dateparser.parse(m_date)
    except:
        pass
    
    #try articleDateExtractor
    try:
        res = articleDateExtractor.extractArticlePublishedDate(url)
        if res!=None:
            print ('articleDateExtractor return')
            return res
    except:
        pass
    
    #try newspaper package
    try:
        article=Article(url)
        article.download()
        article.parse()
        if article.publish_date!=None:
            print ('newspaper return')
            return article.publish_date
    except:
        pass
        
    #try wayback
    #if wayback_date is close enough to url year_date, return wayback_date
    try:
        wayback_date=waybackRes(URL=url)
        if year_date !=None and year_date.year==wayback_date.year: # if year_date is not available, wayback_date need further verification in next step
            print ('wayback return')
            return wayback_date
    except:
        pass
    
    #html dateparser   
    len_dparser=0
    try:
        res=date_extract(text,datetime_range)
        len_dparser=len(res)
        if len_dparser==0:
            if year_date!=None and wayback_date!=None and year_date.year==wayback_date.year:
                print('dtparser wayback return')
                return wayback_date
            else:
                print('dtparser wayback return')
                return year_date
        elif len_dparser==1:
            if year_date !=None and res[0][1].year==year_date.year:
                print ('dparser dp-year return')
                return res[0][1]
            elif wayback_date !=None and res[0][1].year==wayback_date.year:
                print ('dparser dp-wayback return')
                return res[0][1]
            elif wayback_date!=None: # warning: I trust wayback more, but maybe sometimes it is wrong.
                print ('dparser wayback return')
                return wayback_date
            elif year_date!=None:
                print ('dparser year return')
                return year_date
            else:
                return res[0][1] # this step is risky, may be the found date is not publish date at all (may not be relevant to actual date of published) 
            
        else:
            if wayback_date !=None: # warning: I trust wayback more, but maybe sometimes it is wrong.
                diff=[ np.abs(day[1] - wayback_date) for day in res]
                idx=np.argmin(diff)
                #print('diff0',diff[idx])
                if diff[idx]<datetime.timedelta(180):
                #print('idx2',idx)
                    print('dparser multi dp-wayback return')
                    return res[idx][1]
                else:
                    print('dparser multi wayback return')
                    return wayback_date
            elif year_date !=None:
                diff=[ np.abs(day[1] - year_date) for day in res]
                idx=np.argmin(diff)
                #print('diff0',diff[idx])
                if diff[idx]<datetime.timedelta(180):
                #print('idx2',idx)
                    print('dparser multi dp-year return')
                    return res[idx][1]
                else:
                    print('dparser multi year return')
                    return year_date
            
    except:
        pass
    #print(res)
    return None