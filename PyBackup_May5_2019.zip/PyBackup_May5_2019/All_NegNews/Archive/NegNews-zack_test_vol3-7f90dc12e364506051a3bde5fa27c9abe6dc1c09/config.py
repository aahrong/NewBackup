## -*- coding: utf-8 -*-
"""
Created on Tue Feb 13 14:24:37 2018

@author: yangbo
"""
#hello world

"""
NEGATIVE NEWS CONFIGURATION FILE
"""

search_engine = 'BING' #Accept GOOGLE, BING, SECRAWL
translator = 'BING' #Accepts GOOGLE, BING, DEEPL
search_lang = ['english']#,'spanish']#,'spanish','chinese'] #Supported languages: en, es, zh
#config paths must have \\ or / at the end of folders
supported_lang = ['english', 'spanish'] #the languages that are supported in the analysis 
#project_dir = 'C:/NN/negative_news_gitlab/' # - use on Bolun's PC
#project_dir = '/home/docadmin/ZackC/NegNews/' # - use for docadmin
project_dir = '/NNfolder/' # - use for docker
#scraper_dir = project_dir + 'website_scraper_multilang/' #Accepts Links
source_path = project_dir + 'sourcefile/'
working_path =  project_dir + 'workingdir/'
pdf_path = project_dir + 'pdf/'
#pdf_path = '/data/ci/files/'
word_embedding = source_path + 'GoogleNews-vectors-negative300.magnitude'
common_noun = 'common_nouns.txt'
source_excel_file = 'TestList_v3.xlsx'
source_excel_names = 'WFC'#FullList,CoreList
source_excel_tokens = 'Stems'
cache_translatedactive = True
cache_translatedstems = "TranslatedStems.json"
query_picklename = 'Query_Pickle.pk'
BingAPIKey_translate = '9d44b25f4d2d43c9823f2caa53c7097c'
BingAPIKey_search = 'c759653bb84b490ba06cfcd92b2397e4'
#'dc21a3106d8e4968a755888c1944f758'
search_results =500
search_results_output = 50
search_results_maxoutput = 50
max_sent = .2                #max value of sentiment a sentence can have to be included in the results 
LSA_score_filter = 0.00
search_with_location = 0     #include se.location parameter in the search query 
near_filter_distance = 0     #total number of words the first and last name of an individual must be found within (only applicable for individuals not entities)
static_spider = 1            #enables seach of known high risk customer lists available to public
whitelist_search = 1
translate_search_to_english = 0
timeout = 5

entity = 1 #toggle to determine what set of stems are used and how the name is processed in search query (entity = 1 -> searchterms2 used and mulit-word name allowed when searching)
termlist = 1 #toggle to indicate which set of searchterms to use below
searchterms1 =['launder','terrorist','counterfeit','unlawful','indict','evasion','embezzle','sanction','felony','extort','smuggle','fraud','violation','convict','guilty','theft','corrupt','bankrupt','suspect','fugitive','arrest','criminal','bribe','accuse','conspire','allege']
searchterms2 =['launder','terrorist','counterfeit','unlawful','indict','evasion','embezzle','sanction','felony','extort','smuggle','fraud','violation','convict','guilty','theft','corrupt','bankrupt','suspect','fugitive','arrest','criminal','bribe','accuse','conspire','allege']
#searchterms2 = ['scam','patent','unsecured-loans','evasion','embezzle','sanction','felony','extort','smuggle','fraud','violation','convict','launder','terrorist','counterfeit','unlawful','indict','regulation','terrorist','frozen','convicted','compliance','litigation','legal','DOJ','courts','investigation','business_practices','fraud','fine','violation','misleading','pressure','scrutiny','oversight','governing','FED','SEC','PRA','OCC','ECB','SSM','aggressive','tolerance','key_risk_indicator','KRI','run-off','strategy','avoidance','risk-seeking','merger','acquisition','liquidity','funding','line-of-credit','LOC','stress','systemic','crisis','unsecured','obligations','delinquent','overnight','repo','high-quality-liquid-asset','HQLA']

sqlload =0  #=0 indicates we are pulling data from excel file , =1 indicates we are pulling data from sql 
connection_string ='mssql+pyodbc://sqladmin:FinCrimeDEV2017$@adcfincrimeops.database.windows.net:1433/adc-ci?driver=ODBC+Driver+17+for+SQL+Server'
datevar = 'alert_date' #populate only if datevar is present in table 
start_date = '2001-03-12' #start date to pull data from sql (not relevant for excel)
end_date = '2010-01-11' #enddate to stop pulling data from sql(not relevant for excel)
