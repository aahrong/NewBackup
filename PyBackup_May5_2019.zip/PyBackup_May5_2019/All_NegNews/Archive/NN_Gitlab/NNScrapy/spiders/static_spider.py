# -*- coding: utf-8 -*-
"""
Created on Thu Mar  1 12:02:53 2018

@author: queenmi
"""

import sys
import scrapy
from bs4 import BeautifulSoup
import pandas as pd
import nltk
import pickle
import os
import re
import requests
from fake_useragent import UserAgent
import config as config
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage
from io import StringIO
from io import open
from nltk.corpus import stopwords
import spacy

#Create a spider that crawls through all lists of criminals on the whitelist
class StaticSpider(scrapy.Spider):
    name = "static_spider"
    
    custom_settings = {
        'AUTOTHROTTLE_ENABLED': 'True',
        'AUTOTHROTTLE_TARGET_CONCURRENCY': '1.0',
        'DOWNLOAD_DELAY': '2',
        'RANDOMIZE_DOWNLOAD_DELAY': 'True',
        'USER_AGENT': UserAgent().random,
        'ROBOTSTXT_OBEY': 'False',
        'HTTPCACHE_ENABLED': 'False',
        'LOG_LEVEL': 'ERROR',
        'DOWNLOAD_TIMEOUT': '5'
    }
    # Start request for URLs in list
    def start_requests(self):
        
        print(sys.version)
        #Read in URLs from whitelist as dataframe
        cd = config.source_path
        wl_df = pd.read_excel(cd + "Whitelist_Draft v0.7.xlsx",sheet_name = "whitelist",
                          header = 1)
        
        #Filter to URLs and names containing lists that are scrapable and indicators of criminality
        
        wl_filter = wl_df.loc[(wl_df["Structure"] == "List") & (wl_df["Criminal_Lookup"] == "Y") & (wl_df["Scrapy"] == "Y")]
        
        # Get names, urls, and filetypes for all sites        
        wl_urls = wl_filter[["URL"]]
        urls = list(wl_urls.values.flatten())
        wl_names = wl_filter[["Name"]]
        names = list(wl_names.values.flatten())
        wl_ftypes = wl_filter[["File_Type"]]
        ftypes = list(wl_ftypes.values.flatten())            
        
        print(urls)
        # Call the parse methods - If not pdf, use scrapy's parse function. If pdf, use pdf function          
        for url, name, ftype in zip(urls,names,ftypes):
            if ftype != "pdf":
                yield scrapy.Request(url=url, callback=self.parse, meta={'name':name, 'cd':cd})
            else:
                response = requests.get(url)
                site_raw = name
                site = re.sub(r'([^\s\w]|_)+', '', site_raw)
                pdf_filename = config.working_path + 'scraped_sites/%s.pdf' % site 
                #self.log('Processing - ' + site_raw)
                #try:
                with open(pdf_filename, 'wb') as f:
                    f.write(response.content)
                    response.close()                  
                self.pdf_parse(pdf_filename, site, cd)
                #except:
                #    self.logger.error('Error processing ' + site_raw)
    # Extract text from html pages with beautifulsoup, save to disk, and run process_text
    def parse(self, response):
        print('parsing url - {}'.format(response.url))
        site_raw = response.meta['name']
        site = re.sub(r'([^\s\w]|_)+', '', site_raw)
        filename = config.working_path + 'scraped_sites/%s.txt' % site
        soup = BeautifulSoup(response.text,"lxml")
        print(site_raw)
        text = soup.get_text()
#.encode("utf-8")
        with open(filename,'wb') as f:
           f.write(text.encode('utf-8'))
        self.log('Saved file %s' % filename)
        self.process_text(filename)
    
    # Save PDF files and extract text
    def pdf_parse(self, filename, site, cd, delete_raw = 1):
        print('parsing pdf - {}'.format(filename))
        text = self.convert_pdf_to_txt(filename)
        
        # Change file extension to text
        pdf_filename = config.working_path + 'scraped_sites/%s.txt' % site.strip()
        
        #text = self.text.encode("utf-8")
        with open(pdf_filename,'wb') as f:
           f.write(text.encode('utf-8'))
        self.log('Saved file %s' % pdf_filename)
        self.process_text(pdf_filename)
        
        # If delete_raw is activated, delete the pdf file
        if delete_raw == 1:
            os.remove(filename)
    
    # Helper function using pdfminer to extract text from PDF pages
    def convert_pdf_to_txt(self, path):       
        rsrcmgr = PDFResourceManager()
        retstr = StringIO()
        codec = 'utf-8'
        laparams = LAParams()
        device = TextConverter(rsrcmgr, retstr, codec=codec, laparams=laparams)
        fp = open(path, 'rb')
        interpreter = PDFPageInterpreter(rsrcmgr, device)
        password = ""
        maxpages = 0
        caching = False
        pagenos=set()
    
        for page in PDFPage.get_pages(fp, pagenos, maxpages=maxpages, password=password,caching=caching, check_extractable=True):
            interpreter.process_page(page)
    
        self.text = retstr.getvalue()
    
        fp.close()
        device.close()
        retstr.close()
        return self.text  
    
    # Process the scraped text and convert into list of text to be searched
    def process_text(self, text_file, delete_raw = 1):
        print('processing - {}'.format(text_file))
        # text_file = config.working_path + 'test.txt'
        # Read in text file
        with open(text_file,"r",
                  encoding="utf-8") as f:
            raw_text = f.read()
        
        # Tokenize text, convert to lower, remove stopwords and single character tokens
        tokens = nltk.regexp_tokenize(raw_text,r'\w+')
        stops = set(stopwords.words('english'))
        words_lst = [w.lower() for w in tokens if w.isalpha() and not w in stops and len(w) > 1]
        
        # Save list to disk as pickle file
        pkl_path = os.path.splitext(text_file)[0] + "_all.pkl"
        pickle.dump(words_lst,open(pkl_path,"wb"))
        
        # Remove unnecessary data from memory
        raw_text = None
        tokens = None
        stops = None
        
    # We will also do a fuzzy match on only names - Use named entity recognition with spacy to return just people's names.
        #Load Spacy model
        nlp = spacy.load('en')
        
        # Break out into chunks for spacy processing - If word list is > 100000 breakout out into chunks
        batch_size = 1000
        
        def chunks(l, n):
            """Yield successive n-sized chunks from l."""
            for i in range(0, len(l), n):
                yield l[i:i + n]
        
        #If length of list is greater than our batch size, chunk list out and convert each chunk into a string. Process text with spacy
        if len(words_lst)>batch_size:
            batches = list(chunks(words_lst, batch_size))
            word_strings = []
            batch_names = []
            
            # Apply spacy to batches of text
            for i in range(len(batches)): 
                word_strings.append(" ".join(e for e in batches[i]))
                #print(word_strings[i])
                doc = nlp(word_strings[i])
                batch_ner = [(ent.text) for ent in doc.ents if ent.label_ == "PERSON"]
                batch_names.append(batch_ner)
                
            # Create flattened list of unique names in text
            names = list(set([item for sublist in batch_names for item in sublist]))
        
        else:
            word_strings = (" ".join(e for e in words_lst)) #If word length is below limit just convert entire list to string
            doc = nlp(word_strings)
            names = [(ent.text) for ent in doc.ents if ent.label_ == "PERSON"]
        
        # Save list to disk as pickle file
        pkl_path = os.path.splitext(text_file)[0] + "_names.pkl"
        pickle.dump(names,open(pkl_path,"wb"))
        
        # If delete_raw is activated, delete the raw text file
        if delete_raw == 1:
            os.remove(text_file)
        
