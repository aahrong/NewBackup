
#functions to load source data from excel or from sql 
from flask import Flask
from flask import request
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy import text
import os
import pandas as pd
import datetime
from datetime import timedelta
import sys
from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine
import numpy as np
#sql data load
def sqlpulldata(
             connection_string
            , start_date 
            , end_date 
            , datevar 
            , query = "SELECT distinct * from nn_modeling_dataset"
            ):
    
    #create a base class to hold query objects 
    Base = declarative_base()

    #Creating a connections with SQL Server
    connection_string = connection_string
    engine = create_engine(connection_string)
    Base.metadata.bind = engine
    DBSession = sessionmaker(bind = engine)
    session = DBSession()

    #Loading the data from SQL Server table to a dataframe and parsing the date to date format
    if datevar !='':
        df = pd.read_sql(query , con=engine ,parse_dates=[datevar])
    else: 
        df = pd.read_sql(query , con=engine)
    return df 

    
## Import excel file - names and supporting info 
def loadExcel(source_path
            , source_excel_file 
            , source_excel_names):

    with pd.ExcelFile(source_path + source_excel_file) as f:
        names = f.parse(source_excel_names).replace(np.nan, '', regex=True) #loop name, address, country, occupation for each person
    return names 
    