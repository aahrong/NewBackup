# -*- coding: utf-8 -*-
"""
Created on Mon Feb 19 14:36:38 2018

@author: yangbo
"""

import re
from bs4 import BeautifulSoup
from bs4.element import Comment
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
import string
import time
import requests
import config as config
from nn_base.timeout import timeout

#white list custom URL generators 
from nn_base.nn_whitelist_functions import fdic_search
from nn_base.nn_whitelist_functions import colombian_search
from nn_base.nn_whitelist_functions import dockets_search
from nn_base.nn_whitelist_functions import finra_search

def search_on_bing_all(se):
    ## Query bing based on parameters)        
    def search_on_bing(query, count, offset, searchlang):
        subscription_key = config.BingAPIKey_search
        assert subscription_key
        search_url = "https://api.cognitive.microsoft.com/bing/v7.0/search"
        bing_params  = {"q": 'language:'+searchlang[0:2] + ' '+query, "count": count, "offset": offset, "responseFilter":'Webpages'}
        headers = {"Ocp-Apim-Subscription-Key" : subscription_key}
        time.sleep(1)
        bing_response = requests.get(search_url, headers=headers, params = bing_params) #raw bing response output generated here
        bing_response.raise_for_status()
        return bing_response

    ## Parse the results from bing search (convert to json , extract the results from each url)
    def parse_bing_response(bing_response):
        search_results = bing_response.json()        
        try:
            bingquery = search_results['webPages']['webSearchUrl'] #search query used by bing
            url_list = [result['url'] for result in search_results['webPages']['value']] #the url found from search and all other response object informaiton 
        except:
            url_list = []
            bingquery = 'https://www.bing.com/search?q=' + search_results['queryContext']['originalQuery']
            print("Error getting results from bing")
        return url_list, bingquery    
    
    all_links = []
    all_url_list = []
    all_bingquery = []

    #execute the search query genrated above
    for idx in range(0, se.search_lang_ct):
        searchquery = se.entity_querylist[idx] #this is the actual search query executed for the entity 
        if searchquery == []:
            links = []
            url_list = []
            bingquery = []
        else:
            #for the first URL we extract the top 50 results (or value specified by config.search_results)
            search_offset = 0
            #search_offset : the number of initial results to skip before returning data(starts as 0 and increments of 50 until offset>=search_results)
            bing_response = search_on_bing(searchquery, config.search_results, search_offset, se.search_lang_short[idx])
            url_list, bingquery = parse_bing_response(bing_response) #extract the raw response object from bing result
            if len(url_list) == 0:
                print("No Results for searching {} {} in {}".format(se.entity_fname, se.entity_lname, se.search_lang[idx]))
           
            else:
                #for each subsequent iteration of extracting results, enumerate offset in iterations of min(50,config.search_results)
                searchcount=2
                while len(url_list) < config.search_results and searchcount<20:
                    searchcount = searchcount + 1
                    search_offset = search_offset + min(50,config.search_results)
                    bing_response = search_on_bing(searchquery, config.search_results, search_offset, se.search_lang_short[idx])
                    url_list2, _ = parse_bing_response(bing_response)
                    if len(url_list2)==0:
                        print("Cannot find more than {} results after {} searches".format(config.search_results, searchcount))
                        searchcount = 19
                    else:
                       url_list.extend(url_list2)
            items = ['.pdf','.doc', '.csv', '.docx', '.xls', '.xlsx', '.png', '.jpeg', 
                 '.jpg','.gif','.xml', '.json', '.gz', '.zip', 'ppt','.pptx', '.xlsm','.xlsb', '.txt']
    #        blacklist = ['books.google','linkedin.com', 'imdb.com', 'facebook.com', 'pinterest.com', 
    #                 'instagram.com', 'twitter.com', 'youtube.com', 'instantcheckmate', 'webmd.com', 
    #                 'intelius', 'whitepages.com', 'scholar.google', 'nih.gov', 'springer','mylife',
    #                 'alumnius.net', 'peekyou.com', 'amazon.com', 'arxiv.org', 'zoominfo.com', 'quicksearch.in',
    #                 'peoplefinders.com', 'spokeo.com', 'ussearch.com', 'usa-people-search.com', 
    #                 'privateeye.com', 'intelius.com', 'zabasearch.com', 'peoplelookup.com', 'quizlet.com', 'flickr.com']
    #        items = items+ blacklist
            links = url_list
            for i in items:
                links = [link for link in links if i not in link.lower()]
            links = links[0:config.search_results]
        all_links.append(links)
        all_url_list.append(url_list)
        all_bingquery.append(bingquery)
    return all_links, all_url_list, all_bingquery       
        

def extract_google_results(response):
    links=[]
    for b in response.xpath('//h3/a/@href').extract():
        if "/aclk?sa=" not in b and "/search?q=" not in b:
            if "/url?q=" in b:
                links.append(re.search('q=(.*)&sa',b).group(1))
            elif "/url?url=" in b:
                links.append(re.search('url=(.*)&rct',b).group(1))
            else:
                links.append(b)                   
    items = ['.pdf','.doc', '.csv', '.docx', '.xls', '.xlsx', '.png', '.jpeg', 
         '.jpg','.gif','.xml', '.json', '.gz', '.zip', 'ppt','.pptx', '.xlsm','.xlsb', '.txt']
    blacklist = ['books.google','linkedin.com', 'imdb.com', 'facebook.com', 'pinterest.com', 
             'instagram.com', 'twitter.com', 'youtube.com', 'instantcheckmate', 'webmd.com', 
             'intelius', 'whitepages.com', 'scholar.google', 'nih.gov', 'springer','mylife',
             'alumnius.net', 'peekyou.com', 'amazon.com', 'arxiv.org', 'zoominfo.com', 'quicksearch.in']
    items = items+ blacklist
    links_returned_search = len(links)
    for i in items:
        links = [link for link in links if i not in link.lower()]
    print("{} links were removed from the pages searched. " .format(links_returned_search-len(links)))
    print("{} links were left." .format(len(links)))
    print(links)
    return links, len(links), links_returned_search


@timeout(config.timeout)
#WARNING: ZACK CHANGED regex_name FROM {}|{} to {}{} to enable correcet procesing of multi word entity names 
def window_search_regex(text, fname, lname,entity):
    try:
        if entity==1:
            regex_name = ('{}{}'.format(fname, lname)).lower().strip()
        else:
            regex_name = ('{}|{}'.format(fname, lname)).lower().strip()

        text_for_regex = 'the. ' + text + ' the. the.' 
        extracted_text_list =[]
        p = re.compile(r'(([^\.]*\.){1}[^\.]*(' + regex_name + r')[^\.]*\.([^\.]*\.){2})',re.IGNORECASE)
        for name_i in p.findall(text_for_regex,re.IGNORECASE):
            extracted_text_list.append(name_i[0])
        extracted_text_list = list(set(extracted_text_list))
        extracted_text_list = [x[0:2000] for x in extracted_text_list if 10 <= len(x) <= 2000]
        extracted_text = '<!@&>'.join(extracted_text_list)
        return extracted_text
    except:
        return ''

#This is where we parse the actual text form the resposne obejct, apply the window function, and incorporate the custom delimiter 
#which is defined in window_search_regex
def extract_web_results(responsetext, fname, lname,entity):
    @timeout(config.timeout)
    def text_from_html(htmltext, parser):
        def tag_visible(element):
            if element.parent.name in ['style', 'script', 'head', 'title', 'meta', '[document]']:
                return False
            if isinstance(element, Comment):
                return False
            return True
        try:
            soup = BeautifulSoup(htmltext, parser)
            texts = soup.findAll(text=True)
            visible_texts = filter(tag_visible, texts)  
            return u" ".join(t.strip() for t in visible_texts)
        except:
            return ''
    
    #clean raw htm text slightly to enable effective windowing 
    text = text_from_html(responsetext, "html") #text to process and manipulate 
    text = text.strip()
    text = re.sub("\.{2,}" , ".",text)
    #text = re.sub(' +',' ',text)
        
    #apply windowing critera
    extracted_text = window_search_regex(text, fname, lname, entity)    #extract relevant text from URL (and convert to lwoer)
    
    ## Now try with lxml parser, if extracted text is blank
    if extracted_text == '':
        text = text_from_html(responsetext,"lxml")
        text = text.strip()
        text = re.sub("\.{2,}" , ".",text)
        #text = re.sub(' +',' ',text)
        extracted_text = window_search_regex(text, fname, lname,entity)
    return extracted_text
    #except:
    #    return ''

#WARNING: Zack C updated this to account for multi-word entity names (line 183)
def generate_search_query(name, slist, entity, common_nouns=[], location=''):
    namelist = name.split()
    qlist = list(map(lambda x: '('+' OR '.join(x)+')',slist))
    #if the name has common nouns or the name is refering to an entity then require all part of the name to be a single string instead of 2 (this ensures entities with multi word names are processed correct)
    if (len(set(namelist).intersection(set(common_nouns)))>0 or entity==1) or (len(set(namelist).intersection(set(common_nouns)))>0 and entity==1):
        namepart = '("' + ' '.join(namelist) + '")'
    else:
        namepart = '(' + ' '.join(list(map(lambda x: '"' + x + '"', namelist))) + ')'
    locpart = '({}) '.format(' '.join([x for x in location if x != '']))
    if locpart == '() ': locpart = ''
    if config.search_with_location != 1: locpart = ''
    query = [namepart + locpart + q for q in qlist]
    return query

def add_black_list(querylist):
    blacklist = '-cardiac -site:books.google -site:linkedin.com -site:imdb.com -site:facebook.com -site:pinterest.com -site:instagram.com -site:twitter.com -site:youtube.com -site:instantcheckmate -site:webmd.com -site:intelius -site:whitepages.com -site:scholar.google -site:nih.gov -site:springer -site:mylife -site:alumnius.net -site:peekyou.com -site:amazon.com -site:arxiv.org -site:zoominfo.com -site:quicksearch.in -site:peoplefinders.com -site:spokeo.com -site:ussearch.com -site:usa-people-search.com -site:privateeye.com -site:intelius.com -site:zabasearch.com -site:peoplelookup.com -site:quizlet.com -site:flickr.com'
    newquerylist = [x + ' ' + blacklist for x in querylist]
    return newquerylist


#  identify_whitelist: search_entity(se) -> list (whitelist)
#  Function consumes a search_entity item relating to a person or business and returns
#   a list of URL that relates to the search entity coming from white list
#   whitelist will be used by scrapy to ensure these sites are always searched
def identify_whitelist(se):
    whitelist = []
    
    fdic = fdic_search(se)
    colombian=colombian_search(se)
    dockets=dockets_search(se)
    finra=finra_search(se)

    whitelist.append("https://occ.gov/news-issuances/alerts/2018/index-2018-alerts.html")
    whitelist.append("https://www.federalreserve.gov/feeds/press_all.xml")

    whitelist.append(fdic)
    whitelist.append(colombian)
    whitelist.append(dockets)
    whitelist.append(finra)
    
    # Justia.com
    #whitelist.append("https://dockets.justia.com/search?parties={}+{}&cases=mostrecent".format(se.entity_fname, se.entity_lname))
    # Wikipedia
    #whitelist.append("https://en.wikipedia.org/wiki/{}_{}".format(se.entity_fname, se.entity_lname))
    # Colombian District Attorney website
    #whitelist.append("https://www.fiscalia.gov.co/colombia/?s={}+{}".format(se.entity_fname, se.entity_lname))
    # REVISIT: BRB Publications (powered by Intelius) --> on blacklist
    #whitelist.append("https://www.intelius.com/people-search/{}-{}/{}".format(se.entity_fname, se.entity_lname, se.entity_state))
    # REVISIT: Whitepages --> on blacklist
    #whitelist.append("https://www.whitepages.com/name/{}-{}".format(se.entity_fname, se.entity_lname))   
    return whitelist

