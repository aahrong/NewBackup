# -*- coding: utf-8 -*-
"""
Created on Wed Feb 14 16:26:52 2018

@author: yangbo
"""
#import os
#scraper_dir = 'C:\\Users\\yangbo\\Documents\\Engagements\\04 INTAML\\Negative_News\\'
#os.chdir(scraper_dir)

from flask import Flask, request
import sys
import time
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
#import subprocess

import pandas as pd
#import numpy as np
import nn_base.nn_config as config
#from nn_base.nn_classes import search_entity as SE
#from website_scraper.website_scraper.spiders.spider_webscraper_google_v1 import webScrap_google
#from website_scraper.website_scraper.spiders.spider_webscraper_bing_v1 import webScrap_bing
from nn_base.nn_query_generator_v2_single import query_generation_single
from nn_base.nn_namefinder import static_search_setup
from nn_base.nn_namefinder import static_search_name
from scrapyd_api import ScrapydAPI

#subprocess.Popen('scrapyd')
app = Flask(__name__)
app.config["APPLICATION_ROOT"] = os.environ.get('SERVER_CONTEXT_PATH', '/')
APPLICATION_ROOT = os.environ.get('SERVER_CONTEXT_PATH', '/')

@app.route(APPLICATION_ROOT)
def main():
    return "Main Page - Negative News Flask server is up and running \n https://sentinel.eastus.cloudapp.azure.com/ci/negnews/dev/single?fname=_____&lname=_____\n"

@app.route(APPLICATION_ROOT + "single")
def negative_news_single():
    fname = request.args.get('fname', default='', type=str)
    lname = request.args.get('lname', default='', type=str)
    city = request.args.get('city', default='', type=str)
    state = request.args.get('state', default='', type=str)
    company = request.args.get('company', default='', type=str)
    occupation = request.args.get('occupation', default='', type=str)




    print(fname)
    print(lname)
    file = query_generation_single(fname=fname,lname=lname, city=city, state=state,company=company,occupation=occupation)
    #file = pd.read_pickle(config.working_path + config.query_picklename)
    sites_all, sites_names = static_search_setup()



    scrapyd = ScrapydAPI('http://localhost:6800')
    print(scrapyd.list_spiders('default'))


    i = 20 
    for idx, val in file.iterrows():
        if idx < 20:
            jobid = str(idx) + '_' + val.FirstName + '_' + val.LastName + '_' + time.strftime("%Y-%m-%d-%H-%M-%S")
            static_result = static_search_name(0,val.FirstName, val.LastName, sites_all, sites_names)
            scrapyd.schedule('default','webScrape_bing_v3',jobid=jobid, i=str(idx), static_result = static_result)
            print('starting job  - '  + jobid)
            time.sleep(1)
            #break
       # break
            i = i - 1
            if i == 0:
                break
    return "{} {} was sent to negative news engine \n The scrapyd log can be accessed (exec into the container) at: \n http://localhost:6800/logs/default/webScrape_bing_v3/{}.log \n".format(fname, lname, jobid)

if __name__=="__main__":
    #subprocess.Popen(['scrapyd'])
    app.run(host='0.0.0.0',debug=True)
