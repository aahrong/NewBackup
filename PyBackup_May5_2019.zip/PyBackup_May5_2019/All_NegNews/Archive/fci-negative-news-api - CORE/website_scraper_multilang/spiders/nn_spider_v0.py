# -*- coding: utf-8 -*-
"""
Created on Wed Feb 14 16:29:33 2018

@author: yangbo
"""
import numpy as np
import pandas as pd
import pickle
import os
import time
import re
#from nn_base.nn_webprocess import extract_bing_results
from nn_base.nn_webprocess import extract_web_results
from nn_base.nn_webprocess import search_on_bing_all
from nn_base.nn_webprocess import identify_whitelist
from nn_base.nn_textprocess import force_near_filter
from nn_base.nn_textprocess import entity_match_score
from nn_base.nn_textprocess import entity_stem_match
from nn_base.nn_textprocess import clean_paragraph
from nn_base.nn_textprocess import LSA_function
from nn_base.nn_textprocess import normalize_LSA
from nn_base.nn_textprocess import rerank_searchresults
from nn_base.nn_textprocess import summary_scores
from nn_base.nn_classes import search_entity as SE
from nn_base.nn_translate import langname_to_iso639
import nn_base.nn_config as config
import scrapy
from fake_useragent import UserAgent
from nn_base.nn_pdf import create_empty_page
from nn_base.nn_pdf import create_nn_page
from nn_base.nn_pdf import create_pdf_summary
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter

import html

class webScrap_bing(scrapy.Spider):  

	#name of spyder
    name='webScrape_bing_v3'    
    
	#settings to control how scrapy scrapes data 
    custom_settings = {
        'AUTOTHROTTLE_ENABLED': 'True',
        'AUTOTHROTTLE_TARGET_CONCURRENCY': '1.0',
        'DOWNLOAD_DELAY': '2',
        'RANDOMIZE_DOWNLOAD_DELAY': 'True',
        'USER_AGENT': UserAgent().random,
        'ROBOTSTXT_OBEY': 'False',
        'HTTPCACHE_ENABLED': 'False',
        'LOG_LEVEL': 'INFO',
        'DOWNLOAD_TIMEOUT': '10'
    }
	
	#step 1: Iniatlize search entity object 
    def __init__(self, i, **kwargs):
        #Read the pickle file containing full processing list
        print('initializing spiders')
        file = pd.read_pickle(config.working_path + config.query_picklename)
        #Selecting ONLY the name of interest based on argument i
        val = file.ix[int(i)]
        #Construct SearchEntity Object
        self.se = SE(search_lang = config.search_lang, searchid = val.id, fname = val.FirstName, lname=val.LastName, mname=val.MiddleName, 
            city=val.City, state=val.State, state2 = val.State_2, country=val.Country,
            occupation=val.Occupation, company=val.Company, company2=val.Company_2,
            querylist = val.query_list, searchtermlist = val.searchterm_list)     
        self.se.search_lang_short = list(map(langname_to_iso639, self.se.search_lang))
        self.index = i
        self.kwargs = kwargs
    
    #step 2: search on bing for each search entity object, returns a list of links and the bing object itself 
	def start_requests(self):
        print('spider start on {} {}'.format(self.se.entity_fname,self.se.entity_lname))
        #Search on Bing (bingquery returns the searchresult page)
        links, _ , bingquery = search_on_bing_all(self.se)
        self.se.querylisturl = bingquery
        #Loop through each link returned by Bing - call secondary_scrape
       	out = ''.join(['{}:{}'.format(x,len(y)) for (x,y) in zip(self.se.search_lang, links)])
        print('Bing Search Completed on {} Languages: {}'.format(len(self.se.search_lang),out))

        for lang_idx, lang in enumerate(links):
            #Added 2018/03/19 per Rocky's email - adds static whitelist item to english search
            if self.se.search_lang[lang_idx] == 'english':
                whitelist = identify_whitelist(self.se)
                lang.extend(whitelist)
            for url in lang:
		
				#callback is the response object that is fed to secondary_scrape
                yield scrapy.Request(url, callback=self.secondary_scrape, meta={'lang_idx':lang_idx})    
				
	#called / run once for each URL associated with the search entity 
    def secondary_scrape(self,response):
        lang_idx = response.meta.get('lang_idx')
		
		#return the URL and the content in the URL 
        url, text = extract_web_results(response, self.se.entity_fname, self.se.entity_lname)
        
		#Force a near filter on the results - blank out any websites that do not contain Firstname within x words away from Lastname
        #append the results to the original se object to keep track of all original text 
		self.se.origtextlist[lang_idx] = self.se.origtextlist[lang_idx] + [text]
		#force text to contain (at least in one place) the first and last name of the individual seperated by at most 3 characters/words
        text = force_near_filter(text, self.se.entity_fname, self.se.entity_lname, config.near_filter_distance)
		#text pre-processing
        text = clean_paragraph(text, self.se.search_lang[lang_idx])            
        
		#if the pre-processing does not filter out all results, that means its of interst, we save it, and calculate a match score 
		#indicating how relevant the text is to the person that we are searching for 
        if text != '':
            self.se.urllist[lang_idx] = self.se.urllist[lang_idx] + [url]
            self.se.textlist[lang_idx] = self.se.textlist[lang_idx] + [text]
            scores=entity_match_score(text,self.se, lang_idx)
            stemmatch=entity_stem_match(text,self.se, lang_idx)
			
            #Attributes about matching
            self.se.list_fuzzyscore[lang_idx] = self.se.list_fuzzyscore[lang_idx] + [np.mean([x for x in scores if x > 0])]
            self.se.list_fuzzyscoredetail[lang_idx] = self.se.list_fuzzyscoredetail[lang_idx] + [scores]
            self.se.list_matchedstems[lang_idx] = self.se.list_matchedstems[lang_idx] + [stemmatch]
            print('scrapping completed on url - {}'.format(url))

#once we get a reponse from a website, we parse it , and keep ttrack of the URL and text throughout the process 
#closed function is called once all scrapy requests have been completed (called 1 time per search entity) , including secondary scrape 
    def closed(self, reason):
        for idx, text in enumerate(self.se.textlist):
            if text == []: self.se.urllist[idx]=[]

        #joining the search results to the se.search argument
        #stores the lanuage and total URLS looked at (x,len(y))
        searchresults = ' '.join(['{}:{}'.format(x,len(y)) for (x,y) in zip(self.se.search_lang, self.se.urllist)])
        print('Searched {} languages total. The results are: {}'.format(self.se.search_lang_ct, searchresults))     
        print(self.kwargs)
        
        #for static spyder results 
        if self.kwargs is not None:
            if 'static_result' in self.kwargs.keys(): 
                #print('static_result is:' + self.kwargs['static_result'])
                static_result = self.kwargs['static_result']

                #if static search foud something, and we explicitly asked to get results for static files, then create a new record for static match 
                if static_result == '0' and config.static_spider == 1:
                    static_match_path = config.working_path + "static_matches/" + '{}_{}_{}'.format(self.index, self.se.entity_fname, self.se.entity_lname)
                    #print(static_match_path)
                    self.se.static_search_result = pickle.load(open(static_match_path+'.pkl', 'rb'))       
                    #print(static_match_path)

        #if self.se.static_search_result != '': 
        #    print(self.se.static_search_result)
        #else:
        #    print('static search not found or not enabled')
        
        print('exporting results')
        pickle.dump(self.se, open(config.working_path + self.se.entity_fname + ' ' + self.se.entity_lname+ ' ' + time.strftime("%m-%d-%Y") + '.pk', 'wb'))
        
        #takes results, computes LSA score, Ranks them, and summarizes the results 
        #takes search entity object and retunrs the object with an additional vairables LSA SCORE
        self.se = LSA_function(self.se) #looks at the links returned , computes an LSA score on them, and sends them back. LSA score represents how important the informaiton is 
        self.se = rerank_searchresults(self.se, config.LSA_score_filter) #reranks the links based on the LSA scores 
        self.se = summary_scores(self.se, config.search_results) #takes the calculated scores and sets up the information that will be seen in the final pdf 

        #takes the search entity data stored in se and creates a pdf
        fname, failed = create_pdf_summary(self.se)
        print('PDF file stored at - {}'.format(os.path.basename(fname)))
        for x in failed:
            print('PDF creation failed on language - {}'.format(x))

        #create jason file that has all the search entity data 
        jsonname = os.path.splitext(fname)[0]+'.json'
        dataout = self.se.to_json(jsonname)
        if dataout == 0: 
            print('Data saved at {}'.format(os.path.basename(jsonname)))
        else: 
            print('Data Not Saved')
        #pickle.dump(self.se, open(config.working_path + self.se.entity_fname + ' ' + self.se.entity_lname+ ' ' + time.strftime("%m-%d-%Y") + '.pk', 'wb'))
            
#        print("there are {} number of links in final url".format(len(self.se.urllist)))
#        if len(self.se.urllist)==0:
#            create_empty_page(self.se)
#        else:
#            ## Get the LSA score for all the links and sort
#            self.se.LSA_score = LSA_function(self.se)
#            ## Getting how many links have LSA > 0.01
#            max_links_for_score = len([a for a in self.se.LSA_score if a >= 0.01])
#            if max_links_for_score == 0:
#                create_empty_page(self.se)
#            else:
#                self.se = rerank_searchresults(self.se)
#                self.se = summary_scores(self.se, config.search_results)
#                x = create_nn_page(self.se)
#                if x == 0:
#                    print("PDF Successfully completed")
#                else:
#                    print("Error encountered during one of the steps")
#                yield scrapy.http.Request('www.bing.com', callback=self.next_request)
                
##                
##
#import sys
#sys.path.insert(0, 'C:\\Users\\yangbo\\Documents\\Engagements\\04 INTAML\\Negative_News\\Negativenews\\website_scraper_multilang\\')
##
#import pandas as pd
#import numpy as np
#import nn_base.nn_config as config
#from scrapy.crawler import CrawlerRunner
#from scrapy import log
##
#from crochet import setup
#setup()
#crawler = CrawlerRunner()
#spider = webScrap_bing(i=6)
#crawler.crawl(spider,i=6) 
###    
#input('Press ENTER to exit')
#
##se = pickle.load(open(config.working_path + 'Sameer Gupta 03-14-2018.pk','rb'))
