# -*- coding: utf-8 -*-
"""
Created on Wed Feb 14 16:26:52 2018

@author: yangbo
"""
#import os
#scraper_dir = 'C:\\Users\\yangbo\\Documents\\Engagements\\04 INTAML\\Negative_News\\'
#os.chdir(scraper_dir)


import sys
import time
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pandas as pd
#import numpy as np
import nn_base.nn_config as config
#from nn_base.nn_classes import search_entity as SE
#from website_scraper.website_scraper.spiders.spider_webscraper_google_v1 import webScrap_google
#from website_scraper.website_scraper.spiders.spider_webscraper_bing_v1 import webScrap_bing
from nn_base.nn_query_generator_v2_single import query_generation_single
from nn_base.nn_namefinder import static_search_setup
from nn_base.nn_namefinder import static_search_name


"""
MAIN CODE: OUTLINE
1) Query generation: craft query based on an input list (nn_config.py). This includes options below:
    - multiple search engine (Google, Bing)
    - multiple languages (translation via google / deepl)
    - additional search criteria support

2) Main Query: Call search engine specified and retrieve url list of interest

3) For each person searched, perform the following:
    1) call a spider to crawl all of the websites on the url list
    2) for each website returned, extract the texts
    
4) Once all texts are returned, filter and rank the pages

5) Once filtered / ranked, produce output

"""
file = query_generation_single(fname=sys.argv[1],lname=sys.argv[2])
#file = pd.read_pickle(config.working_path + config.query_picklename)
sites_all, sites_names = static_search_setup()


from scrapyd_api import ScrapydAPI
scrapyd = ScrapydAPI('http://localhost:6800')
print(scrapyd.list_spiders('default'))

# #scrapyd.schedule('default', 'web_scraper', query="hello world", sr='2')
# #
# #egg = open('C:\\Users\\yangbo\\Documents\\Engagements\\04 INTAML\\Negative_News\\Negativenews\\nn_scrape\\nnscrape_2.1.egg', 'rb')
# #scrapyd.add_version('nn_scrape', '2.1', egg)
# #egg.close()
# #scrapyd.list_spiders('nn_scrape')
# 
# #scrapyd.schedule('default', 'webScrape_bing', jobid='hellotest', i='1')
# # 
i = 20 
for idx, val in file.iterrows():
    if idx < 20:
        jobid = str(idx) + '_' + val.FirstName + '_' + val.LastName + '_' + time.strftime("%Y-%m-%d-%H-%M-%S")
        static_result = static_search_name(0,val.FirstName, val.LastName, sites_all, sites_names)
        scrapyd.schedule('default','webScrape_bing_v3',jobid=jobid, i=str(idx), static_result = static_result)
        print('starting job  - '  + jobid)
        time.sleep(1)
        #break
   # break
        i = i - 1
        if i == 0:
            break
# for idx, val in file.iterrows():
#     jobid = str(idx) + '_' + val.FirstName + '_' + val.LastName
#     scrapyd.cancel('nn_scrape',jobid)
# #    time.sleep(1)
# #    
#     
# file = pd.read_pickle(config.working_path + config.query_picklename)
