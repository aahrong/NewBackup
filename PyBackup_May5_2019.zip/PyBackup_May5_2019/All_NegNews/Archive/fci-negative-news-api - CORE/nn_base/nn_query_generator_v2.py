# -*- coding: utf-8 -*-
"""
Created on Mon Feb 12 16:30:06 2018
NEGATIVE NEWS ENGINE - ADAPTED FROM NN SCRAPY IMPLEMENTATION BY ASODHI
@author: yangbo
"""


""" TO DELETE"""
#from importlib import reload

#reload(config)


"""
PART 1: LOADING LIBRARIES

"""

#general



#import os
import sys
import pandas as pd
import numpy as np
import csv

#import pdb

#scraper_dir = 'C:\\Users\\yangbo\\Documents\\Engagements\\04 INTAML\\Negative_News\\'
#os.chdir(scraper_dir)

#load config file (contains all the inputs required to execute the process)
if 'config' in sys.modules:
    from importlib import reload
    reload(config)
else:
    import nn_base.nn_config as config

#import module to translate english to anything (or injest non english results)
import nn_base.nn_translate as translate

"""
PART 3: HELPER FUNCTIONS
"""


def generate_search_query(row, slist, engine, common_nouns):
    #create list of search terms 
    qlist = list(map(lambda x: '('+' OR '.join(x)+')',slist))
    if engine == 'GOOGLE':
        #create query to search for first and last name 
        if row.FirstName.lower() in common_nouns or row.LastName.lower() in common_nouns:
            namepart = '("{} {}") '.format(row.FirstName, row.LastName)
            locpart = '({}) '.format(' '.join([x for x in [row.City] if x != '']))
            query = [namepart + locpart + q for q in qlist]
        else:
            namepart = '("{}" AROUND(1) "{}") '.format(row.FirstName, row.LastName)
            locpart = '({}) '.format(' '.join([x for x in [row.City] if x != '']))
            query = [namepart + locpart + q for q in qlist]
    elif engine == 'BING':
        namepart = '("{}" "{}") '.format(row.FirstName, row.LastName)
        locpart = '({}) '.format(' '.join([x for x in [row.City] if x != '']))
        if locpart == '() ': locpart = ''
        if config.search_with_location != 1: locpart = ''
        query = [namepart + locpart + q for q in qlist]
    else:
        print('{} is currently not a supported search engine'.format(engine))
        query = []
    return query

def add_black_list(querylist):
    blacklist = '-cardiac -site:books.google -site:linkedin.com -site:imdb.com -site:facebook.com -site:pinterest.com -site:instagram.com -site:twitter.com -site:youtube.com -site:instantcheckmate -site:webmd.com -site:intelius -site:whitepages.com -site:scholar.google -site:nih.gov -site:springer -site:mylife -site:alumnius.net -site:peekyou.com -site:amazon.com -site:arxiv.org -site:zoominfo.com -site:quicksearch.in -site:peoplefinders.com -site:spokeo.com -site:ussearch.com -site:usa-people-search.com -site:privateeye.com -site:intelius.com -site:zabasearch.com -site:peoplelookup.com -site:quizlet.com -site:flickr.com'
    newquerylist = [x + ' ' + blacklist for x in querylist]
    return newquerylist
    
def query_generation():
    status = 'Start'
    try:
        status = 'Reading Common Nouns'
        ## read common nouns
        with open(config.source_path + config.common_noun) as f:  #1500 words
            reader = csv.reader(f, delimiter="\t")
            d = list(reader)
        common_nouns=[x[0].lower() for x in d]
        
        
        ## Import excel file - names and search terms
        status = 'Loading Excel File'
        with pd.ExcelFile(config.source_path + config.source_excel_file) as f:
            searchterms = list(f.parse(config.source_excel_tokens).iloc[:,0])
            names = f.parse(config.source_excel_names).replace(np.nan, '', regex=True) #loop name, address, country, occupation for each person
        

        ## Translate Search Terms
        status = 'Building and Translating Search Terms'
        searchterms_list = []
        translated_lang = []
        for lang in config.search_lang:
            if lang == 'en' or lang == 'english':
                searchterms_list.append(searchterms)
                translated_lang.append(lang)
            else:
                try:
                    searchterms_list.append(translate.translate_list(searchterms,lang,config.translator))
                    translated_lang.append(lang)
                except:
                    translated_lang.append([])
                    print('error loading language - {}'.format(lang))
        
        status = 'Adding Names and Locations to Query'
        #Convert search terms to a list for query
        names['query_list'] = names.apply(generate_search_query, args = (searchterms_list,config.search_engine, common_nouns), axis=1)
        names['searchterm_list'] = names.apply(lambda x: searchterms_list, axis=1)
        
        #Adding in blacklisted items
        if config.search_engine == 'BING':
            status = 'Adding Blacklist to Bing'
            names['query_list'] = names['query_list'].apply(add_black_list)
        
        
        #output for now so .bat version still runs - TO BE CHANGED
        status = 'Making Pickle Object'
        #query_list_lang1 = [x[0] for x in names.query_list]
        #query_list_lang2 = [x[1] for x in names.query_list]
        #df_out = pd.DataFrame({'query':query_list_lang1, 'sr_no':range(0,len(query_list_lang1)), 'query2':query_list_lang2})
        #df_out.to_csv(config.scraper_dir + '/test_comp.csv', header= False, index=False)
        names.to_pickle(config.working_path + config.query_picklename)
        print("Query Successfully Generated")
        #print(names)
        return names
        
    except:
        print("ERROR WITH QUERY GENERATION ON STEP - {}".format(status))
        return False


 

#1: Query Generation
#df_query_pop = query_generation()

