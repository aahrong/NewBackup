# -*- coding: utf-8 -*-
"""
Created on Tue Feb 20 12:59:41 2018

@author: yangbo
"""
from nn_base.nn_classes import search_entity as SE
from nltk.corpus import stopwords
import nltk
from nltk.stem.snowball import SnowballStemmer
from gensim import corpora, models, similarities
import string
import re
from fuzzywuzzy import fuzz
import numpy as np
import operator

from nn_base import nn_config as config
from itertools import chain
from scipy import spatial
from sklearn import preprocessing

## remove punctuation, lower, remove stop words, porter stemming
def clean_paragraph(content, lang, stemming=True, sent_tokenize=False):
    if lang in SnowballStemmer.languages:
        stop = set(stopwords.words(lang))
        stemmer = SnowballStemmer(lang)
    else:
        stop = set(stopwords.words('english'))
        stemmer = SnowballStemmer('english')
    # puncremove = str.maketrans(string.punctuation,' '*len(string.punctuation))  
    def clean_text(text):
        if sent_tokenize == True:
            sent_tokens = nltk.sent_tokenize(text)
            tokens = [nltk.regexp_tokenize(sentence, r'\w+') for sentence in sent_tokens]
            rettext = []
            for sent in tokens:
                rettext.append([w.lower() for w in sent if w.isalpha() and not w in stop and len(w) > 1])
        else:
            for punc in string.punctuation:
                text = text.replace(punc, '')
            rettext = [x for x in text.lower().split() if (x != '' and x not in stop)]
            if stemming==True:
                rettext = [stemmer.stem(x) for x in rettext]
            rettext = ' '.join(rettext)
        return rettext
    if type(content) is list:
        out = [clean_text(x) for x in content]
    else:
        out = clean_text(content)
    return out
    
#require that the first name and last name be near each other in the search results 
#this is used to identify all articles that do not contian the first and last name of the individual and seperated by at most n words. 
#if name is not found, make the text string blank, otherwise do nothing
def force_near_filter(text, fname, lname, distance):
    string = r'\b(?:{}\W+(?:\w+\W+){{0,{}}}?{}|{}\W+(?:\w+\W+){{0,{}}}?{})\b'.format(fname.lower(),distance, lname.lower(),lname.lower(), distance, fname.lower())
    nearnames = re.findall(string, text.lower())
    if nearnames == []:text = ''
    return text

#various methods for aggregating match similarities / restuls 
def entity_match_score(text, se, lang_idx):
    namelist = clean_paragraph([se.entity_fname, se.entity_lname, se.entity_mname], se.search_lang[lang_idx])
    loclist = clean_paragraph([se.entity_city, se.entity_state, se.entity_state2, se.entity_country], se.search_lang[lang_idx])
    emplist = clean_paragraph([se.entity_occupation, se.entity_company, se.entity_company2], se.search_lang[lang_idx])

    namescore = list(map(lambda x: fuzz.partial_token_set_ratio(text, x), [x for x in namelist if x != '']))
    locscore = list(map(lambda x: fuzz.partial_ratio(text, x),  [x for x in loclist if x != '']))
    empscore = list(map(lambda x: fuzz.partial_ratio(text, x), [x for x in emplist if x != '']))
    
    score_name = int(np.mean(namescore))
    score_city = max(locscore) if len(locscore)>0 else 0
    score_occupation = max(empscore) if len(empscore)>0 else 0
    return (score_name,score_city,score_occupation)

#function to identify what keywords match in each article 
def entity_stem_match(text, se, lang_idx):
    searchstem = clean_paragraph(se.searchtermlist[lang_idx], se.search_lang[lang_idx])
    foundlist = list(map(lambda x: x in text, searchstem))
    matched_stem = [term for term,found in zip(se.searchtermlist[lang_idx],foundlist) if found==True]   
    return matched_stem

#estimate how risky an individual is relative to the total links scraped 
#intention: map the individuals searched so irrelevant individuals have normalized score of 0 , to someone super relevant > .77
#need to refit. 
def normalize_LSA(sum_score1, tot_links):
    lsa_sum = (sum_score1/tot_links)*100
    a = 0.342419512682912
    b = 1.19480978536808
    c = 0.211456297918287
    d = 0.779544742969885
    percent_risk = max(0,c + d*np.tanh((lsa_sum-a)/b))
    return(percent_risk*100)
    

## defining function to order webpages using LSA
#input: search entity object 
def LSA_function(se):
    def LSA_function_single(doc_cluster, stems):
        doc_list = [stems] + doc_cluster
        texts = [document.split() for document in doc_list]
        dictionary = corpora.Dictionary(texts)
        corpus = [dictionary.doc2bow(text) for text in texts]
        ## Using tf-idf conversion for corpus 
        ##note list of keyword strings are being treated just as another docuemnt 
        logent = models.TfidfModel(corpus)

        #apply tfidf model to the corpus 
        corpus_logent = logent[corpus]

        ## Using log entropy conversion for corpus
    #    logent = models.LogEntropyModel(corpus)
    #    corpus_logent = logent[corpus]
        ## To use tf-idf, uncomment that and comment the log entropy one (ignore the naming)
        #create latent samantix indexing(lsi) model that has the total number of topics = total number of articles so the model explains 100% variance
        #implements fast truncated SVD (Singular Value Decomposition). The SVD decomposition can be updated with new observations at any time, for an online, incremental, memory-efficient training.
        #zjc edit(5/18/18): force algo to execute stochastically, instead of assuming the first pass is the optimal solution (onepass=False)
        lsi = models.LsiModel(corpus_logent, id2word=dictionary, num_topics=len(texts), onepass=False)
        #eigen vectors associated with LSI
        S = lsi.projection.s
        #total variance 
        variance = S*S
        #percent total variance explained 
        percent_variance = variance/variance.sum()
        ## Setting the threshold high, since we have low number of links
        thresh = 0.95
        k=0
        dims_assign_check = 0
        for i in range(0,len(percent_variance)):
            if k >= thresh:
                dims = i
                dims_assign_check = 1
                break
            else:
                k += percent_variance[i]
        if dims_assign_check == 0:
            dims=len(texts)
        #refit the model using the lower number of dimensions from the original solution required to explain 95% of total variation 
        lsi_reduced = models.LsiModel(corpus_logent, id2word=dictionary, num_topics=dims)
        #return the corpus 
        corpus_lsi_reduced = lsi_reduced[corpus_logent]
        #mapp all the stems into a dictonary 
        vec_bow = dictionary.doc2bow(stems.split())
        #apply new lsi model to the list of documents as well as the search terms 
        vec_lsi = lsi_reduced[vec_bow]
        #create a document similarity matrix (to compare to the search terms)
        index = similarities.MatrixSimilarity(corpus_lsi_reduced)
        #rank the doc similarity matrix to have the most relevant docs at the top 
        sims = (index[vec_lsi]).tolist()
        #remove the first element in the sims list becuase it is comparing the similarity of search word to itself 
        doc_score = sims[1:len(sims)]
        return doc_score

    #for each languge if the ersults are not blank, extract the post processed text, and clean the search terms , and join them into one string
    for idx in range(0,se.search_lang_ct):
        if not se.urllist[idx] == []:
            doc_cluster = se.textlist[idx]

            #key words (list of keywords joined together by spaces, and compare the total string of key alert 
            #terms to the articles, to identify which articles are most similar to the lsit of search tersm)
            stems = ' '.join(clean_paragraph(se.searchtermlist[idx], se.search_lang_short[idx]))
            se.LSA_score[idx] = LSA_function_single(doc_cluster, stems)
    return se
    


def rerank_searchresults(se, LSA_filter):
    #for each languge the search results were compiled for 
    for idx in range(0, se.search_lang_ct):
        #if the urllist is not blank
        if not se.urllist[idx] == []:
            #first element in each list is associated with the first article returned , then the second, etc....
            #lsa score indicates how relevant the artile is to crime 
            whole_list = list(zip(se.urllist[idx],se.LSA_score[idx],se.list_fuzzyscore[idx],se.list_matchedstems[idx],se.list_fuzzyscoredetail[idx], se.textlist[idx]))
            #sort the list of lists (whole_list) by the values in the second list (LSA SCORE)
            sorted_list = sorted(whole_list, key = operator.itemgetter(1), reverse = True)
            transposed_sorted = list(zip(*sorted_list))
            #filter out articles that do not meet a certain LSA critera 
            LSA_filter_count = len([x for x in transposed_sorted[1] if x >= LSA_filter])
            #append total number of articles significant for the individual (search entity)
            se.LSA_filter_count[idx] = LSA_filter_count

            ## Extract the links and scores from the transposed_sorted which are the list of results sorted by LSA score 
            if LSA_filter_count > 0:
                se.urllist[idx] = transposed_sorted[0][0:LSA_filter_count]
                se.LSA_score[idx] = transposed_sorted[1][0:LSA_filter_count]
                se.list_fuzzyscore[idx] = transposed_sorted[2][0:LSA_filter_count]
                se.list_matchedstems[idx] = transposed_sorted[3][0:LSA_filter_count]
                se.list_fuzzyscoredetail[idx] = transposed_sorted[4][0:LSA_filter_count]
                se.textlist[idx] = transposed_sorted[5][0:LSA_filter_count]

            #if LSA_filter_count == 0 then there are no results that are signifiant and append blanks
            else:
                se.urllist[idx] = []
                se.LSA_score[idx] = []
                se.list_fuzzyscore[idx] = []
                se.list_matchedstems[idx] =[]
                se.list_fuzzyscoredetail[idx] = []
                se.textlist[idx] = []
    return se
    
## Sum the scores

def summary_scores(se, searchcounts):
    #loop through each languge 
    for idx in range(0, se.search_lang_ct):
        if not se.urllist[idx] == []:
            #sum the lsa scores across all articles 
            sum_LSA_score = sum(se.LSA_score[idx])
            se.riskscore_final[idx] = normalize_LSA(sum_LSA_score,len(se.textlist[idx]))
            se.name_fuzzy_all[idx] = str(int(round(np.mean([x[0] for x in se.list_fuzzyscoredetail[idx]]),0)))
            se.location_fuzzy_all[idx] = str(int(round(np.mean([x[1] for x in se.list_fuzzyscoredetail[idx]]),0))) if se.location_provided() else 'N/A - Location not provided'
            se.employment_fuzzy_all[idx] = str(int(round(np.mean([x[2] for x in se.list_fuzzyscoredetail[idx]]),0))) if se.employment_provided() else 'N/A - Employment not provided'
    return se
    

# Re-ordering search results based on W2V similarity instead of LSI
def W2V_function(se):
    # Create TF-IDF to be used in weighting word2vec values.
    def tf_idf(site_list, search_terms):
        doc_list = []
        for site in site_list:
            doc_list.append([item for sublist in site for item in sublist])
        texts = [search_terms] + doc_list
        dictionary = corpora.Dictionary(texts)
        corpus = [dictionary.doc2bow(text) for text in texts]
        ## Using tf-idf conversion for corpus 
        tf_idf_model = models.TfidfModel(corpus,id2word=dictionary, normalize=True) # fit model
        tf_idf_corp = tf_idf_model[corpus] # apply model
        tf_idf_items = {"dic": dictionary, "tf_idf": tf_idf_corp}
        return tf_idf_items
    # Function to get cosine similarity 
    def cosine_sim(a, b):
        return 1 - spatial.distance.cosine(a, b)
    # Function to get weighted average vector of a sentence. Weighting is done by multiplying tf-idf scores
    def avg_phrase(phrase, pymagloc, tf_idf, dictionary, doc_id):
        wv = pymagnitude.Magnitude(pymagloc)
        v = np.zeros(300)
        print(set(phrase))
        for w in set(phrase):
            if w in wv:
                word_id = dictionary.token2id[w]
                doc_vectors = tf_idf[doc_id]
                d = dict(doc_vectors)
                tf_score = d[word_id] 
                v += wv.query(w) * tf_score
        v_norm = preprocessing.normalize(v.reshape(1,-1))
        return  v_norm

'C:\\Users\\yangbo\\Documents\\Engagements\\04 INTAML\\Negative_News\\bitbucket\\fci-negative-news-api\\sourcefile\\GoogleNews-vectors-negative300.magnitude'

    def W2V_function_single(doc_cluster, stems):
        # Pre-process scraped text and search terms
        text_list = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True)
        # Get tf_idf for site text and search terms
        t = tf_idf(text_list, stems)
        # Get average vector for search terms
        search_vec = avg_phrase(stems, model, t["tf_idf"], t["dic"], 0)
        
        # Instantiate list to store cosine similarities
        sim_list = []
        cnt_list = []
        
        if cos_type == 1:
            # Option A) get cosine similiarity of tf idf weighted document vector for each site
            for idx, val in enumerate(text_list):
                if len(val) > 0:
                    sites_flat = [item for sublist in val for item in sublist]
                    text_vec = avg_phrase(sites_flat, model, t["tf_idf"], t["dic"], idx + 1)
                    if text_vec.all != 0:
                        site_sim = cosine_sim(search_vec,text_vec)
                        cnt_list.append(len(sites_flat))
                        sim_list.append(site_sim)  
        else:             
            # Option B) Get soft cosine similarity for each site using gensim functions
            doc_list = []  # Create list of flattened docs
            for site in text_list:
                doc_list.append([item for sublist in site for item in sublist])
            dictionary = t["dic"] #Dictionary to be used in gensim functions
            corpus = [dictionary.doc2bow(text) for text in doc_list]
            similarity_matrix = model.similarity_matrix(dictionary)  # construct similarity matrix
            index = similarities.SoftCosineSimilarity(corpus, similarity_matrix) # Create inde
            
            # Calculate similarity between query and each doc from bow_corpus
            sim_list = index[dictionary.doc2bow(search_terms)]
            
            # Get word counts for each site to be used in final score calculation
            for idx, val in enumerate(text_list):
                if len(val) > 0:
                    sites_flat = [item for sublist in val for item in sublist]
                    cnt_list.append(len(sites_flat))
            
        # Take average of site similarity scores for final scores
        total_len = sum(cnt_list)
        weighted_sims = [sim * (cnt/total_len) for sim, cnt in zip(sim_list,cnt_list)]
        se.nn_score = sum(weighted_sims)
    return se.nn_score

    for idx in range(0,se.search_lang_ct):
        if not se.urllist[idx] == []:
            doc_cluster = se.textlist[idx]
            stems = ' '.join(clean_paragraph(se.searchtermlist[idx], se.search_lang_short[idx]))
            se.ranking_score[idx] = W2V_function_single(doc_cluster, stems)
    return se


############ Experimentation Script - Not for production #########################
# test_path = ("C:/Users/queenmi/Documents/Text_Analytics/Negative_News/Negativenews/" +
# "website_scraper_multilang/sourcefile/test/workingdir/Query_Pickle_returned.pk")

# test_path = "C:/Users/queenmi/Documents/Text_Analytics/Negative_News/Negativenews/website_scraper_multilang/workingdir/Aggregation_20180329.pk"

# test = pd.read_pickle(test_path)

# w2v_path = config.source_path + "GoogleNews-vectors-negative300.bin.gz"
# model = models.KeyedVectors.load_word2vec_format(w2v_path, binary=True, limit = 200000)
# test = test.iloc[0:15,:]
# scores = []

# class SEclass:
#     def __init__(self,site_text,search_terms):
#         self.origtextlist = site_text
#         self.searchterm_list = search_terms        

# for index,row in test.iterrows():
#     if row["origtextlist"] != None and row["searchterm_list"] != None:
#         se = SEclass(row["origtextlist"],row["searchterm_list"])
#         scores.append(wordvector_function(se,model))   
#     else:
#         scores.append(None)

# test["w2v"] = pd.Series(scores)
# test_df = test[["FirstName","LastName","w2v"]]

##### Normalization testing #######
def normalize_LSA(score):
    lsa_sum = (score)*100
    a = 0.342419512682912
    b = 1.19480978536808
    c = 0.211456297918287
    d = 0.779544742969885
    percent_risk = c + d*np.tanh((lsa_sum-a)/b)
    return(percent_risk*100)

t_df["w2v_norm"] = t_df["w2v"].apply(lambda x: 1/(1+np.exp(-x)))