# -*- coding: utf-8 -*-
"""
Created on Thu Mar  1 12:02:53 2018

@author: queenmi
"""

import pickle
import pandas as pd
import os
from fuzzywuzzy import process
import re
import nn_base.nn_config as config

# Specify directory where scraped files are stored
# directory = config.working_path + "scraped_sites"

def CreateTextDict(directory):
    # Initialize dictionary for full text lists for each site and read lists into dictionary
    sites_all = {}
    
    for file in os.listdir(directory):
        path = directory + "/" + file
        filename = os.path.splitext(file)[0] 
        if path.endswith('_all.pkl'):
            with open(path,'rb') as pk_file:
                sites_all[filename] = pickle.load(pk_file)
                
    return sites_all

def CreateNamesDict(directory):
    # Initialize dictionary for lists of names identified in each  site and read lists into dictionary
    sites_names = {}
    
    for file in os.listdir(directory):
        path = directory + "/" + file
        filename = os.path.splitext(file)[0] 
        if path.endswith('_names.pkl'):
            with open(path,'rb') as pk_file:
                sites_names[filename] = pickle.load(pk_file)
                
    return sites_names

# ## If running as a standalone program, we must get the list of names.         
# # Read in a list of names from excel
# namepath = config.source_path + config.source_excel_file
# name_df = pd.read_excel(namepath,sheet_name = "NameTest", header = 0)

# # Create name lists and convert to lower
# first_names = list(name_df['FirstName'].apply(lambda x: x.lower()))
# last_names = list(name_df['LastName'].apply(lambda x: x.lower()))
# full_names = list(name_df["FirstName"].apply(lambda x: x.lower()) + " "
#                   + name_df["LastName"].apply(lambda x: x.lower()))

def RegexMatch(firstName, lastName, site_dict):
    firstName = [firstName]
    lastName = [lastName]
    # Regex - Find matches of names within the scraped texts
    def RegexGen(firstName, lastName):
        regularExpression = '\b' + firstName + r'(?:\W+\w+){0,10}\W+' + lastName + r'\b|\b' + lastName + r'(?:\W+\w+){0,10}\W+' + firstName + r'\b'
        return regularExpression
    
    # Initiate a dictionary to hold regex results
    regex_match = {}
    
    # Apply regex search for each name and website
    for site in site_dict:
        regex_match[site] = [(first, last) for first,last in zip(firstName,lastName)
        if not re.search(RegexGen(first,last), " ".join(site_dict[site]), flags=re.IGNORECASE) is None]
    
    return regex_match 

def FuzzyMatch(firstName, lastName, site_dict):        
    # Initiate a dictionary to hold fuzzy match results
    fuzzy_match = {}
    firstName = [firstName]
    lastName = [lastName] 
    # Fuzzy matching - Find matches of names within the scraped texts
    for site in site_dict:
        for name in zip(firstName,lastName):
            #print(name)
            first_match = process.extract(name[0], site_dict[site], limit = 10)
            first_filter = [match[0] for match in first_match if match[1] >= 95] # filter to names with over 95% similarity
            last_match = process.extract(name[1], site_dict[site], limit = 10)
            last_filter = [match[0] for match in last_match if match[1] >= 95] # filter to names with over 95% similarity
            if first_filter and last_filter:
                fuzzy_match[site] = [first_filter,last_filter]
            else:
                fuzzy_match[site] = []
                
    return fuzzy_match



def static_search_setup():
    sites_all = CreateTextDict(config.working_path + 'scraped_sites')
    sites_names = CreateNamesDict(config.working_path + 'scraped_sites')
    return sites_all, sites_names


def static_search_name(idx, Firstname, Lastname, sites_all, sites_names):
    # If scraped static text is present and static match is enabled, run bing spiders and static name match
    directory = config.working_path + 'scraped_sites'
    # Instantiate a dictionary to store results of static search for each individual 
    static_match_result = -1 
    if os.listdir(directory) != [] and config.static_spider == 1:
        static_search = {'regex': RegexMatch(Firstname, Lastname, sites_all), 'fuzzy': FuzzyMatch(Firstname, Lastname, sites_names)}
        

        if (any(len(d) != 0 for d in static_search["fuzzy"].values()) 
        or any(len(d) != 0 for d in static_search["regex"].values())):

            regex_match = dict((key,value) for (key,value) in static_search["regex"].items() if len(value) != 0)
            fuzzy_match = dict((key,value) for (key,value) in static_search["fuzzy"].items() if len(value) != 0)
        
            static_matches = {"regex": regex_match, "fuzzy": fuzzy_match}

            #print(static_matches)

            static_match_path = config.working_path + "static_matches/" + '{}_{}_{}'.format(str(idx), Firstname, Lastname)
            pickle.dump(static_matches, open(static_match_path + '.pkl', 'wb'))
            static_match_result = 0
    return static_match_result
