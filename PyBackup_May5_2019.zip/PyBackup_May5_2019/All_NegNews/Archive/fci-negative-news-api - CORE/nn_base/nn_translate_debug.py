# -*- coding: utf-8 -*-
"""
Created on Mon Feb 19 09:11:24 2018

@author: yangbo
"""


from googletrans import Translator as gTranslator
from mstranslator import Translator as bTranslator # import statement here because 'Translator' same name as googletrans
#from nn_base.nn_config import BingAPIKey
import pydeepl

BingAPIKey = '2bef92eb52c84c3198b0637c4492f308'

def translate_list(lst, lang, engine='BING'):
    lang = langname_to_iso639(lang)
    #pdb.set_trace()
    if engine.lower() == 'google':
        if lang == 'zh': lang = 'zh-CN'
        translator = gTranslator()
        resultlist = [a.text for a in translator.translate(lst, dest = lang)]
    elif engine.lower() == 'deepl':
        if lang in ['en', 'de', 'fr', 'es', 'it', 'nl', 'pl']:
            resultlist = [a for a in pydeepl.translate(','.join(lst), to_lang=lang.upper())[0].split(', ')] # fixed this line of code
        else:
            print('deepL does not support {} in translation'.format(lang))
            resultlist=''
    elif engine.lower() == 'bing':
       translator = bTranslator(BingAPIKey)
       if lang == 'zh': lang = 'zh-Hans'
       resultlist = [a for a in translator.translate(', '.join(lst), lang_to = lang).split(', ')] # might need to change the lang_to variable here as it seems some of the codes are different for Microsoft Translator (e.g. Chinese Traditional is zh-TW in Google and zh-Hant in Bing/Microsoft)
    return resultlist

def langname_to_iso639(langname):
    ISO_639_1_MAP = {
    'abkhazian' : 'ab',
    'afar' : 'aa',
    'afrikaans' : 'af',
    'akan' : 'ak',
    'albanian' : 'sq',
    'amharic' : 'am',
    'arabic' : 'ar',
    'aragonese' : 'an',
    'armenian' : 'hy',
    'assamese' : 'as',
    'avaric' : 'av',
    'avestan' : 'ae',
    'aymara' : 'ay',
    'azerbaijani' : 'az',
    'bambara' : 'bm',
    'bashkir' : 'ba',
    'basque' : 'eu',
    'belarusian' : 'be',
    'bengali' : 'bn',
    'bihari' : 'bh',
    'bislama' : 'bi',
    'bokmal' : 'nb',
    'bosnian' : 'bs',
    'breton' : 'br',
    'bulgarian' : 'bg',
    'burmese' : 'my',
    'catalan' : 'ca',
    'chamorro' : 'ch',
    'chechen' : 'ce',
    'chinese' : 'zh',
    'chuvash' : 'cv',
    'cornish' : 'kw',
    'corsican' : 'co',
    'cree' : 'cr',
    'croatian' : 'hr',
    'czech' : 'cs',
    'danish' : 'da',
    'dutch' : 'nl',
    'dzongkha' : 'dz',
    'english' : 'en',
    'esperanto' : 'eo',
    'estonian' : 'et',
    'ewe' : 'ee',
    'faroese' : 'fo',
    'fijian' : 'fj',
    'finnish' : 'fi',
    'french' : 'fr',
    'fulah' : 'ff',
    'galician' : 'gl',
    'ganda' : 'lg',
    'german' : 'de',
    'greek' : 'el',
    'guarani' : 'gn',
    'gujarati' : 'gu',
    'haitian' : 'ht',
    'hausa' : 'ha',
    'hebrew' : 'he',
    'herero' : 'hz',
    'hindi' : 'hi',
    'hiri motu' : 'ho',
    'hungarian' : 'hu',
    'icelandic' : 'is',
    'ido' : 'io',
    'igbo' : 'ig',
    'indonesian' : 'id',
    'interlingua' : 'ia',
    'inuktitut' : 'iu',
    'inupiaq' : 'ik',
    'irish' : 'ga',
    'italian' : 'it',
    'japanese' : 'ja',
    'javanese' : 'jv',
    'kalaallisut' : 'kl',
    'kannada' : 'kn',
    'kanuri' : 'kr',
    'kashmiri' : 'ks',
    'kazakh' : 'kk',
    'kikuyu' : 'ki',
    'kinyarwanda' : 'rw',
    'kirghiz' : 'ky',
    'komi' : 'kv',
    'kongo' : 'kg',
    'korean' : 'ko',
    'kuanyama' : 'kj',
    'kurdish' : 'ku',
    'lao' : 'lo',
    'latin' : 'la',
    'latvian' : 'lv',
    'limburgan' : 'li',
    'lingala' : 'ln',
    'lithuanian' : 'lt',
    'luba-katanga' : 'lu',
    'luxembourgish' : 'lb',
    'macedonian' : 'mk',
    'malagasy' : 'mg',
    'malay' : 'ms',
    'malayalam' : 'ml',
    'maltese' : 'mt',
    'manx' : 'gv',
    'maori' : 'mi',
    'marathi' : 'mr',
    'marshallese' : 'mh',
    'micmac' : 'Mi',
    'mongolian' : 'mn',
    'nauru' : 'na',
    'navajo' : 'nv',
    'ndonga' : 'ng',
    'nepali' : 'ne',
    'northern sami' : 'se',
    'norwegian' : 'no',
    'ojibwa' : 'oj',
    'oriya' : 'or',
    'oromo' : 'om',
    'ossetian' : 'os',
    'pali' : 'pi',
    'panjabi' : 'pa',
    'persian' : 'fa',
    'polish' : 'pl',
    'portuguese' : 'pt',
    'pushto' : 'ps',
    'quechua' : 'qu',
    'romanian' : 'ro',
    'romansh' : 'rm',
    'rundi' : 'rn',
    'russian' : 'ru',
    'samoan' : 'sm',
    'sango' : 'sg',
    'sanskrit' : 'sa',
    'sardinian' : 'sc',
    'serbian' : 'sr',
    'shona' : 'sn',
    'sindhi' : 'sd',
    'slovak' : 'sk',
    'slovenian' : 'sl',
    'somali' : 'so',
    'spanish' : 'es',
    'sundanese' : 'su',
    'swahili' : 'sw',
    'swati' : 'ss',
    'swedish' : 'sv',
    'tagalog' : 'tl',
    'tahitian' : 'ty',
    'tajik' : 'tg',
    'tamil' : 'ta',
    'tatar' : 'tt',
    'telugu' : 'te',
    'thai' : 'th',
    'tibetan' : 'bo',
    'tigrinya' : 'ti',
    'tsonga' : 'ts',
    'tswana' : 'tn',
    'turkish' : 'tr',
    'turkmen' : 'tk',
    'twi' : 'tw',
    'uighur' : 'ug',
    'ukrainian' : 'uk',
    'urdu' : 'ur',
    'uzbek' : 'uz',
    'venda' : 've',
    'vietnamese' : 'vi',
    'volapuk' : 'vo',
    'walloon' : 'wa',
    'welsh' : 'cy',
    'wolof' : 'wo',
    'xhosa' : 'xh',
    'yiddish' : 'yi',
    'yoruba' : 'yo',
    'zulu' : 'zu'}
    try:
        return ISO_639_1_MAP[langname]
    except:
        return -1

