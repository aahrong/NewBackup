from setuptools import setup, find_packages
from scrapy.utils.conf import get_config
from scrapy.utils.python import retry_on_eintr
from subprocess import Popen, PIPE, check_call
import tempfile
import os
import sys
import glob
from shutil import copyfile

os.chdir('.')

_SETUP_PY_TEMPLATE = """
# Automatically created by: scrapyd-deploy
from setuptools import setup, find_packages
setup(
    name         = 'website_scraper',
    version      = '1.1',
    packages     = find_packages(),
    entry_points = {'scrapy': ['settings = %(settings)s']},
)
""".lstrip()

def build_egg():
    closest = closest_scrapy_cfg()
    os.chdir(os.path.dirname(closest))
    if not os.path.exists('setup.py'):
        settings = get_config().get('settings', 'default')
        _create_default_setup_py(settings=settings)
    d = tempfile.mkdtemp(prefix="scrapydeploy-")
    o = open(os.path.join(d, "stdout"), "wb")
    e = open(os.path.join(d, "stderr"), "wb")
    retry_on_eintr(check_call, [sys.executable, 'setup.py', 'clean', '-a', 'bdist_egg', '-d', d],
                   stdout=o, stderr=e)
    o.close()
    e.close()
    egg = glob.glob(os.path.join(d, '*.egg'))[0]
    src = 'C:\\Users\\yangbo\\Documents\\engagements\\04 intaml\\negative_news\\Negativenews\\nn_scrape\\nnscrape_2.1.egg'
    copyfile(egg,src)
    return egg, d
    
def _create_default_setup_py(**kwargs):
    with open('setup.py', 'w') as f:
        f.write(_SETUP_PY_TEMPLATE % kwargs)

def closest_scrapy_cfg(path='.', prevpath=None):
    """Return the path to the closest scrapy.cfg file by traversing the current
    directory and its parents
    """
    if path == prevpath:
        return ''
    path = os.path.abspath(path)
    cfgfile = os.path.join(path, 'scrapy.cfg')
    if os.path.exists(cfgfile):
        return cfgfile
    return closest_scrapy_cfg(os.path.dirname(path), path)
os.chdir('C:\\Users\\yangbo\\Documents\\engagements\\04 intaml\\negative_news\\Negativenews\\nn_scrape\\')
a, b = build_egg()