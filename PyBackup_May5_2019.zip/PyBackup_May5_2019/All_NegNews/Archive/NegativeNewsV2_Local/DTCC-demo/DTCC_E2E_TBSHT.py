################################################################
#######THIS IS THE NEW SCRIPT AFTER INTERGRATION OF NEW SPIDER##
################################################################

import os
import sys
#os.chdir('/home/docadmin/YQ/spider/RegulatoryNews/')
#sys.path.insert(0, "//home//docadmin//YQ//spider//")
#sys.path.insert(0, "//home//docadmin//YQ//spider//RegulatoryNews")
os.chdir('/home/docadmin/ZackC/Alisheik/RegulatoryNews/')

from scrapyd_driver_v3 import *
from nn_base.nn_textprocess import indv_found
from nn_base.nn_textprocess import rough_date
from nn_base.nn_textprocess import entity_found
from nn_base.nn_textprocess import trim_key
from nn_base.nn_textprocess import stemsims
from nn_base.nn_textprocess import MinHash
import config as config
from newsapi_downloader_v2 import *
import pickle
import time
from scrapyd_api import ScrapydAPI
import dateparser
import numpy as np
import pandas as pd
import copy
import pymagnitude

###AG comments 8/30/18
#from time import sleep
##import subprocess
#import datetime
#import shutil
#import jsonlines as jl
#from dateutil import parser
#from nn_base.nn_whitelist_functions import finra_search,fdic_search,fdic_name_search
#from nn_base.nn_webprocess import extract_web_results, extract_web_results_two, extract_web_results_three
#from nn_base.nn_webprocess import search_on_bing_all
#from nn_base.nn_webprocess import identify_whitelist
#from nn_base.nn_webprocess import generate_search_query
#from nn_base.nn_webprocess import add_black_list
#from nn_base.nn_textprocess import force_near_filter
#from nn_base.nn_textprocess import clean_paragraph
#from nn_base.nn_textprocess import normalize_LSA
#from nn_base.nn_textprocess import OrigTxt_PreProcess
#import csv
#import sys
#from nn_base.nn_webprocess import window_search_regex
#from nltk.tokenize import word_tokenize 
#from nltk.stem.snowball import SnowballStemmer
#from nltk import regexp_tokenize
#from gensim import corpora, models, similarities
# import string
# import re
#from fuzzywuzzy import fuzz
#import operator
#from itertools import tee, chain, islice
#from nltk.tokenize import sent_tokenize
#from sklearn import preprocessing
#from scipy import spatial
#from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
#from numpy import tanh, exp
#from bs4 import BeautifulSoup
#from operator import itemgetter

from nn_base.nn_translate import langname_to_iso639
from nn_base.nn_translate import translate_searchterms
from nn_base.nn_textprocess import OrigTxt_PreProcess_DTCC
from nn_base.nn_textprocess import entity_match_score
from nn_base.nn_textprocess import entity_stem_match
from nn_base.nn_textprocess import w2v_SortOutput
from nn_base.nn_textprocess import LSA_function
from nn_base.nn_textprocess import rerank_searchresults
from nn_base.nn_textprocess import summary_scores
from nn_base.nn_textprocess import w2v_se2
from nn_base.nn_classes import search_entity as SE
from nn_base.nn_pdf import create_pdf_summary
import re
import json 
from nltk.corpus import stopwords

def call_spider(names,news_source,year_subset,monthsubset,maxsentslider,minsimslider,searchresultlimiter,total_search_terms,spidercall):
    import numpy as np

    #passing names in prespecified format from excel and specifiying config param to change based on spidercall flag
    if spidercall == 0:
        config.bing_entity_querry_list = names 
    else: 
        config.names=names
    
    config.domain_list = news_source
    config.minyear = year_subset
    config.max_sent = maxsentslider
    config.search_results = searchresultlimiter
    config.min_sim = minsimslider
    config.monthmin = monthsubset
    config.searchterms1 = total_search_terms
 
    #print(config.names,config.domain_list,config.minyear,config.max_rg_searching_pages,config.num_pages,config.max_sent,config.min_sim,config.search_results, config.monthmin ,spidercall)
    wv = pymagnitude.Magnitude(config.word_embedding)
    ##########
    stop_words = set(stopwords.words('english'))
    print('zjc')
    
    ####Website Collection###
    scrapyd = ScrapydAPI('http://localhost:6800')

    #ZJC ADDED TO INIDCATE WHAT SPIDER TO USE(8/25)
    if spidercall==0: 
        print('Individual Bing Spider is being Run',spidercall)
        run_bing_spider(scrapyd, entity_querry_list=config.bing_entity_querry_list  ,searchingterm_list=config.searchterms1,count=100)        
    else: 
        print('Entity Spider is being Run',spidercall)
        run_rn_spider(scrapyd,config.names,config.max_rg_searching_pages,config.domain_list,config.num_pages)
    
    wait(scrapyd)
    collect_jl(config.output_dir)
        
    ##load json 
    files=os.listdir(config.output_dir)
    files=[file for file in files if file[0] == '2' and len(file)>5]
    file=files[np.argmax(list(map(lambda x:dateparser.parse(x[:19].replace('.',':')),files)))]
    jl_file_path=config.output_dir+file+'/'+'all_rn_results_'+file[:10]+'.jl'
    print('File Size:',os.path.getsize(jl_file_path))
    print('File Being Aggregated and Analyzed:',jl_file_path)
       
    #read in json contents
    rlt=[] 
    filepath = jl_file_path
    with open(filepath,"r") as f:
        for line in f:
            j_content = json.loads(line,object_hook=trim_key)
            rlt.append(j_content)
            
    #read in json as dataframe
    #read in json as dataframe
    df_rlt=pd.DataFrame(rlt)
    columnsTitles = ['url','source', 'date', 'entity','content','summary','title','origtext']
    df_rlt=df_rlt.reindex(columns=columnsTitles,copy=True)
    df_rlt.rename(columns={'summary': 'Summarylist'}, inplace=True)
    print(df_rlt.entity.unique())

    #fix blank doctitle 
    df_rlt.loc[df_rlt['title'] == None, 'title'] = 'No Title Available'
    df_rlt.loc[df_rlt['title'] == np.nan, 'title'] = 'No Title Available'
    df_rlt.loc[df_rlt['title'].str.strip() == '', 'title'] = 'No Title Available'

    #convert summarylist to string 
    df_rlt['summary'] =df_rlt['Summarylist'].apply(lambda x: ' '.join(map(str, x)).strip())
    df_rlt = df_rlt.copy().drop(['Summarylist'], axis=1)

    #if content is null copy summary over as proxy(NewsAPI does not return full content)
    df_rlt.loc[df_rlt['summary'].str.strip() == 'None', 'summary'] = df_rlt.loc[df_rlt['summary'].str.strip() == 'None', 'content']
    df_rlt.loc[df_rlt['summary'].str.strip() == '', 'summary'] = df_rlt.loc[df_rlt['summary'].str.strip() == '', 'content']
    df_rlt.loc[df_rlt['content'].str.strip() == '', 'content'] = df_rlt.loc[df_rlt['content'].str.strip() == '', 'summary']
    df_rlt=df_rlt[df_rlt.summary.str.strip() != ''].copy()
    df_rlt=df_rlt.copy().drop_duplicates()
    #print(df_rlt.content.value_counts())

    #if origtext = Nan use content 
    df_rlt ['origtext'].replace(np.nan,'', inplace=True)
    df_rlt.loc[df_rlt['origtext'] == '', 'origtext'] = df_rlt.loc[df_rlt['origtext']=='', 'content']
    df_rlt.loc[df_rlt['origtext'].str.strip() == '', 'origtext'] = 'No text'
    df_rlt.loc[df_rlt['origtext'] == 'No text', 'origtext'] = df_rlt.loc[df_rlt['origtext']=='No text', 'summary']

    #create column to replace for missing titles by using url 
    df_rlt["StripURL"] = df_rlt['url'].copy()
    replace_values = {'StripURL':{r'www.':'',r'https://':'',r'http://':'',r'.com':'',r'.org':'',r'.html':'',r'.gov':''}}
    df_rlt.replace(replace_values, regex=True, inplace=True)
    df_rlt["StripURL"]=df_rlt["StripURL"].map(lambda x: x[x.rfind('/')+1:] if len(x[x.rfind('/')+1:])>3 else x)
    df_rlt.loc[df_rlt['title'] == "No Title Available", 'title'] = df_rlt.loc[df_rlt['title'] == "No Title Available", 'StripURL']
    #df_rlt.content.value_counts()

    #subset data to only include responses with URL and Date present 
    df_rlt ['date'].replace('', np.nan, inplace=True)
    #df_rlt.date.value_counts(dropna=False).head()

    #subset based on url
    df_rlt_complete = df_rlt[(df_rlt['url'].isnull()==False)].copy()
    print(df_rlt_complete.entity.value_counts())

    #Try to extract year from date  
    df_rlt_complete['year']=df_rlt_complete.apply(lambda x: '2018' if rough_date(x,'2018')==True else False, axis=1)
    df_rlt_complete.loc[df_rlt_complete['year']==False, 'year']=df_rlt_complete[df_rlt_complete['year']==False].apply(lambda x: '2017' if rough_date(x,'2017')==True else False, axis=1)
    df_rlt_complete.loc[df_rlt_complete['year']==False, 'year']=df_rlt_complete[df_rlt_complete['year']==False].apply(lambda x: '2016' if rough_date(x,'2016')==True else False, axis=1)
    df_rlt_complete.loc[df_rlt_complete['year']==False, 'year']=df_rlt_complete[df_rlt_complete['year']==False].apply(lambda x: '2015' if rough_date(x,'2015')==True else False, axis=1)

    #reformat date from year to be inline with date column  
    df_rlt_complete['year']= df_rlt_complete['year'].apply(lambda x: time.strftime("%m-%d-%Y", time.gmtime(time.mktime((int(x), 1, 1, 17, 3, 38, 1, 48, 0)))) if x!=False else  time.strftime("%m-%d-%Y", time.gmtime(time.mktime((1099, 1, 1, 17, 3, 38, 1, 48, 0)))))
    print(df_rlt_complete)

    #convert date to consistent format 
    df_rlt_complete['date2']=df_rlt_complete.copy().apply(lambda x:  dateparser.parse(x["date"]).strftime("%m-%d-%Y") if pd.notnull(x["date"]) else x['year'], axis=1)
    df_rlt_complete = df_rlt_complete.drop(['date'], axis=1)
    print(df_rlt_complete.entity.value_counts())

    #force near filter(only pull back articles with entity name)
    df_rlt_complete['EntityFound']=df_rlt_complete.apply(lambda x: indv_found(x,'entity') if x['source']=='bing' else entity_found(x,'entity')  , axis=1)
    df_rlt_complete=df_rlt_complete[df_rlt_complete['EntityFound']==True].copy()
    #print(df_rlt_complete.entity.value_counts())

    #if minyear is specified then filter else no filter
    if config.minyear !='':
        from datetime import datetime
        df_rlt_complete['date_filter']=df_rlt_complete.apply(lambda x: datetime.strptime(x['date2'], '%m-%d-%Y') >= datetime(config.minyear,config.monthmin,1),axis=1).copy()
        df_rlt_complete=df_rlt_complete[df_rlt_complete['date_filter']==True].copy()
        df_rlt_complete = df_rlt_complete.drop(['date_filter'], axis=1)
   
    #print(df_rlt_complete.entity.value_counts())
    #remove unneeded columns 
    df_rlt_complete = df_rlt_complete.drop(['year'], axis=1)
    df_rlt_complete = df_rlt_complete.drop(['EntityFound'], axis=1)

    #remove duplicates(ZJC ADD)
    df_rlt_complete=df_rlt_complete.copy().drop_duplicates(['entity','summary'],keep='first',inplace=False).copy()
    

    
    
    #begin post processing of scraped results 
    #fname = ''
    fnames = []
    for idx, val in enumerate(df_rlt_complete.entity.unique()):


        print('val:',val)
        data = df_rlt_complete.loc[df_rlt_complete['entity'] == val]
        
        print('Size at Import: ',data.shape)

        #### BEGIN MUELLER EDITS 8/30 ####
        dupe_idx = MinHash(data['content']).idx_to_remove
        data.drop(data.index[dupe_idx], inplace = True)
        print('Deleting {} duplicate entries for entity {}'.format(len(dupe_idx), val))
        #### BEGIN MUELLER EDITS 8/30 ####
        
        textlistTemp = list(data['origtext'])#textlistTemp = list(data['content'])
        urllist = list(data['url'])
        datelist=list(data['date2'])
        summarylist=list(data['summary'])
        entitylist=list(data['source'])
        querylist=','.join(list(set([x for x in list(data['source'])])))
        entity_querylist = querylist

        print('Post generation of list attributes:','\n'
        ,len(list(filter(None,textlistTemp))),len(textlistTemp),'\n'
        ,len(list(filter(None,urllist))),len(urllist),'\n'
        ,len(list(filter(None,datelist))),len(datelist),'\n'
        ,len(list(filter(None,summarylist))),len(summarylist),'\n'
        ,len(list(filter(None,entitylist))),len(entitylist),'\n'
        ,len(list(filter(None,querylist))),len(querylist),'\n'
        )

        searchterm_list, _  = translate_searchterms(config.searchterms2) if config.termlist==2 else translate_searchterms(config.searchterms1)
        print('Querylist: ',entity_querylist)
        print('Search Term List: ',searchterm_list)

        name=val
        fname = name.split()[0] if config.entity == 0 else name 
        lname = name.split()[1] if len(name.split()) > 1 & config.entity==0 else ''
        print('F_name,L_name: ',fname,":",lname)

        #create SE object
        se = SE(searchid = str(idx), search_lang = ['en'], fname = fname, lname=lname, searchtermlist=searchterm_list)
        se.querylisturl[0] = entity_querylist
        se.search_lang_short = list(map(langname_to_iso639, se.search_lang))
        print('Short Search Language: ',se.search_lang_short)

        #Populate se objects 
        se.origtextlist[0] =list(data['origtext'])
        se.textsummary[0] = list(data['summary'])
        se.lastsearchdate[0] = list(data['date2'])
        se.NewsSource[0] = list(data['source'])
        se.RegNonReg[0] = list(data['source'])
        se.urllist[0] = list(data['url'])
        se.DocTitle[0] = list(data['title'])
        se.entity_querylist = entity_querylist
        #se.entityid = 1
        
        try: 
            se.entity_company= config.bing_entity_querry_list[idx][1]
            se.entity_state= config.bing_entity_querry_list[idx][2]
        except Exception: 
            print('Error')

        print('Post generation of se list attributes:',"\n",
        len(list(filter(None,se.origtextlist[0])))
        ,len(list(filter(None,se.textsummary[0])))
        ,len(list(filter(None,se.lastsearchdate[0])))
        ,len(list(filter(None,se.NewsSource[0])))
        ,len(list(filter(None,se.RegNonReg[0])))
        ,len(list(filter(None,se.urllist[0])))
        ,len(list(filter(None,se.DocTitle[0])))
        #,'\n\n\n\n'
        )

        #sent tokenize and preprocess text for modeling
        textlist,origtext=OrigTxt_PreProcess_DTCC(textlistTemp, se.entity_fname,se.entity_lname,delim ='', window=False)
        textlist_zip = list(zip(textlist, origtext, se.urllist[0],se.textsummary[0],se.lastsearchdate[0],se.NewsSource[0],se.DocTitle[0]))
        #print(len(textlist_zip[0][0]),len(textlist_zip2[0][0]))
        #print(textlist_zip[0][0],'\n\n\n\n\n\n')

        print('Post execution of OrigTxt_Preprocess:',"\n"
        ,len(list(filter(None,textlist))),len(textlist)
        ,len(list(filter(None,origtext))),len(origtext)
        ,len(list(filter(None,se.urllist[0])))
        ,len(list(filter(None,se.textsummary[0])))
        ,len(list(filter(None,se.lastsearchdate[0])))
        ,len(list(filter(None,se.NewsSource[0])))
        ,len(list(filter(None,se.DocTitle[0])))
        )

        print('Textlist Length:',len(textlistTemp))
        print('tlist Length:',len(textlist))
        print('textlist_zip Length:',len(textlist_zip) if textlist_zip else 'zjc messup')

        print('filtering/removing empty strings')
        se.textlist[0] = [x[0] for x in textlist_zip if len(x[0]) != 0] #first element in ziped textlist
        se.pdftext[0] = [x[1] for x in textlist_zip if len(x[0]) != 0] #first element in ziped textlist
        se.urllist[0] = [x[2] for x in textlist_zip if len(x[0]) != 0] #second element in zipped textlist
        se.textsummary[0] = [x[3] for x in textlist_zip if len(x[0]) != 0] #second element in zipped textlist
        se.lastsearchdate[0] = [x[4] for x in textlist_zip if len(x[0]) != 0] #second element in zipped textlist
        se.NewsSource[0] = [x[5] for x in textlist_zip if len(x[0]) != 0] #second element in zipped textlist 
        se.DocTitle[0] = [x[6] for x in textlist_zip if len(x[0]) != 0] #second element in zipped textlist 

        print('Post filtering length check: '
        ,len(list(filter(None,se.textlist[0]))),len(se.textlist[0])
        ,len(list(filter(None,se.pdftext[0]))),len(se.pdftext[0])
        ,len(list(filter(None,se.urllist[0])))
        ,len(list(filter(None,se.textsummary[0])))
        ,len(list(filter(None,se.lastsearchdate[0])))
        ,len(list(filter(None,se.NewsSource[0])))
        ,len(list(filter(None,se.DocTitle[0])))
        )

        #4) Calculate relevancy scores(THESE NEED TO BE UPDATED)
        scoreslist = [entity_match_score(text, se, 0) for text in se.textlist[0]]
        print('ScoreList: ',scoreslist)

        #5) Find stem matches
        stemmatchlist = [entity_stem_match(' '.join(text).split(), se, 0) for text in se.textlist[0]]
        print('StemMatchList:',stemmatchlist)

        #6) Save the processed results (cleaned text, fuzzyscores, details, and matched stems) into appropriate se slot
        se.list_fuzzyscore[0] = [np.mean([x for x in scores if x > 0]) if len([x for x in scores if x > 0])>0 else 0 for scores in scoreslist]
        se.list_fuzzyscoredetail[0] = scoreslist
        se.list_matchedstems[0] = stemmatchlist
        print('FuzzyScore:',se.list_fuzzyscore[0])

        print('urls:',len(se.urllist[0]),'orig:',len(se.textlist[0]),'pdf:',len(se.pdftext[0]))
        print('Origurls:',len(urllist),'orig:',len(se.textlist[0]),'pdf:',len(se.pdftext[0]))

        for idx, text in enumerate(se.textlist):
                    if text == []: se.urllist[idx]=[]

        print('URL length after check for text presence:',len(se.urllist[0]))

        searchresults = ' '.join(['{}:{}'.format(x,len(y)) for (x,y) in zip(se.search_lang, se.urllist)])
        print('Searched {} languages total. The results are: {}'.format(se.search_lang_ct, searchresults)) 

        se = w2v_se2(se, wv, entity=config.entity ,ndoc=1000, nsent=1000, sent_max =config.max_sent , min_sim = config.min_sim, delim = '')

        #print(se.w2vInfo[0])
        se = w2v_SortOutput(se, config.entity, max_sent = config.max_sent)
        #print(se.w2vDfSorted[0])
        se = LSA_function(se)
        se = rerank_searchresults(se, config.LSA_score_filter)
        se = summary_scores(se, config.search_results)

        #assign doc category 
        DocCat,Per = stemsims(se)
        se.DocCategory[0] = DocCat
        se.Perc[0] = Per
        print('exporting results to pickle, which can then be loaded statically for testing new funcitonality using load_results() in text_processing')
        pickle.dump(se, open(config.working_path + se.entity_fname + ' ' + se.entity_lname+ ' ' + time.strftime("%m-%d-%Y") + '.pk', 'wb'))

        #fname: filename of pdf created , failed: list of languages that failed to create a pdf 
        fname, failed = create_pdf_summary(se)
        fnames.append((fname,time.strftime("%Y-%m-%d-%H-%M-%S"), se.riskscore_final[0]))

        print('PDF file stored at - {}'.format(os.path.basename(fname)))
        for x in failed:
            fnames.append((x,time.strftime("%Y-%m-%d-%H-%M-%S"), 999999))
            print('PDF creation failed on language - {}'.format(x))
        jsonname = os.path.splitext(fname)[0]+'.json'

        try:
            dataout = se.to_json(jsonname)
        except Exception:
            print('exception data not saved')
            dataout=12
        pass

        if dataout == 0: #to_json() will return a 0 if sucsesful 
            print('Data saved at {}'.format(os.path.basename(jsonname)))
        else: 
            print('Data Not Saved')
            
    return(fnames)

