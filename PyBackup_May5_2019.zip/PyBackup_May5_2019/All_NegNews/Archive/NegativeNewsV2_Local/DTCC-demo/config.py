## -*- coding: utf-8 -*-
"""
Created on Tue Feb 13 14:24:37 2018

@author: yangbo yqi
"""
#hello world

"""
NEGATIVE NEWS CONFIGURATION FILE
"""

scrapy_dir="//home//docadmin//ZackC//Alisheik//RegulatoryNews//"
output_dir=scrapy_dir+'output//'
pdf_path = scrapy_dir + 'output_pdf//'
project_dir = '/home/docadmin/ZackC/NegNews/' #'/NNfolder/' # /NNfolder/ :use for docker, #project_dir = '/home/docadmin/ZackC/NegNews/' # - use for docadmin

minyear = 2000 #minyear ='' is used to consider all years
monthmin =1
finraocc = 1 
#names=["Wells Fargo"]

max_rg_searching_pages=4
domain_list=['reuters.com','us.cnn.com','fortune.com']
#domain_list=["cnn.com"]
#domain_list = ['bloomberg.com','reuters.com','wsj.com']#'abcnews.go.com','cbsnews.com','cnbc.com','us.cnn.com','ccn.com','fortune.com','foxnews.com','nbcnews.com','reuters.com','nytimes.com','wsj.com','washingtonpost.com','washingtontimes.com/','time.com','usatoday.com/news']
##################### list of all english US sources#################['abcnews.go.com','aljazeera.com','arstechnica.com','apnews.com/','axios.com','bleacherreport.com','bloomberg.com','breitbart.com','businessinsider.com','buzzfeed.com','cbsnews.com','cnbc.com','us.cnn.com','ccn.com','engadget.com','ew.com','espn.go.com','espncricinfo.com/','fortune.com','foxnews.com','foxsports.com','news.google.com','news.ycombinator.com','ign.com','mashable.com','medicalnewstoday.com','msnbc.com','mtv.com/news','news.nationalgeographic.com','nationalreview.com/','nbcnews.com','newscientist.com/section/news','newsweek.com','nymag.com','nextbigfuture.com','nfl.com/news','nhl.com/news','politico.com','polygon.com','recode.net','reddit.com/r/all','reuters.com','techcrunch.com','techradar.com','theamericanconservative.com/','thehill.com','huffingtonpost.com','nytimes.com','thenextweb.com','theverge.com','wsj.com','washingtonpost.com','washingtontimes.com/','time.com','usatoday.com/news','news.vice.com','wired.com']
num_pages=2 #update newsapi_v2 and DTCC_E2E if u want to use this as config. 

#max value of sentiment a sentence can have to be included in the results 
min_sim = 0
max_sent = 1

# terms/phrasees used to actually search google.
#searchingterms = ['launder','fined','sued','enforcement action','terrorist','counterfeit','unlawful','indict','evasion','embezzle','sanction','felony','extort','smuggle','fraud','violation','convict','guilty','theft','corrupt','bankrupt','fugitive','bribe','conspire','allege']

#name , employer , state (must tie these in from the UI)
bing_entity_querry_list=[('Wells Fargo','','New York')]

#[('Lloyd Blankfein','Goldman Sachs','new york')]

# below are old file from Negtive News yangbo
# toggle to determine what set of stems are used and how the name is processed in search query (entity = 1 -> searchterms2 used and mulit-word name allowed when searching)
entity = 1
search_with_location = 0                    # include se.location parameter in the search query 
indiv_parse = 0                             # if 1 parse a specifc domain(specified below in searchdomain=), this also prevents filtering, as all results are output to result if individual site is being parsed# if indiv_parse = 1 , 'site=' generates a single domian report customized to the entity in question
site = 'finra.org'                          # 'fdic.gov'   
yearsearch = ''#[['2018','2017']]                  #[['2018']] #''##[['2017','2018']]  #[['2018','2017']]# if = '', year search is not enabled, else the results will be geared toward the year specified#must use list of list format 
search_results= 120
search_results_output =120
search_results_maxoutput =120

near_filter_distance = 0     # total number of words the first and last name of an individual must be found within (only applicable for individuals not entities)
termlist = 1                 # toggle to indicate which set of searchterms to use below

# terms to be used in generating word embeddings and associated similarity metrics to be used in ranking or results in pdf
#searchterms1 = ['monetary','desist','settelment','statutory','evasion','embezzle','sanction','cease','suspend','default','delinquent','junk','derivitive','launder','implicate','stress','subprime','debenture','collateral','exposure','extortion','Insolvent','warrent']
searchterms1 = ['launder','sued','terrorist','counterfeit','unlawful','indict','evasion','embezzle','sanction'
,'smuggle','fraud','violation','guilty','corrupt','bankrupt','bribe','fined','penalty']#,'rigging','Insolvent'


#searchingterms = ['fined','embezzle','sanction','suspend','subprime','bankruptcy','illiquid','violation','terrorist','launder','deliquent','derivitive','lien'
#                    'warrents','debenture','collateral','unsystemic','exposure','extortion','Insolvent','summonse'
#                    ,'capital restructuring','ratings downgrades','enforcement action','cease and desist','over leveraged'
#                    ,'credit exposure','illiquid asset','unsystemic risk','credit fraud','money laundering','terrorist funding','civil monetary penalty',
#                    'subprime loan'] 

#searchingterms = ['launder','embezzle','penalty','sanction','OCC','MRA','MRIA','extortion','smuggle','terrorist financing','regulatory violation','corrpution','federal lawsuit','counterfeit','fraud','bribe','fined'
#                    ,'enforcement action','cease and desist','credit fraud','money laundering','terrorist funding','civil monetary penalty']
                  


search_engine = 'BING' #Accept GOOGLE, BING, SECRAWL
translator = 'BING' #Accepts GOOGLE, BING, DEEPL
search_lang = ['english']#,'spanish']#,'spanish','chinese'] #Supported languages: en, es, zh
#config paths must have \\ or / at the end of folders
supported_lang = ['english', 'spanish'] #the languages that are supported in the analysis 

#scraper_dir = project_dir + 'website_scraper_multilang/' #Accepts Links
source_path = project_dir + 'sourcefile/'
working_path =  project_dir + 'workingdir/'
#pdf_path = project_dir + 'pdf/'
#pdf_path = '/data/ci/files/'
word_embedding = source_path + 'GoogleNews-vectors-negative300.magnitude'
common_noun = 'common_nouns.txt'
source_excel_file = 'TestList_v3.xlsx'
source_excel_names = 'Banks'#FullList,CoreList
source_excel_tokens = 'Stems'
cache_translatedactive = True
cache_translatedstems = "TranslatedStems.json"
query_picklename = 'Query_Pickle.pk'
BingAPIKey_translate = '9d44b25f4d2d43c9823f2caa53c7097c'
BingAPIKey_search = 'c759653bb84b490ba06cfcd92b2397e4'
#'dc21a3106d8e4968a755888c1944f758'

#
LSA_score_filter = 0.00

static_spider = 1            # enables seach of known high risk customer lists available to public
whitelist_search = 1
translate_search_to_english = 0
timeout = 8

#=0 indicates we are pulling data from excel file , =1 indicates we are pulling data from sql 
sqlload =0
connection_string ='mssql+pyodbc://sqladmin:FinCrimeDEV2017$@adcfincrimeops.database.windows.net:1433/adc-ci?driver=ODBC+Driver+17+for+SQL+Server'
datevar = 'alert_date' #populate only if datevar is present in table 
start_date = '2018-08-12' #start date to pull data from sql (not relevant for excel)
end_date = '2018-09-04' #enddate to stop pulling data from sql(not relevant for excel)

#searchterms1 =['launder','terrorist','counterfeit','unlawful','indict','evasion','embezzle','sanction','felony','extort','smuggle','fraud','violation','convict','guilty','theft','corrupt','bankrupt','suspect','fugitive','arrest','criminal','bribe','accuse','conspire','allege']
#searchterms2 =['launder','terrorist','counterfeit','unlawful','indict','evasion','embezzle','sanction','felony','extort','smuggle','fraud','violation','convict','guilty','theft','corrupt','bankrupt','suspect','fugitive','arrest','criminal','bribe','accuse','conspire','allege']
#searchterms2 = ['scam','patent','unsecured-loans','evasion','embezzle','sanction','felony','extort','smuggle','fraud','violation','convict','launder','terrorist','counterfeit','unlawful','indict','regulation','terrorist','frozen','convicted','compliance','litigation','legal','DOJ','courts','investigation','business_practices','fraud','fine','violation','misleading','pressure','scrutiny','oversight','governing','FED','SEC','PRA','OCC','ECB','SSM','aggressive','tolerance','key_risk_indicator','KRI','run-off','strategy','avoidance','risk-seeking','merger','acquisition','liquidity','funding','line-of-credit','LOC','stress','systemic','crisis','unsecured','obligations','delinquent','overnight','repo','high-quality-liquid-asset','HQLA']

#searchingterms = ['embezzle','sanction','suspend','subprime','bankruptcy','MRA','MRIA','DOJ','illiquid','violation','terrorist','launder','failure','deliquent','derivitive','lien'
#                    ,'debenture','collateral','unsystemic','exposure','extortion','Insolvent','unrecoverable','summonse','warrent','crime',MRA,MRIA,DOJ,
#                    ,'capital restructuring','"ratings downgrades"','"enforcement action"','"management changes"','"monetary fine"','"cease and desist"','"over leveraged"'
#                    ,'"credit exposure"','"illiquid asset"','"unsystemic risk"','"credit fraud"','"money laundering"','"terrorist funding"','"civil monetary penalty"',
#                    '"subprime loan"'
#                    ]

api_list = ['7dd3e4f3c31143e0a4150da36ecbdab9','caf5bc5ba62a4605ba50657cb436ae8a','7dd3e4f3c31143e0a4150da36ecbdab9','4a2cb958e76646d5891025f70935022b', 'ac10c537e0a94fa68722b244013e139b']