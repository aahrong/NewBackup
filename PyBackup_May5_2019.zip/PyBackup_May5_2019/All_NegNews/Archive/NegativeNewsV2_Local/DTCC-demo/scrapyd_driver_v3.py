# -*- coding: utf-8 -*-
"""
Created on Sat Aug 11 11:49:05 2018

@author: qiyi1
"""

import os
from scrapyd_api import ScrapydAPI
from time import sleep
#import subprocess
import datetime
import shutil
import jsonlines as jl

#import logging

#from RegulatoryNews.spiders.RegulatoryNewsSpider import RegulatoryNewsSpider
#abspath = os.path.abspath(__file__)

#scrapy_dir="C:\\Engagements\\NN\\RegulatoryNews\\"
#output_dir=scrapy_dir+'output\\'    
#scrapyd = ScrapydAPI('http://localhost:6800')

def run_rn_spider(scrapyd,entity_list,max_searching_pages,domain_list,num_pages): # see /home/docadmin/YQ/spider/RegulatoryNews/RegulatoryNews/spiders/


#    cmd1 = ["scrapyd"]
#    logging.info(cmd1)
#    proc1 = subprocess.Popen(cmd1, stdout=subprocess.PIPE)#, stderr=subprocess.STDOUT)
    '''Or use cmd to scrapyd + scrapyd_deploy'''
    

    for name in entity_list:
        scrapyd.schedule('RegulatoryNews','regulatory_news_search', entity_name=name,max_searching_pages=max_searching_pages)
        scrapyd.schedule('RegulatoryNews','newsapi_search',entity_name=name,domain_list_str=','.join(domain_list).replace(' ',''),num_pages=num_pages)

def run_bing_spider(scrapyd, entity_querry_list=[],searchingterm_list=[],count=100):
    #entity_querry_list=[(entity_name,employer,state)]
    searchingterm_list_=[ t.strip() for t in searchingterm_list]
    searchingterm_list_str=','.join(searchingterm_list_)
    for entity_name, employer, state in entity_querry_list:
        scrapyd.schedule('RegulatoryNews','bing_search',entity_name=entity_name, employer=employer,state=state,searchingterm_list_str=searchingterm_list_str,count=count)
#    wait(scrapyd)
#
#    for name in names2:
#        scrapyd.schedule('RegulatoryNews','regulatory_news_search', entity_name=name)
        
#        proc1.kill()

#scrapyd.delete_project('RegulatoryNews')    

def collect_jl(output_dir):
    #os.chdir(output_dir)
    files=os.listdir(output_dir)
    arch_folder=str(datetime.datetime.now()).replace(':','.')         
    arch_dir=output_dir+arch_folder
    if not os.path.exists(arch_dir):
        os.mkdir(arch_dir)
    else:
        raise Exception('Archive folder already exist')
        
    rlt=[]
    for file in files:
        if file.endswith('.jl'):
            with open(output_dir+file,'r') as f:
                rlt=rlt+f.readlines()
            shutil.move(output_dir+file,arch_dir+'/'+file)
    with open(arch_dir+'/'+'all_rn_results_'+arch_folder.split(' ')[0]+'.jl','w') as f:
        f.writelines(rlt)

def read_jl(file_path):
    '''
        .jl file is a list of jason+'\n'
        return a list of json
    '''
    rlt=[]
    with jl.open(file_path,'r') as reader:
        for jdic in reader:
            rlt.append(jdic)
    return rlt

def wait(scrapyd):
    job_len=1
    while(job_len):
        sleep(0.05)
        jobs=scrapyd.list_jobs('RegulatoryNews')
        job_len=len(jobs['pending'])+len(jobs['running'])
                
if __name__=='__main__':
    '''
    cmd:
        scrapyd
        scrapd-deploy
    '''
    scrapy_dir="C:\\Engagements\\NN\\RegulatoryNews\\"
    output_dir=scrapy_dir+'output\\'
    scrapyd = ScrapydAPI('http://localhost:6800')
    names1=[
            "Nomura",
            "Schwab",
            "UBS",
            "Barclays",
            "Credit Suisse",
            "Guggenheim",
            "Societe Generale",
            "ETrade"]       

    names2=["Morgan Stanley",
            "JP Morgan",
            "Citi",
            "Bank of America",
            "Wells Fargo",
            "Deutsche Bank",
            "Goldman Sachs"
            ]
    
    
    run_rn_spider(scrapyd,names1,2,['cnn.com','wsj.com'],1)
    wait(scrapyd)
    run_rn_spider(scrapyd,names2,2,['cnn.com','wsj.com'],1)
    wait(scrapyd)
    collect_jl(output_dir)
    
    #################################################
    st=read_jl('C:\\Engagements\\NN\\RegulatoryNews\\output\\2018-08-14 15.38.31.287125\\all_rn_results_2018-08-14.jl')
    import pandas as pd
    df_jl=pd.DataFrame(st)
    columnsTitles = ['source', 'date', 'entity','title','content','summary','url']
    df_jl=df_jl.reindex(columns=columnsTitles)
    df_jl.to_excel('C:\\Engagements\\NN\\RegulatoryNews\\output\\2018-08-14 15.38.31.287125\\all_rn_results_2018-08-14.xlsx')