# -*- coding: utf-8 -*-
"""
Created on Thu Jul 26 23:08:07 2018

@author: qiyi1
"""

import scrapy
from fake_useragent import UserAgent
#from bs4 import BeautifulSoup as BS
#from scrapy.shell import inspect_response
'''
Currently HTML only
No pdf links
'''


class RegulatoryNewsSpider(scrapy.Spider):
    name = 'regulatory_news_search'
#Warning: customer settings not verify     
    custom_settings = {
        #'FEED_URI': '</home/docadmin/ZackC/NN_Gitlab/adhoc_troubleshoot/output/FinraLinks.csv>',
        #, 'FEED_EXPORTERS': {'pickle': 'scrapy.exporters.PickleItemExporter'
        #FEED_EXPORT_FEILDS
        #'FEED_FORMAT': 'csv'
        'ITEM_PIPELINES': {'RegulatoryNews.pipelines.RegulatoryNewsPipeline2json': 300},
   #             'RegulatoryNews.pipelines.RegulatoryNewsPipeline2csv': 500},            
        'AUTOTHROTTLE_ENABLED': 'True',
        'AUTOTHROTTLE_TARGET_CONCURRENCY': '1.0',
        'RANDOMIZE_DOWNLOAD_DELAY': 'True',
        'USER_AGENT': UserAgent().random,
        'ROBOTSTXT_OBEY': 'False',
        'HTTPCACHE_ENABLED': 'False',
        'LOG_STDOUT': 'True',
        #'LOG_LEVEL': 'WARNING',
        'LOG_LEVEL': 'DEBUG', 
        'DOWNLOAD_TIMEOUT': str(10),
        'RETRY_ENABLED': False,
        'CLOSESPIDER_TIMEOUT':'500',
        'DOWNLOAD_DELAY':'0.25'
    
       }

  

    #allowed_domains = [fdic_name_search(self.entity_name)[1]]
    def __init__(self, entity_name='', **kwargs):
        #self.start_urls = [fdic_name_search(entity_name)]
        self.entity=entity_name
        #self.start_urls=["https://www.occ.gov/OCCSearch/Search.aspx?output=xml_no_dtd&client=OCC_Main&proxystylesheet=OCC_Main&entqr=0&ud=1&sort=date%3AD%3AL%3Ad1&site=News_Current&ie=UTF-8&oe=UTF-8&filter=0&q=morgan+stanley&Submit=Search"]
        self.start_urls=[self.finra_querry_page(entity_name),self.occ_querry_page(entity_name)]
        super().__init__(**kwargs)  # python3
    
    def start_requests(self):
        
        yield scrapy.Request(self.start_urls[0], self.parse_finra)
        print("++++++++++++++++++++++++++++++++++++++++++++")
        yield scrapy.Request(self.start_urls[1], self.parse_occ)
    #def parse_finra__(self,response):
    #    print('11111111111111111')
    
    #def parse_occ__(self,response):
    #    print('22222222222222')
    #    pass
    #@classmethod
    def finra_querry_page(self,name):
        namesplit = []
        name = name.replace("\'s","%2527").strip()
        namesplit = name.split()
        safe_dict ={}
        safe_dict['namesplit'] = namesplit
        namelen= len(namesplit)
        formatset = "{}%2520"*(namelen-1)+"{}"
        #fdic = str("https://search.fdic.gov/search?q={}&btnG=Search&output=xml_no_dtd&oe=ISO-8859-1&ie=ISO-8859-1&client=press&proxystylesheet=wwwGOV&wc=200&:%20wc_mc=1&ud=1&wc_mc=1&exclude_apps=1&site=press&ulang=en&ip=10.30.1.36&access=p&entqr=0&entqrm=0&filter=0&sort=date%3AD%3AS%3Ad1".format(name) if namelen ==1 else
        #           "https://search.fdic.gov/search?q="+formatset+"&btnG=Search&output=xml_no_dtd&oe=ISO-8859-1&ie=ISO-8859-1&client=press&proxystylesheet=wwwGOV&wc=200&:%20wc_mc=1&ud=1&wc_mc=1&exclude_apps=1&site=press&ulang=en&ip=10.30.1.36&access=p&entqr=0&entqrm=0&filter=0&sort=date%3AD%3AS%3Ad1").format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
        #occ=str("https://www.occ.gov/OCCSearch/Search.aspx?output=xml_no_dtd&client=OCC_Main&proxystylesheet=OCC_Main&entqr=0&ud=1&sort=date%3AD%3AL%3Ad1&site=News_Current&ie=UTF-8&oe=UTF-8&filter=0&q={}&Submit=Search".format(name) else "https://www.occ.gov/OCCSearch/Search.aspx?output=xml_no_dtd&client=OCC_Main&proxystylesheet=OCC_Main&entqr=0&ud=1&sort=date%3AD%3AL%3Ad1&site=News_Current&ie=UTF-8&oe=UTF-8&filter=0&q="+formatset+"&Submit=Search".format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
        #fdic = str("https://search.fdic.gov/search?q={}&btnG=Search&output=xml_no_dtd&oe=ISO-8859-1&ie=ISO-8859-1&client=press&proxystylesheet=wwwGOV&wc=200&:%20wc_mc=1&ud=1&wc_mc=1&exclude_apps=1&site=press&ulang=en&ip=10.30.1.36&access=p&entqr=0&entqrm=0&filter=0&sort=date%3AD%3AS%3Ad1".format(name) if namelen ==1 else
        #           "https://search.fdic.gov/search?q="+formatset+"&btnG=Search&output=xml_no_dtd&oe=ISO-8859-1&ie=ISO-8859-1&client=press&proxystylesheet=wwwGOV&wc=200&:%20wc_mc=1&ud=1&wc_mc=1&exclude_apps=1&site=press&ulang=en&ip=10.30.1.36&access=p&entqr=0&entqrm=0&filter=0&sort=date%3AD%3AS%3Ad1").format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
        
        
        #occ = str("https://www.occ.gov/OCCSearch/Search.aspx?output=xml_no_dtd&client=OCC_Main&proxystylesheet=OCC_Main&entqr=0&ud=1&sort=date%3AD%3AL%3Ad1&site=News_Current&ie=UTF-8&oe=UTF-8&filter=0&q={}&Submit=Search".format(name) if namelen ==1 else
        #           "https://www.occ.gov/OCCSearch/Search.aspx?output=xml_no_dtd&client=OCC_Main&proxystylesheet=OCC_Main&entqr=0&ud=1&sort=date%3AD%3AL%3Ad1&site=News_Current&ie=UTF-8&oe=UTF-8&filter=0&q="+formatset+"&Submit=Search").format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
          
        finra=str("http://www.finra.org/search/global/{}".format(name) if namelen ==1 else
                   "http://www.finra.org/search/global/"+formatset).format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
          
        #root_url = "search.fdic.gov"
        return finra
    def occ_querry_page(self,name):
        namesplit = []
        name = name.strip()
        namesplit = name.split()
        safe_dict ={}
        safe_dict['namesplit'] = namesplit
        namelen= len(namesplit)
        formatset = "{}+"*(namelen-1)+"{}"
        #fdic = str("https://search.fdic.gov/search?q={}&btnG=Search&output=xml_no_dtd&oe=ISO-8859-1&ie=ISO-8859-1&client=press&proxystylesheet=wwwGOV&wc=200&:%20wc_mc=1&ud=1&wc_mc=1&exclude_apps=1&site=press&ulang=en&ip=10.30.1.36&access=p&entqr=0&entqrm=0&filter=0&sort=date%3AD%3AS%3Ad1".format(name) if namelen ==1 else
        #           "https://search.fdic.gov/search?q="+formatset+"&btnG=Search&output=xml_no_dtd&oe=ISO-8859-1&ie=ISO-8859-1&client=press&proxystylesheet=wwwGOV&wc=200&:%20wc_mc=1&ud=1&wc_mc=1&exclude_apps=1&site=press&ulang=en&ip=10.30.1.36&access=p&entqr=0&entqrm=0&filter=0&sort=date%3AD%3AS%3Ad1").format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
        #occ=str("https://www.occ.gov/OCCSearch/Search.aspx?output=xml_no_dtd&client=OCC_Main&proxystylesheet=OCC_Main&entqr=0&ud=1&sort=date%3AD%3AL%3Ad1&site=News_Current&ie=UTF-8&oe=UTF-8&filter=0&q={}&Submit=Search".format(name) else "https://www.occ.gov/OCCSearch/Search.aspx?output=xml_no_dtd&client=OCC_Main&proxystylesheet=OCC_Main&entqr=0&ud=1&sort=date%3AD%3AL%3Ad1&site=News_Current&ie=UTF-8&oe=UTF-8&filter=0&q="+formatset+"&Submit=Search".format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
        #fdic = str("https://search.fdic.gov/search?q={}&btnG=Search&output=xml_no_dtd&oe=ISO-8859-1&ie=ISO-8859-1&client=press&proxystylesheet=wwwGOV&wc=200&:%20wc_mc=1&ud=1&wc_mc=1&exclude_apps=1&site=press&ulang=en&ip=10.30.1.36&access=p&entqr=0&entqrm=0&filter=0&sort=date%3AD%3AS%3Ad1".format(name) if namelen ==1 else
        #           "https://search.fdic.gov/search?q="+formatset+"&btnG=Search&output=xml_no_dtd&oe=ISO-8859-1&ie=ISO-8859-1&client=press&proxystylesheet=wwwGOV&wc=200&:%20wc_mc=1&ud=1&wc_mc=1&exclude_apps=1&site=press&ulang=en&ip=10.30.1.36&access=p&entqr=0&entqrm=0&filter=0&sort=date%3AD%3AS%3Ad1").format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
        
        
        occ = str("https://www.occ.gov/OCCSearch/Search.aspx?output=xml_no_dtd&client=OCC_Main&proxystylesheet=OCC_Main&entqr=0&ud=1&sort=date%3AD%3AL%3Ad1&site=News_Current&ie=UTF-8&oe=UTF-8&filter=0&q={}&Submit=Search".format(name) if namelen ==1 else
                   "https://www.occ.gov/OCCSearch/Search.aspx?output=xml_no_dtd&client=OCC_Main&proxystylesheet=OCC_Main&entqr=0&ud=1&sort=date%3AD%3AL%3Ad1&site=News_Current&ie=UTF-8&oe=UTF-8&filter=0&q="+formatset+"&Submit=Search").format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
          
        
        #root_url = "search.fdic.gov"
        return occ

    
    def parse_finra(self, response):
        print ('11111111111111')
        #inspect_response(response, self)
        
        #identify the relative xpath associated with the document links
        #DocumentLinks = response.xpath('.//div//a[@ctype="c"]')
        DocumentLinks=response.xpath(".//li[@class='search-result']/h2[@class='title']/a/@href").extract()
        #extract the articles one at a time
        num=0
        for Link in DocumentLinks:
            num=num+1
            #Link = FinLink()
            #Link['links'] = 
            #Link=article.xpath('.//@href').extract_first()
            #Link = article.xpath('.//@href').extract_first()
            
            
            
            response_type=Link.split('.')[-1]   
            
            #yield {'link':Link}
            if response_type in ('pdf','xlsx','xls'):
                #yield {'url': Link,'content': Link}
                pass
            else:
                #print('xxxxxurl'+str(num),Link)
                #yield {'url': Link,'content': scrapy.Request(Link,self.content_parse)} # YQ: I assume Link is a herf, otherwise use scrapy.Request 
                yield scrapy.Request(Link,self.content_parse_finra)
            #response.follow(article,self.content_parse)
        #identify the xpath for the next page link 
        #next_page_url = response.xpath(".//span[@class='s']//a[@ctype='nav.next']//@href").extract()[0]
        next_page= response.xpath(".//div[@class='item-list']/ul[@class='pager']/li[@class='pager__item--next pager__item']/a/@href").extract_first()
        if next_page is not None:
            yield response.follow(next_page,callback=self.parse_finra)
        ###next_page_url = response.xpath(".//a[@ctype='nav.next']//@href").extract()[0]
        
        #if the next page link exists we generate a URL and then send another request to extract 
        
        ######if next_page_url:
        ######    absolute_next_page_url = response.urljoin(next_page_url)
            #print(absolute_next_page_url)
        ######    yield scrapy.Request(absolute_next_page_url,self.parse)
            
    def content_date_parse_finra(self,response):
        '''
        only for content_parse
        '''
        try:
            dt=response.xpath(".//div[@class='field-item even field field--name-field-core-official-dt field--type-datetime field--label-inline clearfix field-item-content field-item-date field-item-date']//text()").extract_first()
            if dt==None:
                dt=response.xpath("//div[@class='field-items official-dt']//text()").extract()[1] #qyk patch 08142018
            return dt
        except: 
            return None
        
    def content_title_parse_finra(self,response):
        '''
        only for content_parse
        '''
        try:
            tt=response.xpath(".//h1[@class='core-title']//text()").extract_first()
            if tt==None:
                tt= response.xpath("//div[@class='title']//h1//text()").extract_first() #qyk patch 08142018
            return tt
        except: 
            return None

        
    def content_parse_finra(self,response):
        
         '''
         parse news page content/date...
         '''
         #print("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww")
         #print (response.url)
         #inspect_response(response,self)
         '''
         --All text
         soup=BS(response.text)
         yield {'url':response.url,'content':soup.text}
         #pass
         '''
         
         '''
         
         --All text
         soup=BS(response.xpath("/div[@id='newsRelease']//text()"))
         yield {'url':response.url,'content':soup.text}
         #pass
         
         '''
         yield { 'source':'finra',
                 'entity':self.entity,
                 'url':response.url,
                #'id': response.xpath(".//div[@class='articleIdentifier']/text()").extract_first(),
                'title': self.content_title_parse_finra(response), #response.xpath(".//h1[@class='core-title']//text()").extract_first(),
                'date': self.content_date_parse_finra(response),
                #'author':response.xpath(".//div[@class='articleContactInfo']/text()").extract_first().split(': ')[1],
                'content': ' '.join( response.xpath(".//div[@class='field-item even field field--name-body field--type-text-with-summary field--label-hidden']/p//text()").extract())
                }

    def parse_occ(self, response):
        print('22222222222222')
        #inspect_response(response, self)
        
        #identify the relative xpath associated with the document links
        DocumentLinks = response.xpath('.//div//a[@ctype="c"]')
        
        #extract the articles one at a time
        num=0
        for article in DocumentLinks:
            num=num+1
            #Link = FinLink()
            #Link['links'] = 
            Link=article.xpath('.//@href').extract_first()
            #Link = article.xpath('.//@href').extract_first()
            
            
            
            response_type=Link.split('.')[-1]   
            
            #yield {'link':Link}
            if response_type=='pdf':
                #yield {'url': Link,'content': Link}
                pass
            else:
                #print('xxxxxurl'+str(num),Link)
                #yield {'url': Link,'content': scrapy.Request(Link,self.content_parse)} # YQ: I assume Link is a herf, otherwise use scrapy.Request
                yield scrapy.Request(Link,self.content_parse_occ)
            #response.follow(article,self.content_parse)
        #identify the xpath for the next page link 
        #next_page_url = response.xpath(".//span[@class='s']//a[@ctype='nav.next']//@href").extract()[0]
        next_page= response.xpath(".//a[@ctype='nav.next']/@href").extract_first()
        if next_page is not None:
            yield response.follow(next_page,callback=self.parse_occ)
        ###next_page_url = response.xpath(".//a[@ctype='nav.next']//@href").extract()[0]
        
        #if the next page link exists we generate a URL and then send another request to extract 
        
        ######if next_page_url:
        ######    absolute_next_page_url = response.urljoin(next_page_url)
            #print(absolute_next_page_url)
        ######    yield scrapy.Request(absolute_next_page_url,self.parse)
            
    def content_date_parse_occ(self,response):
        '''
        only for content_parse
        '''
        try:
            dt=response.xpath(".//div[@class='articleDateline']/text()").extract()[-1]
            return dt.replace('\n','')
        except: 
            return None
        
    def content_parse_occ(self,response):
         '''
         parse news page content/date...
         '''
         #print("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww")
         #inspect_response(response,self)
         '''
         --All text
         soup=BS(response.text)
         yield {'url':response.url,'content':soup.text}
         #pass
         '''
         
         '''
         
         --All text
         soup=BS(response.xpath("/div[@id='newsRelease']//text()"))
         yield {'url':response.url,'content':soup.text}
         #pass
         
         '''
         yield { 'source': 'occ',
                 'entity':self.entity,
                 'url':response.url,
                #'id': response.xpath(".//div[@class='articleIdentifier']/text()").extract_first(),
                'title':  response.xpath(".//div[@class='div-nr-title']//h2/text()").extract_first(),
                'date': self.content_date_parse_occ(response),
                #'author':response.xpath(".//div[@class='articleContactInfo']/text()").extract_first().split(': ')[1],
                'content': ' '.join( response.xpath(".//div[@id='newsRelease']//div//p/text()").extract()).replace(u'\xa0', u' ')
                }
