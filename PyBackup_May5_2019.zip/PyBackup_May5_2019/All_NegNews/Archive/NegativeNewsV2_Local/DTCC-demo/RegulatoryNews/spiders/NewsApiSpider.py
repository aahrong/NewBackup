# -*- coding: utf-8 -*-
"""
Created on Fri Aug 17 14:26:33 2018

@author: qiyi1
"""
import scrapy
from fake_useragent import UserAgent
from newsapi import NewsApiClient
import re
from bs4 import BeautifulSoup
from bs4.element import Comment
from itertools import tee, chain, islice
from nltk.tokenize import sent_tokenize

#from sumy.parsers.html import HtmlParser
#from sumy.nlp.tokenizers import Tokenizer
#from sumy.summarizers.lsa import LsaSummarizer as Summarizer
#from sumy.nlp.stemmers import Stemmer

#import os
#import datetime
#from time import sleep
#import shutil
#import json


class NewsapiSpider(scrapy.Spider):
    name = 'newsapi_search'
    custom_settings = {
        #'FEED_URI': '</home/docadmin/ZackC/NN_Gitlab/adhoc_troubleshoot/output/FinraLinks.csv>',
        #, 'FEED_EXPORTERS': {'pickle': 'scrapy.exporters.PickleItemExporter'
        #FEED_EXPORT_FEILDS
        #'FEED_FORMAT': 'csv'
        'ITEM_PIPELINES': {'RegulatoryNews.pipelines.NewsapiPipeline2json': 300},
   #             'RegulatoryNews.pipelines.RegulatoryNewsPipeline2csv': 500},            
        'AUTOTHROTTLE_ENABLED': 'True',
        'AUTOTHROTTLE_TARGET_CONCURRENCY': '1.0',
        'RANDOMIZE_DOWNLOAD_DELAY': 'True',
        'USER_AGENT': UserAgent().random,
        'ROBOTSTXT_OBEY': 'False',
        'HTTPCACHE_ENABLED': 'False',
        'LOG_STDOUT': 'True',
        #'LOG_LEVEL': 'WARNING',
        'LOG_LEVEL': 'DEBUG', 
        'DOWNLOAD_TIMEOUT': str(15),
        'RETRY_ENABLED': False,
        'CLOSESPIDER_TIMEOUT':'500',
        'DOWNLOAD_DELAY':'0.25'
        ,'COOKIES_ENABLED':False
        
        ### rotate proxies### qyk
#        # Retry many times since proxies often fail
#        ,'RETRY_TIMES' : 100
#        # Retry on most error codes since proxies fail for different reasons
#        ,'RETRY_HTTP_CODES': [500, 503, 504, 400, 403, 404, 408]
#
#        ,'DOWNLOADER_MIDDLEWARES' : {
#                'scrapy.downloadermiddlewares.retry.RetryMiddleware': 90,
#                'scrapy_proxies.randomproxy.RandomProxy': 100,
#                'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 110,
#                }
#
#        # Proxy list containing entries like
#        # http://host1:port
#        # http://username:password@host2:port
#        # http://host3:port
#        # ...
#        ,'PROXY_LIST' : './proxies.txt'
#
#        # Proxy mode
#        # 0 = Every requests have different proxy
#        # 1 = Take only one proxy from the list and assign it to every requests
#        # 2 = Put a custom proxy to use in the settings
#        ,'PROXY_MODE' : 0
#
#        # If proxy mode is 2 uncomment this sentence :
#        #CUSTOM_PROXY = "http://host1:port"
        
       }

  

    #allowed_domains = [fdic_name_search(self.entity_name)[1]]
    def __init__(self, entity_name='', domain_list_str='', start=None, end=None, sort_by='publishedAt', num_pages=1, page_size=25, output_dir='/home/docadmin/ZackC/Alisheik/RegulatoryNews/output/',**kwargs):
        #sort_by 'publishedAt'/'relevance',
        #domain_list_str='bloomberg.com, cnn.com'
        #self.start_urls = [fdic_name_search(entity_name)]
        self.entity=entity_name
        self.output_dir=output_dir
        name_trail=entity_name.split()
        self.fname=name_trail[0]
        if len(name_trail)>1:
            self.lname=' '.join(name_trail[1:])
        else:
            self.lname=''
        
        #self.domain_str=domain_list.strip('[').strip(']')
#        if num_results <= 100:
#            page_size_r = num_results
#            page_r = 1
#        else:
#            page_size_r = 100
#            page_r = num_results//100 +1
        
        #seed=config.api_list[randint(0, len(config.api_list)-1)]
        #api = NewsApiClient(api_key=seed) 
        api = NewsApiClient(api_key='6d26d7df758f4eb6a95a42557233f287')        
        
        self.news_dic_list=[]
        #print(domain_list)
        #print(self.domain_str)
        #print(self.entity)
        print(domain_list_str)
        print(api)
        if domain_list_str=='':
            for pg in range(1,int(num_pages)+1):
                self.news_dic_list=self.news_dic_list+api.get_everything(q=self.entity
                                    #, domains=domain_list_str
                                    , from_param=start ###YYYY-MM-DD
                                    , to=end
                                    , language='en'
                                    , sort_by=sort_by
                                    , page_size=int(page_size)
                                    , page=pg)['articles']
        else:
            domain_list=domain_list_str.split(',')
            for web in domain_list:
                for pg in range(1,int(num_pages)+1):
                    self.news_dic_list=self.news_dic_list+api.get_everything(q=self.entity
                                        , domains=web.strip()
                                        , from_param=start ###YYYY-MM-DD
                                        , to=end
                                        , language='en'
                                        , sort_by=sort_by
                                        , page_size=int(page_size)
                                        , page=pg)['articles']
        print(self.news_dic_list)


#        if self.domain_str=='':
#            for pg in range(1,num_pages+1):
#                self.news_dic_list=self.news_dic_list+api.get_everything(q=self.entity
#                                    , from_param=start ###YYYY-MM-DD
#                                    , to=end
#                                    , language='en'
#                                    , sort_by=sort_by
#                                    , page_size=100
#                                    , page=pg)['articles']
#        else:
#            for pg in range(1,num_pages+1):
#                for web in domain_list:
#                    self.news_dic_list=self.news_dic_list+api.get_everything(q=self.entity
#                                    , domains=web
#                                    , from_param=start ###YYYY-MM-DD
#                                    , to=end
#                                    , language='en'
#                                    , sort_by=sort_by
#                                    , page_size=100
#                                    , page=pg)['articles']
#        
        
        #self.start_urls=["https://www.occ.gov/OCCSearch/Search.aspx?output=xml_no_dtd&client=OCC_Main&proxystylesheet=OCC_Main&entqr=0&ud=1&sort=date%3AD%3AL%3Ad1&site=News_Current&ie=UTF-8&oe=UTF-8&filter=0&q=morgan+stanley&Submit=Search"]
        #self.start_urls=[self.finra_querry_page(entity_name),self.occ_querry_page(entity_name)]
        super().__init__(**kwargs)  # python3
    
    def start_requests(self):
        
        for item_ in self.news_dic_list:
            yield scrapy.Request(item_['url'], self.parse_content, meta=item_)

  #file.write(json.dumps({'source':item['source']['name'],'entity':entity, 'title':item['title'],'date':item['publishedAt'],'content':''#.join(generate_summary(item['url'],n_sentence=300))
  #                                   ,'summary':[item['description']],'url':item['url']})+'\n')

      
  
    def parse_content(self,response):
        print ('11111111111111')
        #print(response.meta)
               
        ext_text=self.extract_web_results(response.text,self.fname,self.lname,entity=0)
        clean_text=' '.join(self.OrigTxt_PreProcess([ext_text], self.fname, self.lname, delim ='<!@&>', window=False)[0][0])
        origtext=' '.join(self.OrigTxt_PreProcess([ext_text], self.fname, self.lname, delim ='<!@&>', window=False)[1][0])
        
        print(clean_text)
        if clean_text!='':
            yield({'source':response.meta['source']['name'],'entity':self.entity, 'title':response.meta['title'],'date':response.meta['publishedAt'],'content':clean_text,'summary':[response.meta['description']],'url':response.meta['url'],'origtext':origtext})
        #inspect_response(response, self)
        else:
            yield({'source':response.meta['source']['name'],'entity':self.entity, 'title':response.meta['title'],'date':response.meta['publishedAt'],'content':response.meta['description'],'summary':[response.meta['description']],'url':response.meta['url'],'origtext':response.meta['description']})

    def extract_web_results(self,responsetext, fname, lname,entity=0):
    #@timeout(config.timeout)
        def text_from_html(htmltext, parser):
            def tag_visible(element):
                if element.parent.name in ['style', 'script', 'head', 'title', 'meta', '[document]']:
                    return False
                if isinstance(element, Comment):
                    return False
                return True
            try:
                soup = BeautifulSoup(htmltext, parser)
                texts = soup.findAll(text=True)
                visible_texts = filter(tag_visible, texts)  
                return u" ".join(t.strip() for t in visible_texts)
            except:
                return ''
        
        #clean raw htm text slightly to enable effective windowing 
        text = text_from_html(responsetext, "html") #text to process and manipulate 
        text = text.strip()
        text = re.sub("\.{2,}" , ".",text)
        #text = re.sub(' +',' ',text)
            
        #apply windowing critera
        extracted_text = self.window_search_regex(text, fname, lname, entity)    #extract relevant text from URL (and convert to lwoer)
        
        ## Now try with lxml parser, if extracted text is blank
        if extracted_text == '':
            text = text_from_html(responsetext,"lxml")
            text = text.strip()
            text = re.sub("\.{2,}" , ".",text)
            #text = re.sub(' +',' ',text)
            extracted_text = self.window_search_regex(text, fname, lname,entity)
        return extracted_text
        #except:
        #    return ''
    def window_search_regex(self,text, fname, lname,entity,left_num=2,right_num=2):
        try:
            if lname!='':
                
                if entity==1:
                    regex_name = ('{} {}'.format(fname, lname)).lower().strip()
                else:
                    regex_name = ('{}|{}'.format(fname, lname)).lower().strip()
                    
            else:
                regex_name=fname.lower().strip()
            
            text=text.replace('U.S.','USA').replace('www.','').replace('.com','').replace('.org','').replace('.gov','').replace('Inc.','Inc').replace('Co.','Co').replace('Mr.','').replace('Mrs.','').replace('Dr.','').replace('Feb.','February').replace('Jan.','January').replace('Aug.','August').replace('Sep.','September').replace('Oct.','October').replace('Nov.','November').replace('Dec.','December').replace('0.','0_').replace('1.','1_').replace('2.','2_').replace('3.','3_').replace('4.','4_').replace('5.','5_').replace('6.','6_').replace('7.','7_').replace('8.','8_').replace('9.','9_')
    
            text_for_regex=text 
            text_for_regex = 'the. ' + text + ' the. the.' 
            extracted_text_list =[]
            #p = re.compile(r'(([^\.]*\.){1}[^\.]*(' + regex_name + r')[^\.]*\.([^\.]*\.){2})',re.IGNORECASE) #original critera 1,2   
            p = re.compile(r'(([^\.]*\.){'+str(left_num)+'}[^\.]*(' + regex_name + r')[^\.]*\.([^\.]*\.){'+str(right_num)+'})',re.IGNORECASE) #original critera 1,2   
            
            for name_i in p.findall(text_for_regex,re.IGNORECASE):
                extracted_text_list.append(name_i[0])
            extracted_text_list = list(set(extracted_text_list))
            extracted_text_list = [x[0:2000] for x in extracted_text_list if 10 <= len(x) <= 2000]
            extracted_text = '<!@&>'.join(extracted_text_list)
            return extracted_text
        except:
            return ''

    def OrigTxt_PreProcess(self,origtextlist, fname, lname, delim ='<!@&>', window=False):
    
    #######################################################
    ################FUNCTION DEFINITIONS###################
    #######################################################
    #check if name is in sentences surrounding the sentence being processed (applied same way for entity and individual because all conditions are OR)  
        def name_in_sent(s1,s2,s3,fname,lname):
            return True if fname in s1 or fname in s2 or fname in s3 or (lname!='' and (lname in s1 or lname in s2 or lname in s3)) else False
    
    #extracts all sentences before and after the sentence being processed 
        def previous_and_next(some_iterable):
            prevs, items, nexts = tee(some_iterable, 3)
            prevs = chain([''], prevs)
            nexts = chain(islice(nexts, 1, None), [''])
            return zip(prevs, items, nexts) 

    ##################################################################
    ########################EXECUTION START###########################
    ##################################################################
    
    #pre-process the original text and assign it back to original text 
    #if text is not se object it is assumed to be long string 
        test = origtextlist
    
    #if the delimiter is not defined, then we assume the doc is already delimited in some way so we do not split the doucment further(until sentence tokenization)
        if delim !="":
            #process text for use in word embedding models 
            test2 = [x.split(delim) for x in test] #split based on custom delimiter
            test3 = [[y.replace('\n',' ') for y in x] for x in test2] #replace all new line characters 
            test4 = [[sent_tokenize(y)for y in x] for x in test3] #sentence tokenize remaining text 
            test5 = [[re.sub('[^A-Za-z ]+', ' ', y) for y in x[0]] for x in test4] #remove all numbers *SKETCH
            test6 = [[y.strip() for y in x if x] for x in test5] #strip trailing and leading white space 
            test7 = [[y for y in x if not y ==''] for x in test6] #remove blank strings from list of strings 
            test8 = [[y for y in x if len(y) > 9] for x in test7] #remove blank strings from list of strings 
            test81= [[re.sub("\.{2,}" , ".",y) for y in x ] for x in test8] #replace multiple period with single period
            test9 = [[re.sub(' +',' ',y) for y in x ] for x in test81] #replace multiple spaces with single space 
            test10 = [[y.lower() for y in x ] for x in test9] #replace multiple spaces with single space 
            
            #process text for output to pdf 
            origtext_delim = [x.split(delim) for x in test] #split based on custom delimiter
            origtext_delim = [[y.replace('\n',' ') for y in x] for x in origtext_delim] #replace all new line characters 
            origtext_delim = [[sent_tokenize(y)for y in x] for x in origtext_delim] #sentence tokenize remaining text 
            origtext_delim = [[y.strip() for y in x[0] if x[0]] for x in origtext_delim] #strip trailing and leading white space  *SKETCH
            origtext_delim = [[y for y in x if not y ==''] for x in origtext_delim] #remove blank strings from list of strings 
            origtext_delim= [[y for y in x if len(y) > 9] for x in origtext_delim] #remove blank strings from list of strings 
            origtext_delim= [[re.sub("\.{2,}" , ".",y) for y in x ] for x in origtext_delim] #replace multiple period with single period
            origtext_delim= [[re.sub(' +',' ',y) for y in x ] for x in origtext_delim] #replace multiple spaces with single space 
            origtext_delim= [[y.strip() for y in x if x] for x in origtext_delim] #strip trailing and leading white space 
    
        else: 
            #process text for use in word embedding models 
            test1 = test 
            test2 = [y.replace('\n',' ') for y in test1] #replace all new line characters 
            test3=  [re.sub(' +',' ',y) for y  in test2] #replace multiple spaces with single space 
            test4 = [sent_tokenize(y)for y in  test3] #sentence tokenize remaining text 
            test5 = [[re.sub('[^A-Za-z ]+', ' ', y) for y in x] for x in test4] #remove all numbers 
            test6 = [[y.strip() for y in x if x] for x in test5] #strip trailing and leading white space 
            test7 = [[y for y in x if not y ==''] for x in test6] #remove blank strings from list of strings 
            test8= [[y for y in x if len(y) > 9] for x in test7] #remove blank strings from list of strings 
            test81= [[re.sub("\.{2,}" , ".",y) for y in x ] for x in test8] #replace multiple periods with single period 
            test9= [[re.sub(' +',' ',y) for y in x ] for x in test81] #replace multiple spaces with single space 
            test10 = [[y.lower() for y in x ] for x in test9] #replace multiple spaces with single space 
            
            #process text for output to pdf 
            origtext_delim = [y.replace('\n',' ') for y in test1] #replace all new line characters 
            origtext_delim=  [re.sub(' +',' ',y) for y  in origtext_delim] #replace multiple spaces with single space 
            origtext_delim = [sent_tokenize(y)for y in  origtext_delim] #sentence tokenize remaining text 
            origtext_delim = [[y.strip() for y in x if x] for x in origtext_delim] #strip trailing and leading white space 
            origtext_delim = [[y for y in x if not y ==''] for x in origtext_delim] #remove blank strings from list of strings 
            origtext_delim= [[y for y in x if len(y) > 9] for x in origtext_delim] #remove blank strings from list of strings 
            origtext_delim= [[re.sub("\.{2,}" , ".",y) for y in x ] for x in origtext_delim] #replace multiple periods with single period 
            origtext_delim= [[re.sub(' +',' ',y) for y in x ] for x in origtext_delim] #replace multiple spaces with single space 
            
      
        #create list of original text with or without windowing depending on option specs
        origtext_delimlist = []
        for doc in origtext_delim:
            if window==False:
                origtext_delimlist.append(doc)
            if window==True: 
                origtext_delimlist.append([X[1] for X in list(previous_and_next(doc)) if name_in_sent(X[0].lower(),X[1].lower(),X[2].lower(),fname.lower(),lname.lower())])
        
        #identify window of sentences around teh first and last name of the individual being processed 
        test11= []
        for doc in test10:
            if window==True: 
                 #if the entity name is sound in the string 
                #extract the sentence before, the sentence, and the sentence after the sentence 
                test11.append([X[1] for X in list(previous_and_next(doc)) if name_in_sent(X[0].lower(),X[1].lower(),X[2].lower(),fname.lower(),lname.lower())])
                #test10.append([X for X in doc if name_in_sent(X[0].lower(),X[1].lower(),X[2].lower(),se.entity_fname.lower(),se.entity_lname.lower())])
            else: 
                test11.append(doc)
        return test11 , origtext_delimlist






            
#    def extract_web_results(self,responsetext):
#    #@timeout(config.timeout)#qykqykqyk
#        def text_from_html(htmltext, parser):
#            def tag_visible(element):
#                if element.parent.name in ['style', 'script', 'head', 'title', 'meta', '[document]']:
#                    return False
#                if isinstance(element, Comment):
#                    return False
#                return True
#            try:
#                soup = BeautifulSoup(htmltext, parser)
#                texts = soup.findAll(text=True)
#                visible_texts = filter(tag_visible, texts)  
#                return u" ".join(t.strip() for t in visible_texts)
#            except:
#                return ''
#    
#    #clean raw htm text slightly to enable effective windowing 
#        text = text_from_html(responsetext, "html") #text to process and manipulate 
#        text = text.strip()
#        extracted_text = re.sub("\.{2,}" , ".",text)
#        #text = re.sub(' +',' ',text)
#            
#        #apply windowing critera
#        #extracted_text = window_search_regex(text, fname, lname, entity)    #extract relevant text from URL (and convert to lwoer)
#        
#        ## Now try with lxml parser, if extracted text is blank
#        if extracted_text == '':
#            text = text_from_html(responsetext,"lxml")
#            text = text.strip()
#            extracted_text = re.sub("\.{2,}" , ".",text)
#            #text = re.sub(' +',' ',text)
#            #extracted_text = window_search_regex(text, fname, lname,entity)
#        return extracted_text
#    #except:
#    #    return ''
