# -*- coding: utf-8 -*-
"""
Created on Thu Jul 26 23:08:07 2018

@author: qiyi1
"""

import scrapy
from fake_useragent import UserAgent
#from bs4 import BeautifulSoup as BS
#from scrapy.shell import inspect_response
'''
Currently HTML only
No pdf links
'''


class FinraNewsSpider(scrapy.Spider):
    name = 'finra_news_search'
#Warning: customer settings not verify     
    custom_settings = {
        #'FEED_URI': '</home/docadmin/ZackC/NN_Gitlab/adhoc_troubleshoot/output/FinraLinks.csv>',
        #, 'FEED_EXPORTERS': {'pickle': 'scrapy.exporters.PickleItemExporter'
        #FEED_EXPORT_FEILDS
        #'FEED_FORMAT': 'csv'
        'ITEM_PIPELINES': {'RegulatoryNews.pipelines.FinraNewsPipeline2json': 300,
                'RegulatoryNews.pipelines.FinraNewsPipeline2csv': 500},            
        'AUTOTHROTTLE_ENABLED': 'True',
        'AUTOTHROTTLE_TARGET_CONCURRENCY': '1.0',
        'RANDOMIZE_DOWNLOAD_DELAY': 'True',
        'USER_AGENT': UserAgent().random,
        'ROBOTSTXT_OBEY': 'False',
        'HTTPCACHE_ENABLED': 'False',
        'LOG_STDOUT': 'True',
        #'LOG_LEVEL': 'WARNING',
        'LOG_LEVEL': 'DEBUG', 
        'DOWNLOAD_TIMEOUT': str(10),
        'RETRY_ENABLED': False,
        'CLOSESPIDER_TIMEOUT':'500',
        'DOWNLOAD_DELAY':'0.25'
    
       }

  

    #allowed_domains = [fdic_name_search(self.entity_name)[1]]
    def __init__(self, entity_name='', **kwargs):
        #self.start_urls = [fdic_name_search(entity_name)]
        self.entity=entity_name
        #self.start_urls=["https://www.occ.gov/OCCSearch/Search.aspx?output=xml_no_dtd&client=OCC_Main&proxystylesheet=OCC_Main&entqr=0&ud=1&sort=date%3AD%3AL%3Ad1&site=News_Current&ie=UTF-8&oe=UTF-8&filter=0&q=morgan+stanley&Submit=Search"]
        self.start_urls=[self.finra_querry_page(entity_name)]
        super().__init__(**kwargs)  # python3
    
    #@classmethod
    def finra_querry_page(self,name):
        namesplit = []
        name = name.replace("\'s","%2527").strip()
        namesplit = name.split()
        safe_dict ={}
        safe_dict['namesplit'] = namesplit
        namelen= len(namesplit)
        formatset = "{}%2520"*(namelen-1)+"{}"
        #fdic = str("https://search.fdic.gov/search?q={}&btnG=Search&output=xml_no_dtd&oe=ISO-8859-1&ie=ISO-8859-1&client=press&proxystylesheet=wwwGOV&wc=200&:%20wc_mc=1&ud=1&wc_mc=1&exclude_apps=1&site=press&ulang=en&ip=10.30.1.36&access=p&entqr=0&entqrm=0&filter=0&sort=date%3AD%3AS%3Ad1".format(name) if namelen ==1 else
        #           "https://search.fdic.gov/search?q="+formatset+"&btnG=Search&output=xml_no_dtd&oe=ISO-8859-1&ie=ISO-8859-1&client=press&proxystylesheet=wwwGOV&wc=200&:%20wc_mc=1&ud=1&wc_mc=1&exclude_apps=1&site=press&ulang=en&ip=10.30.1.36&access=p&entqr=0&entqrm=0&filter=0&sort=date%3AD%3AS%3Ad1").format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
        #occ=str("https://www.occ.gov/OCCSearch/Search.aspx?output=xml_no_dtd&client=OCC_Main&proxystylesheet=OCC_Main&entqr=0&ud=1&sort=date%3AD%3AL%3Ad1&site=News_Current&ie=UTF-8&oe=UTF-8&filter=0&q={}&Submit=Search".format(name) else "https://www.occ.gov/OCCSearch/Search.aspx?output=xml_no_dtd&client=OCC_Main&proxystylesheet=OCC_Main&entqr=0&ud=1&sort=date%3AD%3AL%3Ad1&site=News_Current&ie=UTF-8&oe=UTF-8&filter=0&q="+formatset+"&Submit=Search".format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
        #fdic = str("https://search.fdic.gov/search?q={}&btnG=Search&output=xml_no_dtd&oe=ISO-8859-1&ie=ISO-8859-1&client=press&proxystylesheet=wwwGOV&wc=200&:%20wc_mc=1&ud=1&wc_mc=1&exclude_apps=1&site=press&ulang=en&ip=10.30.1.36&access=p&entqr=0&entqrm=0&filter=0&sort=date%3AD%3AS%3Ad1".format(name) if namelen ==1 else
        #           "https://search.fdic.gov/search?q="+formatset+"&btnG=Search&output=xml_no_dtd&oe=ISO-8859-1&ie=ISO-8859-1&client=press&proxystylesheet=wwwGOV&wc=200&:%20wc_mc=1&ud=1&wc_mc=1&exclude_apps=1&site=press&ulang=en&ip=10.30.1.36&access=p&entqr=0&entqrm=0&filter=0&sort=date%3AD%3AS%3Ad1").format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
        
        
        #occ = str("https://www.occ.gov/OCCSearch/Search.aspx?output=xml_no_dtd&client=OCC_Main&proxystylesheet=OCC_Main&entqr=0&ud=1&sort=date%3AD%3AL%3Ad1&site=News_Current&ie=UTF-8&oe=UTF-8&filter=0&q={}&Submit=Search".format(name) if namelen ==1 else
        #           "https://www.occ.gov/OCCSearch/Search.aspx?output=xml_no_dtd&client=OCC_Main&proxystylesheet=OCC_Main&entqr=0&ud=1&sort=date%3AD%3AL%3Ad1&site=News_Current&ie=UTF-8&oe=UTF-8&filter=0&q="+formatset+"&Submit=Search").format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
          
        finra=str("http://www.finra.org/search/global/{}".format(name) if namelen ==1 else
                   "http://www.finra.org/search/global/"+formatset).format(*tuple([ eval('namesplit[{}]'.format(str(i)),{"__builtins__":None},safe_dict) for i in range(namelen)]))
          
        #root_url = "search.fdic.gov"
        return finra
    
    def parse(self, response):

        #inspect_response(response, self)
        
        #identify the relative xpath associated with the document links
        #DocumentLinks = response.xpath('.//div//a[@ctype="c"]')
        DocumentLinks=response.xpath(".//li[@class='search-result']/h2[@class='title']/a/@href").extract()
        #extract the articles one at a time
        num=0
        for Link in DocumentLinks:
            num=num+1
            #Link = FinLink()
            #Link['links'] = 
            #Link=article.xpath('.//@href').extract_first()
            #Link = article.xpath('.//@href').extract_first()
            
            
            
            response_type=Link.split('.')[-1]   
            
            #yield {'link':Link}
            if response_type in ('pdf','xlsx','xls'):
                #yield {'url': Link,'content': Link}
                pass
            else:
                #print('xxxxxurl'+str(num),Link)
                #yield {'url': Link,'content': scrapy.Request(Link,self.content_parse)} # YQ: I assume Link is a herf, otherwise use scrapy.Request 
                yield scrapy.Request(Link,self.content_parse)
            #response.follow(article,self.content_parse)
        #identify the xpath for the next page link 
        #next_page_url = response.xpath(".//span[@class='s']//a[@ctype='nav.next']//@href").extract()[0]
        next_page= response.xpath(".//div[@class='item-list']/ul[@class='pager']/li[@class='pager__item--next pager__item']/a/@href").extract_first()
        if next_page is not None:
            yield response.follow(next_page,callback=self.parse)
        ###next_page_url = response.xpath(".//a[@ctype='nav.next']//@href").extract()[0]
        
        #if the next page link exists we generate a URL and then send another request to extract 
        
        ######if next_page_url:
        ######    absolute_next_page_url = response.urljoin(next_page_url)
            #print(absolute_next_page_url)
        ######    yield scrapy.Request(absolute_next_page_url,self.parse)
            
    def content_date_parse(self,response):
        '''
        only for content_parse
        '''
        try:
            return response.xpath(".//div[@class='field-item even field field--name-field-core-official-dt field--type-datetime field--label-inline clearfix field-item-content field-item-date field-item-date']//text()").extract_first()
        except: 
            return None
        
    def content_parse(self,response):
        
         '''
         parse news page content/date...
         '''
         #print("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww")
         #print (response.url)
         #inspect_response(response,self)
         '''
         --All text
         soup=BS(response.text)
         yield {'url':response.url,'content':soup.text}
         #pass
         '''
         
         '''
         
         --All text
         soup=BS(response.xpath("/div[@id='newsRelease']//text()"))
         yield {'url':response.url,'content':soup.text}
         #pass
         
         '''
         yield { 'entity':self.entity,
                 'url':response.url,
                #'id': response.xpath(".//div[@class='articleIdentifier']/text()").extract_first(),
                'title':  response.xpath(".//h1[@class='core-title']//text()").extract_first(),
                'date': self.content_date_parse(response),
                #'author':response.xpath(".//div[@class='articleContactInfo']/text()").extract_first().split(': ')[1],
                'content': ' '.join( response.xpath(".//div[@class='field-item even field field--name-body field--type-text-with-summary field--label-hidden']/p//text()").extract())
                }

#if __name__=='__main__':
#    from scrapy.crawler import CrawlerProcess
#    from scrapy.utils.project import get_project_settings
#    import time
#    import os
#    import sys
#    process = CrawlerProcess({
#    'USER_AGENT': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)'
#})
#    process.crawl(OccSearchSpider)
#    process.start()



#######################################################################################


#    time.sleep(0.5)
#
#    os.execl(sys.executable, sys.executable, *sys.argv)
#    process.stop()
#    
#    
#    import scrapy.crawler as crawler
#    from multiprocessing import Process, Queue
#    from twisted.internet import reactor
#    def run_spider():
#        def f(q):
#            try:
#                runner = crawler.CrawlerRunner()
#                deferred = runner.crawl(OccSearchSpider)
#                deferred.addBoth(lambda _: reactor.stop())
#                reactor.run()
#                q.put(None)
#            except Exception as e:
#                q.put(e)
#
#        q = Queue()
#        p = Process(target=f, args=(q,))
#        p.start()
#        result = q.get()
#        p.join()
#        
#        if result is not None:
#            raise result
#
#    run_spider()
#    
#    from crochet import setup
#    from importlib import import_module
#    from scrapy.crawler import CrawlerRunner
#    setup()
#
#    def run_spider(spiderName):
#        #module_name="OccScrapy.spiders.{}".format(spiderName)
#        #scrapy_var = import_module(module_name)   #do some dynamic import of selected spider   
#        #spiderObj=scrapy_var.mySpider()           #get mySpider-object from spider module
#        crawler = CrawlerRunner()   #from Scrapy docs
#        #crawler.crawl(spiderObj)
#        crawler.crawl(spiderName)                          #from Scrapy docs
#
#    run_spider(OccSearchSpider)
#
##    def parse(self, response):
##        # follow links to author pages
##        for href in response.css('.author + a::attr(href)'):
##            yield response.follow(href, self.parse_author)
##
##        # follow pagination links
##        for href in response.css('li.next a::attr(href)'):
##            yield response.follow(href, self.parse)
##
##    def parse_author(self, response):
##        def extract_with_css(query):
##            return response.css(query).extract_first().strip()
##
##        yield {
##            'name': extract_with_css('h3.author-title::text'),
##            'birthdate': extract_with_css('.author-born-date::text'),
##            'bio': extract_with_css('.author-description::text'),
##        }