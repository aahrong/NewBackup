# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
#import csv
import json

#sumy
#from bs4 import BeautifulSoup
#from sumy.parsers.html import HtmlParser
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer
from sumy.summarizers.lex_rank import LexRankSummarizer
from sumy.summarizers.luhn import LuhnSummarizer
from sumy.summarizers.text_rank import TextRankSummarizer
#from sumy.utils import get_stop_words
#import sumy
#from nltk import sent_tokenize

def generate_summary(method,LANGUAGE,articletext,n_sentence):
    """
    1.	Method: the method to generate the summary. The listed value could be “Lex Rank”, “Luhn”,”Text Rank”
    2.	n_sentence: The number of sentences to extract from the text to generate the summary. The default value is 2, but for longer text, there’s more information/entropy, it could be 3
    3.	articletext: As discussed, we would use the text/article from the front end as input.
    
    """
    #articletext=dd['content'] 
    #LANGUAGE='english'
    #n_sentence=3
    parser=PlaintextParser.from_string(articletext,Tokenizer(LANGUAGE))
    try:
        if method=='Lex Rank':
            SUMMARIZER=LexRankSummarizer()
            summary=SUMMARIZER(parser.document,n_sentence)
        elif method=='Luhn':
            SUMMARIZER = LuhnSummarizer()
            summary=SUMMARIZER(parser.document,n_sentence)
        elif method=='Text Rank':
            SUMMARIZER = TextRankSummarizer()
            summary=SUMMARIZER(parser.document,n_sentence)
            
        return summary
    except:
        print("input for generating summary is incorrect!")
        return None
    
    #for sentence in summary:
        #print(sentence)
    


#class OccNewsPipeline2csv(object):
#    def open_spider(self,spider):
#        #self.file=open("C:/Engagements/NN/OccScrapy/OccScrapy/output/OccLinks.csv", "w")
#        self.file=open("C:/Engagements/NN/RegulatoryNews/output/occ_news.csv", "a+")
#        self.wr= csv.writer(self.file, dialect='excel')
#    def process_item(self, item, spider):
#        #print('kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk')
#        #print(item)
#        #self.file=open("C:/Engagements/NN/OccScrapy/OccScrapy/output/OccLinks.csv", "a+")
#        row_list =list(item.values())
#        self.wr.writerow(row_list)
#        #self.file(value)
#        #print(value)
#        #return item
#
#    def close_spider(self,spider):
#        self.file.close()
#        
#        
#class OccNewsPipeline2json(object):
#    def open_spider(self, spider):
#        self.file = open('C:/Engagements/NN/RegulatoryNews/output/occ_items.jl', 'a+')# 'a+' or 'w' depends on needs
#
#    def close_spider(self, spider):
#        self.file.close()
#
#    def process_item(self, item, spider):
#        #print('KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK')
#        #print(type(item))
#        #print(item)
#        #line = json.dumps(dict(item)) + "\n"
#        #item=dd
#        _item=item
#        summ=generate_summary(method='Luhn',LANGUAGE='english',articletext=item['content'],n_sentence=3)
#        
#        _item['summay'] = [str(s) for s in summ]
#        line = json.dumps(_item) + "\n"
#        self.file.write(line)
#        
#        
#        return item
#    
#class FinraNewsPipeline2csv(object):
#    def open_spider(self,spider):
#        #self.file=open("C:/Engagements/NN/OccScrapy/OccScrapy/output/OccLinks.csv", "w")
#        self.file=open("C:/Engagements/NN/RegulatoryNews/output/finra_news.csv", "a+")
#        self.wr= csv.writer(self.file, dialect='excel')
#    def process_item(self, item, spider):
#        #print('kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk')
#        #print(item)
#        #self.file=open("C:/Engagements/NN/OccScrapy/OccScrapy/output/OccLinks.csv", "a+")
#        row_list =list(item.values())
#        self.wr.writerow(row_list)
#        #self.file(value)
#        #print(value)
#        #return item
#
#    def close_spider(self,spider):
#        self.file.close()
#        
#        
#class FinraNewsPipeline2json(object):
#    def open_spider(self, spider):
#        self.file = open('C:/Engagements/NN/RegulatoryNews/output/fira_items.jl', 'a+')# 'a+' or 'w' depends on needs
#
#    def close_spider(self, spider):
#        self.file.close()
#
#    def process_item(self, item, spider):
#        #print('KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK')
#        #print(type(item))
#        #print(item)
#        #line = json.dumps(dict(item)) + "\n"
#        #item=dd
#        _item=item
#        summ=generate_summary(method='Luhn',LANGUAGE='english',articletext=item['content'],n_sentence=3)
#        
#        _item['summay'] = [str(s) for s in summ]
#        line = json.dumps(_item) + "\n"
#        self.file.write(line)
#        
#        
#        return item
    
#class RegulatoryNewsPipeline2csv(object):
#    def open_spider(self,spider):
#        #self.file=open("C:/Engagements/NN/OccScrapy/OccScrapy/output/OccLinks.csv", "w")
#        self.file=open("C:/Engagements/NN/RegulatoryNews/output/regulatory_news.csv", "a+")
#        self.wr= csv.writer(self.file, dialect='excel')
#    def process_item(self, item, spider):
#        #print('kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk')
#        #print(item)
#        #self.file=open("C:/Engagements/NN/OccScrapy/OccScrapy/output/OccLinks.csv", "a+")
#        row_list =list(item.values())
#        if item['content']!=None:
#            self.wr.writerow(row_list)
#        #self.file(value)
#        #print(value)
#        #return item
#
#    def close_spider(self,spider):
#        self.file.close()
        
        
class RegulatoryNewsPipeline2json(object):
    def open_spider(self, spider):
        self.file = open(spider.output_dir+spider.entity+'.jl', 'a+')# 'a+' or 'w' depends on needs

    def close_spider(self, spider):
        self.file.close()

    def process_item(self, item, spider):
        #print('KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK')
        #print(type(item))
        #print(item)
        #line = json.dumps(dict(item)) + "\n"
        #item=dd
        _item=item
        summ=generate_summary(method='Luhn',LANGUAGE='english',articletext=item['content'],n_sentence=3)
        
        _item['summary'] = [str(s) for s in summ]
        line = json.dumps(_item) + "\n"
        if _item['content']!="":
            self.file.write(line)
                
        return item
    
class NewsapiPipeline2json(object):
    def open_spider(self, spider):
        self.file = open(spider.output_dir+spider.entity+'_newsapi'+'.jl', 'a+')# 'a+' or 'w' depends on needs

    def close_spider(self, spider):
        self.file.close()

    def process_item(self, item, spider):
        #print('KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK')
        #print(type(item))
        #print(item)
        #line = json.dumps(dict(item)) + "\n"
        #item=dd
        #item
        summ=generate_summary(method='Luhn',LANGUAGE='english',articletext=item['summary'][0]+' '+item['origtext'],n_sentence=3)
        
        item['summary'] = [str(s) for s in summ]
        line = json.dumps(item) + "\n"
        #if item['content']!="":
        self.file.write(line)
                
        return item
    
class BingsPipeline2json(object):
    def open_spider(self, spider):
        self.file = open(spider.output_dir+spider.entity+'_bing'+'.jl', 'a+')# 'a+' or 'w' depends on needs

    def close_spider(self, spider):
        self.file.close()

    def process_item(self, item, spider):
        #print('KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK')
        #print(type(item))
        #print(item)
        #line = json.dumps(dict(item)) + "\n"
        #item=dd
        #item
        summ=generate_summary(method='Luhn',LANGUAGE='english',articletext=item['origtext'],n_sentence=3)
        
        item['summary'] = [str(s) for s in summ]
        line = json.dumps(item) + "\n"
        #if item['content']!="":
        self.file.write(line)
                
        return item