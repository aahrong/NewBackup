# -*- coding: utf-8 -*-
"""
Created on Wed Feb 14 16:26:52 2018

@author: yangbo
"""
#import os
#scraper_dir = 'C:\\Users\\yangbo\\Documents\\Engagements\\04 INTAML\\Negative_News\\'
#os.chdir(scraper_dir)
from flask import Flask, request, render_template, Response
import sys
import time
import os
#import subprocess
import config
from scrapyd_api import ScrapydAPI
import json
import DTCC_E2E_TBSHT
from fileupload import saveFile
from nn_base.load_source_data import loadExcel

#subprocess.Popen('scrapyd')
app = Flask(__name__)
app.config["APPLICATION_ROOT"] = os.environ.get('SERVER_CONTEXT_PATH', '/')
APPLICATION_ROOT = os.environ.get('SERVER_CONTEXT_PATH', '/')

@app.route(APPLICATION_ROOT)
def main():
    return render_template('NN_UI.html')

@app.route(APPLICATION_ROOT + "batchengine")    
def bulkenginge():
    """files = request.files['filename']
    filename = 'file1.xlsx'
    filepath = saveFile(files,filename,None)"""
    #filepath = config.source_path + config.source_excel_file
    """data = loadExcel(config.source_path
        , config.source_excel_file
        , config.source_excel_names
        )
    data = list(loadExcel(config.source_path, config.source_excel_file, config.source_excel_names)['FirstName'])
    print(data)"""
    test = loadExcel(config.source_path, config.source_excel_file, config.source_excel_names)
    tuples = [tuple(x) for x in test.values]
    out1 = []
    out2 = []
    for i in range(len(tuples)):
        if tuples[i][1]==1:
            out1.append(tuples[i][2]) #output the name of the entity oonly 
        else:         
            out2.append(tuples[i][2:5]) #output everything 
    print (out1)
    print (out2)
    newsource = request.args.get('newssource', default='', type=str)
    yearsubset = request.args.get('yearsubset', default='', type=str)
    maxsentslider = request.args.get('maxsentslider', default='', type=float)
    minsimslider = request.args.get('minsemslider', default='', type=float)
    searchresultlimiter = request.args.get('searchresullimiter', default='', type=int)
    dsearchterms = request.args.get('dsearchterms', default='', type=str)
    csearchterms = request.args.get('csearchterms', default='', type=str)
    entity_names = out1
    
    #ZJC ADD FOR ALISHEIK TO INTERGRATE 
    indv_info = out2
    dsearch_terms = dsearchterms.split(',') if dsearchterms !='' else []
    csearch_terms = csearchterms.split(',') if csearchterms !='' else []
    total_search_terms = dsearch_terms + csearch_terms
    news_source= newsource.split(',') if newsource !='' else []
    year_subset = yearsubset.split('-') if yearsubset !='' else ['','']
    yearsubset = int(year_subset[0]) if year_subset[0]!='' else 2000
    monthsubset = int(year_subset[1])if year_subset[0]!='' else 1
    print(yearsubset)

    #ZJC ADD FOR ALISHEIK TO INTERGRATE
    #Add parameter to call_spider to indicate waht type of information is being passed(provided for both indv and entity below)
    # esentially spidercall becomes the location where the entity toggle will be in non batch and the entity_flag that is in the xlsx for batch 
    #format of indv_info: bing_entity_querry_list=[('Lloyd Blankfein','Goldman Sachs','new york')]
    #try:
    filename = DTCC_E2E_TBSHT.call_spider(entity_names, news_source,yearsubset,monthsubset,maxsentslider,minsimslider,searchresultlimiter,total_search_terms,spidercall=1)
    filename_indv = DTCC_E2E_TBSHT.call_spider(indv_info, news_source,yearsubset,monthsubset,maxsentslider,minsimslider,searchresultlimiter,total_search_terms,spidercall=0)
    #filename = DTCC_E2E_v1.call_spider(entity_names, news_source,yearsubset,monthsubset,maxsentslider,minsimslider,searchresultlimiter)
    print("filename",filename_indv)
    print("filename:",filename)
    return(filename)
    #except:
      #return("failed")

@app.route(APPLICATION_ROOT + "engine")
def enginge():
    #ZJC
    #HOOK UP ENTITY TOGGLE SO WE CAN NAVIGATE TO CORRECT SPIDER
    spidercall = request.args.get('spiderselect', default='', type=int)
    name= request.args.get('name', default='', type=str)
    company= request.args.get('company', default='', type=str)
    state= request.args.get('state', default='', type=str)
    induvidualdetails = (name,company,state)
    bname = request.args.get('entityname', default='', type=str)
    newsource = request.args.get('newssource', default='', type=str)
    yearsubset = request.args.get('yearsubset', default='', type=str)
    maxsentslider = request.args.get('maxsentslider', default='', type=float)
    minsimslider = request.args.get('minsemslider', default='', type=float)
    searchresultlimiter = request.args.get('searchresullimiter', default='', type=int)
    dsearchterms = request.args.get('dsearchterms', default='', type=str)
    csearchterms = request.args.get('csearchterms', default='', type=str)
    induvidual_details = [induvidualdetails]
    print(induvidual_details)
    dsearch_terms = dsearchterms.split(',') if dsearchterms !='' else []
    csearch_terms = csearchterms.split(',') if csearchterms !='' else []
    total_search_terms = dsearch_terms + csearch_terms
    entity_names = bname.split(',') if bname !='' else ['BBVA']
    news_source= newsource.split(',') if newsource !='' else []
    year_subset = yearsubset.split('-') if yearsubset !='' else ['','']
    yearsubset = int(year_subset[0]) if year_subset[0]!='' else 2000
    monthsubset = int(year_subset[1])if year_subset[0]!='' else 1
    print(yearsubset)
    print(type(yearsubset))
    print(total_search_terms)

    #ZJC ADD HERE (MAKE SPIDER CALL THE TOGGLE LINKED TO ENTITY/INDIVIDUAL IN THE UI, DONT LINK IT TO config.entity)
    #filename = DTCC_E2E_v1.call_spider(entity_names, news_source,yearsubset,monthsubset,maxsentslider,minsimslider,searchresultlimiter)
    try:
      if spidercall ==1:
          filename = DTCC_E2E_TBSHT.call_spider(entity_names, news_source,yearsubset,monthsubset,maxsentslider,minsimslider,searchresultlimiter,total_search_terms,spidercall=1)
      else: 
          filename = DTCC_E2E_TBSHT.call_spider(induvidual_details, news_source,yearsubset,monthsubset,maxsentslider,minsimslider,searchresultlimiter,total_search_terms,spidercall=0)
      print("filename",filename)
      return(filename)
    except:
      return("failed")
    
@app.route(APPLICATION_ROOT + "download")
def download_file():
    filepath = request.args.get('filename', default='', type=str)
    #filep = filepath.split('.')
    #filepath = filep[0]+'.docx'
    print(filepath)
    #response= Response(open(filepath,'rb').read(),mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    response= Response(open(filepath,'rb').read(),mimetype="application/pdf")
    #response['Content-Disposition']='attachment; filename='+filename
    #response.headers['Content-disposition'] = 'attachment; filename='+ filepath
    return response

@app.route(APPLICATION_ROOT + "downloadword")
def download_word_file():
    filepath = request.args.get('filename', default='', type=str)
    filep = filepath.split('.')
    filepath = filep[0]+'.docx'
    print(filepath)
    response= Response(open(filepath,'rb').read(),mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    #response= Response(open(filepath,'rb').read(),mimetype="application/pdf")
    #response['Content-Disposition']='attachment; filename='+filename
    #response.headers['Content-disposition'] = 'attachment; filename='+ filepath
    return response


if __name__=="__main__":
    #subprocess.Popen(['scrapyd'])
    app.run(host='0.0.0.0',port=6006,debug=True)

#negative_news_single()
