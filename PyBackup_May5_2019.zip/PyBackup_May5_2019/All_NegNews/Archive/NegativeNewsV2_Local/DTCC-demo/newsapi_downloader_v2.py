# -*- coding: utf-8 -*-
"""
Created on Sun Aug 12 09:35:59 2018

@author: qiyi1
"""

#import os
from newsapi import NewsApiClient
from sumy.parsers.html import HtmlParser
from sumy.nlp.tokenizers import Tokenizer
from sumy.summarizers.lsa import LsaSummarizer as Summarizer
from sumy.nlp.stemmers import Stemmer

import os
import datetime
from time import sleep
import shutil

import json
import config as config
#import json
#import pandas as pd
#import simplejson
#import csv

#from random import randint
#seed=config.api_list[randint(0, len(config.api_list)-1)]
#api = NewsApiClient(api_key=seed)

api= NewsApiClient(api_key='e39db5f4192849598f4d31e2efcaa1e0')
def generate_summary(url,n_sentence):
    #method = 'Luhn'
    LANGUAGE ='english'
    parser = HtmlParser.from_url(url, Tokenizer(LANGUAGE))
    stemmer = Stemmer(LANGUAGE)
    summarizer = Summarizer(stemmer)
    print('url: '+url)
    print(parser.document)
    #summarizer.stop_words = get_stop_words(LANGUAGE)
    try:
        rlt=summarizer(parser.document, n_sentence)
        return list(map(lambda x:' '.join(x.words)+'.',rlt))
    except:
        return []

def newsapi_downloader(output_dir,entity_list=[],domain_list=[],start = None,end = None, sort_by='relevancy', num_pages = 1):#publishedAt
    #start:YYYY-MM-DD ## sort_by='relevancy'
    #entity_list=['morgan stanley','bank of america']
    #domain_list=['bloomberg.com','cnn.com']
    #output_dir='C:\\Engagements\\NN\\NewApi\\output\\'
    #entity='morgan stanley'
    #if num_results <= 100:
    #    page_size_r = num_results
    #    page_r = 1
    #else:
    #    page_size_r = 100
    #    page_r = num_results//100 +1
    #    last_page_size = num_results%100
    
    if domain_list==[]:
        for entity in entity_list: 
          file=open(output_dir+entity+'_newsapi.jl','a+')
          
          dic_rlt_list=[]
          for i in range(1,num_pages+1):               
              dic_rlt_page=api.get_everything(q=entity
                                        , from_param=start ###YYYY-MM-DD
                                        , to=end
                                        , language='en'
                                        , sort_by=sort_by
                                        , page_size=100#####from 1 to 100
                                        , page=i)['articles']######'relevancy' YqZ
              dic_rlt_list = dic_rlt_list+list(dic_rlt_page)
            
          for item in dic_rlt_list:
              file.write(json.dumps({'source':item['source']['name'],'entity':entity, 'title':item['title'],'date':item['publishedAt'],'content':''#.join(generate_summary(item['url'],n_sentence=300))
                                     ,'summary':[item['description']],'url':item['url']})+'\n')
              sleep(0.05)
          file.close()
    else:
        for entity in entity_list: 
          file=open(output_dir+entity+'.jl','a+')
          for web in domain_list:
            dic_rlt_list=[]
            for i in range(1,num_pages+1):
                dic_rlt_page=api.get_everything(q=entity
                                    , domains=web
                                    , from_param=start ###YYYY-MM-DD
                                    , to=end
                                    , language='en'
                                    , sort_by=sort_by
                                    , page_size=100
                                    , page=i)['articles']######'relevancy' YqZ
                dic_rlt_list = dic_rlt_list+list(dic_rlt_page)
            
            for item in dic_rlt_list:
                file.write(json.dumps({'source':item['source']['name'],'entity':entity, 'title':item['title'],'date':item['publishedAt'],'content':' '#.join(generate_summary(item['url'],n_sentence=300))
                                         ,'summary':[item['description']],'url':item['url']})+'\n')
                sleep(0.05)
          file.close()
          

if __name__=="__main__":
    #entity_list=['morgan stanley','bank of america']
    #domain_list=['bloomberg.com','cnn.com']
    names=[
    "Nomura",
    "Schwab",
    "UBS",
    "Barclays",
    "Credit Suisse",
    "Guggenheim",
    "Societe Generale",
    "ETrade",       
    
    "Morgan Stanley",
    "JP Morgan",
    "Citi",
    "Bank of America",
    "Wells Fargo",
    "Deutsche Bank",
    "Goldman Sachs",
    
           ]

    output_dir="/home/docadmin/YQ/spider/RegulatoryNews/output/"
    #entity='morgan stanley'
    newsapi_downloader(output_dir=output_dir,entity_list=names,domain_list=['bloomberg.com,cnn.com'])
    #collect_jl(output_dir)    