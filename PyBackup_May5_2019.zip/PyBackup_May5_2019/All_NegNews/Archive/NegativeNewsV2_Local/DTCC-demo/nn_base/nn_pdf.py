from __future__ import absolute_import
from __future__ import division, print_function, unicode_literals
import os
import sys 

from nn_base import nn_extractfines as ef  
entity_dict = ef.load_entity_dict('entity_dict.pickle')

import spacy
nlp = spacy.load('en_core_web_sm')
from functools import reduce

import errno
from config import * 
import time
import html
import pdb
import cgi
from nn_base.nn_classes import search_entity as SE
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from PyPDF2 import PdfFileMerger
from docx import Document
from docx.shared import RGBColor

def remove_if_exist(filename):
    try:
        os.remove(filename)
    except OSError as e:
        raise e
        
def create_pdf_summary(se):
    fnames_list = []
    final_fname = pdf_path + str(se.entity_id) + '_' + se.entity_fname + ' ' + se.entity_lname+ ' ' + time.strftime("%m-%d-%Y") + '.pdf'
    finalW_fname = pdf_path + str(se.entity_id) + '_' + se.entity_fname + ' ' + se.entity_lname+ ' ' + time.strftime("%m-%d-%Y") + '.docx'

    for idx in range(0,se.search_lang_ct):
        if se.urllist[idx] == []:
            fname,word = create_empty_page(se, idx)
            fnames_list.append(fname)
        else:
            fname,word = create_nn_page(se, idx)
            fnames_list.append(fname)
    merger = PdfFileMerger()
    toremove=[]
    failed = []
    for idx, pdf in enumerate(fnames_list):
        if pdf != -1:
            temp = open(pdf,'rb')
            merger.append(temp)
            toremove.append(temp)
        else:
            failed.append(se.search_lang[idx])
    with open(final_fname, 'wb') as finalout:
        merger.write(finalout)
    for pdf in toremove:
        pdf.close()
    for pdf in fnames_list:
        if pdf!= -1:
            remove_if_exist(pdf)
    word.save(finalW_fname)
    return final_fname, failed
          
def create_empty_page(se, idx):
    pdf_fname = pdf_path + str(se.entity_id) + '_' + se.entity_fname + ' ' + se.entity_lname+ ' ' + time.strftime("%m-%d-%Y") + '_' + str(idx) + '.pdf'
    styles = getSampleStyleSheet()
    doc = SimpleDocTemplate(pdf_fname, leftMargin = 0.75*inch, rightMargin = 0.75*inch, topMargin = 1*inch, bottomMargin = 1*inch)
    Story=[] 
    h1_1=Paragraph(se.entity_fname + ' ' + se.entity_lname + ' - ' + se.search_lang[idx][0].upper() + se.search_lang[idx][1:], styles['Title'])
    Story.append(h1_1)
    h2_1=Paragraph("Search link", styles['Heading2'])
    Story.append(h2_1)
    print(se.querylisturl[idx])
    p_1 = Paragraph(cgi.escape(se.querylisturl[idx].replace(' ','%20')), styles['Normal'])    
    Story.append(p_1)
    h2_2=Paragraph("No negative links found", styles['Heading2'])
    Story.append(h2_2)
    doc.build(Story)

    #Word doc
    word_doc = Document()
    p = word_doc.add_heading('Entity Searched: ' + str(se.entity_fname), level = 0)
    p = word_doc.add_heading('No negative links found') 

    return pdf_fname,word_doc

    
def create_nn_page(se, idx):
    final_links = se.urllist[idx]
    max_links_for_score = se.LSA_filter_count[idx]
    links_after_filter = len(se.urllist[idx])
    
    if links_after_filter >  search_results:
        max_links_for_score = search_results #search_results_maxoutput
        
    #avg_identity_scores = se.list_fuzzyscore[idx]
    #matched_stems_list  = se.list_matchedstems[idx]
    entity_fname = se.entity_fname
    #non_reg = se.RegNonReg
    normalized_risk_score =min(100,int(se.riskscore_final[idx])) 
    name_fuzzy_score = se.name_fuzzy_all[idx]
    location_fuzzy_score = se.location_fuzzy_all[idx]
    employment_fuzzy_score = se.employment_fuzzy_all[idx]
    #queryurl = se.querylisturl[idx]
    w2vtopsent = se.w2vTopSent[idx]
    summary = se.textsummary[idx]
    regnoreg = se.RegNonReg[idx]
    docCat = se.DocCategory[idx]
    percC = se.Perc[idx]
    newssource = se.NewsSource[idx]
    datelist = se.lastsearchdate[idx]
    docTitles = se.DocTitle[idx]
    NumStartUrls = len(se.origtextlist[idx])

    #Compute regulatory percentages
    from collections import Counter
    c = Counter(regnoreg)
    oo = [(i, c[i] / len(regnoreg) * 100.0) for i in c]
    if len(oo)>1:
        Reg = ([item[1] for item in oo if item[0] == "Regulatory"][0])
        NoReg= ([item[1] for item in oo if item[0] == "Non Regulatory"][0])
        PerReg = 100*(Reg/(Reg+NoReg))
    elif oo[0][0] == 'Non Regulatory':
        PerReg = 0
    else:
        PerReg = 100
    
    #Counters for article types
    regCount = 0.01*PerReg*len(summary)
    MFcount = sum(docCat[0])
    LAcount = sum(docCat[2])
    RRcount = sum(docCat[3])

    styles = getSampleStyleSheet()
    outfn = pdf_path + se.entity_fname + ' ' + se.entity_lname+ ' ' + time.strftime("%m-%d-%Y") + '_' + str(idx) + '.pdf'
    ##WORD
    word_doc = Document()
    
    #try:
    pdf_merge_list =[]
    ## Overview pdf generations
    pdf_filename = pdf_path + se.entity_fname + '_'+se.entity_lname + '_Overview.pdf'
    doc = SimpleDocTemplate(pdf_filename, pagesize=letter, leftMargin = 0.75*inch, rightMargin = 0.75*inch, topMargin = 1*inch, bottomMargin = 2*inch)
    Story=[] 
    h1_1=Paragraph('Entity Searched: ' + se.entity_fname + ' ' + se.entity_lname, styles['Title'])
    p = word_doc.add_heading('Entity Searched: ' + str(se.entity_fname), level = 0)
    Story.append(h1_1)
    p1=Paragraph("<para align=center><br/><font size=11><b><u>Total Negative News Score</u></b></font><font size=8><sup>1</sup></font>: " + str(round(normalized_risk_score,2)) + "%" + "</para>", styles['Heading2']) 
    Story.append(p1)
    p = word_doc.add_heading('Total Negative News Score: ')
    p.add_run(str(round(normalized_risk_score,2)) + "%")
   
    if se.static_search_result != '':
        totallist = [item for searchlist in [list(x[1].keys()) for x in se.static_search_result.items() if len(x[1].keys())>0] for item in searchlist]
        px = Paragraph("<para align=center><font size=10><b><u>Warning: Name Found on targeted search list:</u></b></font></para>", styles['Heading2'])
        Story.append(px)
        for res in totallist:
            px = Paragraph("<para lindent=10><font size=9>"+res+ "</font></para>", styles['Normal'])
            Story.append(px)

    t_h=Paragraph("<para align=center><br/><font size=11><b><u>Details on Links Searched</u></b></font><font size=8><sup>2</sup></font> </para>", styles['Heading2'])
    Story.append(t_h)  
    
    p = word_doc.add_heading("Details on Links Searched", level = 1)
    tableW = word_doc.add_table(rows = 3, cols = 2)
    tableW.style = 'TableGrid'
    cell1 = tableW.cell(0,0)
    cell1.text = 'Links returned'
    cell2 = tableW.cell(0,1)
    cell2.text = str(NumStartUrls)
    cell3 = tableW.cell(1,0)
    cell3.text = 'Remaining after filtering'
    cell4 = tableW.cell(1,1)
    cell4.text = str(links_after_filter)
    cell5 = tableW.cell(2,0)
    cell5.text = 'Negative links used for risk scoring'
    cell6 = tableW.cell(2,1)
    cell6.text = str(max_links_for_score)
    
    p = word_doc.add_heading("Average Relevance Scores", level = 1)
    tableW = word_doc.add_table(rows = 3, cols = 2)
    tableW.style = 'TableGrid'
    cell1 = tableW.cell(0,0)
    cell1.text = 'Name'
    cell2 = tableW.cell(0,1)
    cell2.text = str(name_fuzzy_score) + "%"
    cell3 = tableW.cell(1,0)
    cell3.text = 'Location'
    cell4 = tableW.cell(1,1)
    cell4.text = str(location_fuzzy_score)
    cell5 = tableW.cell(2,0)
    cell5.text = 'Employment'
    cell6 = tableW.cell(2,1)
    cell6.text = str(employment_fuzzy_score)
    
    p = word_doc.add_heading("Regulatory Site Count", level = 1)
    tableW = word_doc.add_table(rows = 2, cols = 3)
    tableW.style = 'TableGrid'
    cell1 = tableW.cell(1,0)
    cell1.text = 'Regulatory Site Articles'
    cell2 = tableW.cell(1,2)
    cell2.text = str(round(PerReg,1)) + "%"
    cell3 = tableW.cell(0,1)
    cell3.text = 'Count'
    cell4 = tableW.cell(1,1)
    cell4.text = str(int(round(regCount,1)))
    cell7 = tableW.cell(0,2)
    cell7.text = 'Percent'
    
    p = word_doc.add_heading("Article type summary", level = 1)
    tableW = word_doc.add_table(rows = 4, cols = 3)
    tableW.style = 'TableGrid'
    cell1 = tableW.cell(0,1)
    cell1.text = 'Count'
    cell2 = tableW.cell(0,2)
    cell2.text = 'Percent'
    cell3 = tableW.cell(1,0)
    cell3.text = 'Monetary Fine'
    cell33 = tableW.cell(1,1)
    cell33.text = str(MFcount)
    cell4 = tableW.cell(1,2)
    cell4.text = str(round(100*percC[0],1)) + "%"
    cell5 = tableW.cell(2,0)
    cell5.text = 'Legal Action'
    cell55 = tableW.cell(2,1)
    cell55.text = str(LAcount)
    cell6 = tableW.cell(2,2)
    cell6.text = str(round(100*percC[2],1)) + "%"
    cell7 = tableW.cell(3,0)
    cell7.text = 'Regulatory References'
    cell77 = tableW.cell(3,1)
    cell77.text = str(RRcount)
    cell8 = tableW.cell(3,2)
    cell8.text = str(round(100*percC[3],1)) + "%"
    
    p = word_doc.add_heading("Domains Searched", level = 1)
    p = word_doc.add_paragraph(" ")
    p.add_run(str(se.entity_querylist))

    word_doc.add_page_break()
    
    
    row1 = Paragraph("<para align=center>Links returned </para>", styles['Normal'])
    row2 = Paragraph("<para align=center>Remaining after filtering</para>", styles['Normal'])
    row3 = Paragraph("<para align=center>Negative links used for risk scoring</para>", styles['Normal'])
    row1_2 = Paragraph('<para align=center>' + str(NumStartUrls) + '</para>', styles['Normal'])
    row2_2 = Paragraph('<para align=center>' + str(links_after_filter) + '</para>', styles['Normal'])
    row3_2 = Paragraph('<para align=center>' + str(max_links_for_score) + '</para>', styles['Normal'])
    data= [[row1, row1_2],
           [row2, row2_2],
           [row3,row3_2]]
    t=Table(data, hAlign='CENTER')
    t.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                          ('BOX', (0,0), (-1,-1), 0.25, colors.black)]))
    Story.append(t)
    p3=Paragraph("<para align=center><font size=11><b><u>Average Relevance Scores</u></b></font><font size=8><sup>3</sup></font> </para>", styles['Heading2'])
    Story.append(p3)
    p4_1 = Paragraph("<para align=center>Name</para>",styles['Normal'])
    p4_2 = Paragraph("<para align=center>Location</para>",styles['Normal'])
    p4_3 = Paragraph("<para align=center>Employment</para>",styles['Normal'])
    p5_1 = Paragraph("<para align=center>" + str(name_fuzzy_score) + '</para>', styles['Normal'])
    p5_2 = Paragraph("<para align=center>" + str(location_fuzzy_score) + '</para>', styles['Normal'])
    p5_3 = Paragraph("<para align=center>" + str(employment_fuzzy_score) + '</para>', styles['Normal'])
    data2= [[p4_1, p5_1],
            [p4_2, p5_2],
            [p4_3, p5_3]]
    t2=Table(data2, hAlign='CENTER')
    t2.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                           ('BOX', (0,0), (-1,-1), 0.25, colors.black)]))
    Story.append(t2)
    
    p5=Paragraph("<para align=center><font size=11><b><u>Regulatory Sites</u></b></font><font size=8><sup>3</sup></font> </para>", styles['Heading2'])
    Story.append(p5)
    p4_1 = Paragraph("<para align=center>Regulatory Site Articles</para>",styles['Normal'])
    p4_2 = Paragraph("<para align=center>Count</para>",styles['Normal'])
    p4_3 = Paragraph("<para align=center>Percent</para>",styles['Normal'])
    p5_2 = Paragraph("<para align=center>" + str(round(PerReg,2)) + "%" + '</para>', styles['Normal'])
    p5_1 = Paragraph("<para align=center>" + str(int(round(regCount,1))) + '</para>', styles['Normal'])
    p5_3 = Paragraph("<para align=center> </para>",styles['Normal'])
    data2= [[p5_3, p4_2,p4_3],
            [p4_1, p5_1, p5_2]]
    t2=Table(data2, hAlign='CENTER')
    t2.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                           ('BOX', (0,0), (-1,-1), 0.25, colors.black)]))
    Story.append(t2)
    
    p4=Paragraph("<para align=center><font size=11><b><u>Article Type Summary</u></b></font> </para>", styles['Heading2'])
    Story.append(p4)
    p0_1 = Paragraph("<para align=center> </para>",styles['Normal'])
    p0_2 = Paragraph("<para align=center>Count</para>",styles['Normal'])
    p0_3 = Paragraph("<para align=center>Percent</para>",styles['Normal'])
    p4_1 = Paragraph("<para align=center>Monetary Fine</para>",styles['Normal'])
    p4_2 = Paragraph("<para align=center>Legal Action</para>",styles['Normal'])
    p4_3 = Paragraph("<para align=center>Regulatory Reference</para>",styles['Normal'])
    #p5_3 = Paragraph("<para align=center>" + str(round(PerReg,2)) + "%" + '</para>', styles['Normal'])
    p5_1 = Paragraph("<para align=center>" + str(round(100*percC[0],1)) + "%" + '</para>', styles['Normal'])
    p5_2 = Paragraph("<para align=center>" + str(round(100*percC[2],1)) + "%" + '</para>', styles['Normal'])
    p5_3 = Paragraph("<para align=center>" + str(round(100*percC[3],1)) + "%" + '</para>', styles['Normal'])
    p6_1 = Paragraph("<para align=center>" + str(MFcount) + '</para>', styles['Normal'])
    p6_2 = Paragraph("<para align=center>" + str(LAcount) + '</para>', styles['Normal'])
    p6_3 = Paragraph("<para align=center>" + str(RRcount) + '</para>', styles['Normal'])
    data2= [[p0_1, p0_2, p0_3],
            [p4_1, p6_1, p5_1],
            [p4_2, p6_2, p5_2],
            [p4_3, p6_3, p5_3]]
    t2=Table(data2, hAlign='CENTER')
    t2.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                           ('BOX', (0,0), (-1,-1), 0.25, colors.black)]))
    Story.append(t2)
    h2_1=Paragraph("<para align=center><font size=11><b><u>Domains Searched</u></b></font><font size=8><sup>4</sup></font> </para>", styles['Heading2'])
    Story.append(h2_1)
    address = '<para align=center><link href="' + '">' + se.entity_querylist + '</link></para>'
    a_1 = Paragraph(address, styles['Normal'])
    Story.append(a_1)
    doc.multiBuild(Story, canvasmaker=FooterCanvas)
    pdf_merge_list.insert(0, pdf_filename)
    
    ## Overview pdf generation
    pdf_filename2 = pdf_path + se.entity_fname + '_'+se.entity_lname + '_Overview2.pdf'
    doc = SimpleDocTemplate(pdf_filename2, pagesize=letter, leftMargin = 0.75*inch, rightMargin = 0.75*inch, topMargin = 1*inch, bottomMargin = 1*inch)
    Story=[]         
    h2_4 = Paragraph("<para align=center><font size = 11><u>Links</u></font> </para>", styles['Heading2'])
    Story.append(h2_4)
    p = word_doc.add_heading('Links', level = 1)
    
    for t in range(0,max_links_for_score):  
        #reg vs not reg identifier
        tempR = Paragraph(str(t+1) + ". " + "<u>" + str(regnoreg[t]) + "</u>", styles['Normal'])
        Story.append(tempR)
        p = word_doc.add_paragraph(str(t+1) + '. ')
        p.add_run(str(regnoreg[t])).underline = True
       
        fine_reports = []
        fine_reports.extend(ef.generate_report_string(docTitles[t], ' '.join(w2vtopsent[t]),nlp = nlp, entity_dict = entity_dict))
        fine_reports.extend([fr for sent in w2vtopsent[t] for fr in ef.generate_report_string(sent, nlp = nlp, entity_dict = entity_dict)])
        fine_reports = set(fine_reports)

        DocCats = []
        if (docCat[0][t] == True) or (len(fine_reports) > 0):
            DocCats.append("Monetary Fine ")
        if docCat[2][t] == True:
            DocCats.append("Legal Action ")
        if docCat[3][t] == True:
            DocCats.append("Regulatory Reference ")
        if docCat[0][t]+docCat[2][t]+docCat[3][t] == 0:
            DocCats.append("Other Negative News")
            
        # Entity name
        tempE = Paragraph("<para lindent=11>" + "<u>" + str(entity_fname).upper() + "</u>"  , styles['Normal'])
        p = word_doc.add_paragraph(" ")
        p.add_run(str(entity_fname).upper()).underline = True
        Story.append(tempE)
        tempA = Paragraph("<para lindent=11>" + str(' '.join(DocCats)), styles['Normal'])
        p = word_doc.add_paragraph(" ")
        p.add_run(str(' '.join(DocCats)))
        Story.append(tempA)
        #site name from se
        tempN = Paragraph("<para lindent=11>"  + str(newssource[t]) + " Press Release: " + cgi.escape(final_links[t]),styles['Normal'])
        p = word_doc.add_paragraph(" ")
        p.add_run(str(newssource[t]))
        p.add_run(" Press Release: ")
        wp = p.add_run(cgi.escape(final_links[t]))
        wp.italic = True
        wp.font.color.rgb = RGBColor(0,0,255)
        Story.append(tempN)
        #Date published
        tempDate = Paragraph("<para lindent=11>" + "<u>"  + str(datelist[t]) + " - " + str(docTitles[t]) + "</u>",styles['Normal'])
        p = word_doc.add_paragraph(" ")
        p.add_run('').underline = True
        p.add_run(str(datelist[t])).underline = True
        p.add_run(" - ")
        p.add_run(str(docTitles[t])).underline = True
        Story.append(tempDate)

        #Top sentences
        tempx = Paragraph("<para lindent=11> " + "<br/>" + "Key Findings: " + '</para>', styles['Normal'])
        Story.append(tempx)
        p = word_doc.add_paragraph(" ")
        p.add_run('Key Findings:').underline = True
        for w in w2vtopsent[t]:
            p = word_doc.add_paragraph(w, style = 'List Bullet')
            
        for w in w2vtopsent[t]:
            tempx = Paragraph("<para lindent=45> "  + '\n\u2022' + str(w) + "<br/>" + '</para>', styles['Normal']) 
            Story.append(tempx)
        
        temp5 = Paragraph("<para><br/><br/></para>",styles['Normal'])
        if len(fine_reports) > 0:
            fine_pdf_info = reduce(lambda agg, x: agg + x + "<br/>", fine_reports, "<para lindent=11><u>Actions Taken:</u><br/>") + "<br/></para>"
            temp5 = Paragraph(fine_pdf_info,styles['Normal'])
            p = word_doc.add_paragraph(" ")
            p.add_run('Actions Taken: ').underline = True
            for fine_report in fine_reports:
                p = word_doc.add_paragraph(" ")
                p.add_run(fine_report)
        Story.append(temp5)

        temp4 = Paragraph("<para lindent=11>",styles['Normal'])
        Story.append(temp4)
        p = word_doc.add_paragraph(" ")
    doc.build(Story) 
    
    ##WORD
    word_doc.add_paragraph(Story)
    
    pdf_merge_list.insert(1, pdf_filename2)
    ## Merging all pdfs to generate final
    inputs = pdf_merge_list
    merger = PdfFileMerger()
    temppdfs = []
    for pdf in inputs:
        temp = open(pdf,'rb')
        merger.append(temp)
        temppdfs.append(temp)
    with open(outfn, 'wb') as fout:
        merger.write(fout)    
#    merger.close()
    for pdf in temppdfs:
        pdf.close()
    for pdf in inputs:
        remove_if_exist(pdf)
    return (outfn,word_doc)
    
    
### defining footer for pdf   
class FooterCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        canvas.Canvas.__init__(self, *args, **kwargs)
        self.pages = []
    def showPage(self):
        self.pages.append(dict(self.__dict__))
        self._startPage()
    def save(self):
        page_count = len(self.pages)
        for page in self.pages:
            self.__dict__.update(page)
            self.draw_canvas(page_count)
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)
    def draw_canvas(self, page_count):
        page = "Page %s of %s" % (self._pageNumber, page_count)        
        note2_1 = "The above Total Negative News Score is the a percentage between 0-100 with higher % representing higher risk."
        note1_1 = "The above Search Clause searches the input first name and last name with up to three word in between. The"
        note1_2 = "included quotes ensures that the searched name will appear in every result. In addition, at least one term from the above negative news " 
        note1_3 = "list will appear in every result analyzed. "
        note3_1 = "Links are filtered out by a pre-determined blacklist which includes, for example, links from LinkedIn or Facebook. "
        note4_1 = "Note that the above Name score will always be high due to the structure of the search clause. The confidence score for location"
        note4_2 = "is the result of an approximate or partial match between the input location information and the location that was found on the google "
        note4_3 = "search results. N/A implies location / Employment was not explicitly provided. "
        x = 128
        self.saveState()
        self.setStrokeColorRGB(0, 0, 0)
        self.setLineWidth(0.5)
        self.line(66, 150, letter[0] - 66, 150)
        self.setFont('Helvetica', 5)
        self.drawString(66, 140, '1')
        self.drawString(66, 130, '2')
        self.drawString(66, 120, '3')
        self.drawString(66, 90, '4')           
        self.setFont('Helvetica', 8)
        self.drawString(69, 140, note2_1)
        self.drawString(69, 130, note3_1)
        self.drawString(69, 120, note4_1)
        self.drawString(69, 110, note4_2)
        self.drawString(69, 100, note4_3)
        self.drawString(69, 90, note1_1)
        self.drawString(69, 80, note1_2)
        self.drawString(69, 70, note1_3)     
        self.drawString(letter[0]-x, 65, page)
        self.restoreState()
