# -*- coding: utf-8 -*-
"""
Created on Mon Feb 19 09:11:24 2018

@author: yangbo
"""


from googletrans import Translator as gTranslator
from mstranslator import Translator as bTranslator # import statement here because 'Translator' same name as googletrans
from config import BingAPIKey_translate as BingAPIKey
import config as config
import json
import os
import pydeepl

def translate_list(lst, lang, engine='BING', use_existing = False):
    if use_existing == True and lang in config.supported_lang:
        resultlist = translate_list_cache(lst, lang, engine)
        if resultlist == -1:
            return translate_list(lst, lang, engine, use_existing = False)
        else:
            return resultlist
    else:
        lang = langname_to_iso639(lang)
        #pdb.set_trace()
        if engine.lower() == 'google':
            if lang == 'zh': lang = 'zh-CN'
            translator = gTranslator()
            resultlist = [a.text for a in translator.translate(lst, dest = lang)]
        elif engine.lower() == 'deepl':
            if lang in ['en', 'de', 'fr', 'es', 'it', 'nl', 'pl']:
                resultlist = [a for a in pydeepl.translate(','.join(lst), to_lang=lang.upper())[0].split(', ')] # fixed this line of code
            else:
                print('deepL does not support {} in translation'.format(lang))
                resultlist=''
        elif engine.lower() == 'bing':
            translator = bTranslator(BingAPIKey)
            if lang == 'zh': lang = 'zh-Hans'
            resultlist = [a['TranslatedText'] for a in translator.translate_array(lst, lang_to = lang)] # might need to change the lang_to variable here as it seems some of the codes are different for Microsoft Translator (e.g. Chinese Traditional is zh-TW in Google and zh-Hant in Bing/Microsoft)
            #Edited based on Email from Rocky - 2018/03/16
            #resultlist = [a for a in translator.translate(', '.join(lst), lang_to = lang).split(', ')] # might need to change the lang_to variable here as it seems some of the codes are different for Microsoft Translator (e.g. Chinese Traditional is zh-TW in Google and zh-Hant in Bing/Microsoft)
        return resultlist

def translate_list_cache(lst, lang, engine='BING'):
    def translate_list_cache_make(lst, lang_list, engine, location):
        try:
            cachefileout = {}
            cachefileout['engine'] = engine
            cachefileout['lst'] = lst 
            for lang in lang_list:
                cachefileout[lang] = translate_list(lst, lang, engine, use_existing = False)
            with open(location, 'w') as outfile:
                json.dump(cachefileout, outfile)
                return 0
        except:
            return -1

    cachefile = config.working_path + config.cache_translatedstems
    if os.path.isfile(cachefile):
        translate_cache = json.load(open(cachefile, 'r'))
        if lang in translate_cache.keys() and engine == translate_cache['engine'] and lst == translate_cache['lst']:
            return translate_cache[lang]
        else:
            savefile = translate_list_cache_make(lst, config.supported_lang, engine, cachefile)
            if savefile == 0:
                return translate_list_cache(lst, lang, engine)
            else:
                return -1
    else:
        savefile = translate_list_cache_make(lst, config.supported_lang, engine, cachefile)
        if savefile == 0:
            return translate_list_cache(lst, lang, engine)
        else:
            return -1

## Translate Search Terms
def translate_searchterms(searchterms):
    searchterms_list = []
    translated_lang = []
    for lang in config.search_lang:
        if lang == 'en' or lang == 'english':
            searchterms_list.append(searchterms)
            translated_lang.append(lang)
        else:
            # try:
            searchterms_list.append(translate_list(searchterms,lang,config.translator,use_existing=config.cache_translatedactive))
            translated_lang.append(lang)
            # except:
            #     translated_lang.append([])
            #     translated_lang.append('ERROR')
            #     print('error loading language - {}'.format(lang))
    return searchterms_list, translated_lang
    
def translate_text(text, lang_from):
    lang = langname_to_iso639(lang_from)
    translator = bTranslator(BingAPIKey)    
    if lang == 'zh': lang = 'zh-Hans'
    
    #print(text) 
    if type(text) is list:
        translated = []
        translating = []
        currentlen = 0
        totallen = 0
        for x in text:
            totallen = totallen + len(x)
            if currentlen + len(x) > 10000:
                translated.extend([a['TranslatedText'] for a in translator.translate_array(translating, lang_from=lang, lang_to='en')])
                translating = [x]
                currentlen = len(x)
            else:
                print(x)
                print(translating)
                translating.append(x)
                currentlen = currentlen + len(x)
        translated.extend([a['TranslatedText'] for a in translator.translate_array(translating, lang_from=lang, lang_to='en')])
        return translated, totallen
    else:
        return translator.translate(text, lang_from=lang, lang_to='en'), len(text)


#def MSTranslate_API():
#    # -*- coding: utf-8 -*-
#
#	import http.client, urllib.parse, uuid, json
#
#	# **********************************************
#	# *** Update or verify the following values. ***
#	# **********************************************
#
#	# Replace the subscriptionKey string value with your valid subscription key.
#	subscriptionKey = 'ENTER KEY HERE'
#
#	host = 'api.cognitive.microsofttranslator.com'
#	path = '/translate?api-version=3.0'
#
#	# Translate to German and Italian.
#	params = "&to=de&to=it";
#
#	text = 'Hello, world!'
#
#	def translate (content):
#
#		headers = {
#			'Ocp-Apim-Subscription-Key': subscriptionKey,
#			'Content-type': 'application/json',
#			'X-ClientTraceId': str(uuid.uuid4())
#		}
#
#		conn = http.client.HTTPSConnection(host)
#		conn.request ("POST", path + params, content, headers)
#		response = conn.getresponse ()
#		return response.read ()
#
#	requestBody = [{
#		'Text' : text,
#	}]
#	content = json.dumps(requestBody, ensure_ascii=False).encode('utf-8')
#	result = translate (content)
#
#	# Note: We convert result, which is JSON, to and from an object so we can pretty-print it.
#	# We want to avoid escaping any Unicode characters that result contains. See:
#	# https://stackoverflow.com/questions/18337407/saving-utf-8-texts-in-json-dumps-as-utf8-not-as-u-escape-sequence
#	output = json.dumps(json.loads(result), indent=4, ensure_ascii=False)
#
#	print (output)
#	return ''
#


def langname_to_iso639(langname):
    ISO_639_1_MAP = {
    'abkhazian' : 'ab',
    'afar' : 'aa',
    'afrikaans' : 'af',
    'akan' : 'ak',
    'albanian' : 'sq',
    'amharic' : 'am',
    'arabic' : 'ar',
    'aragonese' : 'an',
    'armenian' : 'hy',
    'assamese' : 'as',
    'avaric' : 'av',
    'avestan' : 'ae',
    'aymara' : 'ay',
    'azerbaijani' : 'az',
    'bambara' : 'bm',
    'bashkir' : 'ba',
    'basque' : 'eu',
    'belarusian' : 'be',
    'bengali' : 'bn',
    'bihari' : 'bh',
    'bislama' : 'bi',
    'bokmal' : 'nb',
    'bosnian' : 'bs',
    'breton' : 'br',
    'bulgarian' : 'bg',
    'burmese' : 'my',
    'catalan' : 'ca',
    'chamorro' : 'ch',
    'chechen' : 'ce',
    'chinese' : 'zh',
    'chuvash' : 'cv',
    'cornish' : 'kw',
    'corsican' : 'co',
    'cree' : 'cr',
    'croatian' : 'hr',
    'czech' : 'cs',
    'danish' : 'da',
    'dutch' : 'nl',
    'dzongkha' : 'dz',
    'english' : 'en',
    'esperanto' : 'eo',
    'estonian' : 'et',
    'ewe' : 'ee',
    'faroese' : 'fo',
    'fijian' : 'fj',
    'finnish' : 'fi',
    'french' : 'fr',
    'fulah' : 'ff',
    'galician' : 'gl',
    'ganda' : 'lg',
    'german' : 'de',
    'greek' : 'el',
    'guarani' : 'gn',
    'gujarati' : 'gu',
    'haitian' : 'ht',
    'hausa' : 'ha',
    'hebrew' : 'he',
    'herero' : 'hz',
    'hindi' : 'hi',
    'hiri motu' : 'ho',
    'hungarian' : 'hu',
    'icelandic' : 'is',
    'ido' : 'io',
    'igbo' : 'ig',
    'indonesian' : 'id',
    'interlingua' : 'ia',
    'inuktitut' : 'iu',
    'inupiaq' : 'ik',
    'irish' : 'ga',
    'italian' : 'it',
    'japanese' : 'ja',
    'javanese' : 'jv',
    'kalaallisut' : 'kl',
    'kannada' : 'kn',
    'kanuri' : 'kr',
    'kashmiri' : 'ks',
    'kazakh' : 'kk',
    'kikuyu' : 'ki',
    'kinyarwanda' : 'rw',
    'kirghiz' : 'ky',
    'komi' : 'kv',
    'kongo' : 'kg',
    'korean' : 'ko',
    'kuanyama' : 'kj',
    'kurdish' : 'ku',
    'lao' : 'lo',
    'latin' : 'la',
    'latvian' : 'lv',
    'limburgan' : 'li',
    'lingala' : 'ln',
    'lithuanian' : 'lt',
    'luba-katanga' : 'lu',
    'luxembourgish' : 'lb',
    'macedonian' : 'mk',
    'malagasy' : 'mg',
    'malay' : 'ms',
    'malayalam' : 'ml',
    'maltese' : 'mt',
    'manx' : 'gv',
    'maori' : 'mi',
    'marathi' : 'mr',
    'marshallese' : 'mh',
    'micmac' : 'Mi',
    'mongolian' : 'mn',
    'nauru' : 'na',
    'navajo' : 'nv',
    'ndonga' : 'ng',
    'nepali' : 'ne',
    'northern sami' : 'se',
    'norwegian' : 'no',
    'ojibwa' : 'oj',
    'oriya' : 'or',
    'oromo' : 'om',
    'ossetian' : 'os',
    'pali' : 'pi',
    'panjabi' : 'pa',
    'persian' : 'fa',
    'polish' : 'pl',
    'portuguese' : 'pt',
    'pushto' : 'ps',
    'quechua' : 'qu',
    'romanian' : 'ro',
    'romansh' : 'rm',
    'rundi' : 'rn',
    'russian' : 'ru',
    'samoan' : 'sm',
    'sango' : 'sg',
    'sanskrit' : 'sa',
    'sardinian' : 'sc',
    'serbian' : 'sr',
    'shona' : 'sn',
    'sindhi' : 'sd',
    'slovak' : 'sk',
    'slovenian' : 'sl',
    'somali' : 'so',
    'spanish' : 'es',
    'sundanese' : 'su',
    'swahili' : 'sw',
    'swati' : 'ss',
    'swedish' : 'sv',
    'tagalog' : 'tl',
    'tahitian' : 'ty',
    'tajik' : 'tg',
    'tamil' : 'ta',
    'tatar' : 'tt',
    'telugu' : 'te',
    'thai' : 'th',
    'tibetan' : 'bo',
    'tigrinya' : 'ti',
    'tsonga' : 'ts',
    'tswana' : 'tn',
    'turkish' : 'tr',
    'turkmen' : 'tk',
    'twi' : 'tw',
    'uighur' : 'ug',
    'ukrainian' : 'uk',
    'urdu' : 'ur',
    'uzbek' : 'uz',
    'venda' : 've',
    'vietnamese' : 'vi',
    'volapuk' : 'vo',
    'walloon' : 'wa',
    'welsh' : 'cy',
    'wolof' : 'wo',
    'xhosa' : 'xh',
    'yiddish' : 'yi',
    'yoruba' : 'yo',
    'zulu' : 'zu'}
    try:
        return ISO_639_1_MAP[langname]
    except:
        return -1

