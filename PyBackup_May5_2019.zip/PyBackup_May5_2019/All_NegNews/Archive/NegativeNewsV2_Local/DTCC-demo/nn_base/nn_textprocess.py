# -*- coding: utf-8 -*-
"""
Created on Tue Feb 20 12:59:41 2018
#
@author: yangbo
"""
import pymagnitude
#from nn_base.nn_classes import search_entity as SE
from nn_base.nn_classes import search_entity as SE
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk import regexp_tokenize
from gensim import corpora, models, similarities
import string
import re
from fuzzywuzzy import fuzz
import numpy as np
import operator
from itertools import tee, chain, islice
from nltk.tokenize import sent_tokenize
import pandas as pd
from sklearn import preprocessing 
from scipy import spatial
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from numpy import tanh, exp
import config as config
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize 
from nltk.stem.snowball import SnowballStemmer
from nltk import regexp_tokenize
from nltk.corpus import stopwords
from gensim import corpora, models, similarities

wv = pymagnitude.Magnitude(config.word_embedding)
stop_words = set(stopwords.words('english'))
#from sumy.parsers.html import HtmlParser
#from sumy.parsers.plaintext import PlaintextParser
#from sumy.nlp.tokenizers import Tokenizer
#from sumy.summarizers.lex_rank import LexRankSummarizer
#from sumy.summarizers.luhn import LuhnSummarizer
#from sumy.summarizers.text_rank import TextRankSummarizer
#from sumy.utils import get_stop_words
#import sumy
#remove bs4 warnings 
#import warnings
#warnings.filterwarnings("ignore", category=UserWarning, module='bs4')

#Document sumarization function(to be used on original text directly after parsed) 
# def generate_summary(text,n_sentence=2): 
#     method = 'Luhn'
#     LANGUAGE ='english'
#     articletext = text
#     n_sentence = n_sentence
#     """
#     1.	Method: the method to generate the summary. The listed value could be �Lex Rank�, �Luhn�,�Text Rank�
#     2.	n_sentence: The number of sentences to extract from the text to generate the summary. The default value is 2, but for longer text, there�s more information/entropy, it could be 3
#     3.	articletext: As discussed, we would use the text/article from the front end as input.
#     """
#     parser=PlaintextParser.from_string(articletext,Tokenizer(LANGUAGE))
#     try:
#         if method=='Lex Rank':
#             SUMMARIZER=LexRankSummarizer()
#             summary=SUMMARIZER(parser.document,n_sentence)
#         elif method=='Luhn':
#             SUMMARIZER = LuhnSummarizer()
#             summary=SUMMARIZER(parser.document,n_sentence)
#         elif method=='Text Rank':
#             SUMMARIZER = TextRankSummarizer()
#             summary=SUMMARIZER(parser.document,n_sentence)
        
#         sentsum = []
#         for sentence in summary:
#             sentsum.append(str(sentence.strip()))
#         summary = ''.join(sentsum)
#     except:
#         print("input for generating summary is incorrect!")
#     return (summary)

#Warning:ZacKC Edited this to include ent filter(it must be declared manually currently)
def force_near_filter(text, fname, lname, distance , entity):
    if entity==1:
        #string = r'\b(?:{}\W+(?:\w+\W+){{0,{}}}?{}|{}\W+(?:\w+\W+){{0,{}}}?{})\b'.format(fname.lower(),distance, lname.lower(),lname.lower(), distance, fname.lower())
        string = r'{}'.format(fname.lower().strip())
        nearnames = re.findall(string, text.lower(), re.IGNORECASE)
        if nearnames == []:text = ''
    else:
        string = r'\b(?:{}\W+(?:\w+\W+){{0,{}}}?{}|{}\W+(?:\w+\W+){{0,{}}}?{})\b'.format(fname.lower().strip(),distance, lname.lower().strip(),lname.lower().strip(), distance, fname.lower().strip())
        nearnames = re.findall(string, text.lower(), re.IGNORECASE)
        if nearnames == []:text = ''
    return text

def entity_match_score(text, se, lang_idx):

    namelist = clean_paragraph([se.entity_fname, se.entity_lname, se.entity_mname], se.search_lang[lang_idx])
    loclist = clean_paragraph([se.entity_city, se.entity_state, se.entity_state2, se.entity_country], se.search_lang[lang_idx])
    emplist = clean_paragraph([se.entity_occupation, se.entity_company, se.entity_company2], se.search_lang[lang_idx])

    namescore = list(map(lambda x: fuzz.partial_token_set_ratio(text, x), [x for x in namelist if x != '']))
    locscore = list(map(lambda x: fuzz.partial_ratio(text, x),  [x for x in loclist if x != '']))
    empscore = list(map(lambda x: fuzz.partial_ratio(text, x), [x for x in emplist if x != '']))
    
    score_name = int(np.mean(namescore))
    score_city = max(locscore) if len(locscore)>0 else 0
    score_occupation = max(empscore) if len(empscore)>0 else 0
    return (score_name,score_city,score_occupation)

def entity_stem_match(text, se, lang_idx):

    text = clean_paragraph(text, se.search_lang[lang_idx], stemming = True, sent_tokenize = False)
    searchstem = clean_paragraph(se.searchtermlist[lang_idx], se.search_lang[lang_idx])
    foundlist = list(map(lambda x: x in text, searchstem))
    matched_stem = [term for term,found in zip(se.searchtermlist[lang_idx],foundlist) if found==True]   
    return matched_stem
    
def normalize_LSA(sum_score1, tot_links):
    lsa_sum = (sum_score1/tot_links)*100
    a = 0.342419512682912
    b = 1.19480978536808
    c = 0.211456297918287
    d = 0.779544742969885
    percent_risk = max(0,c + d*np.tanh((lsa_sum-a)/b))
    return(percent_risk*100)
    

## defining function to order webpages using LSA
def LSA_function(se):
    def LSA_function_single(doc_cluster, stems):
        doc_list = [stems] + doc_cluster
        texts = [document.split() for document in doc_list]
        dictionary = corpora.Dictionary(texts)
        corpus = [dictionary.doc2bow(text) for text in texts]
        ## Using tf-idf conversion for corpus 
        logent = models.TfidfModel(corpus)
        corpus_logent = logent[corpus]
        ## Using log entropy conversion for corpus
    #    logent = models.LogEntropyModel(corpus)
    #    corpus_logent = logent[corpus]
        ## To use tf-idf, uncomment that and comment the log entropy one (ignore the naming)
        lsi = models.LsiModel(corpus_logent, id2word=dictionary, num_topics=len(texts))
        S = lsi.projection.s
        variance = S*S
        percent_variance = variance/variance.sum()
        ## Setting the threshold high, since we have low number of links
        thresh = 0.95
        k=0
        dims_assign_check = 0
        for i in range(0,len(percent_variance)):
            if k >= thresh:
                dims = i
                dims_assign_check = 1
                break
            else:
                k += percent_variance[i]
        if dims_assign_check == 0:
            dims=len(texts)
        lsi_reduced = models.LsiModel(corpus_logent, id2word=dictionary, num_topics=dims)
        corpus_lsi_reduced = lsi_reduced[corpus_logent]
        vec_bow = dictionary.doc2bow(stems.split())
        vec_lsi = lsi_reduced[vec_bow]
        index = similarities.MatrixSimilarity(corpus_lsi_reduced)
        sims = (index[vec_lsi]).tolist()
        doc_score = sims[1:len(sims)]
        return doc_score
    for idx in range(0,se.search_lang_ct):
        if not se.urllist[idx] == []:
            doc_cluster = ['. '.join(x) for x in se.textlist[idx]]
            stems = ' '.join(clean_paragraph(se.searchtermlist[idx], se.search_lang_short[idx]))
            se.LSA_score[idx] = LSA_function_single(doc_cluster, stems)
    return se

## Sum the scores
def summary_scores(se, searchcounts):
    for idx in range(0, se.search_lang_ct):
        if not se.urllist[idx] == []:
            se.riskscore_final[idx] = round((se.w2vDfSorted[idx]['Final_Normalized_Score'].max()+.2)*100,2)  #added constant of .2 to all 
            # sum_LSA_score = sum(se.LSA_score[idx])
            # se.riskscore_final[idx] = normalize_LSA(sum_LSA_score,len(se.textlist[idx]))
            se.name_fuzzy_all[idx] = str(int(round(np.mean([x[0] for x in se.list_fuzzyscoredetail[idx]]),0)))
            se.location_fuzzy_all[idx] = str(int(round(np.mean([x[1] for x in se.list_fuzzyscoredetail[idx]]),0))) if se.location_provided() else 'N/A - Location not provided'
            se.employment_fuzzy_all[idx] = str(int(round(np.mean([x[2] for x in se.list_fuzzyscoredetail[idx]]),0))) if se.employment_provided() else 'N/A - Employment not provided'
    return se
    

#PROCESSING FROM ORIGINALTEXT (Takes SE objet and parses out original_txt_list and replaces it with reivesed text to parse)
#window: do you want to apply the window critera to only return lines around the lines found with first or last name
#Note: Windowing is only set up to work wiht an se object 

#PROCESSING FROM ORIGINALTEXT (Takes SE objet and parses out original_txt_list and replaces it with reivesed text to parse)
#window: do you want to apply the window critera to only return lines around the lines found with first or last name
#Note: Windowing is only set up to work wiht an se object 
def OrigTxt_PreProcess(origtextlist, fname, lname, delim ='<!@&>', window=False):
    
    #######################################################
    ################FUNCTION DEFINITIONS###################
    #######################################################
    #check if name is in sentences surrounding the sentence being processed (applied same way for entity and individual because all conditions are OR)  
    def name_in_sent(s1,s2,s3,fname,lname):
        return True if fname in s1 or fname in s2 or fname in s3 or lname in s1 or lname in s2 or lname in s3 else False
    
    #extracts all sentences before and after the sentence being processed 
    def previous_and_next(some_iterable):
        prevs, items, nexts = tee(some_iterable, 3)
        prevs = chain([''], prevs)
        nexts = chain(islice(nexts, 1, None), [''])
        return zip(prevs, items, nexts) 

    ##################################################################
    ########################EXECUTION START###########################
    ##################################################################
    
    #pre-process the original text and assign it back to original text 
    #if text is not se object it is assumed to be long string 
    test = origtextlist
    
    #if the delimiter is not defined, then we assume the doc is already delimited in some way so we do not split the doucment further(until sentence tokenization)
    if delim !="":
        #process text for use in word embedding models 
        test2 = [x.split(delim) for x in test] #split based on custom delimiter
        test3 = [[y.replace('\n',' ') for y in x] for x in test2] #replace all new line characters 
        test4 = [[sent_tokenize(y)for y in x] for x in test3] #sentence tokenize remaining text 
        test5 = [[re.sub('[^A-Za-z ]+', ' ', y) for y in x[0]] for x in test4] #remove all numbers *SKETCH
        test6 = [[y.strip() for y in x if x] for x in test5] #strip trailing and leading white space 
        test7 = [[y for y in x if not y ==''] for x in test6] #remove blank strings from list of strings 
        test8 = [[y for y in x if len(y) > 9] for x in test7] #remove blank strings from list of strings 
        test81= [[re.sub("\.{2,}" , ".",y) for y in x ] for x in test8] #replace multiple period with single period
        test9 = [[re.sub(' +',' ',y) for y in x ] for x in test81] #replace multiple spaces with single space 
        test10 = [[y.lower() for y in x ] for x in test9] #replace multiple spaces with single space 
        
        #process text for output to pdf 
        origtext_delim = [x.split(delim) for x in test] #split based on custom delimiter
        origtext_delim = [[y.replace('\n',' ') for y in x] for x in origtext_delim] #replace all new line characters 
        origtext_delim = [[sent_tokenize(y)for y in x] for x in origtext_delim] #sentence tokenize remaining text 
        origtext_delim = [[y.strip() for y in x[0] if x[0]] for x in origtext_delim] #strip trailing and leading white space  *SKETCH
        origtext_delim = [[y for y in x if not y ==''] for x in origtext_delim] #remove blank strings from list of strings 
        origtext_delim= [[y for y in x if len(y) > 9] for x in origtext_delim] #remove blank strings from list of strings 
        origtext_delim= [[re.sub("\.{2,}" , ".",y) for y in x ] for x in origtext_delim] #replace multiple period with single period
        origtext_delim= [[re.sub(' +',' ',y) for y in x ] for x in origtext_delim] #replace multiple spaces with single space 
        origtext_delim= [[y.strip() for y in x if x] for x in origtext_delim] #strip trailing and leading white space 

    else: 
        #process text for use in word embedding models 
        test1 = test 
        test2 = [y.replace('\n',' ') for y in test1] #replace all new line characters 
        test3=  [re.sub(' +',' ',y) for y  in test2] #replace multiple spaces with single space 
        test4 = [sent_tokenize(y)for y in  test3] #sentence tokenize remaining text 
        test5 = [[re.sub('[^A-Za-z ]+', ' ', y) for y in x] for x in test4] #remove all numbers 
        test6 = [[y.strip() for y in x if x] for x in test5] #strip trailing and leading white space 
        test7 = [[y for y in x if not y ==''] for x in test6] #remove blank strings from list of strings 
        test8= [[y for y in x if len(y) > 9] for x in test7] #remove blank strings from list of strings 
        test81= [[re.sub("\.{2,}" , ".",y) for y in x ] for x in test8] #replace multiple periods with single period 
        test9= [[re.sub(' +',' ',y) for y in x ] for x in test81] #replace multiple spaces with single space 
        test10 = [[y.lower() for y in x ] for x in test9] #replace multiple spaces with single space 
        
        #process text for output to pdf 
        origtext_delim = [y.replace('\n',' ') for y in test1] #replace all new line characters 
        origtext_delim=  [re.sub(' +',' ',y) for y  in origtext_delim] #replace multiple spaces with single space 
        origtext_delim = [sent_tokenize(y)for y in  origtext_delim] #sentence tokenize remaining text 
        origtext_delim = [[y.strip() for y in x if x] for x in origtext_delim] #strip trailing and leading white space 
        origtext_delim = [[y for y in x if not y ==''] for x in origtext_delim] #remove blank strings from list of strings 
        origtext_delim= [[y for y in x if len(y) > 9] for x in origtext_delim] #remove blank strings from list of strings 
        origtext_delim= [[re.sub("\.{2,}" , ".",y) for y in x ] for x in origtext_delim] #replace multiple periods with single period 
        origtext_delim= [[re.sub(' +',' ',y) for y in x ] for x in origtext_delim] #replace multiple spaces with single space 
        
  
    #create list of original text with or without windowing depending on option specs
    origtext_delimlist = []
    for doc in origtext_delim:
        if window==False:
            origtext_delimlist.append(doc)
        if window==True: 
            origtext_delimlist.append([X[1] for X in list(previous_and_next(doc)) if name_in_sent(X[0].lower(),X[1].lower(),X[2].lower(),fname.lower(),lname.lower())])
    
    #identify window of sentences around teh first and last name of the individual being processed 
    test11= []
    for doc in test10:
        if window==True: 
             #if the entity name is sound in the string 
            #extract the sentence before, the sentence, and the sentence after the sentence 
            test11.append([X[1] for X in list(previous_and_next(doc)) if name_in_sent(X[0].lower(),X[1].lower(),X[2].lower(),fname.lower(),lname.lower())])
            #test10.append([X for X in doc if name_in_sent(X[0].lower(),X[1].lower(),X[2].lower(),se.entity_fname.lower(),se.entity_lname.lower())])
        else: 
            test11.append(doc)
    return test11, origtext_delimlist


###############################
##OrigTxt_PreProcess_DTCC , same as above except because we are not dealing with html, we directly sentence tokenize the data, and thus bypass the need to leverage windowsearch_regex(), as sentence 
##tokenization of text is much more effective when it is feasble

###############################
##OrigTxt_PreProcess_DTCC , same as above except because we are not dealing with html, we directly sentence tokenize the data, and thus bypass the need to leverage windowsearch_regex(), as sentence 
##tokenization of text is much more effective when it is feasble
def OrigTxt_PreProcess_DTCC(origtextlist, fname, lname, delim ='<!@&>', window=False):
    
    #######################################################
    ################FUNCTION DEFINITIONS###################
    #######################################################
    #check if name is in sentences surrounding the sentence being processed (applied same way for entity and individual because all conditions are OR)  
    def name_in_sent(s1,s2,s3,fname,lname):
        return True if fname in s1 or fname in s2 or fname in s3 or lname in s1 or lname in s2 or lname in s3 else False
    
    #extracts all sentences before and after the sentence being processed 
    def previous_and_next(some_iterable):
        prevs, items, nexts = tee(some_iterable, 3)
        prevs = chain([''], prevs)
        nexts = chain(islice(nexts, 1, None), [''])
        return zip(prevs, items, nexts) 

    ##################################################################
    ########################EXECUTION START###########################
    ##################################################################
    
    #pre-process the original text and assign it back to original text 
    #if text is not se object it is assumed to be long string 
    test = origtextlist
    test1 = test 
    test4 = [sent_tokenize(y)for y in  test1] #sentence tokenize remaining text 
    test4 = [[y for y in x if max(len(w) for w in y.split())<15 ] for x in test4]
    test4= [[y for y in x if len(y) > 29 and len(y)<550] for x in test4] #remove blank strings from list of strings 
    test5 = [[re.sub('[^A-Za-z ]+', ' ', y) for y in x] for x in test4] #remove all numbers #syntax to keep $s [^A-Za-z|^\$]
    test6 = [[y.strip() for y in x if x] for x in test5] #strip trailing and leading white space 
    test7 = [[y for y in x if not y ==''] for x in test6] #remove blank strings from list of strings 
    test81= [[re.sub("\.{2,}" , ".",y) for y in x ] for x in test7] #replace multiple periods with single period 
    test9= [[re.sub(' +',' ',y) for y in x ] for x in test81] #replace multiple spaces with single space 
    test10 = [[y.lower() for y in x ] for x in test9] #replace multiple spaces with single space 
    #test2 = [y.replace('\n',' ') for y in test1] #replace all new line characters 
    #test3=  [re.sub(' +',' ',y) for y  in test2] #replace multiple spaces with single space 
    #test10 = [[y  for y in x if fname.lower() in x[0].lower()] for x in test10] #strip sentences that dont have entity name
    #test10 = [[y  for y in x if len(y)>20] for x in test10] #sentence > 20 words?
    #test10 = [[y for y in x if max(len(w) for w in y.split())<15 ] for x in test10]

    #process text for output to pdf 
    origtext_delim = [sent_tokenize(y)for y in  test1] #sentence tokenize remaining text 
    origtext_delim=[[y for y in x if max(len(w) for w in y.split())<15 ] for x in origtext_delim]
    origtext_delim= [[y for y in x if len(y) > 29 and len(y)<550] for x in origtext_delim] #remove blank strings from list of strings 
    origtext_delim = [[y.strip() for y in x if x] for x in origtext_delim] #strip trailing and leading white space 
    origtext_delim = [[y for y in x if not y ==''] for x in origtext_delim] #remove blank strings from list of strings 
    origtext_delim= [[re.sub("\.{2,}" , ".",y) for y in x ] for x in origtext_delim] #replace multiple periods with single period 
    origtext_delim1= [[re.sub(' +',' ',y) for y in x ] for x in origtext_delim] #replace multiple spaces with single space 
    #origtext_delim = [[y.strip() for y in x if x] for x in origtext_delim] #strip trailing and leading white space 
    #origtext_delim = [[y  for y in x if fname.lower() in x[0].lower()] for x in origtext_delim] #strip sentences that dont have entity name
    #origtext_delim = [[y for y in x if len(y)>20] for x in origtext_delim] #strip sentences that dont have entity name
    print(len(origtext_delim),len(test10))
    
    #create list of original text with or without windowing depending on option specs
    origtext_delimlist = []
    for doc in origtext_delim:
        if window==False:
            origtext_delimlist.append(doc)
        if window==True: 
            origtext_delimlist.append([X[1] for X in list(previous_and_next(doc)) if name_in_sent(X[0].lower(),X[1].lower(),X[2].lower(),fname.lower(),lname.lower())])
    
    #identify window of se#ntences around teh first and last name of the individual being processed 
    test11= []
    for doc in test10:
        if window==True: 
            #if the entity name is sound in the string 
            #extract the sentence before, the sentence, and the sentence after the sentence 
            test11.append([X[1] for X in list(previous_and_next(doc)) if name_in_sent(X[0].lower(),X[1].lower(),X[2].lower(),fname.lower(),lname.lower())])
        else: 
            test11.append(doc)
    return test11, origtext_delimlist
    


def clean_paragraph(content, lang, stemming=True, sent_tokenize=False, rem_stop=True, delim="<!@&>"):
    if lang in SnowballStemmer.languages:
        #set up stopword and stemming objects specific to languge specified
        stop = set(stopwords.words(lang))
        stemmer = SnowballStemmer(lang)
        ##if languge specified does not exist default to english
    else:
        stop = set(stopwords.words('english'))
        stemmer = SnowballStemmer('english')
    # puncremove = str.maketrans(string.punctuation,' '*len(string.punctuation))  
    def clean_text(text, delim = delim ):
        #sent tokenize and remove stop words, and alpha's and put to lower 
        #note: for w2v we do NOT want to stem the words or remove punctuation 
        if sent_tokenize == True:
            if delim !='':
                sent_tokens = text.split(delim)
            else: 
                sent_tokens = text
            # sent_tokens = sent_tokenize(text)
            tokens = [regexp_tokenize(sentence, r'\w+') for sentence in sent_tokens]
            rettext = []
            
            if rem_stop ==True: 
                for sent in tokens:
                    rettext.append([w.lower() for w in sent if w.isalpha() and not w in stop and len(w) > 1])
            
            #string is not put to lowercase, stopwords are not removed. however, limiting to char> 1 will prevent punctuation from being incorporated
            else:
                for sent in tokens:
                    rettext.append([w for w in sent if w.isalpha() and len(w) > 1])
        #if we are performing lsa then we remove punctionation , remove stops, lower, and stem 
        else:
             #remove punctuation from each string 
            for punc in string.punctuation:
                text = text.replace(punc, '')
            #text to lower, split by word, and remove stop words    
            rettext = [x for x in text.lower().split() if (x != '' and x not in stop)]
            if stemming==True:
                #stem text(at the word level)
                rettext = [stemmer.stem(x) for x in rettext]
            rettext = ' '.join(rettext)
        #return the clean text object 
        return rettext
        
    if type(content) is list:
        out = [clean_text(x) for x in content]
    else:
        out = clean_text(content)
    return out

#tfidf 
def tf_idf(site_list, search_terms):
    doc_list = []
    for site in site_list:
        #Note: this assumes you have sentence tokenized documents 
        #item represents a word, sublist represents a sentence vector , site represents the document(all the sentences in the doc in sent tokenized format)
        doc_list.append([item for sublist in site for item in sublist])
    
    #append the search terms to the front of the document list (doc_list[0]= search terms)
    texts = [search_terms] + doc_list
    #create a dictonary to hold all key value pairs for all terms found across all documents in the doclist (key = word index, value = word)
    dictionary = corpora.Dictionary(texts)
    ##create a bow tokenized mapping of all words in text #convert tokenized documents to vectors 
    corpus = [dictionary.doc2bow(text) for text in texts]
    ## fit and normalize a tf-idf model to the corpus , and map words in dictonary to ids 
    tf_idf_model = models.TfidfModel(corpus,id2word=dictionary, normalize=True) # fit model
    #apply the tfidf model to the corpus 
    tf_idf_corp = tf_idf_model[corpus] 
    #extract a dictonary of 2 dictonaries, one contianing the tf_idf vectors for all texts and the other a dicontary of key-value mappings of the words in the text 
    tf_idf_items = {"dic": dictionary, "tf_idf": tf_idf_corp}
    return tf_idf_items


#function to get sentiment of sentence 
def VADERSENT(sentences, many = True):
    analyzer = SentimentIntensityAnalyzer()
    str_sent = []
    if many==True:    
        str_df = pd.DataFrame(index=range(1,len(sentences)), columns=['sentence','sentiment'])       
        #iterate through all sentences and extract sentiment 
        i=0
        for sentence in sentences:
            vs = analyzer.polarity_scores(sentence)
            str_sent.append((sentence, vs['compound']))
            str_df.loc[i] = [sentence, vs['compound']]
            i = i+1 
        return(str_df, str_sent)
    else: 
        vs = analyzer.polarity_scores(sentences)
        str_sent.append((sentences, vs['compound']))
        return(str_sent)

# Function to get cosine similarity 
def cosine_sim(a, b):
    return 1 - spatial.distance.cosine(a, b)
   
# Function to get weighted average vector of a sentence. Weighting is done by multiplying tf-idf scores
# note: Changed function so wv(google vecs) are not re-initalized on every call of the funtion, instead wv is defined outside the function and simply referenced inside the function
def avg_phrase(phrase, wv, tf_idf, dictionary, doc_id):
	v = np.zeros(300) #create empty vector to hold the average vector of the nword phrase being processed(likley a sentence)
	#for each word that is in the sentence being processed 
    #note: we use set() operator here to remove duplicate values of words, we only want to capture each word in the phrase one time when calculating average word vectors. 
	for w in set(phrase):
       #if the word is found in the google word embeddings 
		if w in wv:
          #extract the token index associated with the word from the dictonary of all terms contained in the tf-idf 
			word_id = dictionary.token2id[w]
          #extract the tfidf vector of weightings for the document being processed
			doc_vectors = tf_idf[doc_id]
          #create a dictonary from the resulting doc_vector (word_index, tf-idf weighting) 
			d = dict(doc_vectors)
          #return the tf-idf from the dictonary associated with the tf-idf vector of weightings for the doc being processed and extract the weight associated with the word being processed
			tf_score = d[word_id] 
          #alter the google word vector representing the word being procssed to account for its importance in the document being processed via tf-idf weighting 
			v += wv.query(w) * tf_score
   #after all words in the sentence have been processed normilize the final vector back to unit length reprsenting the average word embedding vector for the terms in the sentence 
	v_norm = preprocessing.normalize(v.reshape(1,-1))
	return  v_norm




def w2v_se2(se, wv, entity,ndoc=400, nsent=400, sent_max = 0.3, min_sim = .1, delim = ''):
    #Not#e: we compile the function here and execute the function at the bottom of the parent function 
    
    #compile function to be used on the se(the se elements are extracted from se post below function and then called within this funciton )
    def w2v_SimSent(seurllist, doc_cluster, stems, wv,ndoc,nsent, sent_max, min_sim, se,delim=delim):
        # print(len(doc_cluster))
        # print(len(seurllist))
        #text procesed by w2v vs original sentence to be passed to vadar
        text_list = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True, rem_stop=True , delim = delim)
        text_list_vader = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True, rem_stop=False, delim =delim) #note: both text list, 
        text_summary = se.textsummary[0]
        date = se.lastsearchdate[0]
        source = se.NewsSource[0]
        title = se.DocTitle[0]

        print('DocCluster_TxtlistCounts(All,NonNull): ',len(doc_cluster),len(text_list)
        ,len(list(filter(None,doc_cluster))),len(list(filter(None,text_list))))
        
        #print('text_list',text_list)

        #tfidf 
        t = tf_idf(text_list, stems)
        
        #Get average word vector for search terms
        search_vec = avg_phrase(stems, wv, t["tf_idf"], t["dic"], 0)

        #W2V Execution 
        #compute average word embeddings and identify cosine similarity of the average word vector of the sentence vs average vector of search tersm     
        from datetime import datetime
        startTime = datetime.now()
        sim_list2 = []

        for idx, val in enumerate(text_list):
            #print first text ;if idx==1:print(val)
            if len(val) > 0 and idx < ndoc:
        
                #for each sentence in each document 
                for idx2, sent in enumerate(val):
                    
                    #get sent score up front for downstream use 
                    Vad_Score = VADERSENT(' '.join(text_list_vader[idx][idx2]),many=False)[0][1]
                    
                    #generate the avg vector associated with each sent in doc idx+1 (because idx(0) is the stems)
                    sent_vec = avg_phrase(sent, wv, t["tf_idf"],t["dic"],idx+1)
                    
                    #could also try including VADER filter here (got error last time)
                    if sent_vec.all != 0 and idx2 < nsent: 
                        #print(len(sent))
                        #error handling to prevent computation of cosine similarity with negative numbers 
                        try:                           
                            sim = cosine_sim(search_vec, sent_vec)
                            sent_sim2_all = [sim] #Method 0: one metric for each sentrence (averaged across all stems) #NORMALIZING BIAS SHORT STRINGS FOR LONG ONES REGADLESS   
                        except: 
                            sent_sim2_all = [0] #REMOVE THIS, THIS IS NOT GOOD 
                                      
                        #only extract sentences that meet similarity and sentiment thresholds
                        if sim > min_sim and Vad_Score < sent_max and config.indiv_parse==0:
                            #sim_list2.append(list(zip([idx],[idx2],['DummyURL'],[' '.join(text_list[idx][idx2])],sent_sim2_all, [Vad_Score]))) #Without URL Included 
                            sim_list2.append(list(zip([idx],[idx2],[seurllist[idx]],[' '.join(text_list[idx][idx2])],sent_sim2_all, [Vad_Score],[text_summary[idx]],[date[idx]],[source[idx]],[title[idx]]))) #Without URL Included 
                            #sim_list2.append(list(zip([idx],[idx2],[' '.join(text_list[idx][idx2])],[' '.join(text_list_vader[idx][idx2])],sent_sim2_all, [Vad_Score]))) #Dummy URL Included 
                            #sim_list2.append(list(zip([idx],[idx2],[se.urllist[0][idx]],[' '.join(doc_dic[idx][idx2][1])],sent_sim2_all, [Vad_Score]))) #Option 1: With URL Included
                            #sim_list2.append(list(zip([idx],[idx2],'SentHolder',sent_sim2_all, [VADERSENT(' '.join(doc_dic[idx][idx2][1]),many=False)[0][1]])))                            
                            #sim_list2.append(list(zip([idx],[idx2],sent_sim2_all))),[se.urllist[0][idx]])))#,sent_sim2_all)))
                        if config.indiv_parse==1:
                            sim_list2.append(list(zip([idx],[idx2],[seurllist[idx]],[' '.join(text_list[idx][idx2])],sent_sim2_all, [Vad_Score],[text_summary[idx]],[date[idx]],[source[idx]],[title[idx]])))
        #total #time required to run algo 
        print(datetime.now() - startTime)
        return(sim_list2)
    
    #for each languge if the ersults are not blank, extract the post processed text, and clean the search terms , and join them into one string
    for idxx in range(0,se.search_lang_ct):
        if not se.urllist[idxx] == []:
            #pull out original text from se object 
            #docs and stems/keywords
            doc_cluster = se.textlist[idxx]
            stems= clean_paragraph(se.searchtermlist[idxx], se.search_lang_short[idxx], stemming=False, sent_tokenize=False, rem_stop=True)
                   
            #execute the function for each languge 
            se.w2vInfo[idxx]  = w2v_SimSent(se.urllist[idxx],  doc_cluster, stems, wv, ndoc=ndoc, nsent=nsent, sent_max=sent_max, min_sim = min_sim, se=se)    
    return(se)

def w2v_SortOutput(se, entity, max_sent = config.max_sent): 
    def W2V_ScoreAgg(fname, lname, se_w2vInfo, entity=entity,max_sent = max_sent):
        #extract w2v score data from list -> convert to df and process at doc and person level 
        #Colnames: name, lsiRiskScore,Doc,Sent,URL,Sentence,Similarity,Sentiment
        scores = [(se.entity_fname+"_"+se.entity_lname,x[0][0],x[0][1],x[0][2],x[0][3],x[0][4],x[0][5],x[0][6],x[0][7],x[0][8],x[0][9]) for x in se_w2vInfo]
        flat_list = [sublist  for sublist in scores]#convert scores to dataframe and sort output by Doc -> Similarity 
        se_df = pd.DataFrame(flat_list, columns = ['Person','Doc','Sent','URL','Sentence','Similarity','Sentiment','textsummary','date','source','Title'])
        se_df= se_df.sort_values(by=['Doc','Similarity'],ascending = False)
        se_df= se_df[np.isfinite(se_df['Similarity'])] #Note: Need to round or change this to float64
        se_df['BothNamePres'] = np.where((se_df['Sentence'].str.upper().str.contains(se.entity_fname.upper()) & (se_df['Sentence'].str.upper().str.contains(se.entity_lname.upper()) )),1,0)

        #Normalized Similarity approaches
        se_df['Sim_Tanh_Norm']=tanh(se_df['Similarity'])
        se_df['Sent_Tanh_Norm']=tanh(se_df['Sentiment'])
        se_df['Sim_Tanh_Weighted']=tanh(se_df['Similarity']+se_df['BothNamePres'])
        se_df['Sent_Logit_Norm']=(1 / (1 + exp(-se_df['Sentiment'])))*2-1
        se_df['Sim_Logit_Norm']=(1 / (1 + exp(-se_df['Similarity'])))*2-1
       
        #create document level dataframe and sort by finaldoc metric
        doc_level = se_df.groupby(by=['Person','Doc','URL'],as_index=False)['Similarity','Sentiment'].sum() 
        doc_level.fillna(0, inplace=True)
        doc_level['TotalDocSents'] = se_df.groupby(by=['Person','Doc'],as_index=False).Sent.nunique()#sum of similarity of all sentences associated with each doc 
        doc_level['PerSentSimilarity'] = doc_level.Similarity /doc_level.TotalDocSents; doc_level.fillna(0, inplace=True)
        doc_level['Avg_Sim_Tanh_Norm'] = se_df.groupby(by=['Person','Doc'],as_index=False)['Sim_Tanh_Norm'].mean()['Sim_Tanh_Norm']
        doc_level['maxscore'] = se_df.groupby(by=['Person','Doc'],as_index=False)['Sim_Tanh_Norm'].max()['Sim_Tanh_Norm']
        doc_level['Avg_Sim_Tanh_Weighted'] = se_df.groupby(by=['Person','Doc'],as_index=False)['Sim_Tanh_Weighted'].mean()['Sim_Tanh_Weighted']
        #doc_level['DocScore2'] =  doc_level.Avg_Sim_Tanh_Norm
        if entity==1 & config.indiv_parse==0:
            doc_level['DocScore2'] = doc_level.maxscore#*(1+doc_level.Avg_Sim_Tanh_Norm)#doc_level.PerSentSimilarity*doc_level.TotalDocSents# doc_level.PerSentSimilarity*doc_level.TotalDocSents#doc_level.Similarity ##doc_level.maxscore #*doc_level.Avg_Sim_Tanh_Norm #doc_level.maxscore
        if entity==1 & config.indiv_parse==1:
              doc_level['DocScore2'] =doc_level.maxscore#doc_level.PerSentSimilarity*doc_level.TotalDocSents# ##doc_level.Similarity #doc_level.PerSentSimilarity*doc_level.TotalDocSents
        else:
            doc_level['DocScore2'] =doc_level.maxscore#*(1+doc_level.Avg_Sim_Tanh_Norm)#doc_level.maxscore#doc_level.PerSentSimilarity*doc_level.TotalDocSents##doc_level.Similarity ##   doc_level.maxscore #*doc_level.Avg_Sim_Tanh_Norm #doc_level['DocScore2'] = doc_level.Avg_Sim_Tanh_Weighted  #
        
        
        doc_level['FinalDocScore'] = (doc_level.DocScore2 - doc_level.DocScore2.min()) / (doc_level.DocScore2.max()-doc_level.DocScore2.min()) #normalized doc score
        doc_level = doc_level.sort_values(by=['FinalDocScore','Doc'],ascending = False)
        #doc_level['Avg_Sim_Logit_Norm']  = se_df.groupby(by=['Person','Doc'],as_index=False)['Sim_Logit_Norm'].mean()['Sim_Logit_Norm'] 
        #doc_level['DocScore2'] = doc_level.Avg_Sim_Tanh_Norm
        
        #merge document level and sentence level metrics
        #add document level information to the sentence dataset for output sorting 
        se_df_sort = se_df.merge(doc_level[['FinalDocScore','Doc']], how='left', left_on='Doc', right_on='Doc')
        se_df_sort = se_df_sort.sort_values(by=['FinalDocScore','Doc','Similarity'],ascending = False)

        #aggregation of doc scores at the Person level (To determine sample mean , and standard deviation to use in normalizing doc scores) 
        Person_level = se_df_sort.groupby(by=['Person'],as_index=False)['Similarity','Sentiment','Sim_Tanh_Norm','Sim_Logit_Norm','Sent_Tanh_Norm','Sent_Logit_Norm'].sum() #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
        Person_level['TotalLinks'] = se_df_sort.groupby(by=['Person'],as_index=False).Doc.nunique();Person_level.fillna(0,inplace=True) #very distinct distributions(bad people have more hits)
        Person_level['TotalSents'] = se_df_sort.groupby(by=['Person'],as_index=False).Sent.nunique();Person_level.fillna(0,inplace=True) #no help 
        Person_level['Avg_Sim']  = se_df_sort.groupby(by=['Person'],as_index=False)['Similarity'].mean()['Similarity'] #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
        Person_level['Avg_Sim_Tanh_Norm']  = se_df_sort.groupby(by=['Person'],as_index=False)['Sim_Tanh_Norm'].mean()['Sim_Tanh_Norm'] #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
        Person_level['Avg_Sim_Logit_Norm']  = se_df_sort.groupby(by=['Person'],as_index=False)['Sim_Logit_Norm'].mean()['Sim_Logit_Norm'] #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
        Person_level['Avg_Sent'] = se_df_sort.groupby(by=['Person'],as_index=False)['Sentiment'].mean()['Sentiment']
        Person_level['FINAL_SCORE']  = Person_level.Avg_Sim_Logit_Norm#Person_level.Avg_Sim_Logit_Norm*(1-Person_level.Avg_Sent_Logit_Norm) #/ (1/Person_level.TotalLinks)
        #Person_level['FINAL_SCORE']  = Person_level.Avg_Sim_Logit_Norm*(1/Person_level.P_PosSent) / (1/Person_level.TotalLinks)
        #Person_level['FINAL_SCORE']  = Person_level.Avg_Sim_Logit_Norm*(1/(1+Person_level.P_PosSent)) / (1/Person_level.TotalLinks)#Person_level['FINAL_SCORE']  = Person_level.Avg_Sim_Logit_Norm#*(1-Person_level.Avg_Sent_Logit_Norm) 
        
        #get info for final score (tihs is from a sample of 400 (~50 BAD) to calculate avg similarity normailzied by logit )
        if entity==1:
            MinVal = 0.02483958732992438
            MaxVal = .24#0.2656953953362422
        else: 
            MinVal = 0.06#11#4483958732992438
            MaxVal = 0.24    

        #generate normalized score 
        Person_level['Final_Normalized_Score'] = ((Person_level['FINAL_SCORE'] -MinVal) / (MaxVal-MinVal))
        #Person_level.loc[Person_level['Final_Normalized_Score']>100,'Final_Normalized_Score']=100
        #append person level information to sentence level dataframe 
        se_df_sort2 = se_df_sort.merge(Person_level[['Final_Normalized_Score','Person']], how='left', left_on='Person', right_on='Person')
        se_df_sort2 = se_df_sort2.sort_values(by=['Doc','Similarity'], ascending = [True,False])
        se_df_sort2['RegNonReg'] = [RegVsUnreg(url)[0] for url in se_df_sort2['URL']]
        se_df_sort2['NewsSource'] = [RegVsUnreg(url)[1] for url in se_df_sort2['URL']]

        return(se_df_sort2)
        
    
    #for each languge if the ersults are not blank, extract the post processed text, and clean the search terms , and join them into one string
    for idxx in range(0,se.search_lang_ct):
        if not se.urllist[idxx] == []: 
            #execute the function for each languge 
            se.w2vDfSorted[idxx]  = W2V_ScoreAgg(se.entity_fname, se.entity_lname, se.w2vInfo[idxx], entity, max_sent)
    return(se)

#these results are only used in nn_pdf to genrate the pdf 
def rerank_searchresults(se, LSA_filter=-100):
    for idx in range(0, se.search_lang_ct):
        if not se.urllist[idx] == []:

            #Extract items to output from w2v
            df_person = se.w2vDfSorted[idx]
            
            #*assume origlist is the list of orgtext where index matches to doc/sent on w2vfSorted
            df_person['pdftext'] = df_person.apply(lambda x: se.pdftext[idx][x.Doc][x.Sent], axis=1)
            
            #Rank of documents
            w2vDocRank= list(df_person.sort_values(['Doc','FinalDocScore'], ascending=[True, False]).groupby(['Doc'])['FinalDocScore'].max())
            #Most important sentences in each document
            w2vTopSent= list(df_person.sort_values(['Doc','Similarity'], ascending=[True, False]).groupby(['Doc'])['pdftext'].apply(list).apply(lambda x: x[0:3]))
            #url of each doc - already have, check if sorting was done right
            w2vdocs = list(df_person.sort_values(['Doc','FinalDocScore'], ascending=[True, False]).groupby(['Doc'])['Doc'].first())
            print('THIS IS THE LENGTH OF W2vDoc',len(w2vdocs))
            textsummary =list(df_person.sort_values(['Doc','FinalDocScore'], ascending=[True, False]).groupby(['Doc'])['textsummary'].first())
            date =list(df_person.sort_values(['Doc','FinalDocScore'], ascending=[True, False]).groupby(['Doc'])['date'].first())
            source =list(df_person.sort_values(['Doc','FinalDocScore'], ascending=[True, False]).groupby(['Doc'])['source'].first()) #CNN , etc.

            #regvsnon
            regnoreg = list(df_person.sort_values(['Doc','FinalDocScore'], ascending=[True, False]).groupby(['Doc'])['RegNonReg'].first())
            NewsSource = list(df_person.sort_values(['Doc','FinalDocScore'], ascending=[True, False]).groupby(['Doc'])['NewsSource'].first()) #this is the actual url root 
            Title = list(df_person.sort_values(['Doc','FinalDocScore'], ascending=[True, False]).groupby(['Doc'])['Title'].first())

            w2vDocRank_full = []
            w2vTopSent_full = []
            textsummary_full = []
            RegNoReg = []
            News = []
            dates =[]
            sources=[]
            titles=[]
            counter = 0
            print('URL LIST BEFORE FILTER: ',len(se.urllist[idx]))
            
            for idxx, value in enumerate(se.urllist[idx]):
                
                if idxx in w2vdocs:
                    w2vDocRank_full.append(w2vDocRank[counter])
                    w2vTopSent_full.append(w2vTopSent[counter])
                    RegNoReg.append(regnoreg[counter])
                    News.append(NewsSource[counter])
                    textsummary_full.append(textsummary[counter])
                    dates.append(date[counter])
                    sources.append(source[counter])
                    titles.append(Title[counter])
                    counter+=1
                else:
                    w2vDocRank_full.append(-9999)
                    w2vTopSent_full.append('')
                    RegNoReg.append('')
                    News.append('')
                    textsummary_full.append('')
                    dates.append('')
                    sources.append('')
                    titles.append('')

            se.w2vDocRank[idx]=w2vDocRank_full
            se.w2vTopSent[idx]=w2vTopSent_full
            se.RegNonReg[idx]=RegNoReg
            se.NewsSource[idx]=News
            se.source[idx] = sources
            se.textsummary[idx]=textsummary_full
            se.lastsearchdate[idx]=dates
         
            se.DocTitle[idx]=titles
            
            whole_list = list(zip(se.w2vDocRank[idx], se.urllist[idx],se.w2vTopSent[idx], se.list_fuzzyscore[idx],se.list_matchedstems[idx],se.list_fuzzyscoredetail[idx], se.textlist[idx],  se.RegNonReg[idx],se.NewsSource[idx],se.textsummary[idx],se.lastsearchdate[idx],se.source[idx], se.DocTitle[idx]))
            sorted_list = sorted(whole_list, key = operator.itemgetter(0), reverse = True)
            transposed_sorted = list(zip(*sorted_list))
            #print(transposed_sorted)
            #can be used to rerank and score docs diff
            LSA_filter_count = len([x for x in transposed_sorted[0] if x >= LSA_filter])
            se.LSA_filter_count[idx] = LSA_filter_count
            ## Extract the links and scores
            if LSA_filter_count > 0:
                se.w2vDocRank[idx] = transposed_sorted[0][0:LSA_filter_count]
                se.urllist[idx] = transposed_sorted[1][0:LSA_filter_count]
                se.w2vTopSent[idx] = transposed_sorted[2][0:LSA_filter_count]
                se.list_fuzzyscore[idx] = transposed_sorted[3][0:LSA_filter_count]
                se.list_matchedstems[idx] = transposed_sorted[4][0:LSA_filter_count]
                se.list_fuzzyscoredetail[idx] = transposed_sorted[5][0:LSA_filter_count]
                se.textlist[idx] = transposed_sorted[6][0:LSA_filter_count]
                se.RegNonReg[idx] = transposed_sorted[7][0:LSA_filter_count]
                se.NewsSource[idx] = transposed_sorted[8][0:LSA_filter_count]
                se.textsummary[idx] = transposed_sorted[9][0:LSA_filter_count]
                se.lastsearchdate[idx] = transposed_sorted[10][0:LSA_filter_count]
                se.source[idx] = transposed_sorted[11][0:LSA_filter_count]
                se.DocTitle[idx] = transposed_sorted[12][0:LSA_filter_count]
            else:
                se.w2vDocRank[idx] = []
                se.urllist[idx] = []
                se.w2vTopSent[idx] = []
                se.list_fuzzyscore[idx] = []
                se.list_matchedstems[idx] = []
                se.list_fuzzyscoredetail[idx] = []
                se.textlist[idx] = []
                se.RegNonReg[idx] =[] 
                se.NewsSource[idx] =[]
                se.textsummary[idx] =[]
                se.lastsearchdate[idx] =[]
                se.source[idx] = []
                se.DocTitle[idx]=[]

            print(se.urllist[idx])
            print('=====')
            print(transposed_sorted[7])
            print('NEW URL LIST LENGTH:',len(se.urllist[idx]))
    return se

#determine if url is regulatory or non regulatory
def RegVsUnreg(url):
   
    from urllib.parse import urlparse

    #List of URLS to remove: all government websites and finra org websites. Removing all .org targets too many
    RegulatedURLlist = ['.gov', 'finra.org']

    #Initialize list of lists same length as original URL list for correct indexing
    regURL = []
    sitenameReg = []

    #Search and remove
    if any(k in url for k in RegulatedURLlist):
        regURL.append('Regulatory')        
        sitenameReg.append(urlparse(url)[1].replace('www.','').replace('.com','').replace('.org','').replace('.gov','').replace('.co.uk',''))

    else:
        regURL.append('Non Regulatory')
        sitenameReg.append(urlparse(url)[1].replace('www.','').replace('.com','').replace('.org','').replace('.gov','').replace('.co.uk',''))

    return(regURL[0],sitenameReg[0])

#trimkey func 
def trim_key(obj):
    for key in obj.keys():
        new_key = key.strip()
        if new_key != key:
            obj[new_key] = obj[key]
            del obj[key]
    return obj

def stemsims(se_test):
    
    def isListEmpty(inList):
        if isinstance(inList, list): 
            return all( map(isListEmpty, inList) )
        return False

    def mean(numbers):
        return float(sum(numbers)) / max(len(numbers), 1)

    def avg_phrase(phrase, wv,stems):
        v = np.zeros(300) #create empty vector to hold the average vector of the nword phrase being processed(likley a sentence)ne time when calculating average word vectors. 
        sim = [[] for i in range(len(stems))]
        simmax = [[] for i in range(len(stems))]
        simmean = [[] for i in range(len(stems))]
        stem_index = 0
        for stem in set(stems):
            for w in set(phrase):
           #if the word is found in the google word embeddings 
 
                if stem in wv:
                    sim[stem_index].append(cosine_sim(wv.query(w),wv.query(stem)))

            #for stem in set(stems):
            simmax[stem_index] = (max(sim[stem_index]), stem)
            simmean[stem_index] = max(sim[stem_index])
            stem_index = stem_index +1        
       #after all words in the sentence have been processed normilize the final vector back to unit length reprsenting the average word embedding vector for the terms in the sentence 
        
        return  max(sim), sim, simmax, mean(simmean)
    
    # Function to get cosine similarity 
    def cosine_sim(a, b):
        return 1 - spatial.distance.cosine(a, b)

    SentenceListBool = []
    perc = []
    
    #Start of function
    for stemoption in range(4):
    #Stem options and their weightings - make weighting user customizable?
        if stemoption ==0:
            stems = ['fined','penalty'] #['fined','penalty','monetary']
            weight = 0.35
        elif stemoption ==1:
            stems = ['$'] 
            weight = 0.4
        elif stemoption ==2:
            stems = ['legal', 'judicial', 'action']
            weight = 0.3
        else :
            stems = ['regulatory'] #,'FINRA','SEC']
            weight = 0.4

        #Initialize
        index = 0
        sentmax = [[] for i in range(len(se_test.w2vTopSent[0]))] 
        meanindex = [[] for i in range(len(se_test.w2vTopSent[0]))]        
        #Find the maximum match to each stem in each sentence
        for sent in se_test.w2vTopSent[0]: 
            #this is only for shorter subsamples: if index < 50: #remove for full range case
                index2 = 0
                tempsent = [] #this is only for shorter subsamples: [[] for i in range(len(sent))]

                for sent2 in sent:
                    word_tokens = word_tokenize(sent2)
                    sent2 = [w for w in word_tokens if not w in stop_words]
                    sent2 = ' '.join(sent2)
                    maxout,simfile,simmax,simmean = avg_phrase(sent2.split(),wv,stems)
                    
                    if simmean > weight:
                        arg = simmax,simmean,sent2
                        
                        tempsent.append(arg)
                    else:
                        tempsent.append([])
                    
                    index2 = index2+1
                
                sentmax[index] = tempsent
                
                index = index+1
        
        sentBool = []
        for i in range(len(sentmax)):
            sentBool.append(not isListEmpty(sentmax[i]))
        if len(sentBool)>0:
            perc.append(sum(sentBool)/len(sentBool))
        else:
            perc.append(0)
        SentenceListBool.append(sentBool)
    
    return(SentenceListBool, perc)

#use to determine if entity name is found across an array of columns 
def entity_found (df, entity_col_name):
    #col_names = set(df.index) - set(entity_col_name)
    col_names = ['url','content','source','summary','title']
    return any([df[entity_col_name].lower() in df[col].lower() for col in col_names if df[col] is not None])

def rough_date (df,year):
    #col_names = set(df.index) - set(entity_col_name)
    col_names = ['url','content','source','summary','title']
    return any([year in df[col].lower() for col in col_names if df[col] is not None])

def indv_found (df, entity_col_name):
    #col_names = set(df.index) - set(entity_col_name)
    col_names = ['url','content','source','summary','title']
    return any([df[entity_col_name].split()[0].lower() in df[col].lower() or df[entity_col_name].split()[1].lower() in df[col].lower() for col in col_names if df[col] is not None])


##BEGIN MINHASH DEDUPE CODE (MUELLER EDITS 8/30)##
import re
import binascii
import random
from collections import defaultdict

PUNCTUATION = re.compile(r'[\.!?,:;]\s|[()]')
MAX_SHINGLE_ID = (2**32) - 1
NEXT_PRIME = 4294967311

DEFAULT_SHINGLE_LEN = 3
DEFAULT_DUPE_SIM_THRESHOLD = 0.8
DEFAULT_NUM_HASHES = 50

class MinHash:
    '''Class for modularizing minhash algorithm

    Arguments:
        docs {list} -- list of strings representing the documents to compare 
    
    Keyword Arguments:
        threshold {int} -- similarity threshold to utilize for flagging duplicates (default: {DEFAULT_DUPE_SIM_THRESHOLD})
        num_hashes {int} -- number of hash functions to utilize (default: {DEFAULT_NUM_HASHES})
        shingle_len {int} -- length of shingles to utilize (default: {DEFAULT_SHINGLE_LEN})

    Attributes:
        docs {list} -- list of strings representing the documents to compare
        hash_funcs {list} -- list of randomly generated hash functions utilized to compute hash values from shingle ids
        shingle_ids {list} -- list of hashed shingles representing the n-grams or shingle tuples from each document
        minhash_sigs {list} -- list of minimum hash values for each document computed from the shingle ids for each hash function
        dupe_dict {collections.defaultdict} -- dictionary storing duplicate document indices for each document index for which duplicate documents exist
        idx_to_remove {list} -- list of duplicate document indexes
    '''

    def __init__ (self, docs, threshold = DEFAULT_DUPE_SIM_THRESHOLD, num_hashes = DEFAULT_NUM_HASHES, shingle_len = DEFAULT_SHINGLE_LEN):
        '''Initializes MinHash object
        
        Arguments:
            docs {list} -- list of strings representing the documents to compare 
        
        Keyword Arguments:
            threshold {int} -- similarity threshold to utilize for flagging duplicates (default: {DEFAULT_DUPE_SIM_THRESHOLD})
            num_hashes {int} -- number of hash functions to utilize (default: {DEFAULT_NUM_HASHES})
            shingle_len {int} -- length of shingles to utilize (default: {DEFAULT_SHINGLE_LEN})
        '''

        self.docs = docs
        self.hash_funcs = self.generate_hash_functions(num_hashes)
        self.shingle_ids = [set(self.get_shingle_ids(shingle_len, d)) for d in docs]
        self.minhash_sigs = [self.get_minhash_signatures(ids_, self.hash_funcs) for ids_ in self.shingle_ids]
        self.dupe_dict = defaultdict(list)
        
        for i in range(0, len(self.docs)):
            for j in range(i + 1, len(self.docs)):
                count = sum([self.minhash_sigs[i][k] == self.minhash_sigs[j][k] for k in range(0, num_hashes)])
                
                sim = count / num_hashes
                
                if sim >= threshold:
                    self.dupe_dict[i].append(j)
        
        self.idx_to_remove = list(set([idx for idx_list in self.dupe_dict.values() for idx in idx_list]))
                
    def generate_random_coeff (self, num_coeff, seed = 0):
        '''Returns a list of random integer coefficients
        
        Arguments:
            num_coeff {int} -- number of unique random integer coefficients to return
        
        Keyword Arguments:
            seed {int} -- for testing purposes, seed value to provide to random number generator (default: {0})
        
        Returns:
            list -- list of random integer coefficients between 0 and the MAX_SHINGLE_ID (2**32 - 1)
        '''

        coeff = set()
        
        if seed != 0:
            random.seed(seed)

        while len(coeff) != num_coeff:
            coeff.add(random.randint(0, MAX_SHINGLE_ID))

        return list(coeff)

    def generate_hash_functions (self, n_hashes):
        '''Returns a list of randomly generated hash functions
        
        Arguments:
            n_hashes {int} -- number of hash functions to return
        
        Returns:
            list -- randomly generated hash functions as lambdas
        '''

        coeff_A = self.generate_random_coeff(n_hashes)
        coeff_B = self.generate_random_coeff(n_hashes)
        return [(lambda i: lambda x: sum([coeff_A[i] * x, coeff_B[i]]) % NEXT_PRIME)(i) for i in range(0,n_hashes)]

    def get_shingle_ids (self, size, doc):
        '''Returns the shingle ids for a single document
        
        Arguments:
            size {int} -- length of shingle ids to return
            doc {str} -- string representing document

        Yields:
            int -- shingle ids for a single document
        '''

        doc = PUNCTUATION.sub(' ',str(doc))
        tokens = [word for word in doc.split(' ') if word != '']

        for i in range (0, len(tokens) - size + 1):
            yield(binascii.crc32(bytes(' '.join(tokens[i:i + size]), 'utf-8')) & 0xffffffff)

    def get_minhash_signatures (self, shingle_ids, hash_funcs):
        '''Returns the minhash signatures for a single set of shingle ids
        
        Arguments:
            shingle_ids {list} -- list of shingle ids from a single document
            hash_funcs {list} -- list of randomly generated hash functions
        
        Returns:
            list -- minimum hash values computed from the shingle ids for each hash function
        '''

        return [min([hash_func(id_) for id_ in shingle_ids]) for hash_func in hash_funcs]

    def jaccard_similarity(self, idx1, idx2):
        '''Return the Jaccard similarity between any two documents
        This statistic acts as the 'ground truth' to which the minhash estimate can be compared
        
        Arguments:
            idx1 {int} -- index of first document in docs
            idx2 {int} -- index of second document in docs
        
        Returns:
            int -- Jaccard similarity between any two documents
        '''

        s1 = self.shingle_ids[idx1]
        s2 = self.shingle_ids[idx2]
        return (len(s1.intersection(s2)) / len(s1.union(s2)))
##END MINHASH DEDUPE CODE (MUELLER EDITS 8/30)##