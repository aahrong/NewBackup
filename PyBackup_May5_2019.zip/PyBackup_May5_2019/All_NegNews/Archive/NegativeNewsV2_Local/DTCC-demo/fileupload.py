import os
import config

def saveFile(f, fileName, fileType):
    #Check fileType    
    #print('ingayum vantaen')
    try:
      
        filePath = config.source_path + fileName      
        with open(filePath, 'wb+') as destination:
            chunks = f.chunks()
            try:
                for chunk in chunks:
                    destination.write(chunk)
                    return True,filePath
            except StopIteration:
                pass   
        
    except IOError:
        False,"IO Error"