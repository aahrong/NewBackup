# -*- coding: utf-8 -*-
"""
Created on Wed May 23 07:16:08 2018

@author: caridza
"""
# -*- coding: utf-8 -*-
"""
Created on Tue May 22 15:12:37 2018

@author: caridza
"""

#inputs 

#inputs to most functions being tested
pymagloc = "C:/Users/caridza/Desktop/pythonScripts/NLP/GoogleNewsvectors_negative300.magnitude"
se_list,dfs = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/")
doc_cluster = se_list[1].textlist[0]
doc_cluster2 = se_list[1].textlist[0]
text_list = doc_cluster
stems = ' '.join(clean_paragraph(se_list[1].searchtermlist[0], se_list[1].search_lang_short[0], stemming=False, sent_tokenize=False))
stems2= clean_paragraph(se_list[1].searchtermlist[0], se_list[1].search_lang_short[0], stemming=False, sent_tokenize=False)
wv = pymagnitude.Magnitude(pymagloc)


def tf_idf(site_list, search_terms):
    doc_list = []
    for site in site_list:
        doc_list.append([item for sublist in site for item in sublist])
    texts = [search_terms] + doc_list
    dictionary = corpora.Dictionary(texts)
    corpus = [dictionary.doc2bow(text) for text in texts]
    ## Using tf-idf conversion for corpus 
    tf_idf_model = models.TfidfModel(corpus,id2word=dictionary, normalize=True) # fit model
    tf_idf_corp = tf_idf_model[corpus] # apply model
    tf_idf_items = {"dic": dictionary, "tf_idf": tf_idf_corp}
    return tf_idf_items

		
def cosine_sim(a, b):
    return 1 - spatial.distance.cosine(a, b)
		
# Function to get weighted average vector of a sentence. Weighting is done by multiplying tf-idf scores
def avg_phrase(phrase, pymagloc, tf_idf, dictionary, doc_id):
	wv = pymagnitude.Magnitude(pymagloc)
	v = np.zeros(300)
	#print(set(phrase))
	for w in set(phrase):
		if w in wv:
			word_id = dictionary.token2id[w]
			doc_vectors = tf_idf[doc_id]
			d = dict(doc_vectors)
			tf_score = d[word_id] 
			v += wv.query(w) * tf_score
	v_norm = preprocessing.normalize(v.reshape(1,-1))
	return  v_norm
	

se = se_list[1]
def W2V_function_single(doc_cluster, stems):
    # Pre-process scraped text and search terms (all documents for the client from all websites for a single languge )
    #generates a sentence tokenized list of each text 
    text_list = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True)
 
    # Get tf_idf for site text and search terms
    # note: search terms added to first column of the tfidf 
    t = tf_idf(text_list, stems)
    
    # Get average vector for search terms
    search_vec = avg_phrase(stems, model, t["tf_idf"], t["dic"], 0)
    
    # Instantiate list to store cosine similarities
    sim_list = []
    sim_list_sent = []
    cnt_list = []
    sent_info = []
    all_list = []
    # Option A) get cosine similiarity of tf idf weighted document vector for each site
    for idx, val in enumerate(text_list):
        if len(val) > 0:
            sim_list_sent = []
			#for each sentence in each document 
            for sent in val:
				#generate the avg vector associated with each sent in doc idx+1
                sent_vec = avg_phrase(sent, model, t["tf_idf"],t["dic"],idx+1)
                
                if sent_vec.all != 0:
					
                 #identify the sentence vector representation with the max similarity to the search term vectors 
                    sent_sim =  max([cosine_sim(wv.query(term),sent_vec) for term in stems]) #method 2: compare the averaged vector of the sentence to each vector tied to each keyword
                  # sent_sim = cosine_sim(search_vec, sent_vec) #method 1: compare the averaged vector of keyterms to the avergae vector of the sentence
                    sent_sim_all = [cosine_sim(wv.query(term),sent_vec) for term in stems]
                    term = [term for term in stems]
                    
                    sent_all =  [(term , sent, se.urllist[0][idx], se.textlist[0][idx]),sent_sim_all]                    
                else:
                    sent_sim = 0
				#normalize the similarity metric by the length of the sentence 
                sim_list_sent.append(sent_sim/len(sent))
			
            
            #append the sent with the max similarity to the search term vector (one per doc processed) 	
            sim_list.append(max(sim_list_sent))
            all_list.append(sent_all)
            #append general information about the sentence the match, and the similarity 
            #docinfo.append([se.urllist[0][idx], se.textlist[0][idx] , ])
               
             
    print(sim_list)
	#sum the max similarity found from each document to get total similarity metric 
    return (sum(sim_list), all_list)
	
	

	
	

import nltk
from  scipy import spatial
se = se_list[1]
model = "C:/Users/caridza/Desktop/pythonScripts/NLP/GoogleNewsvectors_negative300.magnitude"

#apply function 
out = W2V_function_single(doc_cluster, stems2)






