from pymongo import MongoClient 

#The main component of PyMongo is the MongoClient class. In order to connect with the database, you need an instance of the client:
client = MongoClient()

#Databases and collections are created automatically if they don’t exist. Let’s create a database called Negnews and a collection called resultstable
db = client['Negnews']
coll = db['resultstable]


#convert pandas df to json and push to Mongodb 
import json 
import pandas

#import df 
dfs = pd.read_excel('/home/docadmin/ZackC/NegNews/example_w2v_revised.xlsx', sheet_name = None)

#create key index 
dfs.set_index(['Person', 'Doc','Sent','URL'], inplace=True)

#convert df to json record 
records = json.loads(dfs.T.to_json()).values() 

#submit record to schema and collection of interest 
db.coll.insert_many(records)