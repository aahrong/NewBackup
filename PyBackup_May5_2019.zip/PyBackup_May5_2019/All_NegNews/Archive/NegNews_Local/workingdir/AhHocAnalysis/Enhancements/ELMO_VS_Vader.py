# -*- coding: utf-8 -*-
"""
Created on Tue Jun 19 10:19:18 2018

@author: caridza
"""
################
#ELMO VS VADER##
################


#load modules 
sys.path.insert(0, "C://Users//caridza//Desktop//pythonScripts//NegNews_local//")
from nn_base.nn_classes import search_entity as SE
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from gensim import corpora, models, similarities
import string
import re
from fuzzywuzzy import fuzz
import numpy as np
import operator
import pymagnitude
import gensim 
import shlex 
import subprocess 
from sklearn import preprocessing 
import vaderSentiment
import pandas as pd 
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import nltk
from scipy import spatial #used for cosine similarities 
import math #used to filter nan tuple elments from list 
import pickle
from nltk.tokenize import sent_tokenize
import itertools #itertools used to extrafct sentences around entities name 
from itertools import tee 
from itertools import chain
from itertools import islice
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

#load list of sentences 
Vader_list,dfs = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NegNews_local", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NegNews_local/workingdir/AhHocAnalysis/ResultsDump/BadGuys/")
doc_cluster = Vader_list[2].origtextlist[0]


#VADER IMPLEMENTAITON 
indivSent = VADERSENT(chunkedtxt[0], many = False)








#sentiment analysis 
#Note: compound score ranges from -1(most negative) to 1(most positive). this is a normalized weighted composite sentiment score 
#compound score thresholds: Positive: >=.05 , neutral: score > -.05 & score <.05, negative: score <-.05
def VADERSENT(sentences, many = True):
    analyzer = SentimentIntensityAnalyzer()
    str_sent = []
    if many==True:    
        str_df = pd.DataFrame(index=range(1,len(sentences)), columns=['sentence','sentiment'])       
        #iterate through all sentences and extract sentiment 
        i=0
        for sentence in sentences:
            vs = analyzer.polarity_scores(sentence)
            str_sent.append((sentence, vs['compound']))
            str_df.loc[i] = [sentence, vs['compound']]
            i = i+1 
        return(str_df, str_sent)
    else: 
        vs = analyzer.polarity_scores(sentences)
        str_sent.append((sentences, vs['compound']))
        return(str_sent)