# -*- coding: utf-8 -*-
"""
Created on Wed May 23 09:30:27 2018

@author: caridza
"""

#VADER 
from nn_base.nn_classes import search_entity as SE
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from gensim import corpora, models, similarities
import string
import re
from fuzzywuzzy import fuzz
import numpy as np
import operator
import pymagnitude
import gensim 
import shlex 
import subprocess 
from sklearn import preprocessing 
import vaderSentiment 
import pandas as pd 
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

#load list of sentences 
Vader_list,dfs = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NegNews_local", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NegNews_local/workingdir/AhHocAnalysis/ResultsDump/BadGuys/")
doc_cluster = Vader_list[2].origtextlist[0]

#list of tokenized sentences from each document 
text_list = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True, rem_stop=False)

#re-create sentence strings from tokenized sentences
sents = []
for sent in text_list[1]:
    sents.append("".join([" "+i if not i.startswith("'") and i not in string.punctuation else i for i in sent]).strip())

#vader sentiment for a group of sentences 
df_out, list_out = VADERSENT(sents, many = True)
indivSent = VADERSENT(chunkedtxt[0], many = False)

#sentiment analysis 
#Note: compound score ranges from -1(most negative) to 1(most positive). this is a normalized weighted composite sentiment score 
#compound score thresholds: Positive: >=.05 , neutral: score > -.05 & score <.05, negative: score <-.05
def VADERSENT(sentences, many = True):
    analyzer = SentimentIntensityAnalyzer()
    str_sent = []
    if many==True:    
        str_df = pd.DataFrame(index=range(1,len(sentences)), columns=['sentence','sentiment'])       
        #iterate through all sentences and extract sentiment 
        i=0
        for sentence in sentences:
            vs = analyzer.polarity_scores(sentence)
            str_sent.append((sentence, vs['compound']))
            str_df.loc[i] = [sentence, vs['compound']]
            i = i+1 
        return(str_df, str_sent)
    else: 
        vs = analyzer.polarity_scores(sentences)
        str_sent.append((sentences, vs['compound']))
        return(str_sent)
                     
    
 
def chunks(s, n):
    """Produce `n`-character chunks from `s`."""
    for start in range(0, len(s), n):
        yield s[start:start+n]


#chunked text to act as sentence tokenizer temporarly 
#chunkedtxt = []
#for chunk in chunks(text_list[0], 90):
#    chunkedtxt.append(chunk)
   