#modules
#path of user created nn_base module 
sys.path.insert(0, "C://Users//caridza//Desktop//pythonScripts//NN_Gitlab//")
from nn_base.nn_classes import search_entity as SE
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from gensim import corpora, models, similarities
import string
import re
from fuzzywuzzy import fuzz
import numpy as np
import operator
import pymagnitude
import gensim 
import shlex 
import subprocess 
from sklearn import preprocessing 
import vaderSentiment 
import pandas as pd 
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import nltk
from scipy import spatial #used for cosine similarities 
##pip install --proxy http://amweb.ey.net:8080 vaderSentiment 

#load se objects
#se_list_orig,dfs_orig = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/Dump1/")
se_list_bad,dfs_bad = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/BadGuys/")

#individual se to test 
se = se_list_bad[0]


def w2v_se(se, pymagloc="C:/Users/caridza/Desktop/pythonScripts/NLP/GoogleNewsvectors_negative300.magnitude"):

    #compile function to be used on the se(the se elements are extracted from se post below function and then called within this funciton )
    def w2v_SimSent(doc_cluster, stems, wv):
        
        #text procesed by w2v vs original sentence to be passed to vadar
        text_list = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True, rem_stop=True)
        text_list_vader = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True, rem_stop=False) #note: both text list, 
        
        #tfidf 
        t = tf_idf(text_list, stems)
        
        #Get average word vector for search terms
        search_vec = avg_phrase(stems, wv, t["tf_idf"], t["dic"], 0)
        
        #store new and old value of sentence in dictonary as tuple
        doc_dic = {} #inialize dic 
        idx=0 #doc index
        for  val ,val_vad in zip(text_list,text_list_vader):   
            idx2=0 #sent index re-initiated for every doc 
            for sent, sent_vad in zip(val, val_vad):
                #must substantiate the second nested dic (otherwise python thinks you are trying to insert values into a dic that doesnt exist, because its nested within another dic)
                if idx not in doc_dic.keys():
                   doc_dic[idx] = {}
                doc_dic[idx][idx2] = (sent,sent_vad) 
                idx2 = idx2+1 #iterate sent index 
            idx=idx+1    #iterate docindex
        
        #W2V Execution 
        #compute average word embeddings and identify cosine similarity of the average word vector of the sentence vs average vector of search tersm     
        from datetime import datetime
        startTime = datetime.now()
        sim_list2 = []
        sim_list3 = []
        sent_sim2_indv = []
        
        for idx, val in enumerate(text_list[:6]):
            #print first text ;if idx==1:print(val)
            if len(val) > 0:
        
                #list to store normalized similarity metric
                sim_list_sent = []
        
                #for each sentence in each document 
                for idx2, sent in enumerate(val):
        
                    #generate the avg vector associated with each sent in doc idx+1
                    sent_vec = avg_phrase(sent, wv, t["tf_idf"],t["dic"],idx+1)
                    if sent_vec.all != 0:
                        #error handling to prevent computation of cosine similarity with negative numbers 
                        try:                           
                            sent_sim2_all = [cosine_sim(search_vec, sent_vec)] #Method 0: one metric for each sentrence (averaged across all stems) #NORMALIZING BIAS SHORT STRINGS FOR LONG ONES REGADLESS   
                            #sent_sim2_max = max([(cosine_sim(wv.query(term),sent_vec),term) for term in stems])                   
                            #sent_sim2_indv.append([(cosine_sim(wv.query(term),sent_vec),term,idx,idx2) for term in stems])
                        except: 
                            sent_sim2_all = [0] #REMOVE THIS, THIS IS NOT GOOD 
                            #sent_sim2_max =[(0,0)]
                            #sent_sim2_indv.append([0,'0',0,0])
                            #sent_sim2_indv.append(list(zip([0],[0],['na'],[(0,'0')])))
                    else:
                        sent_sim2_all = [0]
                        #sent_sim2_max =[(0,0)]
                        #sent_sim2_indv.append([0,'0',0,0])
                        #sent_sim2_indv.append([0],[0])
                    #sentence level 
                    #note: vader requires a sentence, not a sentence tokenized string 
                    sim_list2.append(list(zip([idx],[idx2],[se.urllist[0][idx]],[' '.join(doc_dic[idx][idx2][1])], sent_sim2_all)))
                    #new option
                    #sim_list2.append(list(zip([idx],[idx2],[se.urllist[0][idx]],[' '.join(doc_dic[idx][idx2][1])], sent_sim2_all, VADERSENT(' '.join(doc_dic[idx][idx2][1])))))

                    #sim_list2.append(list(zip([idx],[idx2],[se.urllist[0][idx]],[' '.join(text_list_vader[idx][idx2][1])], sent_sim2_all)))
                    #sim_list3.append(list(sent_sim2_max))
                  
                #document level 
                #append the sent with the max similarity to the search term vector (one per doc processed) 	
                #sim_list.append(max(sim_list_sent))
                #append general information about the sentence the match, and the similarity 
                #docinfo.append([se.urllist[0][idx], se.textlist[0][idx] , ])
        
        
        #total time required to run algo 
        print(datetime.now() - startTime)
        
        #sort list by similarity (sort by the 4th element of the tuple in each element of the list)
        sim_list_by_doc = sorted(sim_list2, key = lambda x: (x[0][0],x[0][4]), reverse=True)
        
        #extract the sentences only for vader processing
        #sents = [x[0][3] for x in sim_list_by_doc]
        
        #process the sentences to identify sentiment 
        df_out, list_out = VADERSENT( [x[0][3] for x in sim_list_by_doc], many = True)
        
        #final LIST OF ALL SENTENCES FOR EACH DOC WITH THE SENTIMENT SCORE FOR EACH SENTENCE INCLUDED 
        sim_list_by_doc_with_sent = [x[0]+(y[1],) for x, y in zip(sim_list_by_doc, list_out)]
    
    
        return(sim_list_by_doc_with_sent)
    

    #for each languge if the ersults are not blank, extract the post processed text, and clean the search terms , and join them into one string
    for idxx in range(0,se.search_lang_ct):
        if not se.urllist[idxx] == []:
            
            #google word embeddig model
            pymagloc = pymagloc
            wv = pymagnitude.Magnitude(pymagloc)
              
            #pull out original text from se object 
            #docs and stems/keywords
            doc_cluster = se.origtextlist[idxx]
            stems= clean_paragraph(se.searchtermlist[idxx], se.search_lang_short[idxx], stemming=False, sent_tokenize=False, rem_stop=True)
                   
            #execute the function for each languge 
            se.w2vInfo[idxx] = w2v_SimSent(doc_cluster, stems, wv)
            
    return se


se = w2v_se(se, pymagloc="C:/Users/caridza/Desktop/pythonScripts/NLP/GoogleNewsvectors_negative300.magnitude")
        


#####################################
##########END FUNCTIONAL FORM########
#####################################



#convert to pandas 
newdf = pd.DataFrame.from_records(sim_list_by_doc_with_sent)
newdf.columns = ['Docidx', 'Sentidx','URL','Sentence','Similarity','Sentiment']

#retaining only docs with negative sentiment 
negdf = newdf[(newdf ['Sentiment']<.30) & (newdf['Similarity']>.2)]

#percent of total sentences meeting critera 
P_Neg = len(negdf.index)/len(newdf.index)

#
#check if avg sent is positive 
dfsum = pd.DataFrame()
dfsum['AvgSent'] = newdf.groupby('Docidx')['Sentiment'].mean()
dfsum['AvgSim'] = newdf.groupby('Docidx')['Similarity'].mean()
dfsum['AvgSim'] = newdf.groupby('Docidx')['Similarity'].mean()
dfsum['MaxSim'] = newdf.groupby('Docidx')['Similarity'].max()
dfsum['MinSim'] = newdf.groupby('Docidx')['Similarity'].min()
dfsum['MaxSent'] = newdf.groupby('Docidx')['Sentiment'].max()
dfsum['MinSent'] = newdf.groupby('Docidx')['Sentiment'].min()

#max valuse associated with each document processed 
idmins = newdf[['Docidx','Similarity','Sentiment']].groupby('Docidx').idxmax()
idmaxs = newdf[['Docidx','Similarity','Sentiment']].groupby('Docidx').idxmin()

#subsetdata frame of min and max values associated with above aggregations 
max_dfs = []            
for i in range(int(idmins.size/2)):
    rowsent = idmins['Sentiment'].iloc[[i]].values.astype(int)[0]
    rowsim = idmins['Similarity'].iloc[[i]].values.astype(int)[0]
    
    max_dfs.append([*list(newdf.iloc[rowsent]),'Sentiment'])
    max_dfs.append([*list(newdf.iloc[rowsim]),'Similarity'])

max_dfs = pd.DataFrame(max_dfs)
max_dfs.columns = ['Docidx', 'Sentidx','URL','Sentence','Similarity','Sentiment','Reason']


#

#user level 
#total docs / sents with positive sentiment with low similarity to search terms 
newdf[(newdf ['Sentiment']>=.10) & (newdf['Similarity']<=.40)][['Docidx','Sentidx']].count()
newdf[(newdf ['Sentiment']<.10) & (newdf['Similarity']>.40)].count()

#return the row associated with the min sentiment and max similarity 
#idea: return 2 sentences: one with the max similarity(that is not positive), two min(sentiment) with similarity>.5


#user level aggregation 
newdf.groupby('Docidx')['Similarity'].mean()


#remove sentences with positive sentiment 

#select the top 5 results(by similarity)

#calculate avg sentiment for each doc 
#if avg sent for the doc is > 0 then ignore the doc 
#for remaining docs , extract the avg similarity across the doc, and all docs, as well as the avg sentiment at the doc and docs level


