# -*- coding: utf-8 -*-
"""
Created on Tue Jul 10 19:01:51 2018

@author: caridza
"""
import re 


names = 'Bank of China' 
namesplit = names.split()
namelen= len(namesplit)
formatset = "{}%2520"*(namelen-1)+"{}"
Finra = str("https://www.finra.org/search/global/"+names if namelen ==1 else "https://www.finra.org/search/global/"+formatset).format(namesplit[0],namesplit[1],namesplit[2])

https://www.finra.org/search/global/{}%2520{}.format
https://www.finra.org/search/global/{}%2520{}%2520{}


namelist = names.split()
namepart = '("' + ' '.join(namelist) + '")'
namepart = '(' + ' '.join(list(map(lambda x: '"' + x + '"', namelist))) + ')'



fname = names 
lname = 'test'
lname2 = ''

'("{}" "{}") '.format(fname, lname2)

regex_name = ('{}{}'.format(fname, lname)).lower().strip()

extracted_text_list =[]
p = re.compile(r'(([^\.]*\.){1}[^\.]*(' + regex_name + r')[^\.]*\.([^\.]*\.){2})',re.IGNORECASE)


#string = r'\b(?:{}\W+(?:\w+\W+){{0,{}}}?{}|{}\W+(?:\w+\W+){{0,{}}}?{})\b'.format(fname.lower(),3, lname.lower(),lname.lower(), 3, fname.lower())
string2 =r'\b(?:{}\W+(?:\w+\W+){{0,{}}}?{}|{}\W+(?:\w+\W+){{0,{}}}?{})\b'.format(fname.lower(),3, lname2.lower(),lname2.lower(), 3, fname.lower()) 
string = r'{}'.format(names.lower())
    
text = 'the man from the bank of china, ran into a dog. the china man ran into the bank of china.'

print(string)
print(string2)


nearnames = re.findall(string, text.lower(), re.IGNORECASE)
if nearnames == []:text = ''

force_near_filter(text, fname, lname, 0,1)

def force_near_filter(text, fname, lname, distance, ent = 1):
    if ent ==1:
        string = r'{}'.format(names.lower())
        nearnames = re.findall(string, text.lower(), re.IGNORECASE)
        if nearnames == []:text = ''
        return text
    else:
        string = r'\b(?:{}\W+(?:\w+\W+){{0,{}}}?{}|{}\W+(?:\w+\W+){{0,{}}}?{})\b'.format(fname.lower(),distance, lname.lower(),lname.lower(), distance, fname.lower())
        nearnames = re.findall(string, text.lower(), re.IGNORECASE)
        if nearnames == []:text = ''
        return text        