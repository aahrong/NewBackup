# -*- coding: utf-8 -*-
"""
Created on Tue May 22 13:17:47 2018

@author: caridza
"""

#numpy array information 
array.dtype #type of data in array 
array.shape #shape of the array 
array.strides #number of byters that should be skipped in nmemory to go to the next element ex. if strides are (10,1), you need to proceed one byte to get to the next column and 10 bytes to locate the next row.


#generate random arrays 
 ones = np.ones(); rand = np.random.random(10); empty = np.empty(); full = np.full() ; identity = np.eye() ; trans = np.transpose(np.random.random())
 
#np.meshgrid() function takes two 1D arrays and produces two 2D matrices corresponding to all pairs of (x, y) in the two arrays. Then, you can use these matrices to make all sorts of plots.
x, y =np.meshgrid(rand,rand+.33)
z = np.sqrt(x**2 + y**2)
plt.imshow(z,cmap=plt.cm.gray)
#plotting nparrays 
import numpy as np
import matplotlib.pyplot as plt
plt.hist(rand)





def tf_idf(site_list, search_terms):
    doc_list = []
    for site in site_list:
        doc_list.append([item for sublist in site for item in sublist])
    texts = [search_terms] + doc_list
    dictionary = corpora.Dictionary(texts)
    corpus = [dictionary.doc2bow(text) for text in texts]
    ## Using tf-idf conversion for corpus 
    tf_idf_model = models.TfidfModel(corpus,id2word=dictionary, normalize=True) # fit model
    tf_idf_corp = tf_idf_model[corpus] # apply model
    tf_idf_items = {"dic": dictionary, "tf_idf": tf_idf_corp}
    return tf_idf_items

    
tfidf = tf_idf(se_list[1].urllist, stems2)

for key,val in tfidf['dic'].items():print(key,"=>",val)





###FINAL FUNCTIONAL FORM 
#inputs a list of docuemnts and a list of search terms 
#tfidf function to create tfidf encompassing all documents associated with an individual 
def tf_idf(doc_list, search_terms):
    
    #list of documents, with 1st element in list reprsenting the key search terms 
    doc_list = [search_terms] + doc_list
    
    #split the doucments into texts 
    texts = [document.split() for document in doc_list]
    
    #create a dictonary of all words in text
    dictionary = corpora.Dictionary(texts)
    
    #create a bow tokenized mapping of all words in text #convert tokenized documents to vectors 
    corpus = [dictionary.doc2bow(text) for text in texts] 
    
    ## Using tf-idf conversion for corpus 
    tf_idf_model = models.TfidfModel(corpus,id2word=dictionary, normalize=True) # fit model
    
    tf_idf_corp = tf_idf_model[corpus] # apply model to corpus 
    #tf_idf_items = {"dic": dictionary, "tf_idf": tf_idf_corp}
    return(dictionary, tf_idf_corp)

# Function to get cosine similarity 
def cosine_sim(a, b):
    return 1 - spatial.distance.cosine(a, b)


#################################################
###############RANDOM Pt1########################
# -*- coding: utf-8 -*-
"""
Created on Tue May 22 13:00:43 2018

@author: caridza
"""

wv = pymagnitude.Magnitude(pymagloc) #google vectors
wv.query('theft') #word vector associated with the
wv.most_similar(positive ='theft', topn=20) #top20 words associated with similarity 
wv.similarity("theft" ,"steal") #word similarity between two words 


v = np.zeros(300) #hold the sum of the wordvectors embeddings 
print(set(stems2))
#for each word in the keyword list 
for w in set(stems2):
    #if the keyword is found in the google word vectors
    if w in wv:
        
        
        
word_id = dict2use.token2id['theft']  #find id assocaiated with term in dictonary , the id represents the term itself
doc_vectors = tfidf_corp[0]    #tfidf weightings of the document being processed 
d = dict(doc_vectors)         # converts all search in the document being processed into a dictonary of (tokenid, tfidf_weight)
for key,val in d.items():print(key,"=>",val)

tf_score = d[word_id]         # for the word in the dictonary pull back the tfidf weighting associated with that term in the document being processed
v += wv.query('theft') * tf_score   # weight the embedding for the tfidf score, words that are more important will have a higher score 
v_norm = preprocessing.normalize(v.reshape(1,-1)) #normalize to unit vector space 


test= wv.query('theft')
test2 = wv.query('steal')
t, t2= np.meshgrid(test,test2)
sd =np.sqrt(t**2 + t2**2)
test.size;plt.hist(test); plt.imshow(sd,cmap=plt.cm.gray)

###########################################################
#################RANDOM pt 2###############################
###########################################################
# -*- coding: utf-8 -*-
"""
Created on Wed May 23 13:12:15 2018

@author: caridza
"""

doc_cluster = se_list_bad[1].origtextlist[0]

#parse 2 sentences
text_list = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True, rem_stop=True)

#clean stems 
stems= clean_paragraph(se_list[1].searchtermlist[0], se_list[1].search_lang_short[0], stemming=False, sent_tokenize=False, rem_stop=True)

tf_idf = t["tf_idf"]
dictionary = t["dic"]

#avg phrase  
wv = pymagnitude.Magnitude(pymagloc)
v = np.zeros(300)

doc_id= 0
w = se_list[1].searchtermlist[0][1]
word_id = dictionary.token2id[w]
doc_vectors = tf_idf[doc_id]
d = dict(doc_vectors)
tf_score = d[word_id] 
v += wv.query(w) * tf_score
v_norm = preprocessing.normalize(v.reshape(1,-1))
    
    
tf_out = tf_idf(text_list, stems)
for key,val in tf_out['dic'].items():print(key,"=>",val)



# -*- coding: utf-8 -*-
"""
Created on Thu May 31 12:00:38 2018

@author: caridza
"""

testsim = all_bad_se2[1].w2vInfo[0]

#english doc value
testsim[0][0][1]
 
#sort list by similarity (sort by the 4th element of the tuple in each element of the list)
testsim_sort = sorted(testsim, key = lambda x: (x[0][0],x[0][4]), reverse=True)

#final LIST OF ALL SENTENCES FOR EACH DOC WITH THE SENTIMENT SCORE FOR EACH SENTENCE INCLUDED 
sim_list_by_doc_with_sent = [x for x in Good_scores]

len(Good_scores)


#extract scores only 
testsim_scores = [(x[0][0],x[0][1],x[0][4],x[0][5]) for x in testsim_sort]
        
negdf = testsim_scores[(testsim_scores[0][3]<.30)]



        #extract the sentences only for vader processing
        #sents = [x[0][3] for x in sim_list_by_doc]
        
        #process the sentences to identify sentiment 
        df_out, list_out = VADERSENT( [x[0][3] for x in sim_list_by_doc], many = True)
        
        #final LIST OF ALL SENTENCES FOR EACH DOC WITH THE SENTIMENT SCORE FOR EACH SENTENCE INCLUDED 
        sim_list_by_doc_with_sent = [x[0]+(y[1],) for x, y in zip(sim_list_by_doc, list_out)]




([item for sublist in site for item in sublist])

