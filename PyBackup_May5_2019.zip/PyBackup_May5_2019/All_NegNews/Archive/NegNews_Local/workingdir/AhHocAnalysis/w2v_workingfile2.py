#w2v Test Function 

#load se objects
se_list_orig,dfs_orig = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/Dump1/")
se_list_bad,dfs_bad = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/BadGuys/")

#individual se to test 
se = se_list_bad[1]

#doc clusters
#doc_cluster_orig= se_list_orig[1].textlist[0] 
doc_cluster = se_list_bad[1].origtextlist[0]

#clean stems 
stems= clean_paragraph(se_list_bad[1].searchtermlist[0], se_list_bad[1].search_lang_short[0], stemming=False, sent_tokenize=False, rem_stop=True)
#stems = ' '.join(clean_paragraph(se_list[1].searchtermlist[0], se_list[1].search_lang_short[0], stemming=False, sent_tokenize=False))

#word embeddings from google 300 
pymagloc = "C:/Users/caridza/Desktop/pythonScripts/NLP/GoogleNewsvectors_negative300.magnitude"
wv = pymagnitude.Magnitude(pymagloc)
###############################################
#####W2V FUNCTIONAL FORM FOR TESTING###########
###############################################
# Pre-process scraped text and search terms (all documents for the client from all websites for a single languge )
#generates a sentence tokenized list of each text 
#text_list[1] = list of all sentences tokenized into lists of words from doc1
#text_list[1][1] = the second sentence from the second document  , tokenized into a list of words 
text_list = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True, rem_stop=True)
 
# Get tf_idf for site text and search terms
# note: search terms added to first column of the tfidf 
# note: must use SENTENCE_TOKENIZED list of text as input or results will be non sensical
t = tf_idf(text_list, stems)
print(len(t),"total docs:",len(t['tf_idf']),"total words in doc1:"len(t["tf_idf"][1]),"total terms:",len(t['dic']))
max([len(t['tf_idf'][i]) for i in range(0,len(t['tf_idf']))])

for i in range(0,len(t['tf_idf'])):
    print("total words in doc:",str(len(t['tf_idf'][i])))
    
# Get average word vector for search terms
search_vec = avg_phrase(stems, model, t["tf_idf"], t["dic"], 0)

# Instantiate list to store cosine similarities
sim_list = []
sim_list_sent = []
all_list = []
sim_list2 = []
# Option A) get cosine similiarity of tf idf weighted document vector for each site
#for each text(val) in the list of texts , process each sentence in the text , and compute the cosine similarity of the avg word vector 
#representation of the sentence and the average word vector representation fo the keywords 
for idx, val in enumerate(text_list[:2]):
    #print first text ;if idx==1:print(val)
    if len(val) > 0:
        #list to store normalized similarity metric
        sim_list_sent = []
        #for each sentence in each document 
        i = 0 
        for sent in val:
            #if idx==1:
            #    print(sent)
            #print(str(idx),sent)
            
			  #generate the avg vector associated with each sent in doc idx+1
            sent_vec = avg_phrase(sent, model, t["tf_idf"],t["dic"],idx+1)
            if sent_vec.all != 0:                          
                
                #similarity of average sentence vector to each search term vector 
                #sent_sim_max =  max([cosine_sim(wv.query(term),sent_vec) for term in stems]) #method 2: compare the averaged vector of the sentence to each vector tied to each keyword
                #sent_sim_all = [cosine_sim(wv.query(term),sent_vec) for term in stems] #Method 1:each sentence willl have 26 similarity metrics (1 for each term)
                sent_sim2_all = [cosine_sim(search_vec, sent_vec)/len(sent)] #Method 0: one metric for each sentrence (averaged across all stems)
                
                # print(sent, sent_sim2_all)
                # sent_sim = cosine_sim(search_vec, sent_vec) #method 1: compare the averaged vector of keyterms to the avergae vector of the sentence
               
                #descripitve tagging info 
                #term = [term for term in stems]
                #index = np.repeat(idx,[len(stems)])
                #sent_index = np.repeat(i, [len(sent_sim_all)])
                #url = np.repeat(se.urllist[0][idx],[len(stems)])
                url = se.urllist[0][idx]
                i = i + 1
                
            else:
                #sent_sim_max = 0
                #term = [term for term in stems]
                #index = np.repeat(idx,[len(stems)])
                #sent_index = i 
                #url = np.repeat(se.urllist[0][idx],[len(stems)])
                url = se.urllist[0][idx]
                i = i + 1
            
			  #sentence level 
            #append results to rolling list 
            #all_list.append(list(zip(url,index, sent_index, term, sent_sim_all)))
            #normalize the similarity metric by the length of the sentence  
            #sim_list_sent.append(sent_sim_max/len(sent))
            sim_list2.append(list(zip(url, sent, sent_sim2_all)))
             
            
        #document level 
        #append the sent with the max similarity to the search term vector (one per doc processed) 	
        #sim_list.append(max(sim_list_sent))
        
        #append general information about the sentence the match, and the similarity 
        #docinfo.append([se.urllist[0][idx], se.textlist[0][idx] , ])



        
        
        