# -*- coding: utf-8 -*-
"""
Created on Thu Aug  2 10:27:17 2018

@author: caridza
"""

yearsearch = [['2018','2019']]  
location = ['Cary','ECU']
locstring = ['Clevland Ohio']
locstring = 'Clevland Ohio'

len(locstring[0].split(' '))
map(lambda x: '('+' OR '.join(x)+')',yearsearch)
    
list(map(lambda x: '('+' OR '.join(x)+')',yearsearch))[0]


locpart = '({}) '.format(' OR '.join([x for x in location if x != '']))
locpart = '({}) '.format(' OR '.join([x for x in locstring if x != '']))
 
#locpart = '({}) '.format(' OR '.join(locstring.split(' ')))
locpart = '("' + ' '.join(locstring) + '")'

   
#split(locstring)

locpart
loc = []
loc.append(locstring)

namepart = '("' + ' '.join(namelist) + '" AND ' + ' '.join(list(map(lambda x: '' + x + '', loclist))) + ')'


locpart = '({}) '.format(' '.join(locstring.strip().split(' ')))
locpart



a = ("John", "Charles", "Mike")
b = ("Jenny", "Christy", "Monica", "Vicky")

x = zip(b, a)
list(x)

location = [['Cary','ECU']]
locstring = [['Clevland Ohio']]
locstring = [['Clevland Ohio']]
locstring = [['Clevland Ohio'],['zjc']]
locstring = [[],[]]

def isListEmpty(inList):
    if isinstance(inList, list): 
        return all( map(isListEmpty, inList) )
    return False


mystring = "Today is the day that Wells Fargo runs the world"
if 'Wells Fargo' in mystring:
    print('jadfasda')