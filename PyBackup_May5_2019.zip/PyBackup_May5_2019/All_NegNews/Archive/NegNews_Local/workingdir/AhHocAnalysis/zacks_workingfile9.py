# -*- coding: utf-8 -*-
"""
Created on Mon Jun  4 10:27:39 2018

@author: caridza
"""
#Bolun 
#1. Are you extracting the full page, or are you applying the window critera first 
    #a. if you extract the entire page, i can apply the window critera post extraction using OrigTxt_PreProcess() 
#2. We need to remove the lowercase functionality so it is easier to identify starting sentences and NER tagging 

#3. extract stems found in each sentence 
#4. check if first and last name in 
#load modules 
sys.path.insert(0, "C://Users//caridza//Desktop//pythonScripts//NN_Gitlab//")
from nn_base.nn_classes import search_entity as SE
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from gensim import corpora, models, similarities
import string
import re
from fuzzywuzzy import fuzz
import numpy as np
import operator
import pymagnitude
import gensim 
import shlex 
import subprocess 
from sklearn import preprocessing 
import vaderSentiment
import pandas as pd 
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import nltk
from scipy import spatial #used for cosine similarities 
import math #used to filter nan tuple elments from list 
import pickle
from nltk.tokenize import sent_tokenize
import itertools #itertools used to extract sentences around entities name 
from itertools import tee 
from itertools import chain
from itertools import islice




#Load the text extracted from webpages 
#laod data 
se_list_bad2,dfs_bad = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/BadGuys2/")
#se_list_good,dfs_good = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/EY_folks/")

#bad guy 		
se = [se for se in se_list_bad2 if se.entity_lname == 'Cannon'][0]
se1 = [se for se in se_list_bad2 if se.entity_lname == 'Crittenden'][0]
se2 = [se for se in se_list_bad2 if se.entity_fname == 'Dontrelle'][0]
se3 = [se for se in se_list_bad2 if se.entity_fname == 'Brittany'][0]




#execute compiled function 
se_new = w2v_full_Execution(se,w2v_loc = "C:/Users/caridza/Desktop/pythonScripts/NLP/GoogleNewsvectors_negative300.magnitude")
se_new.w2vDfSorted[0][0][0].to_excel('C://Users//caridza//Desktop//pythonScripts//Zack learning(DataCamp)//Python_Misc//example_w2v_revised.xlsx')


#pre-process orginal text list to prepare for w2v and clean_paragraph()
se  = OrigTxt_PreProcess(se, delim ="<!@&>", window=True, se_inout = True)
se1  = OrigTxt_PreProcess(se1, delim ="<!@&>", window=True, se_inout = True)
se2  = OrigTxt_PreProcess(se2, delim ="<!@&>", window=True, se_inout = True)
se3  = OrigTxt_PreProcess(se3, delim ="<!@&>", window=True, se_inout = True)

#Load Embeddings and concatenate google and fasttext 
pymagloc_FT= "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/wiki-news-300d-1M-subword.magnitude" #Fast Text 
pymagloc_Gog = "C:/Users/caridza/Desktop/pythonScripts/NLP/GoogleNewsvectors_negative300.magnitude" #google word vectors 
wv = pymagnitude.Magnitude(pymagloc_Gog) 
#wv = pymagnitude.Magnitude(pymagloc_FT,pymagloc_Gog)

#execute w2v 
se= w2v_se2(se, wv, ndoc=200, nsent=3000 , sent_max = .3, min_sim=.1, delim = '')
se1 = w2v_se2(se1, wv, ndoc=200, nsent=300,sent_max = .3, min_sim=.1, delim = '')
se2 = w2v_se2(se2, wv, ndoc=200, nsent=300,sent_max = .3, min_sim=.1, delim = '')
se3 = w2v_se2(se3, wv, ndoc=200, nsent=300,sent_max = .3, min_sim=.1, delim = '')
se.origtextlist[0]

#Aggregate w2v output (w2vDfSorted)
se = w2v_SortOutput(se, max_sent = .3)
se1 = w2v_SortOutput(se1, max_sent = .3)
se2 = w2v_SortOutput(se2, max_sent = .3)
se3 = w2v_SortOutput(se3, max_sent = .3)

#save results to pickle file
#se_list_bad = [se,se1,se2]
#pickle.dump(se_list_bad, open('C://Users//caridza//Desktop//pythonScripts//NN_Gitlab//workingdir//AhHocAnalysis//ResultsDump//newbads_June6.pkl','wb'))

#processing original text within se object vs string implementation
#se_list_good[1]  = OrigTxt_PreProcess(se_list_good[1], delim ="<!@&>", window=True, se_inout = True)
#text = OrigTxt_PreProcess(se_list_good[1].origtextlist[0][0], delim ="", window=False, se_inout = False)   
se1.w2vDfSorted[0][0][0].to_excel('C://Users//caridza//Desktop//pythonScripts//Zack learning(DataCamp)//Python_Misc//RoshandaBAD.xlsx')
#se1.w2vDfSorted[0][0][0][['Doc','Similarity','Sentiment','FinalDocScore','BothNamePres','Sentence',]]

#Function to execute the full w2v process (input se , output se)
def w2v_full_Execution(se,w2v_loc = "C:/Users/caridza/Desktop/pythonScripts/NLP/GoogleNewsvectors_negative300.magnitude"):
    #load word embeddings
    wv = pymagnitude.Magnitude(w2v_loc) 
    #preprocess scrapyd search results (including windowing critera)
    se = OrigTxt_PreProcess(se, delim ="<!@&>", window=True, se_inout = True)
    #conduct w2v analysis and generate se.w2vInfo to use in sorting output for pdf
    se= w2v_se2(se, wv, ndoc=200, nsent=300 , sent_max = .3, min_sim=.1, delim = '')
    #filter out positive sentiment results and organize search results into se.w2vDfSorted by custom similarity metric at the document then sentence level
    se = w2v_SortOutput(se, max_sent = .3)
    return(se)
    
#concatenate lsit data 
def concatenate_list_data(list):
    result= ''
    for element in list:
        result += str(element)
    return result


#load results from json 
def load_results(nn_class_path, folderpath):
    import json
    import os
    import sys
    import pandas as pd
    
    #set path location of nn_base class functions 
    sys.path.insert(0, nn_class_path)
    from nn_base.nn_classes import search_entity as SE
    
    #curernt directory 
    #cwd = os.getcwd()
    #change working directory 
    #os.chdir(os.path.join(cwd,'Desktop','pythonScripts','NN_Gitlab','workingdir','AhHocAnalysis'))
    
    #function to strip all whitespace from each key (spaces in the json dump will mess things up)
    def trim_key(obj):
        for key in obj.keys():
            new_key = key.strip()
            if new_key != key:
                obj[new_key] = obj[key]
                del obj[key]
        return obj
    
    #folder containing all the results 
    folderpath = folderpath
            
    #set up results objects 
    folder = []
    file = []
    fname = []
    lname = []
    mname = []
    city = []
    state = []
    riskscore_final = []
    
    #final returned obejct with list of all attributes for each individual 
    se_list = []
    #for each file in the results dump folder, extract the key feilds into the se object 
    
    for filename in os.listdir(folderpath):
        #only consider json files 
        if filename.endswith('.json') :
            #load the file and process each feild thorugh the trim_key function to remove whitespace
            jsonfile = json.load(open(folderpath + filename,'r'), object_hook=trim_key)
            jsonfile= trim_key(jsonfile) #trim whitespace again for saftey
            folder.append(folderpath) #append folder where se is located 
            file.append(filename)
            fname.append(jsonfile['entity_fname'])
            mname.append(jsonfile['entity_mname'])
            lname.append(jsonfile['entity_lname'])
            city.append(jsonfile['entity_city'])
            state.append(jsonfile['entity_state'])
            riskscore_final.append(jsonfile['riskscore_final'])
            
            #create empty list object to hold all SE information 
            se = SE(search_lang=['english','spanish'])
            #se.entity_id=jsonfile['id']
            se.entity_id = ''
            se.entity_fname=jsonfile['entity_fname']
            se.entity_lname=jsonfile['entity_lname']
            se.entity_mname=jsonfile['entity_mname']
            se.entity_city=jsonfile['entity_city']
            se.entity_state=jsonfile['entity_state']
            se.entity_state2=jsonfile['entity_state2']
            se.entity_country=jsonfile['entity_country']
            se.entity_occupation=jsonfile['entity_occupation']
            se.entity_company=jsonfile['entity_company']
            se.entity_company2=jsonfile['entity_company2']
            se.entity_querylist=jsonfile['entity_querylist']
            se.searchtermlist=jsonfile['searchtermlist']
            se.search_lang=jsonfile['search_lang']
            se.search_lang_ct=jsonfile['search_lang_ct']
            se.search_lang_short=jsonfile['search_lang_short']
            se.querylisturl=jsonfile['querylisturl']
            se.urllist=jsonfile['urllist']
            se.origtextlist=jsonfile['origtextlist']
            se.textlist=jsonfile['textlist']
            se.static_search_result=jsonfile['static_search_result']
            se.list_fuzzyscore=jsonfile['list_fuzzyscore']
            se.list_fuzzyscoredetail=jsonfile['list_fuzzyscoredetail']
            se.list_matchedstems=jsonfile['list_matchedstems']
            se.LSA_score=jsonfile['LSA_score']
            se.LSA_filter_count=jsonfile['LSA_filter_count']
            se.riskscore_final=jsonfile['riskscore_final']
            se.link_score_threshold=jsonfile['link_score_threshold']
            se.name_fuzzy_all=jsonfile['name_fuzzy_all']
            se.location_fuzzy_all=jsonfile['location_fuzzy_all']
            se.employment_fuzzy_all=jsonfile['employment_fuzzy_all']
            
            #append the se object to the list of all se objects 
            se_list.append(se)
    
    
    #create final df containing all the se informaiton for each individual 
    #this will be used to text lsa / w2v functionality 
    df = pd.DataFrame({'folder': folder, 'filename': file, 'fname':fname, 'mname':mname, 'lname':lname, 'city':city, 'state':state, 'riskscore':riskscore_final})
    return(se_list,df)

#create pandas dfs out of output to sort and prioritize document and article heirarchy in the final pdf 
#Helpful Additions: Year of article , NER output by link , total links available(count of total links google/bing have identified on the www)

#create pandas dfs out of output to sort and prioritize document and article heirarchy in the final pdf 
#Helpful Additions: Year of article , NER output by link , total links available(count of total links google/bing have identified on the www)
def w2v_SortOutput(se, max_sent = .3): 
    def W2V_ScoreAgg(se, max_sent = max_sent):
        
        #copy se objct
        se = se 
        
        #identify first and last name of individual being processed 
        l = [se.entity_fname.upper(),se.entity_lname.upper()]  
        regstr = '&'.join(l)

        if max_sent > .3: 
            #extract w2v score data from list -> convert to df and process at doc and person level 
            #Colnames: name, lsiRiskScore,Doc,Sent,URL,Sentence,Similarity,Sentiment
            scores = [(se.entity_fname+"_"+se.entity_lname, se.riskscore_final[0],x[0][0],x[0][1],x[0][2],x[0][3],x[0][4],x[0][5]) for x in se.w2vInfo[0]]
            flat_list = [sublist  for sublist in scores]#convert scores to dataframe and sort output by Doc -> Similarity 
            se_df = pd.DataFrame(flat_list, columns = ['Person','LSIRiskScore','Doc','Sent','URL','Sentence','Similarity','Sentiment'])
            se_df= se_df.sort_values(by=['Doc','Similarity'],ascending = False)
            se_df= se_df[np.isfinite(se_df['Similarity'])]
            se_df['BothNamePres'] = np.where((se_df['Sentence'].str.upper().str.contains(se.entity_fname.upper()) & (se_df['Sentence'].str.upper().str.contains(se.entity_lname.upper()) )),1,0)

            #add additional mertrics to dataframe 
            se_df['PosSentFlag'] = np.where(se_df['Sentiment']>=.3, 'yes', 'no')
            se_df['NegSentFlag'] = np.where(se_df['Sentiment']<=-.05, 'yes', 'no')
            se_df['NeutSentFlag'] = np.where((se_df['Sentiment']<.3) &(se_df['Sentiment']>-.05), 'yes', 'no')
            
            #Normalized Similarity approaches
            se_df['Sim_Tanh_Norm']=tanh(se_df['Similarity'])
            se_df['Sent_Tanh_Norm']=tanh(se_df['Sentiment'])
            se_df['Sim_Tanh_Weighted']=tanh(se_df['Similarity']+se_df['BothNamePres'])
            #se_df['Sim_Logit_Norm']=(1 / (1 + exp(-se_df['Similarity'])))*2-1
            #se_df['Sent_Logit_Norm']=(1 / (1 + exp(-se_df['Sentiment'])))*2-1

            #extract the highest similarity sentence from each doc and highest sentiment sentence from each doc (pos and neg)
            se_df = se_df.sort_values(by=['Doc','Similarity'],ascending = False);TopSimSentPerDoc = se_df.groupby(by=['Doc']).head(1).reset_index(drop=True)
            se_df = se_df.sort_values(by=['Doc','Sentiment'],ascending = False);TopPosSentSentPerDoc = se_df.groupby(by=['Doc']).head(1).reset_index(drop=True)
            se_df = se_df.sort_values(by=['Doc','Sentiment'],ascending = True);TopNegSentSentPerDoc = se_df.groupby(by=['Doc']).head(1).reset_index(drop=True)
            se_df = se_df.sort_values(by=['Doc','Similarity'],ascending = False)
            
            #create document level dataframe and sort by finaldoc metric
            doc_level = se_df.groupby(by=['Person','Doc','URL'],as_index=False)['Similarity','Sentiment'].sum() 
            doc_level.fillna(0, inplace=True)
            doc_level['TotalDocSents'] = se_df.groupby(by=['Person','Doc'],as_index=False).Sent.nunique()#sum of similarity of all sentences associated with each doc 
            doc_level['PerSentSimilarity'] = doc_level.Similarity /doc_level.TotalDocSents; doc_level.fillna(0, inplace=True)
            doc_level['P_PosSent'] = se_df.groupby(by=['Person','Doc','PosSentFlag']).size().unstack()['yes'].values / doc_level.TotalDocSents; doc_level.fillna(0, inplace=True)
            doc_level['P_NegSent'] = se_df.groupby(by=['Person','Doc','NegSentFlag']).size().unstack()['yes'].values / doc_level.TotalDocSents; doc_level.fillna(0, inplace=True)
            doc_level['P_NeutSent'] = se_df.groupby(by=['Person','Doc','NeutSentFlag']).size().unstack()['yes'].values  / doc_level.TotalDocSents; doc_level.fillna(0, inplace=True)
            doc_level['Avg_Sim_Tanh_Norm'] = se_df.groupby(by=['Person','Doc'],as_index=False)['Sim_Tanh_Norm'].mean()['Sim_Tanh_Norm']
            doc_level['Avg_Sim_Tanh_Weighted'] = se_df.groupby(by=['Person','Doc'],as_index=False)['Sim_Tanh_Weighted'].mean()['Sim_Tanh_Weighted']
            doc_level['DocScore2'] = doc_level.Avg_Sim_Tanh_Norm
            doc_level['FinalDocScore'] = (doc_level.DocScore2 - doc_level.DocScore2.min()) / (doc_level.DocScore2.max()-doc_level.DocScore2.min())      
            doc_level = doc_level.sort_values(by=['Doc','FinalDocScore'],ascending = False)
        
            #add document level information to the sentence dataset for output sorting 
            se_df_sort = se_df.merge(doc_level[['FinalDocScore','Doc']], how='left', left_on='Doc', right_on='Doc')
            se_df_sort = se_df_sort.sort_values(by=['FinalDocScore','Similarity'],ascending = False)
            
            #aggregation of doc scores at the Person level (To determine sample mean , and standard deviation to use in normalizing doc scores) 
            Person_level = se_df.groupby(by=['Person'],as_index=False)['Similarity','Sentiment','Sim_Tanh_Norm','Sim_Logit_Norm','Sent_Tanh_Norm','Sent_Logit_Norm'].sum() #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
            Person_level['TotalLinks'] = se_df.groupby(by=['Person'],as_index=False).Doc.nunique();Person_level.fillna(0,inplace=True) #very distinct distributions(bad people have more hits)
            Person_level['TotalSents'] = se_df.groupby(by=['Person'],as_index=False).Sent.nunique();Person_level.fillna(0,inplace=True) #no help 
            Person_level['P_PosSent'] = se_df.groupby(by=['Person','PosSentFlag']).size().unstack()['yes'].values / Person_level.TotalLinks;Person_level.fillna(0,inplace=True)
            Person_level['P_NegSent'] = se_df.groupby(by=['Person','NegSentFlag']).size().unstack()['yes'].values / Person_level.TotalLinks;Person_level.fillna(0,inplace=True)
            Person_level['P_NeutSent'] = se_df.groupby(by=['Person','NeutSentFlag']).size().unstack()['yes'].values  / Person_level.TotalLinks;Person_level.fillna(0,inplace=True)
            Person_level['Avg_Sim']  = se_df.groupby(by=['Person'],as_index=False)['Similarity'].mean()['Similarity'] #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
            Person_level['Avg_Sim_Tanh_Norm']  = se_df.groupby(by=['Person'],as_index=False)['Sim_Tanh_Norm'].mean()['Sim_Tanh_Norm'] #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
            Person_level['Avg_Sim_Logit_Norm']  = se_df.groupby(by=['Person'],as_index=False)['Sim_Logit_Norm'].mean()['Sim_Logit_Norm'] #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
            Person_level['Avg_Sent'] = se_df.groupby(by=['Person'],as_index=False)['Sentiment'].mean()['Sentiment']
            Person_level['FINAL_SCORE']  = Person_level.Avg_Sim_Logit_Norm*(1/(1+Person_level.P_PosSent)) / (1/Person_level.TotalLinks)#Person_level['FINAL_SCORE']  = Person_level.Avg_Sim_Logit_Norm#*(1-Person_level.Avg_Sent_Logit_Norm) 
            
            #get info for final score 
            #Note: MinVal and MaxVal are the representative min and max valuese found from a sample of 450 search entity objects (50 bad 350 good)
            MinVal = 0.022771272266701493 
            MaxVal = 6.291994240522779
            Person_level['Final_Normalized_Score'] = (Person_level['FINAL_SCORE'] - MinVal) / (MaxVal - MinVal)
            
            #append person level information to sentence level dataframe 
            se_df_sort = se_df_sort.merge(Person_level[['Final_Normalized_Score','Person']], how='left', left_on='Person', right_on='Person')
             
            return(list(zip([se_df_sort],[doc_level],[Person_level])))
        else: 
            #extract w2v score data from list -> convert to df and process at doc and person level 
            #Colnames: name, lsiRiskScore,Doc,Sent,URL,Sentence,Similarity,Sentiment
            scores = [(se.entity_fname+"_"+se.entity_lname, se.riskscore_final[0],x[0][0],x[0][1],x[0][2],x[0][3],x[0][4],x[0][5]) for x in se.w2vInfo[0]]
            flat_list = [sublist  for sublist in scores]#convert scores to dataframe and sort output by Doc -> Similarity 
            se_df = pd.DataFrame(flat_list, columns = ['Person','LSIRiskScore','Doc','Sent','URL','Sentence','Similarity','Sentiment'])
            se_df= se_df.sort_values(by=['Doc','Similarity'],ascending = False)
            se_df= se_df[np.isfinite(se_df['Similarity'])]
            se_df['BothNamePres'] = np.where((se_df['Sentence'].str.upper().str.contains(se.entity_fname.upper()) & (se_df['Sentence'].str.upper().str.contains(se.entity_lname.upper()) )),1,0)

            #Normalized Similarity approaches
            se_df['Sim_Tanh_Norm']=tanh(se_df['Similarity'])
            se_df['Sent_Tanh_Norm']=tanh(se_df['Sentiment'])
            se_df['Sim_Tanh_Weighted']=tanh(se_df['Similarity']+se_df['BothNamePres'])
            #se_df['Sent_Logit_Norm']=(1 / (1 + exp(-se_df['Sentiment'])))*2-1
            #se_df['Sim_Logit_Norm']=(1 / (1 + exp(-se_df['Similarity'])))*2-1

            #extract the highest similarity sentence from each doc and highest sentiment sentence from each doc (pos and neg)
            se_df = se_df.sort_values(by=['Doc','Similarity'],ascending = False);TopSimSentPerDoc = se_df.groupby(by=['Doc']).head(1).reset_index(drop=True)
            se_df = se_df.sort_values(by=['Doc','Sentiment'],ascending = False);TopPosSentSentPerDoc = se_df.groupby(by=['Doc']).head(1).reset_index(drop=True)
            se_df = se_df.sort_values(by=['Doc','Sentiment'],ascending = True);TopNegSentSentPerDoc = se_df.groupby(by=['Doc']).head(1).reset_index(drop=True)
            se_df = se_df.sort_values(by=['Doc','Similarity'],ascending = False)
            
            #create document level dataframe and sort by finaldoc metric
            doc_level = se_df.groupby(by=['Person','Doc','URL'],as_index=False)['Similarity','Sentiment'].sum() 
            doc_level.fillna(0, inplace=True)
            doc_level['TotalDocSents'] = se_df.groupby(by=['Person','Doc'],as_index=False).Sent.nunique()#sum of similarity of all sentences associated with each doc 
            doc_level['PerSentSimilarity'] = doc_level.Similarity /doc_level.TotalDocSents; doc_level.fillna(0, inplace=True)
            doc_level['Avg_Sim_Tanh_Norm'] = se_df.groupby(by=['Person','Doc'],as_index=False)['Sim_Tanh_Norm'].mean()['Sim_Tanh_Norm']
            doc_level['Avg_Sim_Tanh_Weighted'] = se_df.groupby(by=['Person','Doc'],as_index=False)['Sim_Tanh_Weighted'].mean()['Sim_Tanh_Weighted']
            doc_level['DocScore2'] = doc_level.Avg_Sim_Tanh_Norm
            doc_level['FinalDocScore'] = (doc_level.DocScore2 - doc_level.DocScore2.min()) / (doc_level.DocScore2.max()-doc_level.DocScore2.min()) #normalized doc score
            doc_level = doc_level.sort_values(by=['Doc','FinalDocScore'],ascending = False)
            #doc_level['Avg_Sim_Logit_Norm']  = se_df.groupby(by=['Person','Doc'],as_index=False)['Sim_Logit_Norm'].mean()['Sim_Logit_Norm'] 
            #doc_level['DocScore2'] = doc_level.Avg_Sim_Tanh_Norm
            
            #merge document level and sentence level metrics
            #add document level information to the sentence dataset for output sorting 
            se_df_sort = se_df.merge(doc_level[['FinalDocScore','Doc']], how='left', left_on='Doc', right_on='Doc')
            se_df_sort = se_df_sort.sort_values(by=['FinalDocScore','Similarity'],ascending = False)

            #aggregation of doc scores at the Person level (To determine sample mean , and standard deviation to use in normalizing doc scores) 
            Person_level = se_df.groupby(by=['Person'],as_index=False)['Similarity','Sentiment','Sim_Tanh_Norm','Sim_Logit_Norm','Sent_Tanh_Norm','Sent_Logit_Norm'].sum() #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
            Person_level['TotalLinks'] = se_df.groupby(by=['Person'],as_index=False).Doc.nunique();Person_level.fillna(0,inplace=True) #very distinct distributions(bad people have more hits)
            Person_level['TotalSents'] = se_df.groupby(by=['Person'],as_index=False).Sent.nunique();Person_level.fillna(0,inplace=True) #no help 
            Person_level['Avg_Sim']  = se_df.groupby(by=['Person'],as_index=False)['Similarity'].mean()['Similarity'] #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
            Person_level['Avg_Sim_Tanh_Norm']  = se_df.groupby(by=['Person'],as_index=False)['Sim_Tanh_Norm'].mean()['Sim_Tanh_Norm'] #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
            Person_level['Avg_Sim_Logit_Norm']  = se_df.groupby(by=['Person'],as_index=False)['Sim_Logit_Norm'].mean()['Sim_Logit_Norm'] #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
            Person_level['Avg_Sent'] = se_df.groupby(by=['Person'],as_index=False)['Sentiment'].mean()['Sentiment']
            Person_level['FINAL_SCORE']  = Person_level.Avg_Sim_Logit_Norm#Person_level.Avg_Sim_Logit_Norm*(1-Person_level.Avg_Sent_Logit_Norm) #/ (1/Person_level.TotalLinks)
            #Person_level['FINAL_SCORE']  = Person_level.Avg_Sim_Logit_Norm*(1/Person_level.P_PosSent) / (1/Person_level.TotalLinks)
            #Person_level['FINAL_SCORE']  = Person_level.Avg_Sim_Logit_Norm*(1/(1+Person_level.P_PosSent)) / (1/Person_level.TotalLinks)#Person_level['FINAL_SCORE']  = Person_level.Avg_Sim_Logit_Norm#*(1-Person_level.Avg_Sent_Logit_Norm) 
            
            #get info for final score (tihs is from a sample of 400 (~50 BAD) to calculate avg similarity normailzied by logit )
            MinVal = 0.04483958732992438
            MaxVal = 0.2656953953362422
            
            #generate normalized score 
            Person_level['Final_Normalized_Score'] = ((Person_level['FINAL_SCORE'] -MinVal) / (MaxVal-MinVal))
        
            #append person level information to sentence level dataframe 
            se_df_sort = se_df_sort.merge(Person_level[['Final_Normalized_Score','Person']], how='left', left_on='Person', right_on='Person')
            
            return(list(zip([se_df_sort],[doc_level],[Person_level])))
    
        
    #for each languge if the ersults are not blank, extract the post processed text, and clean the search terms , and join them into one string
    for idxx in range(0,se.search_lang_ct):
        if not se.urllist[idxx] == []: 
            #execute the function for each languge 
            se.w2vDfSorted[idxx]  = W2V_ScoreAgg(se)
            
    return(se )   
    

    
    
#PROCESSING FROM ORIGINALTEXT (Takes SE objet and parses out original_txt_list and replaces it with reivesed text to parse)
#window: do you want to apply the window critera to only return lines around the lines found with first or last name
#Note: Windowing is only set up to work wiht an se object 
def OrigTxt_PreProcess(se, delim ='<!@&>', window=False, se_inout = False):
    
    #######################################################
    ################FUNCTION DEFINITIONS###################
    #######################################################
    #check if name is in sentences surrounding the sentence being processed  
    def name_in_sent(s1,s2,s3,fname,lname):
        return True if fname in s1 or fname in s2 or fname in s3 or lname in s1 or lname in s2 or lname in s3 else False
    
    #extracts all sentences before and after the sentence being processed 
    def previous_and_next(some_iterable):
        prevs, items, nexts = tee(some_iterable, 3)
        prevs = chain([''], prevs)
        nexts = chain(islice(nexts, 1, None), [''])
        return zip(prevs, items, nexts) 

    ##################################################################
    ########################EXECUTION START###########################
    ##################################################################
    
    #pre-process the original text and assign it back to original text 
    #if text is not se object it is assumed to be long string 
    if se_inout == True: 
        test = se.origtextlist[0]
    else: 
        test = se 
    #if the delimiter is not defined, then we assume the doc is already delimited in some way so we do not split the doucment further(until sentence tokenization)
    if delim !="":
        test2 = [x.split(delim) for x in test] #split based on custom delimiter
        test3 = [[y.replace('\n',' ') for y in x] for x in test2] #replace all new line characters 
        test4 = [[sent_tokenize(y)for y in x] for x in test3] #sentence tokenize remaining text 
        test5 = [[re.sub('[^A-Za-z ]+', ' ', y) for y in x[0]] for x in test4] #remove all numbers 
        test6 = [[y.strip() for y in x if x] for x in test5] #strip trailing and leading white space 
        test7 = [[y for y in x if not y ==''] for x in test6] #remove blank strings from list of strings 
        test8= [[y for y in x if len(y) > 9] for x in test7] #remove blank strings from list of strings 
        test9= [[re.sub(' +',' ',y) for y in x ] for x in test8] #replace multiple spaces with single space 
    else: 
        test1 = test 
        test2 = [y.replace('\n',' ') for y in test1] #replace all new line characters 
        test3=  [re.sub(' +',' ',y) for y  in test2] #replace multiple spaces with single space 
        test4 = [sent_tokenize(y)for y in  test3] #sentence tokenize remaining text 
        test5 = [[re.sub('[^A-Za-z ]+', ' ', y) for y in x] for x in test4] #remove all numbers 
        test6 = [[y.strip() for y in x if x] for x in test5] #strip trailing and leading white space 
        test7 = [[y for y in x if not y ==''] for x in test6] #remove blank strings from list of strings 
        test8= [[y for y in x if len(y) > 9] for x in test7] #remove blank strings from list of strings 
        test9= [[re.sub(' +',' ',y) for y in x ] for x in test8] #replace multiple spaces with single space 
   #identify window of sentences around teh first and last name of the individual being processed 
    test10= []
    for doc in test9:
        if window==True: 
             #if the entity name is sound in the string 
            #extract the sentence before, the sentence, and the sentence after the sentence 
            test10.append([X[1] for X in list(previous_and_next(doc)) if name_in_sent(X[0].lower(),X[1].lower(),X[2].lower(),se.entity_fname.lower(),se.entity_lname.lower())])
            #test10.append([X for X in doc if name_in_sent(X[0].lower(),X[1].lower(),X[2].lower(),se.entity_fname.lower(),se.entity_lname.lower())])
        else: 
            test10.append(doc)
            
    #append the cleaned text back to the se object , this will only contain the windowed text from each doc if the window option = True
    if se_inout ==True: 
        se.origtextlist[0] = test10 #test10
    else: 
        se = test10 #test10 
    return(se)


def w2v_se2(se, wv, ndoc=5, nsent=3, sent_max = 1, min_sim = .1, delim = ''):
    #Note: we compile the function here and execute the function at the bottom of the parent function 
    
    #compile function to be used on the se(the se elements are extracted from se post below function and then called within this funciton )
    def w2v_SimSent(se, doc_cluster, stems, wv,ndoc,nsent, sent_max, min_sim, delim=delim):
        
        #text procesed by w2v vs original sentence to be passed to vadar
        text_list = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True, rem_stop=True , delim = delim)
        text_list_vader = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True, rem_stop=False, delim =delim) #note: both text list, 
        
        #tfidf 
        t = tf_idf(text_list, stems)
        
        #Get average word vector for search terms
        search_vec = avg_phrase(stems, wv, t["tf_idf"], t["dic"], 0)

        #W2V Execution 
        #compute average word embeddings and identify cosine similarity of the average word vector of the sentence vs average vector of search tersm     
        from datetime import datetime
        startTime = datetime.now()
        sim_list2 = []
        sim_list_filtered = []

        for idx, val in enumerate(text_list):
            #print first text ;if idx==1:print(val)
            if len(val) > 0 and idx < ndoc:
        
                #for each sentence in each document 
                for idx2, sent in enumerate(val):
                    
                    #get sent score up front for downstream use 
                    Vad_Score = VADERSENT(' '.join(text_list_vader[idx][idx2]),many=False)[0][1]
                    
                    #generate the avg vector associated with each sent in doc idx+1 (because idx(0) is the stems)
                    sent_vec = avg_phrase(sent, wv, t["tf_idf"],t["dic"],idx+1)
                    
                    #could also try including VADER filter here (got error last time)
                    if sent_vec.all != 0 and idx2 < nsent: 
                        #print(len(sent))
                        #error handling to prevent computation of cosine similarity with negative numbers 
                        try:                           
                            sim = cosine_sim(search_vec, sent_vec)
                            sent_sim2_all = [sim] #Method 0: one metric for each sentrence (averaged across all stems) #NORMALIZING BIAS SHORT STRINGS FOR LONG ONES REGADLESS   
                        except: 
                            sent_sim2_all = [0] #REMOVE THIS, THIS IS NOT GOOD 
                                      
                        #only extract sentences that meet similarity and sentiment thresholds
                        if sim > min_sim and Vad_Score < sent_max:
                            #sim_list2.append(list(zip([idx],[idx2],['DummyURL'],[' '.join(text_list[idx][idx2])],sent_sim2_all, [Vad_Score]))) #Without URL Included 
                            sim_list2.append(list(zip([idx],[idx2],[se.urllist[0][idx]],[' '.join(text_list[idx][idx2])],sent_sim2_all, [Vad_Score]))) #Without URL Included 
                            #sim_list2.append(list(zip([idx],[idx2],[' '.join(text_list[idx][idx2])],[' '.join(text_list_vader[idx][idx2])],sent_sim2_all, [Vad_Score]))) #Dummy URL Included 
                            #sim_list2.append(list(zip([idx],[idx2],[se.urllist[0][idx]],[' '.join(doc_dic[idx][idx2][1])],sent_sim2_all, [Vad_Score]))) #Option 1: With URL Included
                            #sim_list2.append(list(zip([idx],[idx2],'SentHolder',sent_sim2_all, [VADERSENT(' '.join(doc_dic[idx][idx2][1]),many=False)[0][1]])))                            
                            #sim_list2.append(list(zip([idx],[idx2],sent_sim2_all))),[se.urllist[0][idx]])))#,sent_sim2_all)))
        #total time required to run algo 
        print(datetime.now() - startTime)
        return(sim_list2)
    
    #for each languge if the ersults are not blank, extract the post processed text, and clean the search terms , and join them into one string
    for idxx in range(0,se.search_lang_ct):
        if not se.urllist[idxx] == []:
            #pull out original text from se object 
            #docs and stems/keywords
            se = se
            doc_cluster = se.origtextlist[idxx]
            stems= clean_paragraph(se.searchtermlist[idxx], se.search_lang_short[idxx], stemming=False, sent_tokenize=False, rem_stop=True)
                   
            #execute the function for each languge 
            se.w2vInfo[idxx]  = w2v_SimSent(se,  doc_cluster, stems, wv, ndoc=ndoc, nsent=nsent, sent_max=sent_max, min_sim = min_sim)    
    return(se)

        

def clean_paragraph(content, lang, stemming=True, sent_tokenize=False, rem_stop=True, delim="<!@&>"):
    if lang in SnowballStemmer.languages:
        #set up stopword and stemming objects specific to languge specified
        stop = set(stopwords.words(lang))
        stemmer = SnowballStemmer(lang)
        ##if languge specified does not exist default to english
    else:
        stop = set(stopwords.words('english'))
        stemmer = SnowballStemmer('english')
    # puncremove = str.maketrans(string.punctuation,' '*len(string.punctuation))  
    def clean_text(text, delim = delim ):
        #sent tokenize and remove stop words, and alpha's and put to lower 
        #note: for w2v we do NOT want to stem the words or remove punctuation 
        if sent_tokenize == True:
            if delim !='':
                sent_tokens = text.split(delim)
            else: 
                sent_tokens = text
            # sent_tokens = nltk.sent_tokenize(text)
            tokens = [nltk.regexp_tokenize(sentence, r'\w+') for sentence in sent_tokens]
            rettext = []
            
            if rem_stop ==True: 
                for sent in tokens:
                    rettext.append([w.lower() for w in sent if w.isalpha() and not w in stop and len(w) > 1])
            
            #string is not put to lowercase, stopwords are not removed. however, limiting to char> 1 will prevent punctuation from being incorporated
            else:
                for sent in tokens:
                    rettext.append([w for w in sent if w.isalpha() and len(w) > 1])
        #if we are performing lsa then we remove punctionation , remove stops, lower, and stem 
        else:
             #remove punctuation from each string 
            for punc in string.punctuation:
                text = text.replace(punc, '')
            #text to lower, split by word, and remove stop words    
            rettext = [x for x in text.lower().split() if (x != '' and x not in stop)]
            if stemming==True:
                #stem text(at the word level)
                rettext = [stemmer.stem(x) for x in rettext]
            rettext = ' '.join(rettext)
        #return the clean text object 
        return rettext
        
    if type(content) is list:
        out = [clean_text(x) for x in content]
    else:
        out = clean_text(content)
    return out

#tfidf 
def tf_idf(site_list, search_terms):
    doc_list = []
    for site in site_list:
        #Note: this assumes you have sentence tokenized documents 
        #item represents a word, sublist represents a sentence vector , site represents the document(all the sentences in the doc in sent tokenized format)
        doc_list.append([item for sublist in site for item in sublist])
    
    #append the search terms to the front of the document list (doc_list[0]= search terms)
    texts = [search_terms] + doc_list
    #create a dictonary to hold all key value pairs for all terms found across all documents in the doclist (key = word index, value = word)
    dictionary = corpora.Dictionary(texts)
    ##create a bow tokenized mapping of all words in text #convert tokenized documents to vectors 
    corpus = [dictionary.doc2bow(text) for text in texts]
    ## fit and normalize a tf-idf model to the corpus , and map words in dictonary to ids 
    tf_idf_model = models.TfidfModel(corpus,id2word=dictionary, normalize=True) # fit model
    #apply the tfidf model to the corpus 
    tf_idf_corp = tf_idf_model[corpus] 
    #extract a dictonary of 2 dictonaries, one contianing the tf_idf vectors for all texts and the other a dicontary of key-value mappings of the words in the text 
    tf_idf_items = {"dic": dictionary, "tf_idf": tf_idf_corp}
    return tf_idf_items


#function to get sentiment of sentence 
def VADERSENT(sentences, many = True):
    analyzer = SentimentIntensityAnalyzer()
    str_sent = []
    if many==True:    
        str_df = pd.DataFrame(index=range(1,len(sentences)), columns=['sentence','sentiment'])       
        #iterate through all sentences and extract sentiment 
        i=0
        for sentence in sentences:
            vs = analyzer.polarity_scores(sentence)
            str_sent.append((sentence, vs['compound']))
            str_df.loc[i] = [sentence, vs['compound']]
            i = i+1 
        return(str_df, str_sent)
    else: 
        vs = analyzer.polarity_scores(sentences)
        str_sent.append((sentences, vs['compound']))
        return(str_sent)

# Function to get cosine similarity 
def cosine_sim(a, b):
    return 1 - spatial.distance.cosine(a, b)
     
# Function to get weighted average vector of a sentence. Weighting is done by multiplying tf-idf scores
# note: Changed function so wv(google vecs) are not re-initalized on every call of the funtion, instead wv is defined outside the function and simply referenced inside the function
def avg_phrase(phrase, wv, tf_idf, dictionary, doc_id):

	v = np.zeros(300) #create empty vector to hold the average vector of the nword phrase being processed(likley a sentence)
	#for each word that is in the sentence being processed 
    #note: we use set() operator here to remove duplicate values of words, we only want to capture each word in the phrase one time when calculating average word vectors. 
	for w in set(phrase):
       #if the word is found in the google word embeddings 
		if w in wv:
          #extract the token index associated with the word from the dictonary of all terms contained in the tf-idf 
			word_id = dictionary.token2id[w]
          #extract the tfidf vector of weightings for the document being processed
			doc_vectors = tf_idf[doc_id]
          #create a dictonary from the resulting doc_vector (word_index, tf-idf weighting) 
			d = dict(doc_vectors)
          #return the tf-idf from the dictonary associated with the tf-idf vector of weightings for the doc being processed and extract the weight associated with the word being processed
			tf_score = d[word_id] 
          #alter the google word vector representing the word being procssed to account for its importance in the document being processed via tf-idf weighting 
			v += wv.query(w) * tf_score
   #after all words in the sentence have been processed normilize the final vector back to unit length reprsenting the average word embedding vector for the terms in the sentence 
	v_norm = preprocessing.normalize(v.reshape(1,-1))
	return  v_norm