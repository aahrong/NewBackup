#pip install --proxy http://amweb.ey.net:8080 vaderSentiment 
from nn_base.nn_classes import search_entity as SE
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from gensim import corpora, models, similarities
import string
import re
from fuzzywuzzy import fuzz
import numpy as np
import operator
import pymagnitude
import gensim 
import shlex 
import subprocess 
from sklearn import preprocessing 

#load google w2v model (will be stored all in memory)
#bigrams from google 300 model:  [bigram for bigram in m.index2word if '_' in bigram]
#w2v = gensim.models.Word2Vec.load_word2vec_format(, binary = True)
#https://github.com/zeffii/NLP_class_notes/blob/master/readme.md
#load google 300 using pymagnitude vectors(will be stored on disk) 
#1.convet google w2v bin file to magnitude format using pymagnitude converter 
#input_file: C:/Users/caridza/Desktop/pythonScripts/NLP/GoogleNews_vectors_negative300.bin 
#output_file: C:/Users/caridza/Desktop/pythonScripts/NLP/Google300.magnitude
#pymagconvert(input_file = "C:/Users/caridza/Desktop/pythonScripts/NLP/GoogleNews_vectors_negative300.bin", output_file = "C:/Users/caridza/Desktop/pythonScripts/NLP/Google300.magnitude")
#2.load magnitude file into python object 
#g300_vecs = pymagnitude.Magnitude("path" , lazy_loading = True , use_numpy = True , case_insensative=True, eager=True, ngram_oov=True )



#inputs to most functions being tested
pymagloc = "C:/Users/caridza/Desktop/pythonScripts/NLP/GoogleNewsvectors_negative300.magnitude"
se_list,dfs = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/")
doc_cluster = se_list[1].textlist[0]
doc_cluster2 = se_list[1].textlist[0]

text_list = doc_cluster
stems = ' '.join(clean_paragraph(se_list[1].searchtermlist[0], se_list[1].search_lang_short[0], stemming=False, sent_tokenize=False))
stems2= clean_paragraph(se_list[1].searchtermlist[0], se_list[1].search_lang_short[0], stemming=False, sent_tokenize=False)
wv = pymagnitude.Magnitude(pymagloc)

#tfidf for 
dict2use, tfidf_corp = tf_idf(doc_cluster, stems)
print(list(tfidf_corp));print(list(dict2use.token2id)); for doc in tfidf_corp: print(doc) #print tfidf weightings for each indexed token 

#average phrase 
#Get average vector for search terms
search_vec = avg_phrase(stems2, pymagloc, tfidf_corp, dict2use, 0)


# Instantiate list to store cosine similarities
cos_type =1;
sim_list = [];cnt_list = []
if cos_type == 1:
    # Option A) get cosine similiarity of tf idf weighted document vector for each site
    for idx, val in enumerate(text_list):
        print(idx, len(val))
        if len(val) > 0:
            sites_flat = val #[item for item in val] #[item for sublist in val for item in sublist]#[item for item in val]
            text_vec = avg_phrase(val, pymagloc, tfidf_corp, dict2use, idx + 1)
            if text_vec.all != 0:
                site_sim = cosine_sim(search_vec,text_vec)
                cnt_list.append(len(sites_flat))
                sim_list.append(site_sim)  






def avg_phrase(phrase, pymagloc, tf_idf, dictionary, doc_id):
    wv = pymagnitude.Magnitude(pymagloc)
    v = np.zeros(300)
    print(set(phrase))
    for w in set(phrase):
        if w in wv:
            word_id = dictionary.token2id[w]
            doc_vectors = tf_idf[doc_id]
            d = dict(doc_vectors)
            tf_score = d[word_id] 
            v += wv.query(w) * tf_score
    v_norm = preprocessing.normalize(v.reshape(1,-1))
    return  v_norm






















#tfidf function to create tfidf encompassing all documents associated with an individual 
def tf_idf(doc_list, search_terms):
    doc_list = [search_terms] + doc_list
    texts = [document.split() for document in doc_list]
    dictionary = corpora.Dictionary(texts)
    corpus = [dictionary.doc2bow(text) for text in texts] #convert tokenized documents to vectors 
    ## Using tf-idf conversion for corpus 
    tf_idf_model = models.TfidfModel(corpus,id2word=dictionary, normalize=True) # fit model
    tf_idf_corp = tf_idf_model[corpus] # apply model
    #tf_idf_items = {"dic": dictionary, "tf_idf": tf_idf_corp}
    return(dictionary, tf_idf_corp)

# Function to get cosine similarity 
def cosine_sim(a, b):
    return 1 - spatial.distance.cosine(a, b)
     




#tf-idf 
doc_list = [stems] + text_list
texts = [document.split() for document in doc_list]
dictionary = corpora.Dictionary(texts)
corpus = [dictionary.doc2bow(text) for text in texts] #convert texts into bow numeric representations 
## Using tf-idf conversion for corpus 
tf_idf_model = models.TfidfModel(corpus,id2word=dictionary, normalize=True) # fit model
tf_idf_corp = tf_idf_model[corpus] # apply model
tf_idf_items = {"dic": dictionary, "tf_idf": tf_idf_corp}

#
#avg phase functional breakout 
#
#inputs: (phrase, pymagloc, tf_idf, dictionary, doc_id)
wv = pymagnitude.Magnitude(pymagloc) #google vectors
v = np.zeros(300) #hold the sum of the wordvectors embeddings 
print(set(stems2))
#for each word in the keyword list 
for w in set(stems2):
    #if the keyword is found in the google word vectors
    if w in wv:
        word_id = dict2use.token2id[w]  #find id assocaiated with term in dictonary , the id represents the term itself
        doc_vectors = tfidf_corp[5]    #tfidf weightings of the document being processed 
        d = dict(doc_vectors)         # converts all terms in the document being processed into a dictonary 
        tf_score = d[word_id]         # for the word in the dictonary pull back the tfidf weighting associated with that term in the document being processed
        v += wv.query(w) * tf_score   # weight the embedding for the tfidf score, words that are more important will have a higher score 
v_norm = preprocessing.normalize(v.reshape(1,-1)) #normalize to unit vector space 
#






#tf-idf 
doc_list = []
for site in site_list:
    doc_list.append([item for sublist in site for item in sublist])
texts = [search_terms] + doc_list
dictionary = corpora.Dictionary(texts)
corpus = [dictionary.doc2bow(text) for text in texts]
## Using tf-idf conversion for corpus 
tf_idf_model = models.TfidfModel(corpus,id2word=dictionary, normalize=True) # fit model
tf_idf_corp = tf_idf_model[corpus] # apply model
tf_idf_items = {"dic": dictionary, "tf_idf": tf_idf_corp}




# Re-ordering search results based on W2V similarity instead of LSI
def W2V_function(se):
    # Create TF-IDF to be used in weighting word2vec values.
    def tf_idf(site_list, search_terms):
        doc_list = []
        for site in site_list:
            doc_list.append([item for sublist in site for item in sublist])
        texts = [search_terms] + doc_list
        dictionary = corpora.Dictionary(texts)
        corpus = [dictionary.doc2bow(text) for text in texts]
        ## Using tf-idf conversion for corpus 
        tf_idf_model = models.TfidfModel(corpus,id2word=dictionary, normalize=True) # fit model
        tf_idf_corp = tf_idf_model[corpus] # apply model
        tf_idf_items = {"dic": dictionary, "tf_idf": tf_idf_corp}
        return tf_idf_items
    
    # Function to get cosine similarity 
    def cosine_sim(a, b):
        return 1 - spatial.distance.cosine(a, b)
    
    # Function to get weighted average vector of a sentence. Weighting is done by multiplying tf-idf scores
    def avg_phrase(phrase, pymagloc, tf_idf, dictionary, doc_id):
        wv = pymagnitude.Magnitude(pymagloc)
        v = np.zeros(300)
        print(set(phrase))
        for w in set(phrase):
            if w in wv:
                word_id = dictionary.token2id[w]
                doc_vectors = tf_idf[doc_id]
                d = dict(doc_vectors)
                tf_score = d[word_id] 
                v += wv.query(w) * tf_score
        v_norm = preprocessing.normalize(v.reshape(1,-1))
        return  v_norm

#'C:\\Users\\yangbo\\Documents\\Engagements\\04 INTAML\\Negative_News\\bitbucket\\fci-negative-news-api\\sourcefile\\GoogleNews-vectors-negative300.magnitude'

    def W2V_function_single(doc_cluster, stems):
        # Pre-process scraped text and search terms
        text_list = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True)
        # Get tf_idf for site text and search terms
        t = tf_idf(text_list, stems)
        # Get average vector for search terms
        search_vec = avg_phrase(stems, model, t["tf_idf"], t["dic"], 0)
        
        # Instantiate list to store cosine similarities
        sim_list = []
        cnt_list = []
        
        if cos_type == 1:
            # Option A) get cosine similiarity of tf idf weighted document vector for each site
            for idx, val in enumerate(text_list):
                if len(val) > 0:
                    sites_flat = [item for sublist in val for item in sublist]
                    text_vec = avg_phrase(sites_flat, model, t["tf_idf"], t["dic"], idx + 1)
                    if text_vec.all != 0:
                        site_sim = cosine_sim(search_vec,text_vec)
                        cnt_list.append(len(sites_flat))
                        sim_list.append(site_sim)  
        else:             
            # Option B) Get soft cosine similarity for each site using gensim functions
            doc_list = []  # Create list of flattened docs
            for site in text_list:
                doc_list.append([item for sublist in site for item in sublist])
            dictionary = t["dic"] #Dictionary to be used in gensim functions
            corpus = [dictionary.doc2bow(text) for text in doc_list]
            similarity_matrix = model.similarity_matrix(dictionary)  # construct similarity matrix
            index = similarities.SoftCosineSimilarity(corpus, similarity_matrix) # Does not run with pymagnitude and gensim 
            
            # Calculate similarity between query and each doc from bow_corpus
            sim_list = index[dictionary.doc2bow(search_terms)]
            
            # Get word counts for each site to be used in final score calculation
            for idx, val in enumerate(text_list):
                if len(val) > 0:
                    sites_flat = [item for sublist in val for item in sublist]
                    cnt_list.append(len(sites_flat))
            
        # Take average of site similarity scores for final scores
        total_len = sum(cnt_list)
        weighted_sims = [sim * (cnt/total_len) for sim, cnt in zip(sim_list,cnt_list)]
        se.nn_score = sum(weighted_sims)
    return se.nn_score

    for idx in range(0,se.search_lang_ct):
        if not se.urllist[idx] == []:
            doc_cluster = se.textlist[idx]
            stems = ' '.join(clean_paragraph(se.searchtermlist[idx], se.search_lang_short[idx]))
            se.ranking_score[idx] = W2V_function_single(doc_cluster, stems)
    return se


############ Experimentation Script - Not for production #########################
# test_path = ("C:/Users/queenmi/Documents/Text_Analytics/Negative_News/Negativenews/" +
# "website_scraper_multilang/sourcefile/test/workingdir/Query_Pickle_returned.pk")

# test_path = "C:/Users/queenmi/Documents/Text_Analytics/Negative_News/Negativenews/website_scraper_multilang/workingdir/Aggregation_20180329.pk"

# test = pd.read_pickle(test_path)

# w2v_path = config.source_path + "GoogleNews-vectors-negative300.bin.gz"
# model = models.KeyedVectors.load_word2vec_format(w2v_path, binary=True, limit = 200000)
# test = test.iloc[0:15,:]
# scores = []

# class SEclass:
#     def __init__(self,site_text,search_terms):
#         self.origtextlist = site_text
#         self.searchterm_list = search_terms        

# for index,row in test.iterrows():
#     if row["origtextlist"] != None and row["searchterm_list"] != None:
#         se = SEclass(row["origtextlist"],row["searchterm_list"])
#         scores.append(wordvector_function(se,model))   
#     else:
#         scores.append(None)

# test["w2v"] = pd.Series(scores)
# test_df = test[["FirstName","LastName","w2v"]]

##### Normalization testing #######
def normalize_LSA(score):
    lsa_sum = (score)*100
    a = 0.342419512682912
    b = 1.19480978536808
    c = 0.211456297918287
    d = 0.779544742969885
    percent_risk = c + d*np.tanh((lsa_sum-a)/b)
    return(percent_risk*100)

t_df["w2v_norm"] = t_df["w2v"].apply(lambda x: 1/(1+np.exp(-x)))