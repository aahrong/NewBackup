#modules
#path of user created nn_base module 
sys.path.insert(0, "C://Users//caridza//Desktop//pythonScripts//NN_Gitlab//")
from nn_base.nn_classes import search_entity as SE
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from gensim import corpora, models, similarities
import string
import re
from fuzzywuzzy import fuzz
import numpy as np
import operator
import pymagnitude
import gensim 
import shlex 
import subprocess 
from sklearn import preprocessing 
import vaderSentiment 
import pandas as pd 
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import nltk
from scipy import spatial #used for cosine similarities 
import math #used to filter nan tuple elments from list 
##pip install --proxy http://amweb.ey.net:8080 vaderSentiment 

#load google word embeddig model
#note: runs way faster when only compiled a single time
pymagloc = "C:/Users/caridza/Desktop/pythonScripts/NLP/GoogleNewsvectors_negative300.magnitude"
wv = pymagnitude.Magnitude(pymagloc)
                          
#load se objects
#se_list_orig,dfs_orig = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/Dump1/")
se_list_bad2,dfs_bad = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/BadGuys/")
se_list_good,dfs_good = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/EY_folks/")
se_Factiva,dfs_factiva = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/Factiva/")

print(len(se_list_bad2),len(se_list_good))

#bads 
all_bad_se2 = []
for i in range(0,len(se_list_bad2)):
    se = se_list_bad2[i]
    se = w2v_se2(se, wv, ndoc=6,nsent=3)
    #Scores_Bad.append([(x[0],x[1],x[4],x[5]) for x in se.w2vInfo[0]])
    all_bad_se2.append(se)
    print(str(i))

#goods 
all_good_se = []
for i in range(0,len(se_list_good)):
    se = se_list_good[i]
    se = w2v_se2(se, wv, ndoc=3, nsent=3)
    all_good_se.append(se)
    print(str(i))


#save as pickle and load back as list 
#pickle.dump(all_good_se, open('C://Users//caridza//Desktop//pythonScripts//NN_Gitlab//workingdir//AhHocAnalysis//ResultsDump//good.pkl','wb'))
#good = pickle.load(open('C://Users//caridza//Desktop//pythonScripts//NN_Gitlab//workingdir//AhHocAnalysis//ResultsDump//good.pkl','rb'))
#pickle.dump(all_bad_se2, open('C://Users//caridza//Desktop//pythonScripts//NN_Gitlab//workingdir//AhHocAnalysis//ResultsDump//bad.pkl','wb'))
#bad = pickle.load(open('C://Users//caridza//Desktop//pythonScripts//NN_Gitlab//workingdir//AhHocAnalysis//ResultsDump//bad.pkl','rb'))
    
#extract raw scores to plot 
Scores_Bad=[]
for i in range(0,len(all_bad_se2)):
    Scores_Bad.append([(all_bad_se2[i].entity_fname+"_"+all_bad_se2[i].entity_lname, all_bad_se2[i].riskscore_final[0],x[0][0],x[0][1],x[0][3],x[0][4]) for x in all_bad_se2[i].w2vInfo[0]])
  
#create flattened list and convert to pandas 
flat_listb = [item for sublist in Scores_Bad for item in sublist]
dfb = pd.DataFrame(flat_listb , columns = ['Person','LSIRiskScore','Doc','Sent','Similarity','Sentiment'])
dfb = dfb.sort_values(by=['Person','Similarity'],ascending = False)
dfb = dfb[np.isfinite(dfb['Similarity'])]
dfb['typed'] = 'BAD'

#extract raw scores to plot 
Good_scores=[]
for i in range(0,len(all_good_se)):
    score = [(all_good_se[i].entity_fname+"_"+all_good_se[i].entity_lname,all_good_se[i].riskscore_final[0],x[0][0],x[0][1],x[0][3],x[0][4]) for x in all_good_se[i].w2vInfo[0]]
    Good_scores.append(list(filter(None, score)))
    #Good_scores3.append( [t for t in score if not any(isinstance(n, float) and math.isnan(n) for n in t)])


#create flattened list and convert to pandas      
flat_listg = [item for sublist in Good_scores for item in sublist]
dfg = pd.DataFrame(flat_listg , columns = ['Person','LSIRiskScore','Doc','Sent','Similarity','Sentiment'])
dfg = dfg.sort_values(by=['Person','Similarity'],ascending = False)
dfg = dfg[np.isfinite(dfg['Similarity'])]
dfg['typed']='GOOD'

#final dataset to use 
#append good and bad into single datafarme 
bigdata = dfb.append(dfg, ignore_index=True)
bigdata['PosSentFlag'] = np.where(bigdata['Sentiment']>=.3, 'yes', 'no')
bigdata['NegSentFlag'] = np.where(bigdata['Sentiment']<=.-05, 'yes', 'no')
bigdata['NeutSentFlag'] = np.where((bigdata['Sentiment']<.3) &(bigdata['Sentiment']>-.05), 'yes', 'no')

#aggregation of doc scores at the Person level 
Person_level = bigdata.groupby(by=['typed','Person'],as_index=False)['Similarity','Sentiment'].sum()
Person_level['Avg_Sent'] = bigdata.groupby(by=['typed','Person'],as_index=False)['Sentiment'].mean()['Sentiment']
Person_level['Min_Sent'] = bigdata.groupby(by=['typed','Person'],as_index=False)['Sentiment'].min()['Sentiment']
Person_level['Max_Sent'] = bigdata.groupby(by=['typed','Person'],as_index=False)['Sentiment'].max()['Sentiment']
Person_level['TotalLinks'] = bigdata.groupby(by=['typed','Person'],as_index=False).Doc.nunique()
Person_level['TotalSents'] = bigdata.groupby(by=['typed','Person'],as_index=False).Sent.nunique()
Person_level['TotalPosSent'] = bigdata.groupby(by=['Person','PosSentFlag']).size().unstack()['yes']
Person_level['TotalNegSent'] = bigdata.groupby(by=['Person','NegSentFlag']).size().unstack()['yes']
Person_level['NeutSentFlag'] = bigdata.groupby(by=['Person','NeutSentFlag']).size().unstack()['yes']



#percentage of sentences taht are negative , neutral, and positive 
Person_level['TotalPosSents'] = bigdata[(bigdata ['Sentiment']>=.30))][['Docidx','Sentidx']].count()

bigdata.groupby('Person').size().reset_index(name='Count')
    
    
Person_level['TotalNuetralSents'] = bigdata[(bigdata ['Sentiment']>-.05) & (bigdata ['Sentiment']<.30)][['Docidx','Sentidx']].count()
Person_level['TotalNegSents'] = bigdata[(bigdata ['Sentiment']<=-.05)][['Docidx','Sentidx']].count()
Person_level = Person_level.sort_values('Similarity', ascending=False)


df1 = bigdata.loc[bigdata.groupby('Person').Sentiment.filter(lambda x: x.values() <.3).index]

bigdata.groupby('Person').apply(lambda g: g[g['PosSentFlag'] =='yes'])

#plotting
import matplotlib.pyplot as plt 
import seaborn as sns 
sns.set(color_codes=True)
#sidebyside hist
bigdata['Similarity'].hist(by=bigdata['typed'])

#SIMILARITY density plot overlaid 
w2v=sns.kdeplot(bigdata.loc[bigdata['typed'] == 'GOOD', 'Similarity'], shade=True, color="b")
w2v=sns.kdeplot(bigdata.loc[bigdata['typed'] == 'BAD', 'Similarity'], shade=True, color="r")


#SENTIMENT density plot overlaid 
p2=sns.kdeplot(bigdata.loc[bigdata['typed'] == 'GOOD', 'Sentiment'], shade=True, color="r")
p2=sns.kdeplot(bigdata.loc[bigdata['typed'] == 'BAD', 'Sentiment'], shade=True, color="b")

#boxplots 
bigdata[['Similarity','Sentiment','typed']].boxplot(by='typed')
bigdata[['Similarity','Sentiment','LSIRiskScore','typed']].boxplot(by='typed')




#aggregation of doc scores at the document level 
doc_level = bigdata.groupby(by=['typed','Person','Doc'],as_index=False)['Similarity','Sentiment'].sum()

#get min and max values 
#Person_level.loc[Person_level['typed'] == 'GOOD', :]







#check presence of individual in dataset 
Persons = pd.Series(Person_level['Person'])
Person_level[Persons.str.contains('Clew')]


doc_level.groupby('typed')['Similarity'].describe()
doc_level.groupby('typed')['Similarity'].describe()


#SENTIMENT density plot overlaid 
p2=sns.kdeplot(doc_level.loc[doc_level['typed'] == 'GOOD', 'Similarity'], shade=True, color="b")
p2=sns.kdeplot(doc_level.loc[doc_level['typed'] == 'BAD', 'Similarity'], shade=True, color="r")

p3=sns.kdeplot(Person_level.loc[Person_level['typed'] == 'GOOD', 'Similarity'], shade=True, color="b")
p3=sns.kdeplot(Person_level.loc[Person_level['typed'] == 'BAD', 'Similarity'], shade=True, color="r")

lsi=sns.kdeplot(bigdata.loc[bigdata['typed'] == 'BAD',:].groupby(by=['Person','typed','LSIRiskScore'],as_index=False).max()['LSIRiskScore'], shade=True, color="r")
lsi=sns.kdeplot(bigdata.loc[bigdata['typed'] == 'GOOD',:].groupby(by=['Person','typed','LSIRiskScore'],as_index=False).max()['LSIRiskScore'], shade=True, color="b")



#aggregation of doc scores at the document level 
bigdata.loc[bigdata['typed'] == 'GOOD', :].groupby(by=['Person','Doc'],as_index=False)['Similarity','Sentiment'].sum()


dfsum['AvgSim'] = bigdata.groupby('Person')['Similarity'].sum()

dfsum['MaxSim'] = bigdata.groupby('Doc')['Similarity'].max()
dfsum['MinSim'] = bigdata.groupby('Doc')['Similarity'].min()

dfsum['MaxSent'] = bigdata.groupby('Doc')['Sentiment'].max()
dfsum['MinSent'] = bigdata.groupby('Doc')['Sentiment'].min()

dfsum['StdSent'] = bigdata.groupby('Doc')['Sentiment'].std()
dfsum['StdSim'] = bigdata.groupby('Doc')['Similarity'].std()

bigdata.groupby('typed')['Similarity'].describe()
bigdata.groupby('typed')['Sentiment'].describe()






#contingency table 
bigdata




#numeric summary 
#at the typed level (NOT USEFUL)
dfsum = pd.DataFrame()
dfsum['AvgSent'] = bigdata.groupby('typed')['Sentiment'].mean()
dfsum['AvgSim'] = bigdata.groupby('typed')['Similarity'].mean()

dfsum['MaxSim'] = bigdata.groupby('typed')['Similarity'].max()
dfsum['MinSim'] = bigdata.groupby('typed')['Similarity'].min()

dfsum['MaxSent'] = bigdata.groupby('typed')['Sentiment'].max()
dfsum['MinSent'] = bigdata.groupby('typed')['Sentiment'].min()

dfsum['StdSent'] = bigdata.groupby('typed')['Sentiment'].std()
dfsum['StdSim'] = bigdata.groupby('typed')['Similarity'].std()

bigdata.groupby('typed')['Similarity'].describe()
bigdata.groupby('typed')['Sentiment'].describe()


























def w2v_se2(se, wv, ndoc=5, nsent=3):

    #compile function to be used on the se(the se elements are extracted from se post below function and then called within this funciton )
    def w2v_SimSent(doc_cluster, stems, wv,ndoc,nsent):
        
        #text procesed by w2v vs original sentence to be passed to vadar
        text_list = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True, rem_stop=True)
        text_list_vader = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True, rem_stop=False) #note: both text list, 
        
        #tfidf 
        t = tf_idf(text_list, stems)
        
        #Get average word vector for search terms
        search_vec = avg_phrase(stems, wv, t["tf_idf"], t["dic"], 0)
        
        #store new and old value of sentence in dictonary as tuple
        doc_dic = {} #inialize dic 
        idx=0 #doc index
        for  val ,val_vad in zip(text_list,text_list_vader):   
            idx2=0 #sent index re-initiated for every doc 
            for sent, sent_vad in zip(val, val_vad):
                #must substantiate the second nested dic (otherwise python thinks you are trying to insert values into a dic that doesnt exist, because its nested within another dic)
                if idx not in doc_dic.keys():
                   doc_dic[idx] = {}
                doc_dic[idx][idx2] = (sent,sent_vad) 
                idx2 = idx2+1 #iterate sent index 
            idx=idx+1    #iterate docindex
        
        #W2V Execution 
        #compute average word embeddings and identify cosine similarity of the average word vector of the sentence vs average vector of search tersm     
        from datetime import datetime
        startTime = datetime.now()
        sim_list2 = []
     
        for idx, val in enumerate(text_list):
            #print first text ;if idx==1:print(val)
            if len(val) > 0 and idx < ndoc:
        
                #for each sentence in each document 
                for idx2, sent in enumerate(val):
                    
                    #generate the avg vector associated with each sent in doc idx+1 (because idx(0) is the stems)
                    sent_vec = avg_phrase(sent, wv, t["tf_idf"],t["dic"],idx+1)
                    
                    if sent_vec.all != 0 and idx2 < nsent: 
                        #print(len(sent))
                        #error handling to prevent computation of cosine similarity with negative numbers 
                        try:                           
                            sent_sim2_all = [cosine_sim(search_vec, sent_vec)] #Method 0: one metric for each sentrence (averaged across all stems) #NORMALIZING BIAS SHORT STRINGS FOR LONG ONES REGADLESS   
   
                        except: 
                            sent_sim2_all = [0] #REMOVE THIS, THIS IS NOT GOOD 
              
                        #sentence level 
                        #note: vader requires a sentence, not a sentence tokenized string 
                        #sim_list2.append(list(zip([idx],[idx2],[se.urllist[0][idx]],[' '.join(doc_dic[idx][idx2][1])],sent_sim2_all, [VADERSENT(' '.join(doc_dic[idx][idx2][1]),many=False)[0][1]])))
                        sim_list2.append(list(zip([idx],[idx2],[' '.join(doc_dic[idx][idx2][1])],sent_sim2_all, [VADERSENT(' '.join(doc_dic[idx][idx2][1]),many=False)[0][1]])))
                        #sim_list2.append(list(zip([idx],[idx2],'SentHolder',sent_sim2_all, [VADERSENT(' '.join(doc_dic[idx][idx2][1]),many=False)[0][1]])))

                        #print(sent_sim2_all)
                       #sim_list2.append(list(zip([idx],[idx2],sent_sim2_all))),[se.urllist[0][idx]])))#,sent_sim2_all)))
             
        #total time required to run algo 
        print(datetime.now() - startTime)

        return(sim_list2)
    

    #for each languge if the ersults are not blank, extract the post processed text, and clean the search terms , and join them into one string
    for idxx in range(0,se.search_lang_ct):
        if not se.urllist[idxx] == []:
         
            #pull out original text from se object 
            #docs and stems/keywords
            doc_cluster = se.origtextlist[idxx]
            stems= clean_paragraph(se.searchtermlist[idxx], se.search_lang_short[idxx], stemming=False, sent_tokenize=False, rem_stop=True)
                   
            #execute the function for each languge 
            se.w2vInfo[idxx] = w2v_SimSent(doc_cluster, stems, wv, ndoc=ndoc, nsent=nsent)
            
    return se

        

