# -*- coding: utf-8 -*-
"""
Created on Tue Jun  5 10:55:44 2018

@author: caridza
"""

stems = se_Factiva[1].list_matchedstems

myinfo = []
for stem in stems: 
    for string in stem: 
        for word in string: 
            myinfo.append(word)
        
set(myinfo)

#jane green 
'accuse','allege', 'arrest', 'conspire', 'convict', 'criminal', 'evasion', 'felony', 'guilty', 'indict', 'launder', 'terrorist', 'theft'

#john smith 
'accuse','allege','arrest','bribe','conspire','convict','corrupt','criminal','embezzle','evasion','extort','felony','fraud','guilty','indict','launder','suspect','theft','violation'

######################
###BIGRAM EXPLORTATION / INCORP



#pre process all strings in original text list 
text = []
text.append([OrigTxt_PreProcess(x, delim ="", window=False, se_inout = False) for x in se_Factiva[1].origtextlist[0]])


#flatten the list of lists of text to a list of text 
from itertools import chain 
test = list(chain.from_iterable(list(chain.from_iterable(list(chain.from_iterable(text))))))
textfull = [concatenate_list_data(test)]

#input: list of sentences 
#output: list of word tokenized sentences 
#input: list of tokenized strings (i.e. [['u','are','not','nice'],['my','mom','is','nice']])
#use if input is list 
#use if input is list of list #
#sentence_stream = [nltk.regexp_tokenize(sentence, r'\w+') for sent in textflat for sentence in sent]
sentence_stream = [nltk.regexp_tokenize(textfull[0], r'\w+')]

  
#extract / implant popular phrases 
from gensim.models import Phrases
from gensim.models.phrases import Phraser
#train the phrase detection model (specifying stop words as common terms to overlook. this ensures the parsed version of bank of america (bank america) is still detected as bigram)
Phrased = Phrases(sentence_stream[0], common_terms = set(stopwords.words('english')), min_count = 2 , threshold = 2)
#create permanent Phraser object to transform any sentence(list of tokens) using standard gensim syntax 
bigram = Phraser(Phrased) 
#apply to any sentence stream 
print(bigram[sentence_stream[0]])

matching = [s for s in bigram[sentence_stream] if "_" in s]

