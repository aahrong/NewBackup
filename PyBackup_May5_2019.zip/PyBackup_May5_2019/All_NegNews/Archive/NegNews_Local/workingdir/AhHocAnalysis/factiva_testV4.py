# -*- coding: utf-8 -*-
"""
Created on Wed May 30 13:44:50 2018

@author: caridza
"""

from nltk.tokenize import sent_tokenize
import re

#load factiva se objects
se_Factiva,dfs_factiva = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/Factiva/")
Factiva_Scores=[]
Factiva_se =[]
for i in range(0,len(se_Factiva)):
    se  = se_Factiva[i]
    
    #pre-process the original text and assign it back to original text 
    test = se.origtextlist[0]
    test2 = [x.split('<!@&>') for x in test]
    test3 = [[y.replace('\n',' ') for y in x] for x in test2]
    test4 = [[sent_tokenize(y)for y in x] for x in test3]
    test5 = [[re.sub('[^A-Za-z ]+', ' ', y) for y in x[0]] for x in test4] #remove all numbers 
    test6 = [[y.strip() for y in x if x] for x in test5] #strip trailing and leading white space 
    test7 = [[y for y in x if not y ==''] for x in test6] #remove blank strings from list of strings 
    test8= [[y for y in x if len(y) > 9] for x in test7] #remove blank strings from list of strings 
    test9= [[re.sub(' +',' ',y) for y in x ] for x in test8] #replace multiple spaces with single space 
    
    #identify window of sentences around teh first and last name of the individual being processed 
    test10= []
    for doc in test9:
        #test10.append([X for X in doc if name_in_sent1(X.lower(),se.entity_fname.lower(),se.entity_lname.lower())])

        test10.append([X[1] for X in list(previous_and_next(doc)) if name_in_sent(X[0].lower(),X[1].lower(),X[2].lower(),se.entity_fname.lower(),se.entity_lname.lower())])
        #test10.append([X for X in doc if name_in_sent(X[0].lower(),X[1].lower(),X[2].lower(),se.entity_fname.lower(),se.entity_lname.lower())])
    
    #append the cleaned text back to the se object 
    se.origtextlist[0] = test10
    
    #execute w2v
    se = w2v_se2_Factiva(se, wv, ndoc=100, nsent=1000, max_sent = .01)
    
    #extract score informaiton for each sentence within each document 
    Factiva_Scores.append([(se.entity_fname+"_"+se.entity_lname, se.riskscore_final[0],x[0][0],x[0][1],x[0][2],x[0][3],x[0][4],x[0][5]) for x in se.w2vInfo[0]])
    Factiva_se.append(se)

pickle.dump(Indiv_DocLevel_Dfs, open('C://Users//caridza//Desktop//pythonScripts//Zack learning(DataCamp)//Python_Misc//factiva_se_processed_new.pkl','wb'))
#################################################################
###########AGGREGATED DATAFRAME OF ALL CUSTOMERS PROCESSED#######
#################################################################
#convert scores to dataframe and sort output by Doc -> Similarity 
flat_list = [item for sublist in Factiva_Scores for item in sublist]
factiva_df = pd.DataFrame(flat_list, columns = ['Person','LSIRiskScore','Doc','Sent','URL','Sentence','Similarity','Sentiment'])
factiva_df= factiva_df.sort_values(by=['Doc','Similarity'],ascending = False)
factiva_df= factiva_df[np.isfinite(factiva_df['Similarity'])]

#create flags for sentiment 
factiva_df['PosSentFlag'] = np.where(factiva_df['Sentiment']>=.3, 'yes', 'no')
factiva_df['NegSentFlag'] = np.where(factiva_df['Sentiment']<=-.05, 'yes', 'no')
factiva_df['NeutSentFlag'] = np.where((factiva_df['Sentiment']<.3) &(factiva_df['Sentiment']>-.05), 'yes', 'no')

#Normalized Similarity approaches
factiva_df['Sim_Tanh_Norm']=tanh(factiva_df['Similarity'])
factiva_df['Sim_Logit_Norm']=(1 / (1 + exp(-factiva_df['Similarity'])))*2-1
factiva_df['Sim_Tanh_Norm']=tanh(factiva_df['Similarity'])
factiva_df['Sim_Logit_Norm']=(1 / (1 + exp(-factiva_df['Similarity'])))*2-1
factiva_df['Sent_Tanh_Norm']=tanh(factiva_df['Sentiment'])
factiva_df['Sent_Logit_Norm']=(1 / (1 + exp(-factiva_df['Sentiment'])))*2-1
factiva_df_final = factiva_df 

factiva_df_final.to_pickle('C://Users//caridza//Desktop//pythonScripts//Zack learning(DataCamp)//Python_Misc//factiva_df_final2.pkl')
factiva_df_final[['Person','Doc','Sent','URL','Sentence','LSIRiskScore','Similarity','Sentiment']].to_excel('C://Users//caridza//Desktop//pythonScripts//Zack learning(DataCamp)//Python_Misc//factiva_df_final3.xlsx')
#################################################################
####INDIVIDUAL DATAFRAME FOR EACH CUSTOMER AT DOC LEVEL##########
#################################################################
Indiv_DocLevel_Dfs = []

for i in range(0,len(se_Factiva)):
    factiva_df = factiva_df_final[factiva_df_final['Person'] == se_Factiva[i].entity_fname+"_"+se_Factiva[i].entity_lname]

    #extract the highest similarity sentence from each doc 
    factiva_df = factiva_df.sort_values(by=['Doc','Similarity'],ascending = False)
    TopSimSentPerDoc = factiva_df.groupby(by=['Doc']).head(1).reset_index(drop=True)
    factiva_df = factiva_df.sort_values(by=['Doc','Sentiment'],ascending = False)
    TopPosSentSentPerDoc = factiva_df.groupby(by=['Doc']).head(1).reset_index(drop=True)
    factiva_df = factiva_df.sort_values(by=['Doc','Sentiment'],ascending = True)
    TopNegSentSentPerDoc = factiva_df.groupby(by=['Doc']).head(1).reset_index(drop=True)
    factiva_df = factiva_df.sort_values(by=['Doc','Similarity'],ascending = False)

    #aggregation of doc scores at the document level and sort by doc_score2 for final review 
    factiva_doc_level = factiva_df.groupby(by=['Doc','URL'],as_index=False)['Similarity','Sentiment'].sum()
    
    factiva_doc_level['Person'] = str(se_Factiva[i].entity_fname+"_"+se_Factiva[i].entity_lname)
    factiva_doc_level['TotalSents'] = factiva_df.groupby(by=['Doc'],as_index=False).Sent.nunique()
    factiva_doc_level['PerSentSimilarity'] = factiva_doc_level['Similarity']/factiva_doc_level['TotalSents']
    factiva_doc_level.fillna(0, inplace=True)
    factiva_doc_level['P_NegSent'] = factiva_df.groupby(by=['Doc','NegSentFlag']).size().unstack()['yes']  / factiva_doc_level.TotalSents
    factiva_doc_level['P_PosSent'] = factiva_df.groupby(by=['Doc','PosSentFlag']).size().unstack()['yes']  / factiva_doc_level.TotalSents
    factiva_doc_level['P_NutSent'] = factiva_df.groupby(by=['Doc','NeutSentFlag']).size().unstack()['yes'] / factiva_doc_level.TotalSents
    factiva_doc_level.fillna(0, inplace=True)
    factiva_doc_level['Avg_Sent'] = factiva_df.groupby(by=['Doc'],as_index=False)['Sentiment'].mean()['Sentiment']
    factiva_doc_level['Min_Sent'] = factiva_df.groupby(by=['Doc'],as_index=False)['Sentiment'].min()['Sentiment']
    factiva_doc_level['Max_Sent'] = factiva_df.groupby(by=['Doc'],as_index=False)['Sentiment'].max()['Sentiment']
    factiva_doc_level['Avg_Sim'] = factiva_df.groupby(by=['Doc'],as_index=False)['Similarity'].mean()['Similarity']
    factiva_doc_level['Min_Sim'] = factiva_df.groupby(by=['Doc'],as_index=False)['Similarity'].min()['Similarity']
    factiva_doc_level['Max_Sim'] = factiva_df.groupby(by=['Doc'],as_index=False)['Similarity'].max()['Similarity']
    factiva_doc_level['Doc_Score'] = factiva_doc_level['Similarity']*(factiva_doc_level['P_NegSent'])
    factiva_doc_level['Doc_Score2'] = factiva_doc_level['Similarity']*(factiva_doc_level['P_NegSent'])*(1-factiva_doc_level['PerSentSimilarity'])
    factiva_doc_level['MaxSimSent'] = TopSimSentPerDoc['Sentence'] 
    factiva_doc_level['MaxSentSent'] = TopPosSentSentPerDoc['Sentence']
    factiva_doc_level['MinSentSent'] = TopNegSentSentPerDoc['Sentence']
    
    factiva_doc_level['FinalScore'] = tanh(factiva_doc_level.Similarity*(1/(1+factiva_doc_level.P_PosSent))) #*(1-factiva_doc_level.PerSentSimilarity) #tanh(factiva_doc_level.Similarity*(1-factiva_doc_level.P_PosSent)*(1-factiva_doc_level.PerSentSimilarity))
    
    factiva_doc_level = factiva_doc_level.sort_values(by=['Doc_Score2'],ascending = False)   
    Indiv_DocLevel_Dfs.append(factiva_doc_level)

pickle.dump(Indiv_DocLevel_Dfs, open('C://Users//caridza//Desktop//pythonScripts//Zack learning(DataCamp)//Python_Misc//Factiva_Indiv_DocLevel_Dfs2.pkl','wb'))

#OVERALL SCORE 
PersonMetrics = []
FinalScores = []
for i in range(0,len(se_Factiva)):
    df = factiva_df_final[factiva_df_final['Person'] == se_Factiva[i].entity_fname+"_"+se_Factiva[i].entity_lname]

    #aggregation of doc scores at the Person level (To determine sample mean , and standard deviation to use in normalizing doc scores) 
    Person_level = df.groupby(by=['Person'],as_index=False)['Similarity','Sentiment','Sim_Tanh_Norm','Sim_Logit_Norm','Sent_Tanh_Norm','Sent_Logit_Norm'].sum() #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
    
    Person_level['TotalLinks'] = df.groupby(by=['Person'],as_index=False).Doc.nunique() #very distinct distributions(bad people have more hits)
    Person_level['TotalSents'] = df.groupby(by=['Person'],as_index=False).Sent.nunique() #no help 
    
    Person_level['P_PosSent'] = df.groupby(by=['Person','PosSentFlag']).size().unstack()['yes'].values / Person_level.TotalLinks
    Person_level['P_NegSent'] = df.groupby(by=['Person','NegSentFlag']).size().unstack()['yes'].values / Person_level.TotalLinks
    Person_level['P_NeutSent'] = df.groupby(by=['Person','NeutSentFlag']).size().unstack()['yes'].values  / Person_level.TotalLinks
    Person_level.fillna(0, inplace=True)
    
    Person_level['Sum_PosSent'] = pd.pivot_table(df, values='Sentiment', index=['Person'],columns=['PosSentFlag'], aggfunc=np.sum)['yes'].values
    Person_level['Sum_NegSent'] = pd.pivot_table(df, values='Sentiment', index=['Person'],columns=['NegSentFlag'], aggfunc=np.sum)['yes'].values
    Person_level['Sum_NeutSent'] = pd.pivot_table(df, values='Sentiment', index=['Person'],columns=['NeutSentFlag'], aggfunc=np.sum)['yes'].values
    Person_level.fillna(0, inplace=True)
    
    Person_level['Avg_Sim']  = df.groupby(by=['Person'],as_index=False)['Similarity'].mean()['Similarity'] #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
    Person_level['Avg_Sim_Tanh_Norm']  = df.groupby(by=['Person'],as_index=False)['Sim_Tanh_Norm'].mean()['Sim_Tanh_Norm'] #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
    Person_level['Avg_Sim_Logit_Norm']  = df.groupby(by=['Person'],as_index=False)['Sim_Logit_Norm'].mean()['Sim_Logit_Norm'] #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
    Person_level.fillna(0, inplace=True)
    
    Person_level['Sent_tanh']  = tanh(df.groupby(by=['Person'],as_index=False)['Sentiment'].sum()['Sentiment']) #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
    Person_level['Sent_logit']  = (1 / (1 + exp(-df.groupby(by=['Person'],as_index=False)['Sentiment'].sum()['Sentiment']) ))*2-1
    Person_level['Avg_Sent'] = df.groupby(by=['Person'],as_index=False)['Sentiment'].mean()['Sentiment']
    Person_level['Avg_Sent_Tanh_Norm'] = df.groupby(by=['Person'],as_index=False)['Sent_Tanh_Norm'].mean()['Sent_Tanh_Norm']
    Person_level['Avg_Sent_Logit_Norm'] = df.groupby(by=['Person'],as_index=False)['Sent_Logit_Norm'].mean()['Sent_Logit_Norm']
    Person_level.fillna(0, inplace=True)
    
    Person_level['FINAL_SCORE']  = Person_level.Avg_Sim_Logit_Norm*(1/Person_level.P_PosSent) / (1/Person_level.TotalLinks)
    
    #get info for final score 
    MinVal = 0.022771272266701493
    MaxVal = 6.291994240522779
    LSI_Score = factiva_df_final[factiva_df_final['Person'] == df.Person.unique()[0]]['LSIRiskScore'].unique()[0]
    Person_level['Final_Normalized_Score'] = ((Person_level['FINAL_SCORE'] -MinVal) / (MaxVal-MinVal))
    
    PersonMetrics.append(Person_level)
    FinalScores.append([str(df.Person.unique()[0]),LSI_Score, Person_level.FINAL_SCORE[0] ,Person_level.Final_Normalized_Score[0]])

pickle.dump(FinalScores, open('C://Users//caridza//Desktop//pythonScripts//Zack learning(DataCamp)//Python_Misc//FinalScores2.pkl','wb'))
pickle.dump(PersonMetrics, open('C://Users//caridza//Desktop//pythonScripts//Zack learning(DataCamp)//Python_Misc//PersonMetrics.pkl','wb'))
      

pd.options.display.max_colwidth=2000
df_test =Indiv_DocLevel_Dfs[0]
df_test.sort_values(by=['Doc','FinalScore'],ascending = False)
PersonMetrics

PersonMetrics[0]

## remove punctuation, lower, remove stop words, porter stemming
# remove punctuation, lower, remove stop words, porter stemming
#cleaning processes used will depend on weather or not you use w2v or lsa 
def clean_paragraph_factiva(content, lang, stemming=True, sent_tokenize=False, rem_stop=True):
    if lang in SnowballStemmer.languages:
        #set up stopword and stemming objects specific to languge specified
        stop = set(stopwords.words(lang))
        stemmer = SnowballStemmer(lang)
        ##if languge specified does not exist default to english
    else:
        stop = set(stopwords.words('english'))
        stemmer = SnowballStemmer('english')
    # puncremove = str.maketrans(string.punctuation,' '*len(string.punctuation))  
    def clean_text(text):
        #sent tokenize and remove stop words, and alpha's and put to lower 
        #note: for w2v we do NOT want to stem the words or remove punctuation 
        if sent_tokenize == True:
           # sent_tokens = text.split("<!@&>")
            sent_tokens = text #nltk.sent_tokenize(text)
            tokens = [nltk.regexp_tokenize(sentence, r'\w+') for sentence in sent_tokens]
            rettext = []
            
            if rem_stop ==True: 
                for sent in tokens:
                    rettext.append([w.lower() for w in sent if w.isalpha() and not w in stop and len(w) > 1])
            
            #string is not put to lowercase, stopwords are not removed. however, limiting to char> 1 will prevent punctuation from being incorporated
            else:
                for sent in tokens:
                    rettext.append([w for w in sent if w.isalpha() and len(w) > 1])
        #if we are performing lsa then we remove punctionation , remove stops, lower, and stem 
        else:
             #remove punctuation from each string 
            for punc in string.punctuation:
                text = text.replace(punc, '')
            #text to lower, split by word, and remove stop words    
            rettext = [x for x in text.lower().split() if (x != '' and x not in stop)]
            if stemming==True:
                #stem text(at the word level)
                rettext = [stemmer.stem(x) for x in rettext]
            rettext = ' '.join(rettext)
        #return the clean text object 
        return rettext
        
    if type(content) is list:
        out = [clean_text(x) for x in content]
    else:
        out = clean_text(content)
    return out




def w2v_se2_Factiva(se, wv, ndoc=5, nsent=3,max_sent=-.2):

    #compile function to be used on the se(the se elements are extracted from se post below function and then called within this funciton )
    def w2v_SimSent_Factiva(doc_cluster, stems, wv,ndoc,nsent,max_sent):
        
        #text procesed by w2v vs original sentence to be passed to vadar
        text_list = clean_paragraph_factiva(doc_cluster,'english',stemming=False,sent_tokenize=True, rem_stop=True)
        text_list_vader = clean_paragraph_factiva(doc_cluster,'english',stemming=False,sent_tokenize=True, rem_stop=False) #note: both text list, 
        
        #tfidf 
        t = tf_idf(text_list, stems)
        
        #Get average word vector for search terms
        search_vec = avg_phrase(stems, wv, t["tf_idf"], t["dic"], 0)
        
        #store new and old value of sentence in dictonary as tuple
        doc_dic = {} #inialize dic 
        idx=0 #doc index
        for  val ,val_vad in zip(text_list,text_list_vader):   
            idx2=0 #sent index re-initiated for every doc 
            for sent, sent_vad in zip(val, val_vad):
                #must substantiate the second nested dic (otherwise python thinks you are trying to insert values into a dic that doesnt exist, because its nested within another dic)
                if idx not in doc_dic.keys():
                   doc_dic[idx] = {}
                doc_dic[idx][idx2] = (sent,sent_vad) 
                idx2 = idx2+1 #iterate sent index 
            idx=idx+1    #iterate docindex
        
        #W2V Execution 
        #compute average word embeddings and identify cosine similarity of the average word vector of the sentence vs average vector of search tersm     
        from datetime import datetime
        startTime = datetime.now()
        sim_list2 = []
     
        for idx, val in enumerate(text_list):
            #print first text ;if idx==1:print(val)
            if len(val) > 0 and idx < ndoc:
        
                #for each sentence in each document 
                for idx2, sent in enumerate(val):
                    
                    #generate the avg vector associated with each sent in doc idx+1 (because idx(0) is the stems)
                    sent_vec = avg_phrase(sent, wv, t["tf_idf"],t["dic"],idx+1)
                    
                    if sent_vec.all != 0 and idx2 < nsent: 
                        #print(len(sent))
                        #error handling to prevent computation of cosine similarity with negative numbers 
                        try:                           
                            sent_sim2_all = [cosine_sim(search_vec, sent_vec)] #Method 0: one metric for each sentrence (averaged across all stems) #NORMALIZING BIAS SHORT STRINGS FOR LONG ONES REGADLESS   
   
                        except: 
                            sent_sim2_all = [0] #REMOVE THIS, THIS IS NOT GOOD 
              
                        #sentence level 
                        #note: vader requires a sentence, not a sentence tokenized string 
                        if VADERSENT(' '.join(doc_dic[idx][idx2][1]),many=False)[0][1] < max_sent:
                            sim_list2.append(list(zip([idx],[idx2],[se.urllist[0][idx]],[' '.join(doc_dic[idx][idx2][1])],sent_sim2_all, [VADERSENT(' '.join(doc_dic[idx][idx2][1]),many=False)[0][1]])))
                            #sim_list2.append(list(zip([idx],[idx2],[' '.join(doc_dic[idx][idx2][1])],sent_sim2_all, [VADERSENT(' '.join(doc_dic[idx][idx2][1]),many=False)[0][1]])))
                            #sim_list2.append(list(zip([idx],[idx2],'SentHolder',sent_sim2_all, [VADERSENT(' '.join(doc_dic[idx][idx2][1]),many=False)[0][1]])))
    
                            #print(sent_sim2_all)
                           #sim_list2.append(list(zip([idx],[idx2],sent_sim2_all))),[se.urllist[0][idx]])))#,sent_sim2_all)))
                 
        #total time required to run algo 
        print(datetime.now() - startTime)

        return(sim_list2)
    

    #for each languge if the ersults are not blank, extract the post processed text, and clean the search terms , and join them into one string
    for idxx in range(0,se.search_lang_ct):
        if not se.urllist[idxx] == []:
         
            #pull out original text from se object 
            #docs and stems/keywords
            doc_cluster = se.origtextlist[idxx]
            stems= clean_paragraph(se.searchtermlist[idxx], se.search_lang_short[idxx], stemming=False, sent_tokenize=False, rem_stop=True)
                   
            #execute the function for each languge 
            se.w2vInfo[idxx] = w2v_SimSent_Factiva(doc_cluster, stems, wv, ndoc=ndoc, nsent=nsent, max_sent = max_sent)
            
    return se

def name_in_sent(s1,s2,s3,fname,lname):
    return True if fname in s1 or fname in s2 or fname in s3 or lname in s1 or lname in s2 or lname in s3 else False

def name_in_sent1(s1,fname,lname):
    if len(fname)>2 and len(lname)>2:
        return True if fname in s1 or lname in s1 else False
    if len(fname)>2 and len(lname)<2:
        return True if fname in s1  else False 
    if len(fname)<2 and len(lname)>2:
        return True if lname in s1  else False 
    

from itertools import tee, islice, chain
def previous_and_next(some_iterable):
    prevs, items, nexts = tee(some_iterable, 3)
    prevs = chain([''], prevs)
    nexts = chain(islice(nexts, 1, None), [''])
    return zip(prevs, items, nexts) 
