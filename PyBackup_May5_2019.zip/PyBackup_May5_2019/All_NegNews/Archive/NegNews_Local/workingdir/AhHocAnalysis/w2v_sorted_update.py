def w2v_SortOutput(se, max_sent = .3): 
    def W2V_ScoreAgg(fname, lname, se_w2vInfo, max_sent = max_sent):
        #extract w2v score data from list -> convert to df and process at doc and person level 
        #Colnames: name, lsiRiskScore,Doc,Sent,URL,Sentence,Similarity,Sentiment
        scores = [(se.entity_fname+"_"+se.entity_lname,x[0][0],x[0][1],x[0][2],x[0][3],x[0][4],x[0][5]) for x in se_w2vInfo]
        flat_list = [sublist  for sublist in scores]#convert scores to dataframe and sort output by Doc -> Similarity 
        se_df = pd.DataFrame(flat_list, columns = ['Person','Doc','Sent','URL','Sentence','Similarity','Sentiment'])
        se_df= se_df.sort_values(by=['Doc','Similarity'],ascending = False)
        se_df= se_df[np.isfinite(se_df['Similarity'])]
        se_df['BothNamePres'] = np.where((se_df['Sentence'].str.upper().str.contains(se.entity_fname.upper()) & (se_df['Sentence'].str.upper().str.contains(se.entity_lname.upper()) )),1,0)

        #Normalized Similarity approaches
        se_df['Sim_Tanh_Norm']=tanh(se_df['Similarity'])
        se_df['Sent_Tanh_Norm']=tanh(se_df['Sentiment'])
        se_df['Sim_Tanh_Weighted']=tanh(se_df['Similarity']+se_df['BothNamePres'])
        se_df['Sent_Logit_Norm']=(1 / (1 + exp(-se_df['Sentiment'])))*2-1
        se_df['Sim_Logit_Norm']=(1 / (1 + exp(-se_df['Similarity'])))*2-1
       
        #create document level dataframe and sort by finaldoc metric
        doc_level = se_df.groupby(by=['Person','Doc','URL'],as_index=False)['Similarity','Sentiment'].sum() 
        doc_level.fillna(0, inplace=True)
        doc_level['TotalDocSents'] = se_df.groupby(by=['Person','Doc'],as_index=False).Sent.nunique()#sum of similarity of all sentences associated with each doc 
        doc_level['PerSentSimilarity'] = doc_level.Similarity /doc_level.TotalDocSents; doc_level.fillna(0, inplace=True)
        doc_level['Avg_Sim_Tanh_Norm'] = se_df.groupby(by=['Person','Doc'],as_index=False)['Sim_Tanh_Norm'].mean()['Sim_Tanh_Norm']
        doc_level['Avg_Sim_Tanh_Weighted'] = se_df.groupby(by=['Person','Doc'],as_index=False)['Sim_Tanh_Weighted'].mean()['Sim_Tanh_Weighted']
        doc_level['DocScore2'] = doc_level.Avg_Sim_Tanh_Norm
        doc_level['FinalDocScore'] = (doc_level.DocScore2 - doc_level.DocScore2.min()) / (doc_level.DocScore2.max()-doc_level.DocScore2.min()) #normalized doc score
        doc_level = doc_level.sort_values(by=['FinalDocScore','Doc'],ascending = False)
        #doc_level['Avg_Sim_Logit_Norm']  = se_df.groupby(by=['Person','Doc'],as_index=False)['Sim_Logit_Norm'].mean()['Sim_Logit_Norm'] 
        #doc_level['DocScore2'] = doc_level.Avg_Sim_Tanh_Norm
        
        #merge document level and sentence level metrics
        #add document level information to the sentence dataset for output sorting 
        se_df_sort = se_df.merge(doc_level[['FinalDocScore','Doc']], how='left', left_on='Doc', right_on='Doc')
        se_df_sort = se_df_sort.sort_values(by=['FinalDocScore','Similarity'],ascending = False)

        #aggregation of doc scores at the Person level (To determine sample mean , and standard deviation to use in normalizing doc scores) 
        Person_level = se_df_sort.groupby(by=['Person'],as_index=False)['Similarity','Sentiment','Sim_Tanh_Norm','Sim_Logit_Norm','Sent_Tanh_Norm','Sent_Logit_Norm'].sum() #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
        Person_level['TotalLinks'] = se_df_sort.groupby(by=['Person'],as_index=False).Doc.nunique();Person_level.fillna(0,inplace=True) #very distinct distributions(bad people have more hits)
        Person_level['TotalSents'] = se_df_sort.groupby(by=['Person'],as_index=False).Sent.nunique();Person_level.fillna(0,inplace=True) #no help 
        Person_level['Avg_Sim']  = se_df_sort.groupby(by=['Person'],as_index=False)['Similarity'].mean()['Similarity'] #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
        Person_level['Avg_Sim_Tanh_Norm']  = se_df_sort.groupby(by=['Person'],as_index=False)['Sim_Tanh_Norm'].mean()['Sim_Tanh_Norm'] #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
        Person_level['Avg_Sim_Logit_Norm']  = se_df_sort.groupby(by=['Person'],as_index=False)['Sim_Logit_Norm'].mean()['Sim_Logit_Norm'] #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
        Person_level['Avg_Sent'] = se_df_sort.groupby(by=['Person'],as_index=False)['Sentiment'].mean()['Sentiment']
        Person_level['FINAL_SCORE']  = Person_level.Avg_Sim_Logit_Norm#Person_level.Avg_Sim_Logit_Norm*(1-Person_level.Avg_Sent_Logit_Norm) #/ (1/Person_level.TotalLinks)
        #Person_level['FINAL_SCORE']  = Person_level.Avg_Sim_Logit_Norm*(1/Person_level.P_PosSent) / (1/Person_level.TotalLinks)
        #Person_level['FINAL_SCORE']  = Person_level.Avg_Sim_Logit_Norm*(1/(1+Person_level.P_PosSent)) / (1/Person_level.TotalLinks)#Person_level['FINAL_SCORE']  = Person_level.Avg_Sim_Logit_Norm#*(1-Person_level.Avg_Sent_Logit_Norm) 
        
        #get info for final score (tihs is from a sample of 400 (~50 BAD) to calculate avg similarity normailzied by logit )
        MinVal = 0.04483958732992438
        MaxVal = 0.2656953953362422
        
        #generate normalized score 
        Person_level['Final_Normalized_Score'] = ((Person_level['FINAL_SCORE'] -MinVal) / (MaxVal-MinVal))
    
        #append person level information to sentence level dataframe 
        se_df_sort2 = se_df_sort.merge(Person_level[['Final_Normalized_Score','Person']], how='left', left_on='Person', right_on='Person')
        se_df_sort2 = se_df_sort2.sort_values(by=['Doc','Similarity'], ascending = [True,False])
        return(se_df_sort2)
        
    
    #for each languge if the ersults are not blank, extract the post processed text, and clean the search terms , and join them into one string
    for idxx in range(0,se.search_lang_ct):
        if not se.urllist[idxx] == []: 
            #execute the function for each languge 
            se.w2vDfSorted[idxx]  = W2V_ScoreAgg(se.entity_fname, se.entity_lname, se.w2vInfo[idxx], max_sent)
            
    return(se)   

