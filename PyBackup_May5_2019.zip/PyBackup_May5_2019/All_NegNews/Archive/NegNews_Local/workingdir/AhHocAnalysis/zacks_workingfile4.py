#modules
#path of user created nn_base module 
sys.path.insert(0, "C://Users//caridza//Desktop//pythonScripts//NN_Gitlab//")

from nn_base.nn_classes import search_entity as SE
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from gensim import corpora, models, similarities
import string
import re
from fuzzywuzzy import fuzz
import numpy as np
import operator
import pymagnitude
import gensim 
import shlex 
import subprocess 
from sklearn import preprocessing 
import vaderSentiment 
import pandas as pd 
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import nltk
from scipy import spatial
##pip install --proxy http://amweb.ey.net:8080 vaderSentiment 

#load se objects
#se_list_orig,dfs_orig = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/Dump1/")
se_list_bad,dfs_bad = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/BadGuys/")

#individual se to test 
se = se_list_bad[1]

#docs and stems/keywords
doc_cluster = se_list_bad[1].origtextlist[0]
stems= clean_paragraph(se_list_bad[1].searchtermlist[0], se_list_bad[1].search_lang_short[0], stemming=False, sent_tokenize=False, rem_stop=True)

#google word embeddig model
pymagloc = "C:/Users/caridza/Desktop/pythonScripts/NLP/GoogleNewsvectors_negative300.magnitude"
wv = pymagnitude.Magnitude(pymagloc)

#text procesed by w2v vs original sentence to be passed to vadar
text_list = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True, rem_stop=True)
text_list_vader = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True, rem_stop=False) #note: both text list, 

#tfidf 
t = tf_idf(text_list, stems)

#Get average word vector for search terms
search_vec = avg_phrase(stems, wv, t["tf_idf"], t["dic"], 0)

#store new and old value of sentence in dictonary as tuple
doc_dic = {} #inialize dic 
idx=0 #doc index
for  val ,val_vad in zip(text_list,text_list_vader):   
    idx2=0 #sent index re-initiated for every doc 
    for sent, sent_vad in zip(val, val_vad):
        #must substantiate the second nested dic (otherwise python thinks you are trying to insert values into a dic that doesnt exist, because its nested within another dic)
        if idx not in doc_dic.keys():
           doc_dic[idx] = {}
        doc_dic[idx][idx2] = (sent,sent_vad) 
        idx2 = idx2+1 #iterate sent index 
    idx=idx+1    #iterate docindex

#W2V Execution 
#compute average word embeddings and identify cosine similarity of the average word vector of the sentence vs average vector of search tersm     
from datetime import datetime
startTime = datetime.now()
sim_list2 = []
sim_list3 = []
for idx, val in enumerate(text_list[:6]):
    #print first text ;if idx==1:print(val)
    if len(val) > 0:
        #list to store normalized similarity metric
        sim_list_sent = []
        #for each sentence in each document 
        for idx2, sent in enumerate(val):
            #generate the avg vector associated with each sent in doc idx+1
            sent_vec = avg_phrase(sent, wv, t["tf_idf"],t["dic"],idx+1)
            if sent_vec.all != 0:
                try:                           
                    sent_sim2_all = [cosine_sim(search_vec, sent_vec)] #Method 0: one metric for each sentrence (averaged across all stems) #NORMALIZING BIAS SHORT STRINGS FOR LONG ONES REGADLESS   
                    sent_sim2_max = max([(term,cosine_sim(wv.query(term),sent_vec)) for term in stems])                        
                except: 
                    sent_sim2_all = [0] #REMOVE THIS, THIS IS NOT GOOD 
                    sent_sim2_max =[(0,0)]
            else:
                sent_sim2_all = [0]
                sent_sim2_max =[(0,0)]
                
            #sentence level 
            sim_list2.append(list(zip([idx],[idx2],[se.urllist[0][idx]],[' '.join(doc_dic[idx][idx2][1])], sent_sim2_all)))
            sim_list3.append(list(sent_sim2_max))
          
        #document level 
        #append the sent with the max similarity to the search term vector (one per doc processed) 	
        #sim_list.append(max(sim_list_sent))
        #append general information about the sentence the match, and the similarity 
        #docinfo.append([se.urllist[0][idx], se.textlist[0][idx] , ])


#total time required to run algo 
print(datetime.now() - startTime)
#sort list by similarity 
sim_list_by_doc = sorted(sim_list2, key = lambda x: (x[0][0],x[0][4]),reverse=True)

#extract the sentences only for vader processing
sents = [x[0][3] for x in sim_list_by_doc]
#process the sentences to identify sentiment 
df_out, list_out = VADERSENT( [x[0][3] for x in sim_list_by_doc], many = True)

#final LIST OF ALL SENTENCES FOR EACH DOC WITH THE SENTIMENT SCORE FOR EACH SENTENCE INCLUDED 
sim_list_by_doc_with_sent = [x[0]+(y[1],) for x, y in zip(sim_list_by_doc, list_out)]





