# -*- coding: utf-8 -*-
"""
Created on Mon Jun 25 12:52:26 2018

@author: caridza
"""

#path of user created nn_base module 
sys.path.insert(0, "C://Users//caridza//Desktop//pythonScripts//NN_Gitlab//")
from nn_base.nn_classes import search_entity as SE
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from gensim import corpora, models, similarities
import string
import re
from fuzzywuzzy import fuzz
import numpy as np
import operator
import pymagnitude
import gensim 
import shlex 
import subprocess 
from sklearn import preprocessing 
import vaderSentiment 
import pandas as pd 
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import nltk
from scipy import spatial #used for cosine similarities 
import math #used to filter nan tuple elments from list 
import pickle

#load results of spyder scraping into static dataframe 
#syntax example: se_lists,dfs = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/")
def load_results(nn_class_path, folderpath):
    import json
    import os
    import sys
    import pandas as pd
    
    #set path location of nn_base class functions 
    sys.path.insert(0, nn_class_path)
    from nn_base.nn_classes import search_entity as SE
    
    #curernt directory 
    #cwd = os.getcwd()
    #change working directory 
    #os.chdir(os.path.join(cwd,'Desktop','pythonScripts','NN_Gitlab','workingdir','AhHocAnalysis'))
    
    #function to strip all whitespace from each key (spaces in the json dump will mess things up)
    def trim_key(obj):
        for key in obj.keys():
            new_key = key.strip()
            if new_key != key:
                obj[new_key] = obj[key]
                del obj[key]
        return obj
    
    #folder containing all the results 
    folderpath = folderpath
            
    #set up results objects 
    folder = []
    file = []
    fname = []
    lname = []
    mname = []
    city = []
    state = []
    riskscore_final = []
    
    #final returned obejct with list of all attributes for each individual 
    se_list = []
    #for each file in the results dump folder, extract the key feilds into the se object 
    
    for filename in os.listdir(folderpath):
        #only consider json files 
        if filename.endswith('.json') :
            #load the file and process each feild thorugh the trim_key function to remove whitespace
            jsonfile = json.load(open(folderpath + filename,'r'), object_hook=trim_key)
            jsonfile= trim_key(jsonfile) #trim whitespace again for saftey
            folder.append(folderpath) #append folder where se is located 
            file.append(filename)
            fname.append(jsonfile['entity_fname'])
            mname.append(jsonfile['entity_mname'])
            lname.append(jsonfile['entity_lname'])
            city.append(jsonfile['entity_city'])
            state.append(jsonfile['entity_state'])
            riskscore_final.append(jsonfile['riskscore_final'])
            
            #create empty list object to hold all SE information 
            se = SE(search_lang=['english','spanish'])
            #se.entity_id=jsonfile['id']
            se.entity_id = ''
            se.entity_fname=jsonfile['entity_fname']
            se.entity_lname=jsonfile['entity_lname']
            se.entity_mname=jsonfile['entity_mname']
            se.entity_city=jsonfile['entity_city']
            se.entity_state=jsonfile['entity_state']
            se.entity_state2=jsonfile['entity_state2']
            se.entity_country=jsonfile['entity_country']
            se.entity_occupation=jsonfile['entity_occupation']
            se.entity_company=jsonfile['entity_company']
            se.entity_company2=jsonfile['entity_company2']
            se.entity_querylist=jsonfile['entity_querylist']
            se.searchtermlist=jsonfile['searchtermlist']
            se.search_lang=jsonfile['search_lang']
            se.search_lang_ct=jsonfile['search_lang_ct']
            se.search_lang_short=jsonfile['search_lang_short']
            se.querylisturl=jsonfile['querylisturl']
            se.urllist=jsonfile['urllist']
            se.origtextlist=jsonfile['origtextlist']
            se.textlist=jsonfile['textlist']
            se.static_search_result=jsonfile['static_search_result']
            se.list_fuzzyscore=jsonfile['list_fuzzyscore']
            se.list_fuzzyscoredetail=jsonfile['list_fuzzyscoredetail']
            se.list_matchedstems=jsonfile['list_matchedstems']
            se.LSA_score=jsonfile['LSA_score']
            se.w2vInfo = jsonfile['w2vInfo']
            se.w2vDfSorted = jsonfile['w2vDfSorted']
            se.w2vDocRank = jsonfile['w2vDocRank']
            se.w2vTopSent = jsonfile['w2vTopSent']
            
            se.LSA_filter_count=jsonfile['LSA_filter_count']
            se.riskscore_final=jsonfile['riskscore_final']
            se.link_score_threshold=jsonfile['link_score_threshold']
            se.name_fuzzy_all=jsonfile['name_fuzzy_all']
            se.location_fuzzy_all=jsonfile['location_fuzzy_all']
            se.employment_fuzzy_all=jsonfile['employment_fuzzy_all']
            
            #append the se object to the list of all se objects 
            se_list.append(se)
    
    
    #create final df containing all the se informaiton for each individual 
    #this will be used to text lsa / w2v functionality 
    df = pd.DataFrame({'folder': folder, 'filename': file, 'fname':fname, 'mname':mname, 'lname':lname, 'city':city, 'state':state, 'riskscore':riskscore_final})
    return(se_list,df)