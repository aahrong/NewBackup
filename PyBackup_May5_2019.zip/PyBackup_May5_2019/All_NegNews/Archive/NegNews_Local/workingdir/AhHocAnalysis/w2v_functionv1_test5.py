#modules
#path of user created nn_base module 
sys.path.insert(0, "C://Users//caridza//Desktop//pythonScripts//NN_Gitlab//")
from nn_base.nn_classes import search_entity as SE
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from gensim import corpora, models, similarities
import string
import re
from fuzzywuzzy import fuzz
import numpy as np
import operator
import pymagnitude
import gensim 
import shlex 
import subprocess 
from sklearn import preprocessing 
import vaderSentiment
import pandas as pd 
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import nltk
from scipy import spatial #used for cosine similarities 
import math #used to filter nan tuple elments from list 
import pickle
##pip install --proxy http://amweb.ey.net:8080 vaderSentiment 


#load google word embeddig model
#note: runs way faster when only compiled a single time
#pymagloc = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/wiki-news-300d-1M-subword.magnitude" #Fast Text 
pymagloc = "C:/Users/caridza/Desktop/pythonScripts/NLP/GoogleNewsvectors_negative300.magnitude" #google word vectors 
wv = pymagnitude.Magnitude(pymagloc)
                          
#load se objects
#se_list_orig,dfs_orig = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/Dump1/")
se_list_bad2,dfs_bad = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/BadGuys/")
se_list_good,dfs_good = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/EY_folks/")
se_Factiva,dfs_factiva = load_results(nn_class_path ="C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab", folderpath = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/AhHocAnalysis/ResultsDump/Factiva/")
print(len(se_list_bad2),len(se_list_good))

#bads 
#all_bad_se2 = []
all_bad_se3 = []

for i in range(0,len(se_list_bad2)):
    se = se_list_bad2[i]
    se = w2v_se2(se, wv, ndoc=1000,nsent=3000, sent_max = 1, min_sim = .15)
    #Scores_Bad.append([(x[0],x[1],x[4],x[5]) for x in se.w2vInfo[0]])
    #all_bad_se2.append(se)
    all_bad_se3.append(se)
    print(str(i))

#goods 
#all_good_se = []

for i in range(0,len(se_list_good)):
    se = se_list_good[i]
    se = w2v_se2(se, wv, ndoc=10000, nsent=3000,sent_max = 1, min_sim=.15)
    #all_good_se.append(se)
    all_good_se4.append(se)
    print(str(i))
    
#first 100
#all_good_se = all_good_se3+all_good_se4
#all_bad_se2 = all_bad_se3
#laod pickle of last sample
all_bad_se2 = pickle.load(open('C://Users//caridza//Desktop//pythonScripts//NN_Gitlab//workingdir//AhHocAnalysis//ResultsDump//bad.pkl','rb'))
all_good_se = pickle.load(open('C://Users//caridza//Desktop//pythonScripts//NN_Gitlab//workingdir//AhHocAnalysis//ResultsDump//good.pkl','rb'))
  
#save as pickle and load back as list 
#pickle.dump(all_good_se, open('C://Users//caridza//Desktop//pythonScripts//NN_Gitlab//workingdir//AhHocAnalysis//ResultsDump//good_full100.pkl','wb'))
all_good_se = pickle.load(open('C://Users//caridza//Desktop//pythonScripts//NN_Gitlab//workingdir//AhHocAnalysis//ResultsDump//good_full100.pkl','rb'))
#pickle.dump(all_bad_se3, open('C://Users//caridza//Desktop//pythonScripts//NN_Gitlab//workingdir//AhHocAnalysis//ResultsDump//bad_full_v2.pkl','wb'))
all_bad_se2 = pickle.load(open('C://Users//caridza//Desktop//pythonScripts//NN_Gitlab//workingdir//AhHocAnalysis//ResultsDump//bad_full_v2.pkl','rb'))
    
#extract raw scores to plot 
Scores_Bad=[]
for i in range(0,len(all_bad_se2)):
    Scores_Bad.append([(all_bad_se2[i].entity_fname+"_"+all_bad_se2[i].entity_lname, all_bad_se2[i].riskscore_final[0],x[0][0],x[0][1],x[0][2],x[0][3],x[0][4]) for x in all_bad_se2[i].w2vInfo[0]])

#extract raw scores to plot 
Good_scores=[]
for i in range(0,len(all_good_se)):
    score = [(all_good_se[i].entity_fname+"_"+all_good_se[i].entity_lname,all_good_se[i].riskscore_final[0],x[0][0],x[0][1],x[0][2],x[0][3],x[0][4]) for x in all_good_se[i].w2vInfo[0]]
    Good_scores.append(list(filter(None, score))) #Prevent NANs from entering the data series #Good_scores3.append( [t for t in score if not any(isinstance(n, float) and math.isnan(n) for n in t)])

  
#create flattened list and convert to pandas 
flat_listb = [item for sublist in Scores_Bad for item in sublist]
dfb = pd.DataFrame(flat_listb , columns = ['Person','LSIRiskScore','Doc','Sent','Sentence','Similarity','Sentiment'])
dfb = dfb.sort_values(by=['Person','Similarity'],ascending = False)
dfb = dfb[np.isfinite(dfb['Similarity'])]
dfb['typed'] = 'BAD'
 
#create flattened list and convert to pandas      
flat_listg = [item for sublist in Good_scores for item in sublist]
dfg = pd.DataFrame(flat_listg , columns = ['Person','LSIRiskScore','Doc','Sent','Sentence','Similarity','Sentiment'])
dfg = dfg.sort_values(by=['Person','Similarity'],ascending = False)
dfg = dfg[np.isfinite(dfg['Similarity'])]
dfg['typed']='GOOD'

#Create final dataset to use 
#append good and bad into single datafarme 
bigdata = dfb.append(dfg, ignore_index=True)
bigdata['PosSentFlag'] = np.where(bigdata['Sentiment']>=.3, 'yes', 'no')
bigdata['NegSentFlag'] = np.where(bigdata['Sentiment']<= -.05, 'yes', 'no')
bigdata['NeutSentFlag'] = np.where((bigdata['Sentiment']<.3) &(bigdata['Sentiment']>-.05), 'yes', 'no')

#Normalized Similarity approaches
bigdata['Sim_Tanh_Norm']=tanh(bigdata['Similarity'])
bigdata['Sim_Logit_Norm']=(1 / (1 + exp(-bigdata['Similarity'])))*2-1
bigdata['Sent_Tanh_Norm']=tanh(bigdata['Sentiment'])
bigdata['Sent_Logit_Norm']=(1 / (1 + exp(-bigdata['Sentiment'])))*2-1

#plot the series 
import matplotlib.pyplot as plt 
import seaborn as sns 
sns.set(color_codes=True)
metrics = ['Similarity','Sim_Logit_Norm','Sim_Tanh_Norm','Sent_Tanh_Norm','Sentiment']
plots(bigdata,metrics) #custom plotting function

#save file as pickle 
pickle.dump(bigdata, open('C://Users//caridza//Desktop//pythonScripts//Zack learning(DataCamp)//Python_Misc//W2V_Sentiment_SentLevel.pkl','wb'))

#DOCUMENT LEVEL DATA AGGREGATION 
#aggregation of doc scores at the document level 
#doc_level = bigdata.groupby(by=['typed','Person','Doc'],as_index=False)['Similarity','Sentiment','Sim_Tanh_Norm','Sim_Logit_Norm'].sum() #sum of similarity of all sentences associated with each doc 
doc_level = bigdata.groupby(by=['typed','Person','Doc'],as_index=False)['Similarity','Sentiment','Sim_Tanh_Norm','Sim_Logit_Norm','Sent_Tanh_Norm','Sent_Logit_Norm'].sum() 
doc_level['TotalDocSents'] = bigdata.groupby(by=['typed','Person','Doc'],as_index=False).Sent.nunique()#sum of similarity of all sentences associated with each doc 
doc_level['NormSimScore'] =  doc_level.Similarity / (1/doc_level.TotalDocSents)
doc_level['PerSentSimilarity'] = doc_level.Similarity /doc_level.TotalDocSents
doc_level['NormDocScore_tanh'] = doc_level.Sim_Tanh_Norm/ doc_level.TotalDocSents
doc_level['NormDocScore_logit'] = doc_level.Sim_Logit_Norm/ doc_level.TotalDocSents
doc_level['NormSentScore'] =  doc_level.Sentiment / doc_level.TotalDocSents
doc_level['NormSentScore_tanh'] =  doc_level.Sent_Tanh_Norm / doc_level.TotalDocSents
doc_level['NormSentScore_Logit'] =  doc_level.Sent_Logit_Norm / doc_level.TotalDocSents
doc_level['test']  =  doc_level.Sim_Tanh_Norm+doc_level.Sent_Tanh_Norm
doc_level['P_PosSent'] = bigdata.groupby(by=['typed','Person','Doc','PosSentFlag']).size().unstack()['yes'].values / doc_level.TotalDocSents
doc_level['P_NegSent'] = bigdata.groupby(by=['typed','Person','Doc','NegSentFlag']).size().unstack()['yes'].values / doc_level.TotalDocSents
doc_level['P_NeutSent'] = bigdata.groupby(by=['typed','Person','Doc','NeutSentFlag']).size().unstack()['yes'].values  / doc_level.TotalDocSents
doc_level.fillna(0, inplace=True)
doc_level['Sum_PosSent'] = pd.pivot_table(bigdata, values='Sentiment', index=['Person', 'Doc'],columns=['PosSentFlag'], aggfunc=np.sum)['yes'].values
doc_level['Sum_NegSent'] = pd.pivot_table(bigdata, values='Sentiment', index=['Person', 'Doc'],columns=['NegSentFlag'], aggfunc=np.sum)['yes'].values
doc_level['Sum_NeutSent'] = pd.pivot_table(bigdata, values='Sentiment', index=['Person', 'Doc'],columns=['NeutSentFlag'], aggfunc=np.sum)['yes'].values
doc_level.fillna(0, inplace=True)
doc_level['FinalDocScore'] = tanh(doc_level.Similarity*(1/(1+doc_level.P_PosSent)))*(1-doc_level.PerSentSimilarity)  #final doc scores 

#doc_level['Doc_Score'] = doc_level.Sim_Tanh_Norm*(1-doc_level.P_PosSent) #GOOD 
plots(doc_level,['NormSimScore'])
 

#aggregation of doc scores at the Person level (To determine sample mean , and standard deviation to use in normalizing doc scores) 
Person_level = bigdata.groupby(by=['typed','Person'],as_index=False)['Similarity','Sentiment','Sim_Tanh_Norm','Sim_Logit_Norm','Sent_Tanh_Norm','Sent_Logit_Norm'].sum() #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
Person_level['TotalLinks'] = bigdata.groupby(by=['typed','Person'],as_index=False).Doc.nunique() #very distinct distributions(bad people have more hits)
Person_level['TotalSents'] = bigdata.groupby(by=['typed','Person'],as_index=False).Sent.nunique() #no help 
Person_level['P_PosSent'] = bigdata.groupby(by=['typed','Person','PosSentFlag']).size().unstack()['yes'].values / Person_level.TotalLinks
Person_level['P_NegSent'] = bigdata.groupby(by=['typed','Person','NegSentFlag']).size().unstack()['yes'].values / Person_level.TotalLinks
Person_level['P_NeutSent'] = bigdata.groupby(by=['typed','Person','NeutSentFlag']).size().unstack()['yes'].values  / Person_level.TotalLinks
Person_level.fillna(0,inplace=True)
Person_level['Sum_PosSent'] = pd.pivot_table(bigdata, values='Sentiment', index=['Person'],columns=['PosSentFlag'], aggfunc=np.sum)['yes'].values
Person_level['Sum_NegSent'] = pd.pivot_table(bigdata, values='Sentiment', index=['Person'],columns=['NegSentFlag'], aggfunc=np.sum)['yes'].values
Person_level['Sum_NeutSent'] = pd.pivot_table(bigdata, values='Sentiment', index=['Person'],columns=['NeutSentFlag'], aggfunc=np.sum)['yes'].values
Person_level.fillna(0,inplace=True)
Person_level['Avg_Sim']  = bigdata.groupby(by=['typed','Person'],as_index=False)['Similarity'].mean()['Similarity'] #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
Person_level['Avg_Sim_Tanh_Norm']  = bigdata.groupby(by=['typed','Person'],as_index=False)['Sim_Tanh_Norm'].mean()['Sim_Tanh_Norm'] #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
Person_level['Avg_Sim_Logit_Norm']  = bigdata.groupby(by=['typed','Person'],as_index=False)['Sim_Logit_Norm'].mean()['Sim_Logit_Norm'] #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
Person_level['Sent_tanh']  = tanh(bigdata.groupby(by=['typed','Person'],as_index=False)['Sentiment'].sum()['Sentiment']) #Sum of similarity across all sentences in the doc , Sum of Sentiment across all sentences in the doc 
Person_level['Sent_logit']  = (1 / (1 + exp(-bigdata.groupby(by=['typed','Person'],as_index=False)['Sentiment'].sum()['Sentiment']) ))*2-1
Person_level['Avg_Sent'] = bigdata.groupby(by=['typed','Person'],as_index=False)['Sentiment'].mean()['Sentiment']
Person_level['Avg_Sent_Tanh_Norm'] = bigdata.groupby(by=['typed','Person'],as_index=False)['Sent_Tanh_Norm'].mean()['Sent_Tanh_Norm']
Person_level['Avg_Sent_Logit_Norm'] = bigdata.groupby(by=['typed','Person'],as_index=False)['Sent_Logit_Norm'].mean()['Sent_Logit_Norm']
#Person_level['FINAL_SCORE']  = Person_level.Avg_Sim_Logit_Norm#*(1-Person_level.Avg_Sent_Logit_Norm) 
Person_level['FINAL_SCORE']  = Person_level.Avg_Sim_Logit_Norm*(1/(1+Person_level.P_PosSent)) / (1/Person_level.TotalLinks)

#get info for final score 
MinVal = Person_level['FINAL_SCORE'].min() #0.022771272266701493 ; 023312713770638024
MaxVal = Person_level['FINAL_SCORE'].max() #6.291994240522779
Person_level['Final_Normalized_Score'] = ((Person_level['FINAL_SCORE'] - Person_level['FINAL_SCORE'].min()) / (Person_level['FINAL_SCORE'].max() -Person_level['FINAL_SCORE'].min()))

plots(Person_level,['FINAL_SCORE'])

#check presence of individual in dataset 
Persons = pd.Series(Person_level['Person'])
Person_level[Persons.str.contains('Clew')]


doc_level.groupby('typed')['Similarity'].describe()
doc_level.groupby('typed')['Similarity'].describe()






#contingency table 
bigdata


all_se = all_bad_se2 + all_good_se

Indiv_DocLevel = []
pd.options.display.max_colwidth=1000
for i in range(0,len(all_se)):
    factiva_df = bigdata[bigdata['Person'] == all_se[i].entity_fname+"_"+all_se[i].entity_lname]
    #print(list(factiva_df))
    #extract the highest similarity sentence from each doc 
    factiva_df = factiva_df.sort_values(by=['Doc','Similarity'],ascending = False)
    TopSimSentPerDoc = factiva_df.groupby(by=['Doc']).head(1).reset_index(drop=True)
    factiva_df = factiva_df.sort_values(by=['Doc','Sentiment'],ascending = False)
    TopPosSentSentPerDoc = factiva_df.groupby(by=['Doc']).head(1).reset_index(drop=True)
    factiva_df = factiva_df.sort_values(by=['Doc','Sentiment'],ascending = True)
    TopNegSentSentPerDoc = factiva_df.groupby(by=['Doc']).head(1).reset_index(drop=True)
    factiva_df = factiva_df.sort_values(by=['Doc','Similarity'],ascending = False)

    #aggregation of doc scores at the document level and sort by doc_score2 for final review 
    factiva_doc_level = factiva_df.groupby(by=['Doc'],as_index=False)['Similarity','Sentiment'].sum()
    factiva_doc_level['Person'] = str(se_Factiva[i].entity_fname+"_"+se_Factiva[i].entity_lname)
    factiva_doc_level['TotalSents'] = factiva_df.groupby(by=['Doc'],as_index=False).Sent.nunique()
    factiva_doc_level['PerSentSimilarity'] = factiva_doc_level['Similarity']/factiva_doc_level['TotalSents']
    factiva_doc_level['P_NegSent'] = factiva_df.groupby(by=['Doc','NegSentFlag']).size().unstack()['yes']  / factiva_doc_level.TotalSents
    factiva_doc_level['P_PosSent'] = factiva_df.groupby(by=['Doc','PosSentFlag']).size().unstack()['yes']  / factiva_doc_level.TotalSents
    factiva_doc_level['P_NutSent'] = factiva_df.groupby(by=['Doc','NeutSentFlag']).size().unstack()['yes'] / factiva_doc_level.TotalSents
    factiva_doc_level['Avg_Sent'] = factiva_df.groupby(by=['Doc'],as_index=False)['Sentiment'].mean()['Sentiment']
    factiva_doc_level['Min_Sent'] = factiva_df.groupby(by=['Doc'],as_index=False)['Sentiment'].min()['Sentiment']
    factiva_doc_level['Max_Sent'] = factiva_df.groupby(by=['Doc'],as_index=False)['Sentiment'].max()['Sentiment']
    factiva_doc_level['Avg_Sim'] = factiva_df.groupby(by=['Doc'],as_index=False)['Similarity'].mean()['Similarity']
    factiva_doc_level['Min_Sim'] = factiva_df.groupby(by=['Doc'],as_index=False)['Similarity'].min()['Similarity']
    factiva_doc_level['Max_Sim'] = factiva_df.groupby(by=['Doc'],as_index=False)['Similarity'].max()['Similarity']
    factiva_doc_level['Doc_Score'] = factiva_doc_level['Similarity']*(factiva_doc_level['P_NegSent'])
    factiva_doc_level['Doc_Score2'] = factiva_doc_level['Similarity']*(factiva_doc_level['P_NegSent'])*(1-factiva_doc_level['PerSentSimilarity'])
    factiva_doc_level['MaxSimSent'] = TopSimSentPerDoc['Sentence'] 
    factiva_doc_level['MaxSentSent'] = TopPosSentSentPerDoc['Sentence']
    factiva_doc_level['MinSentSent'] = TopNegSentSentPerDoc['Sentence']
    factiva_doc_level = factiva_doc_level.sort_values(by=['Doc_Score2'],ascending = False)
    Indiv_DocLevel.append(factiva_doc_level)























#pymagloc = "C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/wiki-news-300d-1M-subword.magnitude" #Fast Text 
pymagloc = "C:/Users/caridza/Desktop/pythonScripts/NLP/GoogleNewsvectors_negative300.magnitude" #google word vectors 
wv = pymagnitude.Magnitude(pymagloc)
 



def w2v_se2(se, wv, ndoc=5, nsent=3, sent_max = 1, min_sim = .1):

    #compile function to be used on the se(the se elements are extracted from se post below function and then called within this funciton )
    def w2v_SimSent(doc_cluster, stems, wv,ndoc,nsent, sent_max, min_sim):
        
        #text procesed by w2v vs original sentence to be passed to vadar
        text_list = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True, rem_stop=True)
        text_list_vader = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True, rem_stop=False) #note: both text list, 
        
        #tfidf 
        t = tf_idf(text_list, stems)
        
        #Get average word vector for search terms
        search_vec = avg_phrase(stems, wv, t["tf_idf"], t["dic"], 0)
        
        #store new and old value of sentence in dictonary as tuple
        doc_dic = {} #inialize dic 
        idx=0 #doc index
        for  val ,val_vad in zip(text_list,text_list_vader):   
            idx2=0 #sent index re-initiated for every doc 
            for sent, sent_vad in zip(val, val_vad):
                #must substantiate the second nested dic (otherwise python thinks you are trying to insert values into a dic that doesnt exist, because its nested within another dic)
                if idx not in doc_dic.keys():
                   doc_dic[idx] = {}
                doc_dic[idx][idx2] = (sent,sent_vad) 
                idx2 = idx2+1 #iterate sent index 
            idx=idx+1    #iterate docindex
        
        #W2V Execution 
        #compute average word embeddings and identify cosine similarity of the average word vector of the sentence vs average vector of search tersm     
        from datetime import datetime
        startTime = datetime.now()
        sim_list2 = []
        sim_list_filtered = []
        for idx, val in enumerate(text_list):
            #print first text ;if idx==1:print(val)
            if len(val) > 0 and idx < ndoc:
        
                #for each sentence in each document 
                for idx2, sent in enumerate(val):
                    
                    #get sent score up front for downstream use 
                    Vad_Score = VADERSENT(' '.join(doc_dic[idx][idx2][1]),many=False)[0][1]
                    
                    #generate the avg vector associated with each sent in doc idx+1 (because idx(0) is the stems)
                    sent_vec = avg_phrase(sent, wv, t["tf_idf"],t["dic"],idx+1)
                    
                    #could also try including VADER filter here (got error last time)
                    if sent_vec.all != 0 and idx2 < nsent: 
                        #print(len(sent))
                        #error handling to prevent computation of cosine similarity with negative numbers 
                        try:                           
                            sim = cosine_sim(search_vec, sent_vec)
                            sent_sim2_all = [sim] #Method 0: one metric for each sentrence (averaged across all stems) #NORMALIZING BIAS SHORT STRINGS FOR LONG ONES REGADLESS   
                        except: 
                            sent_sim2_all = [0] #REMOVE THIS, THIS IS NOT GOOD 
              
                        #sentence level 
                        #note: vader requires a sentence, not a sentence tokenized string 
                        #sim_list2.append(list(zip([idx],[idx2],[se.urllist[0][idx]],[' '.join(doc_dic[idx][idx2][1])],sent_sim2_all, [VADERSENT(' '.join(doc_dic[idx][idx2][1]),many=False)[0][1]])))
                        #sim_list2.append(list(zip([idx],[idx2],[' '.join(doc_dic[idx][idx2][1])],sent_sim2_all, [VADERSENT(' '.join(doc_dic[idx][idx2][1]),many=False)[0][1]])))
                        
                        #only extract sentences that meet similarity and sentiment thresholds
                        if sim > min_sim and Vad_Score < sent_max:
                            #sim_list2.append(list(zip([idx],[idx2],[' '.join(doc_dic[idx][idx2][1])],sent_sim2_all, [Vad_Score]))) #Without URL Included 
                            sim_list2.append(list(zip([idx],[idx2],[se.urllist[0][idx]],[' '.join(doc_dic[idx][idx2][1])],sent_sim2_all, [Vad_Score]))) #Option 1: With URL Included
                            
                            
                            #sim_list2.append(list(zip([idx],[idx2],'SentHolder',sent_sim2_all, [VADERSENT(' '.join(doc_dic[idx][idx2][1]),many=False)[0][1]])))                            
                       #sim_list2.append(list(zip([idx],[idx2],sent_sim2_all))),[se.urllist[0][idx]])))#,sent_sim2_all)))
        #total time required to run algo 
        print(datetime.now() - startTime)

        return(sim_list2)
    

    #for each languge if the ersults are not blank, extract the post processed text, and clean the search terms , and join them into one string
    for idxx in range(0,se.search_lang_ct):
        if not se.urllist[idxx] == []:
         
            #pull out original text from se object 
            #docs and stems/keywords
            doc_cluster = se.origtextlist[idxx]
            stems= clean_paragraph(se.searchtermlist[idxx], se.search_lang_short[idxx], stemming=False, sent_tokenize=False, rem_stop=True)
                   
            #execute the function for each languge 
            se.w2vInfo[idxx] = w2v_SimSent(doc_cluster, stems, wv, ndoc=ndoc, nsent=nsent, sent_max=sent_max, min_sim = min_sim)
            
    return se

        

