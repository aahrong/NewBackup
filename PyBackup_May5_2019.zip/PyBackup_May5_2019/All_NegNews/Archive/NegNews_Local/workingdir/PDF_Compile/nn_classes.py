# -*- coding: utf-8 -*-
"""
Created on Tue Feb 20 13:19:47 2018

@author: yangbo
"""

import json
class search_entity():
    def __init__(self, search_lang = ['en'], searchid = '', fname='', lname='', mname='', city='', state='', state2='', country='', occupation='', company='', company2='',querylist=[],searchtermlist=[]):
    #Attributes about the entity
        self.entity_id = searchid
        self.entity_fname = fname
        self.entity_lname = lname
        self.entity_mname = mname
        self.entity_city = city
        self.entity_state = state
        self.entity_state2 = state2
        self.entity_country = country
        self.entity_occupation = occupation
        self.entity_company = company
        self.entity_company2 = company2
    #Attributes about what we are searching for
        self.entity_querylist = querylist
        self.searchtermlist = searchtermlist
        self.search_lang = search_lang
        self.search_lang_ct = len(self.search_lang)
        self.search_lang_short = ['']*self.search_lang_ct
    #Attributes about returned result
        self.querylisturl = [[]]*self.search_lang_ct
        self.urllist = [[]]*self.search_lang_ct
        self.origtextlist = [[]]*self.search_lang_ct
        self.textlist = [[]]*self.search_lang_ct
        self.static_search_result = ''
    #Attributes about matching
        self.list_fuzzyscore = [[]]*self.search_lang_ct
        self.list_fuzzyscoredetail = [[]]*self.search_lang_ct
        self.list_matchedstems = [[]]*self.search_lang_ct
    #Additional Attributes
        self.LSA_score = [[]]*self.search_lang_ct
        self.w2vInfo =  [[]]*self.search_lang_ct
        self.w2vDocRank = [[]]*self.search_lang_ct
        self.w2vTopSent = [[]]*self.search_lang_ct
    #Final Scores
        self.LSA_filter_count = ['']*self.search_lang_ct
        self.riskscore_final = ['']*self.search_lang_ct
        self.link_score_threshold = ['']*self.search_lang_ct
        self.name_fuzzy_all = ['']*self.search_lang_ct
        self.location_fuzzy_all = ['']*self.search_lang_ct
        self.employment_fuzzy_all = ['']*self.search_lang_ct
         
    def aggregate_info(self):
        printlist = [self.entity_fname, self.entity_lname, self.entity_mname, self.entity_city, self.entity_state, self.entity_state2, self.entity_country, self.entity_occupation, self.entity_company, self.entity_company2]
        return " ".join([x.lower() for x in printlist if x != ''])

    def location_provided(self):
        loclist = [self.entity_city, self.entity_state, self.entity_state2, self.entity_country]
        returnval = False
        if len([x for x in loclist if x != ''])>0: returnval = True
        return returnval

    def employment_provided(self):
        loclist = [self.entity_occupation, self.entity_company, self.entity_company2]
        returnval = False
        if len([x for x in loclist if x != ''])>0: returnval = True
        return returnval

    def to_json(self, location):
        try:
            outdata = {}
            outdata['id'] = self.entity_id
            outdata['entity_fname'] = self.entity_fname
            outdata['entity_lname'] = self.entity_lname
            outdata['entity_mname'] = self.entity_mname
            outdata['entity_city'] = self.entity_city
            outdata['entity_state'] = self.entity_state
            outdata['entity_state2'] = self.entity_state2
            outdata['entity_country'] = self.entity_country
            outdata['entity_occupation'] = self.entity_occupation
            outdata['entity_company'] = self.entity_company
            outdata['entity_company2'] = self.entity_company2
            outdata['entity_querylist']=self.entity_querylist 
            outdata['searchtermlist']=self.searchtermlist 
            outdata['search_lang']=self.search_lang 
            outdata['search_lang_ct']=self.search_lang_ct 
            outdata['search_lang_short']=self.search_lang_short 
            outdata['querylisturl']=self.querylisturl 
            outdata['urllist']=self.urllist 
            outdata['origtextlist']=self.origtextlist 
            outdata['textlist']=self.textlist 
            outdata['static_search_result']=self.static_search_result 
            outdata['list_fuzzyscore']=self.list_fuzzyscore 
            outdata['list_fuzzyscoredetail']=self.list_fuzzyscoredetail 
            outdata['list_matchedstems']=self.list_matchedstems 
            outdata['LSA_score']=self.LSA_score 
            outdata['LSA_filter_count']=self.LSA_filter_count 
            outdata['w2vInfo']=self.w2vInfo 
            outdata['riskscore_final']=self.riskscore_final 
            outdata['link_score_threshold']=self.link_score_threshold 
            outdata['name_fuzzy_all']=self.name_fuzzy_all 
            outdata['location_fuzzy_all']=self.location_fuzzy_all 
            outdata['employment_fuzzy_all']=self.employment_fuzzy_all
            with open(location, 'w') as outfile:
                json.dump(outdata, outfile)
            return 0
        except:
            return -1



