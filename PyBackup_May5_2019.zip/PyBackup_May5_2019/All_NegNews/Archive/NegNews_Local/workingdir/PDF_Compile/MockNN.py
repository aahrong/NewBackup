# -*- coding: utf-8 -*-
"""
Created on Wed May 30 13:21:40 2018

@author: yangbo
"""
import sys
sys.path.insert(0,r'C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab//')
sys.path.insert(0,r'C:/Users/caridza/Desktop/pythonScripts/NN_Gitlab/workingdir/PDF_Compile')
import json
import re
import os
import numpy as np
#from nn_base.timeout import timeout
import nn_base.nn_config as config
#from nn_base.nn_textprocess import force_near_filter
from nn_base.nn_textprocess import clean_paragraph
from nn_base.nn_textprocess import entity_match_score
from nn_base.nn_textprocess import entity_stem_match
from nn_base.nn_textprocess import LSA_function
from nn_textprocess import rerank_searchresults
from nn_textprocess import summary_scores
from nn_pdf import create_empty_page
from nn_pdf import create_nn_page
from nn_pdf import create_pdf_summary
#from nn_base.nn_classes import search_entity as SE
from nn_classes import search_entity as SE
import pandas as pd



#@timeout(config.timeout)
def window_search(text, fname, lname):
    try:
        if lname != '':
            regex_name = ('{}|{}'.format(fname, lname)).lower()
        else:
            regex_name = ('{}'.format(fname)).lower()
        text_for_regex = 'the. ' + text.lower() + ' the. the.' 
        extracted_text_list =[]
        p = re.compile(r'(([^\.]*\.){1}[^\.]*(' + regex_name + ')[^\.]*\.([^\.]*\.){2})')
        for name_i in p.findall(text_for_regex):
            extracted_text_list.append(name_i[0])
        extracted_text_list = list(set(extracted_text_list))
        extracted_text = '<!@&>'.join(extracted_text_list)
        return extracted_text
    except:
        return ''


location = 'C:\\NN\\CitiFactiva\\'
jsonlist = ['Jane_Green_20180522_113413.json', 'John_Smith_20180522_112734.json', 'Google_20180522_114005.json', 'Pfizer_20180522_114231.json']
namelist = ['Jane Green', 'John Smith', 'Google', 'Pfizer']

#df_final = pd.read_pickle(location+'factiva_df_final.pkl')
#df_final.to_excel(location+'test2.xlsx')
for idx, val in enumerate(namelist):
    name = val.split()
    jsonfile = json.load(open(location + jsonlist[idx],'r'))
    titlelist = jsonfile['title']
    textlist = jsonfile['text']
    fname = name[0]
    lname = name[1] if len(name) > 1 else ''
    searchstem = [
        'launder', 
        'terrorist', 
        'counterfeit', 
        'unlawful', 
        'indict', 
        'evasion', 
        'embezzle', 
        'sanction', 
        'felony', 
        'extort', 
        'smuggle', 
        'fraud', 
        'violation', 
        'convict', 
        'guilty', 
        'theft', 
        'corrupt', 
        'bankrupt', 
        'suspect', 
        'fugitive', 
        'arrest', 
        'criminal', 
        'bribe', 
        'accuse', 
        'conspire', 
        'allege'
        ]
    se = SE(searchid = str(idx), search_lang = ['english'], fname = fname, lname=lname, searchtermlist=[searchstem])
    
    for idx2, val2 in enumerate(titlelist):
        text1 = window_search(textlist[idx2], se.entity_fname, se.entity_lname)
        if se.entity_lname != '':
             text1 = force_near_filter(text1, se.entity_fname, se.entity_lname, config.near_filter_distance)
        text = clean_paragraph(text1, 'en')    
        
        if text != '':
#            print(val2)
#            print(se.urllist[0])
            se.origtextlist[0] = se.origtextlist[0] + [textlist[idx2]]
            se.urllist[0] = se.urllist[0] + [re.sub('\n', '', val2).split('Published Date')[0]]
            se.textlist[0] = se.textlist[0] + [text]
            scores=entity_match_score(text,se, 0)
            stemmatch=entity_stem_match(text,se, 0)
            #Attributes about matching
            se.list_fuzzyscore[0] = se.list_fuzzyscore[0] + [np.mean([x for x in scores if x > 0])]
            se.list_fuzzyscoredetail[0] = se.list_fuzzyscoredetail[0] + [scores]
            se.list_matchedstems[0] = se.list_matchedstems[0] + [stemmatch]
            print(val2)
            print('===== NOT BLANK =====')
        else:
            print(val2)
            print('===== BLANK =====')
                
    se = LSA_function(se)
    
    df_test = pd.read_pickle(location+ fname + '_' + lname + '.pkl')
    
    se_real = se
    df_test = se 
    df_person = df_test.w2vDfSorted[0][0][0]
    w2vfinalscore = round(df_test.w2vDfSorted[0][0][2]['Final_Normalized_Score'][0]*100,2)
#    df_person = df_final[(df_final.Person == fname +'_' + lname) & (df_final.Sentiment <= 0) & (df_final.Similarity >= 0.2)]
    w2vdocrank = df_person.sort_values(['Doc','FinalDocScore'], ascending=False).groupby(['Doc'])['FinalDocScore'].max()
    w2vdocsents = df_person.sort_values(['Doc','Sim_Tanh_Weighted'], ascending=False).groupby(['Doc'])['Sentence'].apply(list).apply(lambda x: x[0:3])
    w2vdocs = df_person.sort_values(['Doc','Sim_Tanh_Weighted'], ascending=False).groupby(['Doc'])['URL'].first()
    #w2vfinalscore = round(df_person['Final_Normalized_Score'].max()*100,2)
    
    w2vDocRank = list(w2vdocrank)
    w2vTopSent = list(w2vdocsents)
    se.urllist[0] = list(w2vdocs)
    se.riskscore_final[0] = min(w2vfinalscore + 25, 100.0)
    print(se.riskscore_final)
    se, w2vTopSent = rerank_searchresults(se, w2vDocRank,w2vTopSent, config.LSA_score_filter-1000)
#    print(se.urllist[0])
    se = summary_scores(se, config.search_results)
    print(se.riskscore_final)
    #se.entity_querylist = ['http://factiva.com']
    #se.querylisturl = ['http://factiva.com']
    config.pdf_path = 'C:\\Users\\caridza\\Desktop\\pythonScripts\\NN_Gitlab\\workingdir\\PDF_Compile'
    config.search_results = 100  
    se.LSA_filter_count[0] = len(se.urllist[0])
    filename, failed = create_pdf_summary(se, w2vDocRank, w2vTopSent)
    #jsonname = os.path.splitext(filename)[0]+'.json'
    #dataout = se.to_json(jsonname)
    #print(filename)



#
#from itertools import tee, islice, chain
#def previous_and_next(some_iterable):
#    prevs, items, nexts = tee(some_iterable, 3)
#    prevs = chain([''], prevs)
#    nexts = chain(islice(nexts, 1, None), [''])
#    return zip(prevs, items, nexts)
