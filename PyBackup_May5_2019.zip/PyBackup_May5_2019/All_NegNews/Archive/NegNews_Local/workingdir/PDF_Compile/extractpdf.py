# -*- coding: utf-8 -*-
"""
Created on Wed May 30 10:50:34 2018

@author: yangbo
"""
from io import StringIO
import json
import re
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage

def convert_pdf_to_txt(path):       
    rsrcmgr = PDFResourceManager()
    retstr = StringIO()
    codec = 'utf-8'
    laparams = LAParams()
    device = TextConverter(rsrcmgr, retstr, codec=codec, laparams=laparams)
    fp = open(path, 'rb')
    interpreter = PDFPageInterpreter(rsrcmgr, device)
    password = ""
    maxpages = 0
    caching = False
    pagenos=set()

    for page in PDFPage.get_pages(fp, pagenos, maxpages=maxpages, password=password,caching=caching, check_extractable=True):
        interpreter.process_page(page)

    text = retstr.getvalue()

    fp.close()
    device.close()
    retstr.close()
    return text  

#for John Smith
text = convert_pdf_to_txt(r'C:\NN\CitiFactiva\\John_Smith_20180522_112734.pdf')
text = re.sub(r'\n\n\x0c', r'\n', text)
text = re.sub(r'\n\n\Today’s Action Designates', r'\n', text)
testlist = text.split('\n\n')[15:]
testlist = testlist[:-1]
testlist = [b for a in testlist for b in a.split('NEWARK, N.J. (AP)')]
testlist = [b for a in testlist for b in a.split('ATLANTA, May 3')]

i = 0
titlelist = []
textlist = []

for text in testlist:
    if 'Published Date' in text:
        titlelist.append(text)
    else:
        textlist.append(text)

outdata = {}
outdata['title'] = titlelist
outdata['text'] = textlist
with open(r'C:\NN\CitiFactiva\\John_Smith_20180522_112734.json', 'w') as outfile:
    json.dump(outdata, outfile)
    
    
#for Jane Green
text = convert_pdf_to_txt(r'C:\NN\CitiFactiva\\Jane_Green_20180522_113413.pdf')
text = re.sub(r'\n\n\xa0', r'\n', text)
text = re.sub(r'\n\n\x0c', r'\n', text)
text = re.sub(r'\n\n\“Nathan', r'\n', text)
testlist = text.split('\n\n')[15:]
testlist = testlist[:-1]
testlist = [b for a in testlist for b in a.split('A Wigan')]
#testlist = [b for a in testlist for b in a.split('ATLANTA, May 3')]

i = 0
titlelist = []
textlist = []

for text in testlist:
    if 'Published Date' in text:
        titlelist.append(text)
    else:
        textlist.append(text)

outdata = {}
outdata['title'] = titlelist
outdata['text'] = textlist
with open(r'C:\NN\CitiFactiva\\Jane_Green_20180522_113413.json', 'w') as outfile:
    json.dump(outdata, outfile)
    
    
    
#for Google
text = convert_pdf_to_txt(r'C:\NN\CitiFactiva\\Google_20180522_114005.pdf')
text = re.sub(r'\n\n\xa0', r'\n', text)
text = re.sub(r'\n\n\x0c', r'\n', text)
testlist = text.split('\n\n')[13:]
testlist = testlist[:-1]
testlist = [b for a in testlist for b in a.split('WHAT THE OTHER')]
testlist = [b for a in testlist for b in a.split('White said.')]
i = 0
titlelist = []
textlist = []
for text in testlist:
    if 'Published Date' in text:
        titlelist.append(text)
    else:
        textlist.append(text)
outdata = {}
outdata['title'] = titlelist
outdata['text'] = textlist
with open(r'C:\NN\CitiFactiva\\Google_20180522_114005.json', 'w') as outfile:
    json.dump(outdata, outfile)
    
    
#for Pfizer
text = convert_pdf_to_txt(r'C:\NN\CitiFactiva\\Pfizer_20180522_114231.pdf')
text = re.sub(r'\n\n\xa0', r'\n', text)
text = re.sub(r'\n\n\x0c', r'\n', text)
testlist = text.split('\n\n')[13:]
testlist = testlist[:-1]
#testlist = [b for a in testlist for b in a.split('WHAT THE OTHER')]
#testlist = [b for a in testlist for b in a.split('White said.')]
i = 0
titlelist = []
textlist = []
for text in testlist:
    if 'Published Date' in text:
        titlelist.append(text)
    else:
        textlist.append(text)
outdata = {}
outdata['title'] = titlelist
outdata['text'] = textlist
with open(r'C:\NN\CitiFactiva\\Pfizer_20180522_114231.json', 'w') as outfile:
    json.dump(outdata, outfile)