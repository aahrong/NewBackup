import json
import os
import sys
import pandas as pd
sys.path.insert(0, 'C:/NN/fci-negative-news-api')

from nn_base.nn_classes import search_entity as SE


def trim_key(obj):
    for key in obj.keys():
        new_key = key.strip()
        if new_key != key:
            obj[new_key] = obj[key]
            del obj[key]
    return obj


folderpath = 'C:/NN/20180516_2_NOLOC/'
#folderpath='C:/NN/' + sys.argv[1]

folder = []
file = []
fname = []
lname = []
mname = []
city = []
state = []
riskscore_final = []
se_list = []

for filename in os.listdir(folderpath):
    if filename.endswith('.json'):
        #folder.append(sys.argv[1])
        jsonfile = json.load(open(folderpath + filename,'r'), object_hook=trim_key)
        folder.append(folderpath)
        file.append(filename)
        fname.append(jsonfile['entity_fname'])
        mname.append(jsonfile['entity_mname'])
        lname.append(jsonfile['entity_lname'])
        city.append(jsonfile['entity_city'])
        state.append(jsonfile['entity_state'])
        riskscore_final.append(jsonfile['riskscore_final'])
        se = SE()
        #se.entity_id=jsonfile['id']
        se.entity_id = ''
        se.entity_fname=jsonfile['entity_fname']
        se.entity_lname=jsonfile['entity_lname']
        se.entity_mname=jsonfile['entity_mname']
        se.entity_city=jsonfile['entity_city']
        se.entity_state=jsonfile['entity_state']
        se.entity_state2=jsonfile['entity_state2']
        se.entity_country=jsonfile['entity_country']
        se.entity_occupation=jsonfile['entity_occupation']
        se.entity_company=jsonfile['entity_company']
        se.entity_company2=jsonfile['entity_company2']
        se.entity_querylist=jsonfile['entity_querylist']
        se.searchtermlist=jsonfile['searchtermlist']
        se.search_lang=jsonfile['search_lang']
        se.search_lang_ct=jsonfile['search_lang_ct']
        se.search_lang_short=jsonfile['search_lang_short']
        se.querylisturl=jsonfile['querylisturl']
        se.urllist=jsonfile['urllist']
        se.origtextlist=jsonfile['origtextlist']
        se.textlist=jsonfile['textlist']
        se.static_search_result=jsonfile['static_search_result']
        se.list_fuzzyscore=jsonfile['list_fuzzyscore']
        se.list_fuzzyscoredetail=jsonfile['list_fuzzyscoredetail']
        se.list_matchedstems=jsonfile['list_matchedstems']
        se.LSA_score=jsonfile['LSA_score']
        se.LSA_filter_count=jsonfile['LSA_filter_count']
        se.riskscore_final=jsonfile['riskscore_final']
        se.link_score_threshold=jsonfile['link_score_threshold']
        se.name_fuzzy_all=jsonfile['name_fuzzy_all']
        se.location_fuzzy_all=jsonfile['location_fuzzy_all']
        se.employment_fuzzy_all=jsonfile['employment_fuzzy_all']
        se_list.append(se)

df = pd.DataFrame({'folder': folder, 'filename': file, 'fname':fname, 'mname':mname, 'lname':lname, 'city':city, 'state':state, 'riskscore':riskscore_final})

#df.to_csv('test.csv')


