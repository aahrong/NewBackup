# -*- coding: utf-8 -*-
"""
Created on Tue Feb 13 14:24:37 2018

@author: yangbo
"""


"""
NEGATIVE NEWS CONFIGURATION FILE

#Inputs: 
#Outputs: 

#
"""

search_engine = 'BING' #Accept GOOGLE, BING, SECRAWL
translator = 'BING' #Accepts GOOGLE, BING, DEEPL
search_lang = ['english','Spanish']#,'spanish']#,'spanish','chinese'] #Supported languages: en, es, zh
#config paths must have \\ or / at the end of folders
project_dir = 'c:/users/caridza/desktop/Pythonscripts/NN_Gitlab/'
#project_dir = '/' # - use for docker
scraper_dir = project_dir + 'website_scraper_multilang/' #Accepts Links
source_path = project_dir + 'sourcefile/'  #what does source file contian? 
working_path =  project_dir + 'workingdir/' #what does workin directory contain 
pdf_path = project_dir + 'pdf/' #location to store final pdf output 
#pdf_path = '/data/ci/files/'
common_noun = 'common_nouns.txt'
source_excel_file = 'TestList_v3.xlsx'
source_excel_names = 'TIAAList'#FullList,CoreList
source_excel_tokens = 'Stems'
query_picklename = 'Query_Pickle.pk'
BingAPIKey_translate = '9d44b25f4d2d43c9823f2caa53c7097c'
BingAPIKey_search = 'c759653bb84b490ba06cfcd92b2397e4'
#'dc21a3106d8e4968a755888c1944f758'
search_results = 100
search_results_output = 100
search_results_maxoutput = 100
LSA_score_filter = 0.00
search_with_location = 0
near_filter_distance = 3
static_spider = 0
