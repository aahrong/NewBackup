# -*- coding: utf-8 -*-
"""
Created on Mon Feb 19 14:36:38 2018

@author: yangbo
"""

import re
from bs4 import BeautifulSoup
from bs4.element import Comment
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
import string
import time
import requests
import nn_base.nn_config as config

#take search entity object and return the links and the query that we care about 
#note: all inputs are from the se or from the config file. 
#note: each bing request returns at max 50 results 
def search_on_bing_all(se):
    ## Query bing based on parameters)        
    def search_on_bing(query, count, offset, searchlang):
        subscription_key = config.BingAPIKey_search
        assert subscription_key
        search_url = "https://api.cognitive.microsoft.com/bing/v7.0/search"
        bing_params  = {"q": 'language:'+searchlang[0:2] + ' '+query, "count": count, "offset": offset, "responseFilter":'Webpages'}
        headers = {"Ocp-Apim-Subscription-Key" : subscription_key}
        time.sleep(1)
        bing_response = requests.get(search_url, headers=headers, params = bing_params)
        bing_response.raise_for_status()
        return bing_response
    ## Parse the results from bing search 
    def parse_bing_response(bing_response):
        search_results = bing_response.json()        
        try:
            bingquery = search_results['webPages']['webSearchUrl']
            url_list = [result['url'] for result in search_results['webPages']['value']]
        except:
            url_list = []
            bingquery = 'https://www.bing.com/search?q=' + search_results['queryContext']['originalQuery']
            print("Error getting results from bing")
        return url_list, bingquery    
    
    all_links = []
    all_url_list = []
    all_bingquery = []
    for idx in range(0, se.search_lang_ct):
        searchquery = se.entity_querylist[idx]
        if searchquery == []:
            links = []
            url_list = []
            bingquery = []
        else:
            search_offset = 0
            bing_response = search_on_bing(searchquery, config.search_results, search_offset, se.search_lang_short[idx])
            url_list, bingquery = parse_bing_response(bing_response)
            if len(url_list) == 0:
                print("No Results for searching {} {} in {}".format(se.entity_fname, se.entity_lname, se.search_lang[idx]))
            else:
                searchcount=2
                while len(url_list)<config.search_results or searchcount<6:
                    searchcount = searchcount + 1
                    search_offset = search_offset + config.search_results
                    bing_response = search_on_bing(searchquery, config.search_results, search_offset, se.search_lang_short[idx])
                    url_list2, _ = parse_bing_response(bing_response)
                    if len(url_list2)==0:
                        print("Cannot find more than {} results after {} searches".format(config.search_results, searchcount))
                        searchcount = 5
                    else:
                       url_list.extend(url_list2)
            items = ['.pdf','.doc', '.csv', '.docx', '.xls', '.xlsx', '.png', '.jpeg', 
                 '.jpg','.gif','.xml', '.json', '.gz', '.zip', 'ppt','.pptx', '.xlsm','.xlsb', '.txt']
    #        blacklist = ['books.google','linkedin.com', 'imdb.com', 'facebook.com', 'pinterest.com', 
    #                 'instagram.com', 'twitter.com', 'youtube.com', 'instantcheckmate', 'webmd.com', 
    #                 'intelius', 'whitepages.com', 'scholar.google', 'nih.gov', 'springer','mylife',
    #                 'alumnius.net', 'peekyou.com', 'amazon.com', 'arxiv.org', 'zoominfo.com', 'quicksearch.in',
    #                 'peoplefinders.com', 'spokeo.com', 'ussearch.com', 'usa-people-search.com', 
    #                 'privateeye.com', 'intelius.com', 'zabasearch.com', 'peoplelookup.com', 'quizlet.com', 'flickr.com']
    #        items = items+ blacklist
            links = url_list
            for i in items:
                links = [link for link in links if i not in link.lower()]
            links = links[0:config.search_results]
        all_links.append(links)
        all_url_list.append(url_list)
        all_bingquery.append(bingquery)
    return all_links, all_url_list, all_bingquery       
        

def extract_google_results(response):
    links=[]
    for b in response.xpath('//h3/a/@href').extract():
        if "/aclk?sa=" not in b and "/search?q=" not in b:
            if "/url?q=" in b:
                links.append(re.search('q=(.*)&sa',b).group(1))
            elif "/url?url=" in b:
                links.append(re.search('url=(.*)&rct',b).group(1))
            else:
                links.append(b)                   
    items = ['.pdf','.doc', '.csv', '.docx', '.xls', '.xlsx', '.png', '.jpeg', 
         '.jpg','.gif','.xml', '.json', '.gz', '.zip', 'ppt','.pptx', '.xlsm','.xlsb', '.txt']
    blacklist = ['books.google','linkedin.com', 'imdb.com', 'facebook.com', 'pinterest.com', 
             'instagram.com', 'twitter.com', 'youtube.com', 'instantcheckmate', 'webmd.com', 
             'intelius', 'whitepages.com', 'scholar.google', 'nih.gov', 'springer','mylife',
             'alumnius.net', 'peekyou.com', 'amazon.com', 'arxiv.org', 'zoominfo.com', 'quicksearch.in']
    items = items+ blacklist
    links_returned_search = len(links)
    for i in items:
        links = [link for link in links if i not in link.lower()]
    print("{} links were removed from the pages searched. " .format(links_returned_search-len(links)))
    print("{} links were left." .format(len(links)))
    print(links)
    return links, len(links), links_returned_search

#parse down the search results, to only the search results that contain the names and keywords of the individual in quesiton  
def extract_web_results(response, fname, lname):
    def text_from_html(htmltext, parser):
        def tag_visible(element):
            if element.parent.name in ['style', 'script', 'head', 'title', 'meta', '[document]']:
                return False
            if isinstance(element, Comment):
                return False
            return True
        soup = BeautifulSoup(htmltext, parser)
        texts = soup.findAll(text=True)
        visible_texts = filter(tag_visible, texts)  
        return u" ".join(t.strip() for t in visible_texts)
    ## defining function to return fuzzy score for name, location and occupation
 
    url = response.url
    try:
        contents=response.text
        text = text_from_html(contents, "html")
        regex_name = ('{}|{}'.format(fname, lname)).lower()
        text_for_regex = 'the. ' + text.lower() + ' the. the.' 
        extracted_text_list =[]
        p = re.compile(r'(([^\.]*\.){1}[^\.]*(' + regex_name + ')[^\.]*\.([^\.]*\.){2})')
        for name_i in p.findall(text_for_regex):
            extracted_text_list.append(name_i[0])
        extracted_text_list = list(set(extracted_text_list))
        extracted_text = '<!@&>'.join(extracted_text_list)
        ## Now try with lxml parser, if extracted text is blank
        if extracted_text == '':
            text = text_from_html(contents,"lxml")
            text_for_regex = 'the. ' + text.lower() + ' the. the.' 
            extracted_text_list =[]
            for name_i in p.findall(text_for_regex):
                 extracted_text_list.append(name_i[0])
        extracted_text = ' '.join(extracted_text_list)
        return url, extracted_text
    except:
        return url, ''

#  identify_whitelist: search_entity(se) -> list (whitelist)
#  Function consumes a search_entity item relating to a person or business and returns
#   a list of URL that relates to the search entity coming from white list
#   whitelist will be used by scrapy to ensure these sites are always searched
def identify_whitelist(se):
    whitelist = []
    # Justia.com
    whitelist.append("https://dockets.justia.com/search?parties={}+{}&cases=mostrecent".format(se.entity_fname, se.entity_lname))
    # Wikipedia
    whitelist.append("https://en.wikipedia.org/wiki/{}_{}".format(se.entity_fname, se.entity_lname))
    # Colombian District Attorney website
    whitelist.append("https://www.fiscalia.gov.co/colombia/?s={}+{}".format(se.entity_fname, se.entity_lname))
    # REVISIT: BRB Publications (powered by Intelius) --> on blacklist
    #whitelist.append("https://www.intelius.com/people-search/{}-{}/{}".format(se.entity_fname, se.entity_lname, se.entity_state))
    # REVISIT: Whitepages --> on blacklist
    #whitelist.append("https://www.whitepages.com/name/{}-{}".format(se.entity_fname, se.entity_lname))   
    return whitelist

