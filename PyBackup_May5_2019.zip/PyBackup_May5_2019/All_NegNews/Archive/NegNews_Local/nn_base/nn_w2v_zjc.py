

# Re-ordering search results based on W2V similarity instead of LSI
def W2V_function(se):
    # Create TF-IDF to be used in weighting word2vec values.
    def tf_idf(site_list, search_terms):
        doc_list = []
        for site in site_list:
            doc_list.append([item for sublist in site for item in sublist])
        texts = [search_terms] + doc_list
        dictionary = corpora.Dictionary(texts)
        corpus = [dictionary.doc2bow(text) for text in texts]
        ## Using tf-idf conversion for corpus 
        tf_idf_model = models.TfidfModel(corpus,id2word=dictionary, normalize=True) # fit model
        tf_idf_corp = tf_idf_model[corpus] # apply model
        tf_idf_items = {"dic": dictionary, "tf_idf": tf_idf_corp}
        return tf_idf_items
    # Function to get cosine similarity 
    def cosine_sim(a, b):
        return 1 - spatial.distance.cosine(a, b)
    # Function to get weighted average vector of a sentence. Weighting is done by multiplying tf-idf scores
    def avg_phrase(phrase, pymagloc, tf_idf, dictionary, doc_id):
        wv = pymagnitude.Magnitude(pymagloc)
        v = np.zeros(300)
        print(set(phrase))
        for w in set(phrase):
            if w in wv:
                word_id = dictionary.token2id[w]
                doc_vectors = tf_idf[doc_id]
                d = dict(doc_vectors)
                tf_score = d[word_id] 
                v += wv.query(w) * tf_score
        v_norm = preprocessing.normalize(v.reshape(1,-1))
        return  v_norm

'C:\\Users\\yangbo\\Documents\\Engagements\\04 INTAML\\Negative_News\\bitbucket\\fci-negative-news-api\\sourcefile\\GoogleNews-vectors-negative300.magnitude'

    def W2V_function_single(doc_cluster, stems):
        # Pre-process scraped text and search terms
        text_list = clean_paragraph(doc_cluster,'english',stemming=False,sent_tokenize=True)
        # Get tf_idf for site text and search terms
        t = tf_idf(text_list, stems)
        # Get average vector for search terms
        search_vec = avg_phrase(stems, model, t["tf_idf"], t["dic"], 0)
        
        # Instantiate list to store cosine similarities
        sim_list = []
        cnt_list = []
        
        if cos_type == 1:
            # Option A) get cosine similiarity of tf idf weighted document vector for each site
            for idx, val in enumerate(text_list):
                if len(val) > 0:
                    sites_flat = [item for sublist in val for item in sublist]
                    text_vec = avg_phrase(sites_flat, model, t["tf_idf"], t["dic"], idx + 1)
                    if text_vec.all != 0:
                        site_sim = cosine_sim(search_vec,text_vec)
                        cnt_list.append(len(sites_flat))
                        sim_list.append(site_sim)  
        else:             
            # Option B) Get soft cosine similarity for each site using gensim functions
            doc_list = []  # Create list of flattened docs
            for site in text_list:
                doc_list.append([item for sublist in site for item in sublist])
            dictionary = t["dic"] #Dictionary to be used in gensim functions
            corpus = [dictionary.doc2bow(text) for text in doc_list]
            similarity_matrix = model.similarity_matrix(dictionary)  # construct similarity matrix
            index = similarities.SoftCosineSimilarity(corpus, similarity_matrix) # Does not run with pymagnitude and gensim 
            
            # Calculate similarity between query and each doc from bow_corpus
            sim_list = index[dictionary.doc2bow(search_terms)]
            
            # Get word counts for each site to be used in final score calculation
            for idx, val in enumerate(text_list):
                if len(val) > 0:
                    sites_flat = [item for sublist in val for item in sublist]
                    cnt_list.append(len(sites_flat))
            
        # Take average of site similarity scores for final scores
        total_len = sum(cnt_list)
        weighted_sims = [sim * (cnt/total_len) for sim, cnt in zip(sim_list,cnt_list)]
        se.nn_score = sum(weighted_sims)
    return se.nn_score

    for idx in range(0,se.search_lang_ct):
        if not se.urllist[idx] == []:
            doc_cluster = se.textlist[idx]
            stems = ' '.join(clean_paragraph(se.searchtermlist[idx], se.search_lang_short[idx]))
            se.ranking_score[idx] = W2V_function_single(doc_cluster, stems)
    return se


############ Experimentation Script - Not for production #########################
# test_path = ("C:/Users/queenmi/Documents/Text_Analytics/Negative_News/Negativenews/" +
# "website_scraper_multilang/sourcefile/test/workingdir/Query_Pickle_returned.pk")

# test_path = "C:/Users/queenmi/Documents/Text_Analytics/Negative_News/Negativenews/website_scraper_multilang/workingdir/Aggregation_20180329.pk"

# test = pd.read_pickle(test_path)

# w2v_path = config.source_path + "GoogleNews-vectors-negative300.bin.gz"
# model = models.KeyedVectors.load_word2vec_format(w2v_path, binary=True, limit = 200000)
# test = test.iloc[0:15,:]
# scores = []

# class SEclass:
#     def __init__(self,site_text,search_terms):
#         self.origtextlist = site_text
#         self.searchterm_list = search_terms        

# for index,row in test.iterrows():
#     if row["origtextlist"] != None and row["searchterm_list"] != None:
#         se = SEclass(row["origtextlist"],row["searchterm_list"])
#         scores.append(wordvector_function(se,model))   
#     else:
#         scores.append(None)

# test["w2v"] = pd.Series(scores)
# test_df = test[["FirstName","LastName","w2v"]]

##### Normalization testing #######
def normalize_LSA(score):
    lsa_sum = (score)*100
    a = 0.342419512682912
    b = 1.19480978536808
    c = 0.211456297918287
    d = 0.779544742969885
    percent_risk = c + d*np.tanh((lsa_sum-a)/b)
    return(percent_risk*100)

t_df["w2v_norm"] = t_df["w2v"].apply(lambda x: 1/(1+np.exp(-x)))