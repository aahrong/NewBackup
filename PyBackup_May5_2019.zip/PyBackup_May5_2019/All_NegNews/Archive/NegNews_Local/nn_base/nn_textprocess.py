# -*- coding: utf-8 -*-
"""
Created on Tue Feb 20 12:59:41 2018

@author: yangbo
"""

from nn_base.nn_classes import search_entity as SE
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from gensim import corpora, models, similarities
import string
import re
from fuzzywuzzy import fuzz
import numpy as np
import operator

## remove punctuation, lower, remove stop words, porter stemming
# remove punctuation, lower, remove stop words, porter stemming
#cleaning processes used will depend on weather or not you use w2v or lsa 
def clean_paragraph(content, lang, stemming=True, sent_tokenize=False):
    if lang in SnowballStemmer.languages:
        #set up stopword and stemming objects specific to languge specified
        stop = set(stopwords.words(lang))
        stemmer = SnowballStemmer(lang)
        ##if languge specified does not exist default to english
    else:
        stop = set(stopwords.words('english'))
        stemmer = SnowballStemmer('english')
    # puncremove = str.maketrans(string.punctuation,' '*len(string.punctuation))  
    def clean_text(text):
        #sent tokenize and remove stop words, and alpha's and put to lower 
        #note: for w2v we do NOT want to stem the words or remove punctuation 
        if sent_tokenize == True:
            sent_tokens = nltk.sent_tokenize(text)
            tokens = [nltk.regexp_tokenize(sentence, r'\w+') for sentence in sent_tokens]
            rettext = []
            for sent in tokens:
                rettext.append([w.lower() for w in sent if w.isalpha() and not w in stop and len(w) > 1])
        #if we are performing lsa then we remove punctionation , remove stops, lower, and stem 
        else:
             #remove punctuation from each string 
            for punc in string.punctuation:
                text = text.replace(punc, '')
            #text to lower, split by word, and remove stop words    
            rettext = [x for x in text.lower().split() if (x != '' and x not in stop)]
            if stemming==True:
                #stem text(at the word level)
                rettext = [stemmer.stem(x) for x in rettext]
            rettext = ' '.join(rettext)
        #return the clean text object 
        return rettext
        
    if type(content) is list:
        out = [clean_text(x) for x in content]
    else:
        out = clean_text(content)
    return out
    

#require that the first name and last name be near each other in the search results 
#this is used to identify all articles that do not contian the first and last name of the individual and seperated by at most n words. 
#if name is not found, make the text string blank, otherwise do nothing
#note: looks at the original article and removes the article from consideration if the name of the se is not found within n words of a keyword search term 
#note: does not look at the cleaned text, it looks at the original text 
def force_near_filter(text, fname, lname, distance):
    string = r'\b(?:{}\W+(?:\w+\W+){{0,{}}}?{}|{}\W+(?:\w+\W+){{0,{}}}?{})\b'.format(fname.lower(),distance, lname.lower(),lname.lower(), distance, fname.lower())
    nearnames = re.findall(string, text.lower())
    if nearnames == []:text = ''
    return text
	
#various methods for aggregating match similarities / results
#1.use clean_paragraph to stem / clean the search string to be inline with the stemed versions of the search strings we will be looking for 
def entity_match_score(text, se, lang_idx):
    namelist = clean_paragraph([se.entity_fname, se.entity_lname, se.entity_mname], se.search_lang[lang_idx], stemming=True , sent_tokenize=False)
    loclist = clean_paragraph([se.entity_city, se.entity_state, se.entity_state2, se.entity_country], se.search_lang[lang_idx], stemming=True, sent_tokenize=False)
    emplist = clean_paragraph([se.entity_occupation, se.entity_company, se.entity_company2], se.search_lang[lang_idx], stemming=True, sent_tokenize=False)

    #compute similarity raios for names , locations, and company info 
    namescore = list(map(lambda x: fuzz.partial_token_set_ratio(text, x), [x for x in namelist if x != ''])) #returns the ratio of the most similar substring as a number between 0 and 100 but sorting the token before comparing.
    locscore = list(map(lambda x: fuzz.partial_ratio(text, x),  [x for x in loclist if x != ''])) #compares the strings and returns the match from the best substring
    empscore = list(map(lambda x: fuzz.partial_ratio(text, x), [x for x in emplist if x != '']))
    
    #compute / aggregate results of similarity metrics 
    score_name = int(np.mean(namescore)) 
    score_city = max(locscore) if len(locscore)>0 else 0
    score_occupation = max(empscore) if len(empscore)>0 else 0
    
    #return match score for name, city, and occupation related fields
    return (score_name,score_city,score_occupation)
    
#function to identify what keywords match in each article 
def entity_stem_match(text, se, lang_idx):
    #stem keyword search terms(the words indicating criminality)
    searchstem = clean_paragraph(se.searchtermlist[lang_idx], se.search_lang[lang_idx], stemming=True, sent_tokenize=False)
    foundlist = list(map(lambda x: x in text, searchstem))
    matched_stem = [term for term,found in zip(se.searchtermlist[lang_idx],foundlist) if found==True]   
    return matched_stem
	
#estimate how risky an individual is relative to the total links scraped 
#intention: map the individuals searched so irrelevant individuals have normalized score of 0 , to someone super relevant > .77
#need to refit. 
def normalize_LSA(sum_score1, tot_links):
    lsa_sum = (sum_score1/tot_links)*100
    a = 0.342419512682912
    b = 1.19480978536808
    c = 0.211456297918287
    d = 0.779544742969885
    percent_risk = max(0,c + d*np.tanh((lsa_sum-a)/b))
    return(percent_risk*100)
    


# defining function to order webpages using LSA
#input: search entity object 
def LSA_function(se):
    def LSA_function_single(doc_cluster, stems): #docluster = se.textlist , stems= search terms to be compared 
        #Create a list, where first element contains list of all keywords to search,and all thereafter elements are the documents being searched 
        doc_list = [stems] + doc_cluster
        #split each element in the list(the documents) into lists of words (so now instead of a document in each element of the list, you have a list of words in each element of the list)
        texts = [document.split() for document in doc_list]
        #fit a dictonaary containing the textual values found in the documents(load id->word mapping (the dictionary),) 
        dictionary = corpora.Dictionary(texts)
        #transform the texts into a BOW representation (integer counts)
        corpus = [dictionary.doc2bow(text) for text in texts]
        ## create tfidf transformation object to convert vector from bag of words representation to tfidf (real valued weighs)
        ##Note: the tf-idf will only contain words associated with the sentences directly tied to the individuals name 
        logent = models.TfidfModel(corpus)

        #apply tfidf model to corpus 
        corpus_logent = logent[corpus]
        ## Using log entropy conversion for corpus
    #    logent = models.LogEntropyModel(corpus)
    #    corpus_logent = logent[corpus]
        ## To use tf-idf, uncomment that and comment the log entropy one (ignore the naming)
        #create latent samantix indexing(lsi) model that has the total number of topics = total number of articles so the model explains 100% variance
        #implements fast truncated SVD (Singular Value Decomposition). The SVD decomposition can be updated with new observations at any time, for an online, incremental, memory-efficient training.
        #zjc edit(5/18/18): force algo to execute stochastically, instead of assuming the first pass is the optimal solution (onepass=False)
        lsi = models.LsiModel(corpus_logent, id2word=dictionary, num_topics=len(texts), onepass=False)
        #eigen vectors associated with LSI
        S = lsi.projection.s
        #total variance 
        variance = S*S
        #percent total variance explained by each eigenvector(i.e. topic)
        percent_variance = variance/variance.sum()
        ## Setting the threshold high, since we have low number of links
        thresh = 0.95
        k=0
        dims_assign_check = 0

        #iterate through each eigenvector until the total %variance explained is 95
        #once 95% of variance explained, the total number of dims required to reach this is assigned to dims
        for i in range(0,len(percent_variance)):
            if k >= thresh:
                dims = i
                dims_assign_check = 1
                break
            else:
                k += percent_variance[i]
        if dims_assign_check == 0:
            dims=len(texts)
        #refit the model using the lower number of dimensions from the original solution required to explain 95% of total variation 
        lsi_reduced = models.LsiModel(corpus_logent, id2word=dictionary, num_topics=dims)
        #return the corpus(vectorize input copus in BoW format)
        corpus_lsi_reduced = lsi_reduced[corpus_logent]
        #mapp all the stems into a dictonary 
        vec_bow = dictionary.doc2bow(stems.split())
        #apply new lsi model to the list of documents as well as the search terms 
        vec_lsi = lsi_reduced[vec_bow]
        #create a document similarity matrix (to compare to the search terms)
        #Compute cosine similarity against a corpus of documents by storing the index matrix in memory.
        index = similarities.MatrixSimilarity(corpus_lsi_reduced)
        #rank the doc similarity matrix to have the most relevant docs at the top 
        sims = (index[vec_lsi]).tolist()
        #remove the first element in the sims list becuase it is comparing the similarity of search word to itself (the max should always be like 1)
        doc_score = sims[1:len(sims)]
        return doc_score

    #for each languge if the ersults are not blank, extract the post processed text, and clean the search terms , and join them into one string
    for idx in range(0,se.search_lang_ct):
        if not se.urllist[idx] == []:
            doc_cluster = se.textlist[idx]
            #key words (list of keywords joined together by spaces, and compare the total string of key alert 
            #terms to the articles, to identify which articles are most similar to the lsit of search tersm)
            stems = ' '.join(clean_paragraph(se.searchtermlist[idx], se.search_lang_short[idx], stemming=True, sent_tokenize=False))
            se.LSA_score[idx] = LSA_function_single(doc_cluster, stems)
    return se
    
    
def rerank_searchresults(se, LSA_filter):
    #for each languge the search results were compiled for 
    for idx in range(0, se.search_lang_ct):
		#if the urllist is not blank
        if not se.urllist[idx] == []:
		    #first element in each list is associated with the first article returned , then the second, etc....
            #lsa score indicates how relevant the artile is to crime 
            whole_list = list(zip(se.urllist[idx],se.LSA_score[idx],se.list_fuzzyscore[idx],se.list_matchedstems[idx],se.list_fuzzyscoredetail[idx], se.textlist[idx]))
            #sort the list of lists (whole_list) by the values in the second list (LSA SCORE)
			sorted_list = sorted(whole_list, key = operator.itemgetter(1), reverse = True)
            transposed_sorted = list(zip(*sorted_list))
			#filter out articles that do not meet a certain LSA critera 
            LSA_filter_count = len([x for x in transposed_sorted[1] if x >= LSA_filter])
			#append total number of articles significant for the individual (search entity)
            se.LSA_filter_count[idx] = LSA_filter_count
			
            ## Extract the links and scores from the transposed_sorted which are the list of results sorted by LSA score 
            if LSA_filter_count > 0:
                se.urllist[idx] = transposed_sorted[0][0:LSA_filter_count]
                se.LSA_score[idx] = transposed_sorted[1][0:LSA_filter_count]
                se.list_fuzzyscore[idx] = transposed_sorted[2][0:LSA_filter_count]
                se.list_matchedstems[idx] = transposed_sorted[3][0:LSA_filter_count]
                se.list_fuzzyscoredetail[idx] = transposed_sorted[4][0:LSA_filter_count]
                se.textlist[idx] = transposed_sorted[5][0:LSA_filter_count]
			#if LSA_filter_count == 0 then there are no results that are signifiant and append blanks
            else:
                se.urllist[idx] = []
                se.LSA_score[idx] = []
                se.list_fuzzyscore[idx] = []
                se.list_matchedstems[idx] =[]
                se.list_fuzzyscoredetail[idx] = []
                se.textlist[idx] = []
    return se
    
## Sum the scores
def summary_scores(se, searchcounts):
    for idx in range(0, se.search_lang_ct):
        if not se.urllist[idx] == []:
            sum_LSA_score = sum(se.LSA_score[idx])
            se.riskscore_final[idx] = normalize_LSA(sum_LSA_score,len(se.textlist[idx]))
            se.name_fuzzy_all[idx] = str(int(round(np.mean([x[0] for x in se.list_fuzzyscoredetail[idx]]),0)))
            se.location_fuzzy_all[idx] = str(int(round(np.mean([x[1] for x in se.list_fuzzyscoredetail[idx]]),0))) if se.location_provided() else 'N/A - Location not provided'
            se.employment_fuzzy_all[idx] = str(int(round(np.mean([x[2] for x in se.list_fuzzyscoredetail[idx]]),0))) if se.employment_provided() else 'N/A - Employment not provided'
    return se
    
