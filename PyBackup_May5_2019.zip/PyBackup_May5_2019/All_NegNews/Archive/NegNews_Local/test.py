from subprocess import call
call(["python","main_single_flask.py"])

print('test complete')
