# -*- coding: utf-8 -*-
"""
Created on Fri Dec  7 09:28:24 2018

@author: caridza
"""
import pickle
import pandas as pd
import numpy as np
df=pd.read_pickle("C:/Users/caridza/Desktop/EY/AI/COE/AA COE/NegNews/Data/results_df.pickle")


People=list(df.groupby(['Person']).groups.keys())
EntriesPerPerson ={i:len(df.groupby(['Person']).groups[i]) for i in People}
print('ddata frame columns {}'.format(' , '.join(list(df))),'\n','\n'.join(['{}:{}'.format(item[0],item[1]) for item in EntriesPerPerson.items()]))
#summary stats by group across col (produces data.series)
#df.describe()
#df.groupby('entity')['entity'].count()
#df.groupby('entity')['date'].count()
#df.groupby('entity')['jobname'].count()

#summary of average sentiment per person data from source=bing 
#df[df['source'] == 'bing'].groupby('entity')['jobname']

#average similarity , sentiment, and Docscore per source for each person
#note:if you calculate more than one column of results, your result will 
#be a Dataframe. For a single column of results, the agg function, by default, will produce a Series.
stats = df.groupby(['Person','Doc'])['Similarity','Sentiment','FinalDocScore'].mean()
stats=stats.reset_index()
#df.groupby('Person', as_index=False).agg({"Similarity": "mean"})
#df['FinalEntityScore'].unique()
list(stats)


print(pd.Series(stats['Similarity']).agg('max') 
,pd.Series(stats['Similarity']).agg('min') 
,pd.Series(stats['Similarity']).quantile(q=.97)
,pd.Series(stats['Similarity']).quantile(q=.01)
,pd.Series(stats['Similarity']).quantile(q=.1)
     )



stats.pivot_table(columns='Similarity',  aggfunc=np.mean).sort_values(by = 'Similarity',ascending=False)
   
#plotting distributions 
list(stats)