import sys
from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine
import pandas as pd

Base = declarative_base()

def alertLookBack(df):
    df['review_start_dt'] =  df['alert_created_date'] - pd.to_timedelta(60, unit='d' )
    return df


#Rolling up the table on alert and account
def alertAccountPartyRollup(df):
    _df1 = df.groupby(['alert_key','account_number', 'alert_created_date', 'rule_id','rule_name','party_address', 'party_key', 'party_name','email', 'phone','is_single_joint','acct_type_cd','alert_name','review_start_dt','prior_sars','case_number','loan_completed_date','loan_amount','signor','alert_negative_news_score','ars_score','variable1','variable2','variable3','alert_type'])['account_number'].nunique().reset_index(name='n_acct')
    _df2 = df.groupby(['alert_key','account_number', 'alert_created_date', 'rule_id','rule_name','party_address', 'party_key', 'party_name','email', 'phone','is_single_joint','acct_type_cd','alert_name','review_start_dt','prior_sars','case_number','loan_completed_date','loan_amount','signor','alert_negative_news_score','ars_score','variable1','variable2','variable3','alert_type'])['tran_cd_desc'].nunique().reset_index(name='n_channels')
    _df3 = df.groupby(['alert_key','account_number', 'alert_created_date', 'rule_id','rule_name','party_address', 'party_key', 'party_name','email', 'phone','is_single_joint','acct_type_cd','alert_name','review_start_dt','prior_sars','case_number','loan_completed_date','loan_amount','signor','alert_negative_news_score','ars_score','variable1','variable2','variable3','alert_type'])['tran_key'].count().reset_index(name='n_tran')
    _df4 = df.groupby(['alert_key','account_number', 'alert_created_date', 'rule_id','rule_name','party_address', 'party_key', 'party_name','email', 'phone','is_single_joint','acct_type_cd','alert_name','review_start_dt','prior_sars','case_number','loan_completed_date','loan_amount','signor','alert_negative_news_score','ars_score','variable1','variable2','variable3','alert_type'])['tran_amt'].sum().reset_index(name='sum_tran_amt')
    _df = pd.concat([_df1, _df2, _df3, _df4], axis=1, join='inner')
    _df = _df.loc[:,~_df.columns.duplicated()]
    return _df




#Function to get information about the single or joined account
def is_single_joint(df):
    df['is_single_joint.string'] = df['is_single_joint'].apply(
        lambda x: "This account do not have any indication regarding sole or joined account." if (pd.notnull(x[0]))
        else (
        " Account owner is the sole owner and authorized signer for the account. " if x == 1
        else " This account has other authorized owner(s). "))
    return df


#Transaction Summary on Alert id and alert date
def transactionSummary(df, alert_id, alert_dt):
    _df1 = df.groupby(['alert_key', 'alert_created_date','account_number','credit_debit_indicator','tran_channel'])['tran_amt'].sum().reset_index(name='sum_tran_amt')
    _df2 = df.groupby(['alert_key', 'alert_created_date','account_number','credit_debit_indicator','tran_channel'])['tran_key'].count().reset_index(name='n_tran')
    _df = pd.concat([_df1, _df2], axis=1, join='inner')
    _df = _df.loc[:,~_df.columns.duplicated()]
    return _df


#Summarizing the credit and debit transaction
def tranSummaryCD(df,creditOrDebit):
    df = df[df['credit_debit_indicator'] == creditOrDebit]
    # check df is empty or not and return accordingly
    return df



def narrativeSummary(args_dict):
    if args_dict['ars_score'] == 0:
        return( "Summary " + '\n' + "Bank ABC's Financial Intelligence Unit received alert #" + str(args_dict['alert_id'])  + " for the account #" +  str(args_dict['acct_num']) + \
     " on " + str(args_dict['alert_dt']) + " as a result of account activity wherein the client conducted '" + args_dict['rule_name'] +"'. " + "No prior SARs were identified regarding the account." + "\n \n")
    else:
        return("Summary " + '\n' + "Bank ABC's Financial Intelligence Unit received alert #" + str(args_dict['alert_id'])  + " for the account #" +  str(args_dict['acct_num']) + \
     " on " + str(args_dict['alert_dt']) + " as a result of account activity wherein the client conducted '" + args_dict['rule_name'] +"'. " + "The alert was rated high risk of " + str(args_dict['ars_score']) + " by the scoring model with the top 3 reasons contributing to the high score being reason "+ str(args_dict['variable1'])+", " + str(args_dict['variable2']) +", " + str(args_dict['variable3']) + ". There was a prior SAR filed for this account for '"+ str(args_dict['alert_name']) + "'. There was a prior case #" + str(args_dict['case_number']) + " and DCNs associated with it. " + "\n \n")


def creditTransac(df):
    result = ''
    for index, row in df.iterrows():
        a = str(row['n_tran']) + " outgoing transaction(s) from '" + row['tran_channel'] + "' with total amount of $" + str(
            row['sum_tran_amt'])
        b = str(a)
        result = result + ", " + b
    return result

# To check if there is any credit history
def ifcredit(args_dict):
    if args_dict['total_tran_credit'] == 0:
        return("No credit history was found for account #" + str(args_dict['acct_num'])+ "\n \n" )
    else:
        return detailsOfInve3(args_dict)


#To check if there is any debit history
def ifdebit(args_dict):
    if args_dict['total_tran_debit'] == 0:
        return ("No debit history was found for  #" + str(args_dict['acct_num'])+ "\n \n" )
    else:
        return detailsOfInve4(args_dict)

#Creating the 1st para for Details of Investigation
def detailsOfInve1(args_dict):
    if args_dict['account_desc'] == 'loan':
        return("Details of Investigation"  + '\n' + "Account #" + str(args_dict['acct_num']) +" is a " +args_dict['account_desc'] + " account opened on " + str(args_dict['acct_open_dt']) +  " by " +\
                     args_dict['party_name'] + ". " + args_dict['is_single_joint'] + " Loan amount $" + str(args_dict['loan_amount'])+ " was closed on " +str(args_dict['loan_completed_date'])+\
            " and the signor of the loan was "+ args_dict['signor'] +"."+ '\n' '' + '\n')
    else:
        return("Details of Investigation"  + '\n' + "Account #" + str(args_dict['acct_num']) +" is a " +args_dict['account_desc'] + " account opened on " + str(args_dict['acct_open_dt']) +  " by " \
        + args_dict['party_name'] + ". " + args_dict['is_single_joint']+ '\n' '' + '\n')


def detailsOfInve2(args_dict):
    detailsOfInve2 =  args_dict['party_name'] + " resides at " + args_dict['party_address'] + ". Internal Bank record list email address as " + \
                     args_dict['party_email'] +" and phone number is " + args_dict['party_phone'] +". An internet negative news search for the customer returned a negative news score of " + str(args_dict['alert_negative_news_score']) + ". " \
              + "An attachment of the negative news results can be found in attachment A. "  + '\n' '' + '\n'
    return detailsOfInve2

#Creating the Details of Investgation on the credit information
def detailsOfInve3(args_dict):
    detailsOfInve3 = "A transactional review was conducted of the alerted account. Credit activity during the review period totaled $" + str(args_dict['total_amt_credit']) + \
                     " consisting of " + str(args_dict['total_tran_credit']) + " transactions from " + str(args_dict['total_channel_count_credit']) +\
                     " channels" + str(creditTransac(args_dict['tran_c'])) +"."+ '\n' + '' + '\n'
    return detailsOfInve3


#Creating the Details of Investgation on the debit information
def detailsOfInve4(args_dict):
    detailsOfInve4 = "Debit activity during the review period totaled $" + str(args_dict['total_amt_debit']) + " consisting of " + str(args_dict['total_tran_debit'])\
    + " transactions from " + str(args_dict['total_channel_count_debit']) + " channels" + str(creditTransac(args_dict['tran_d']))+"."+ '\n' '' + '\n'
    return detailsOfInve4


#Creating the conclusion of the narrative
def conclusion(args_dict):
    if args_dict['ars_score'] == 0 and args_dict['alert_type'] == "Transfer to/From High Risk Country":
        return("TIAA’s Financial Intelligence Unit identified that the alerted wire transaction was a domestic wire, and did not involve a high risk country. As such, no further action is necessary.")
    if args_dict['ars_score'] == 0 and args_dict['alert_type'] == "Internal Transfers" :
        return("TIAA’s Financial Intelligence Unit identified that the alerted activity consisted of an internal transfer or transfers either received from or remitted to a related internal TIAA account or accounts. No external funds were received or remitted to or from TIAA. The reviewed activity does not pose an AML risk. As such, no further action is necessary.")
    if args_dict['ars_score'] == 0 and args_dict['alert_type'] == "Payroll Direct Deposit":
        return("TIAA’s Financial Intelligence Unit identified that the alerted activity consisted entirely of a payroll direct deposit. The reviewed activity does not pose an AML risk. As such, no further action is necessary.")
    if args_dict['ars_score'] == 0 and args_dict['alert_type'] == "Employee Contributions From Payroll to Employer Sponsored Retirement Plans":
        return("TIAA’s Financial Intelligence Unit identified the alerted transactions consisted of employee contributions directly from their payroll to their employer sponsored retirement plans. The reviewed activity does not pose any AML risk; therefore, no further action is necessary.")
    if args_dict['ars_score'] == 0 and args_dict['alert_type'] == "Periodic Scheduled Distributions":
        return("The alerted activity is consistent with the expected activity of a check account. A SAR filing is not warranted at this time due to lack of negative news regarding this customer. The source of fund is legitimate, and the alerted activity is consistent with expected activity of this account type. The account will continue to be monitored via Actimize.")
    if args_dict['ars_score'] == 0 and args_dict['alert_type'] == "Omni Loan Payments":
        return("TIAA’s Financial Intelligence Unit identified that the alerted account consisted of a TIAA loan that has gone into default. The alerted activity represents the movement of assets from the participant’s retirement plan into a separate account where the funds are non-distributable and will be held until the participant reaches a triggering event such as termination of employment or reaching 59 ½; therefore, the reviewed activity does not pose an AML risk. As such, no further action is necessary.")
    if args_dict['ars_score'] == 0 and args_dict['alert_type'] == "1035 Exchange":
        return("TIAA’s Financial Intelligence Unit identified that the alerted activity consisted of entirely of a 1035 exchange which consisted of a direct transfer from an external life insurance or annuity policy owned by the customer. A 1035 exchange is a provision in the tax code which allows you, as a policyholder, to transfer funds from a life insurance, endowment or annuity to a new policy, without having to pay taxes. The reviewed activity does not pose an AML risk. As such, no further action is necessary.")
    if args_dict['ars_score'] == 0 and args_dict['alert_type'] == "Term Life":
        return("This is a Term Life account. Per http://www.naic.org/documents/committees-_d_antifraud_meetingcc_faqsinsurance_103105.pdf, term insurance products are not considered to be covered and do not have any AML suspicious activity requirements.")
    if args_dict['ars_score'] == 0 and args_dict['alert_type'] == "OMNI-Periodically Scheduled Minimum Distributions":
        return("TIAA’s Financial Intelligence Unit identified that the alerted activity consisted of periodically scheduled MDO’s. The MDO calculates and pays the participant their required minimum federal distribution amounts from their retirement accounts. The source of funds for the distributions is not in question, and the payments do not pose any AML risk. Therefore, not further action is necessary.")
    if args_dict['ars_score'] == 0 and args_dict['alert_type'] == "403(b)":
        return("TIAA’s Financial Intelligence Unit identified the alerted transactions consisted entirely of after tax distributions from the client’s 403b plan which is a retirement plan solely for employees of public schools, tax-exempt organizations, and certain ministries. Contributions can only be made through a salary reduction agreement by the employer and employee through payroll. The source of funds for these types of alerts does not pose any AML Risk. Therefore, no further action is necessary.")
    else:
        return("Conclusion"  + '\n' + "ABC Bank's Financial Intelligence Unit is recommending alert_id #" + str(args_dict['alert_id'])  +"  be escalated for further review, which represents the '" 
            + str(args_dict['rule_name']) + "' in the amount of $" + str(args_dict['sum_tran_amt'])+" in both incoming and outgoing activity for the period " \
                   + str(args_dict['review_start_dt']) + " through " +str(args_dict['alert_dt']) +\
                  "The manner in which the '" + args_dict['rule_name'] +"' were conducted gives the appearance of structuring. The supporting documentation will be retained in the case file and is available upon request.")
    