from flask import Flask
from flask import request
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy import text
import database_setup
from database_setup import Base
import os
import pandas as pd

app = Flask(__name__)
#app.config["SERVER_NAME"] = "sentinel.eastus.cloudapp.azure.com"
#app.config["APPLICATION_ROOT"] = os.environ.get('SERVER_CONTEXT_PATH','/')
APPLICATION_ROOT = os.environ.get('SERVER_CONTEXT_PATH','/')

@app.route(APPLICATION_ROOT)
@app.route(APPLICATION_ROOT + 'narrativeGenEscalated')
def NarrativeGenEscalated():
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    #Creating a connections with SQL Server
    connection_string = 'mssql+pyodbc://sqladmin:FinCrimeDEV2017$@adcfincrimeops.database.windows.net:1433/adc-ci?driver=ODBC+Driver+17+for+SQL+Server'
    engine = create_engine(connection_string)
    Base.metadata.bind = engine
    DBSession = sessionmaker(bind = engine)
    session = DBSession()

    #Loading the data from SQL Server table to a dataframe and parsing the date to date format
    #df = pd.read_sql("SELECT * FROM ng_modeling_dataset", con=engine,parse_dates=['alert_created_date'])
    df = pd.read_sql("SELECT * FROM ng_modeling_dataset where alert_created_date between '"+start_date+"' AND '"+end_date+"'",con=engine,parse_dates=['alert_created_date'])

    #df = pd.read_excel('C:/Users/ep486mz/Documents/Projects/TIAA/NarrativeGen/NG_escalated/ng_data_test.xlsx')

    _file = database_setup.alertLookBack(df)

    base_df = database_setup.alertAccountPartyRollup(_file)

    base_df = database_setup.is_single_joint(base_df)
    table_dict = {}
    cols = ['alert_id','ng_file_name','alert_date','party_name','ng_status']
    lst = []

    df_new = pd.DataFrame(columns=cols)

    for i in range(0, len(base_df)):
        tsumm = pd.DataFrame()
        args_dict = {}
        args_dict['alert_id'] = base_df.iloc[i]['alert_key']
        args_dict['account_desc'] = base_df.iloc[i]['acct_type_cd'].lower()
        args_dict['acct_num'] = base_df.iloc[i]['account_number']
        args_dict['party_name'] = base_df.iloc[i]['party_name']
        args_dict['alert_dt'] = base_df.iloc[i]['alert_created_date']
        args_dict['rule_id'] = base_df.iloc[i]['rule_id']
        args_dict['rule_name'] = base_df.iloc[i]['rule_name']
        args_dict['review_start_dt'] = base_df.iloc[i]['review_start_dt']
        args_dict['review_end_dt'] = args_dict['alert_dt']
        args_dict['acct_open_dt'] = base_df.iloc[i]['alert_created_date']
        args_dict['party_address'] = base_df.iloc[i]['party_address']
        args_dict['party_email'] = base_df.iloc[i]['email']
        args_dict['party_phone'] = base_df.iloc[i]['phone']
        #args_dict['prior_sars'] = base_df.iloc[i]['prior_sars.string']
        args_dict['is_single_joint'] = base_df.iloc[i]['is_single_joint.string']
        args_dict['loan_completed_date'] = base_df.iloc[i]['loan_completed_date']
        args_dict['signor'] = base_df.iloc[i]['signor']
        args_dict['loan_amount'] = base_df.iloc[i]['loan_amount']
        args_dict['sum_tran_amt'] = base_df.iloc[i]['sum_tran_amt']
        args_dict['alert_negative_news_score'] = base_df.iloc[i]['alert_negative_news_score']
        args_dict['alert_name'] = base_df.iloc[i]['alert_name']
        args_dict['ars_score'] = base_df.iloc[i]['ars_score']
        args_dict['variable1'] = base_df.iloc[i]['variable1']
        args_dict['variable2'] = base_df.iloc[i]['variable2']
        args_dict['variable3'] = base_df.iloc[i]['variable3']
        args_dict['case_number'] = base_df.iloc[i]['case_number']
        args_dict['alert_type'] = base_df.iloc[i]['alert_type']
        args_dict['ng_status'] = "Completed"

        # print(i,alert_id)
        df_filter_for_alert_id = _file[_file.alert_key == args_dict['alert_id']]
        tsumm = database_setup.transactionSummary(df_filter_for_alert_id, args_dict['alert_id'], args_dict['acct_open_dt'])

        tran_c = database_setup.tranSummaryCD(tsumm, 'credit')
        args_dict['tran_c'] = tran_c
        tran_d = database_setup.tranSummaryCD(tsumm, 'debit')
        args_dict['tran_d'] = tran_d
        tran_loan = database_setup.tranSummaryCD(tsumm, 'loan')
        args_dict['total_amt_credit'] = tran_c['sum_tran_amt'].sum()
        args_dict['total_tran_credit'] = tran_c['n_tran'].sum()

        args_dict['total_channel_count_credit'] = tran_c['n_tran'].count()
        args_dict['total_amt_debit'] = tran_d['sum_tran_amt'].sum()
        args_dict['total_tran_debit'] = tran_d['n_tran'].sum()
        args_dict['total_channel_count_debit'] = tran_d['n_tran'].count()

        output = database_setup.narrativeSummary(args_dict) + database_setup.detailsOfInve1(args_dict)+ database_setup.detailsOfInve2(args_dict) + database_setup.ifcredit(args_dict) + database_setup.ifdebit(args_dict) + database_setup.conclusion(args_dict)

        file_name_test = "narrative_" + str(args_dict['alert_id']) + "_" + (str(args_dict['alert_dt']))[:10] + ".txt"
        file = open("/data/ci/files/"+file_name_test, "w")
        file.write(output)
        file.close()
        print("Narrative has been generated for " + str(args_dict['alert_id']))
        lst.append([args_dict['alert_id'],file_name_test,args_dict['alert_dt'],args_dict['party_name'],args_dict['ng_status']])
    
    df_new = pd.DataFrame(lst, columns=cols)
    # print("File output table is :" + '\n' '' )
    # print(df_new)
    df_new.to_sql(name='narrativeGenOutput',con=engine, if_exists='append',index=False)

    return "Success"

if __name__ == '__main__':
    app.debug = True
    app.run(debug=True, host='0.0.0.0')
    #
