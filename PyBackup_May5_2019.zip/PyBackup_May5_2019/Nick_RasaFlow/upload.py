# -*- coding: utf-8 -*-
"""
Created on Mon Apr 30 10:07:49 2018
#goal : use pyinstaller to generate windowns executable to run file 
@author: JK927DH
"""
import paramiko 
import os

dir_path = 'C:\\Users\\caridza\\Desktop\\pythonScripts\\Nick_RasaFlow'


#dir_path = os.path.dirname(os.path.realpath('C:\\Users\\caridza\\Desktop\\pythonScripts\\Nick_RasaFlow'))

#connect to AA VM Server
s = paramiko.SSHClient()
s.set_missing_host_key_policy(paramiko.AutoAddPolicy())
s.connect("10.246.59.58",22,username='docadmin',password='ItW!llB3Great77',timeout=10)

#Upload file to server 
print("Uploading")
sftp = s.open_sftp()

#copy file from local driver to server 
sftp.put('%s\\Upload_Files\\Searchable_BB5087_2.pdf' %(dir_path), '/home/docadmin/NickBrennan/InputFiles/Searchable_BB5087_2.pdf')

#run OCR_Demo script on server using the file we just uploaded to the server 
print("Invoking Shell Command")
s.invoke_shell()

#call python in ssh by specifying locaiton of binary , then run the OCR_DEMO.py (which pulls from the folder:  '/home/docadmin/NickBrennan/InputFiles/Searchable_BB5087_2.pdf')
stdin, stdout, stderr = s.exec_command('/usr/bin/python /home/docadmin/NickBrennan/OCR_Demo.py')
exit_status = stdout.channel.recv_exit_status()          # Blocking call
if exit_status == 0:
    print ("Completed! Downloading File Now...")
else:
    print("Error", exit_status)
sftp.get('/home/docadmin/NickBrennan/Output.csv', '%s\\Output.csv' %(dir_path))
s.invoke_shell()
stdin, stdout, stderr = s.exec_command('rm /home/docadmin/NickBrennan/Output.csv')
exit_status = stdout.channel.recv_exit_status()          # Blocking call
if exit_status == 0:
    print ("Completed! Downloading File Now...")
else:
    print("Error", exit_status)
s.close()
