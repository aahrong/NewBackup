# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import os , errno
from os import mkdir


def makedir(directory):      
    try:
        os.makedirs(directory)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise

def makedirwrap(dirlist):    
    [makedir(dir) for dir in dirlist]



if __name__ == '__main__':

    dirlist=["C:/Users/caridza/Desktop/pythonScripts/test"
    ,"C:/Users/caridza/Desktop/pythonScripts/test/subtest"
    ,"C:/Users/caridza/Desktop/pythonScripts/test/subtest/subsubtest"]
    
    makedirwrap(dirlist)