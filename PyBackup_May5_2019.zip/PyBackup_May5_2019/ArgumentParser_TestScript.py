# -*- coding: utf-8 -*-
"""
Created on Fri Jul 21 12:19:36 2017

@author: caridza
"""

import sys
import time
import urllib
import tempfile
import os
import shutil
import zipfile
import argparse #module used to write user freindly command line interfaces

#create parsing object 
parser = argparse.ArgumentParser(description = 'Download tools for the Freddie Mac Single-Family dataset')

#Parser to direct where on local dir to store the data
#add argument purpose:used to specify which command-line options the program is willing to accept
parser.add_argument('--dir_local'        #command line call to execute 
                    , dest = 'dir_local' #destination to direct --dir_local to 
                    , action = 'store'   #action to perform (store data)
                    , help = 'Path to store the dataset locally'
                    )

#add argument to parser to direct where on the HDFS to store the data 
parser.add_argument('--dir_hdfs', dest = 'dir_hdfs', action='store', help = 'Path to store the dataset on HDFS')

#parse the arguments 
args = parser.parse_args()
