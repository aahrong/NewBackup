# -*- coding: utf-8 -*-
"""
Created on Thu Feb 14 11:06:56 2019
COMET ML
#https://www.comet.ml/zjc1002/quickstart
@author: caridza
"""
from pypac import pac_context_for_url
import ssl

context = ssl._create_unverified_context()
with pac_context_for_url('https://www.google.com'):
        
    import comet_ml
    from comet_ml import Experiment
    import os
    
    # Add the following code anywhere in your machine learning file
    exp = Experiment(api_key="PJJk299wTzoIVqTqXW5LwkNR8",
                            project_name="general",
                            workspace="zjc1002",
                            log_graph = True,
                            )
    
    #import non ml data science modules
    import keras 
    import sys 
    import nltk
    import matplotlib
    import pandas as pd 
    from nltk.corpus import stopwords
    from nltk.stem.snowball import SnowballStemmer
    from nltk.stem import WordNetLemmatizer
    from nltk import word_tokenize
    import sklearn
    from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer,TfidfTransformer
    import keras
    import string
    import numpy as np
    from negative_news2.consumer.utils import replace_words,remove_punctuation,remove_stop,stem_words,remove_nonchars
    
    
    #clean original text to be used in generation of tfidf and other text transformation objects
    def orig_text_clean(data,target='',txtfeild='origtext',stopwords=['the','is','a','i','are','it'],stemmer=None):
        print(list(data))
        trainDF = pd.DataFrame()
        trainDF['text'] = data[txtfeild].apply(lambda x: remove_punctuation(x))
        trainDF['text'] = trainDF['text'].apply(lambda x: remove_nonchars(x))
        trainDF['text'] = trainDF['text'].apply(lambda x: remove_stop(x,stopwords=stopwords))
        
        if stemmer!=None:
            trainDF[txtfeild] = trainDF['text'].apply(lambda x: stem_words(x,stemmer=stemmer))
        else:
            trainDF[txtfeild] = trainDF['text']
            
        if target!='':
            trainDF['label'] = data[target]
            le = sklearn.preprocessing.LabelEncoder() 
            le.fit(trainDF['label'])
            trainDF['label_id'] =le.transform(trainDF['label'])
        else:
            trainDF['DocIndex']=data['DocIndex']
        
        trainDF.drop(['text'],axis=1,inplace=True)
        
        trainDF=trainDF.reset_index(drop=True)
        return trainDF 
    
    
    #punctuation to remove, stopwords to remove, stemming and lemmatizing objects for preprocessing
    stemmer = SnowballStemmer('english')
    wordnet_lemmatizer = WordNetLemmatizer()
    exclude = set(string.punctuation)
    stopwords = stopwords.words('english')
    newStopWords = ['.','?','%','Google','Wells Fargo','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December']
    stopwords.extend(newStopWords)
    stop_list=set(stopwords)
    
    #data 
    datapath = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/SentDF.pickle"
    data = pd.read_pickle(datapath)
    data.drop(columns=['date'])
    
    #define target , clean text, and split data into test and train
    target = "MandA"
    Data = orig_text_clean(data,target=target , txtfeild='Sentence' , stopwords=stop_list,stemmer=stemmer)
    train_x,valid_x,train_y,valid_y= sklearn.model_selection.train_test_split(Data['Sentence'],Data['label_id'],shuffle=True, stratify=Data['label_id'],test_size=.3, random_state=10)
    
    
    #model parameters 
    vocab_size = 10000
    units = 50
    batch_size = 200
    epochs = 50
    
    #params for experiment ml_comet 
    params = {
            "layer1_units":units ,
            "vocab_size": vocab_size, 
            "epochs": epochs,
            "batch_size":batch_size,
            }
    
    
    #vectorized matrix of tfidf weights for input as independent variables 
    #fit tfidf on trianing data and transform the tfidf on the test data 
    vectorizer = TfidfVectorizer(analyzer='word', ngram_range=(1,1), max_features=vocab_size,min_df=2 ,stop_words='english', max_df=.1, smooth_idf=True, norm='l2',sublinear_tf=True,lowercase=True,)
    x_train_vec = vectorizer.fit_transform(train_x).toarray()
    x_test_vec = vectorizer.transform(valid_x).toarray()
    
    
    #define model 
    num_labels=1
    model = keras.models.Sequential() #0
    model.add(keras.layers.Dense(units, input_shape=(vocab_size,),kernel_regularizer=keras.regularizers.l2(.0001),activity_regularizer=keras.regularizers.l2(.0001)))
    model.add(keras.layers.GaussianDropout(0.9))
    model.add(keras.layers.Activation('selu'))
    model.add(keras.layers.Dense(num_labels)) #7
    model.add(keras.layers.Activation('sigmoid')) #8
    model.compile(loss='binary_crossentropy',optimizer='adam',metrics=['accuracy'])
    model.summary() #9
    
    #fit final model 
    early = keras.callbacks.EarlyStopping(monitor="val_loss", mode="min", patience=1)
    
    #will log metrics with prefix 'train_'
    with exp.train(): 
        final_out = model.fit(x_train_vec,train_y
                  , batch_size=batch_size,epochs=epochs,verbose=1,validation_data=(x_test_vec,valid_y)
                  , callbacks = [early]
                  , class_weight = {0:1,1:1},                       
                            )
        
    #will log metrics with prefix 'test_'
    with exp.test(): 
        loss, accuracy = model.evaluate(x_test_vec, valid_y)
        metrics = {
                'loss':loss,
                'accuracy':accuracy
            }
        exp.log_metrics(metrics)
    
    
    #log params to Comet.ml
    exp.log_parameters(params)
    exp.log_dataset_has(x_train_vec)