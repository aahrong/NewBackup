# -*- coding: utf-8 -*-
"""
Created on Thu Nov 29 09:18:24 2018

@author: caridza
"""

#multiprocess.pool() example: 
#pool() generates a series of workers to be ready to execute work 
#map() is used to map the function being executed to the pool of workers, handles the distribution and aggreagtion of information to and from workers in the pool

import os
from multiprocessing import Pool
import timeit

#test function to use to test functionality 
def f(x):
    return x*x



#example 1: execute a function using 3 pooled workers
#if __name__=="__main__":
#    #subprocess.Popen(['scrapyd'])
#    print('pool test active')    
#    
#    #generate pool of 5 workers
#    p = Pool(3)
#    
#    # have the 5 workers each execute the function over the values 1,2,3
#    print(p.map(f,[1,2,3]))
#    
#example 2: using with pool instead of expliciting defining an object to hold the pool 
#if __name__=="__main__":
#    #subprocess.Popen(['scrapyd'])
#    print('pool async testing')    
#    start = timeit.default_timer()
#    with Pool(processes=3) as pool:
#        pool.map(f,range(10000000))
#    stop = timeit.default_timer()
#    print('Time:{}'.format(stop-start))
#    
    
#example 3: using with pool instead of expliciting defining an object to hold the pool 
#if __name__=="__main__":
#    
#    #pooling process with no async process inlayed
#    print('pool async testing')    
#    start = timeit.default_timer()
#    with Pool(processes=3) as pool:
#        pool.map(f,range(10000000))
#    stop = timeit.default_timer()
#    print('Time:{}'.format(stop-start))
#
#    #pooling process with async process inlayed 
#    print('pool async testing')    
#    start = timeit.default_timer()
#    with Pool(processes=3) as pool:
#        pool.map(f,range(10000000))
#        
#        #async process
#        res = pool.apply_async(f, (20,))      # runs in *only* one process
#        print(res.get(timeout=1))             # prints "400"   
#        
#    stop = timeit.default_timer()
#    print('Time:{}'.format(stop-start))


#Example 4 launching multiple evaluations asyncronosilly 
if __name__=="__main__":
    #pooling process with no async process inlayed
    print('pool async testing')    
    start = timeit.default_timer()
    with Pool(processes=4) as pool:
        multiple_results = [pool.apply_async(os.getpid, ()) for i in range(4)]        
        print([res.get(timeout=1) for res in multiple_results])
     
    #EXITING THE WITH BLOCK HAS / WILL STOP THE POOL 
    print('pooling process stopped after existing with loop')
    stop = timeit.default_timer()
    print('Execution Time:{}'.format(stop-start))
    # evaluate "f(20)" asynchronously
      

        # evaluate "os.getpid()" asynchronously
        ##res = pool.apply_async(os.getpid, ()) # runs in *only* one process
        #print(res.get(timeout=1))             # prints the PID of that process

        # launching multiple evaluations asynchronously *may* use more processes
        #multiple_results = [pool.apply_async(os.getpid, ()) for i in range(4)]
        #print([res.get(timeout=1) for res in multiple_results])


    

    