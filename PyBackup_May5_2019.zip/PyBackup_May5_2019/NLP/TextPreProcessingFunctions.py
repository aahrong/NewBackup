#strip new line delimiters
def stripnewlines(textlist):
	Intermediate =[textlist[raw].encode('utf-8').decode('utf-8').strip() for raw in range(len(textlist))]
	Final = [el.replace('\n', ' ') for el in Intermediate]
	return Final

#replace abreviations
def AbrevReplace(textlist):
	replacer= RegexpReplacer()
	NewTrainList = []
	NewTrainList = [replacer.replace(doc) for doc in textlist]
	return NewTrainList

#delete repeating characters
def DeleteRepeatChars(textlist):
	replacer = RepeatReplacer()
	NewTrainList2=[]
	NewTrainList2 = [replacer.replace(doc.lower()) for doc in textlist]
	return NewTrainList2


#lemmitize and word tokenize
def LemonandWordToken(textlist):
	#word tokenize
	tokenized_docs=[word_tokenize(doc.lower().encode('utf-8').decode('utf-8')) for doc in textlist]

	#lemmentize words
	lemmatizer = WordNetLemmatizer()
	lemma_list_of_words = []
	for i in range(0, len(tokenized_docs)):
	    l1 = tokenized_docs[i]
	    l2 = ' '.join([lemmatizer.lemmatize(word) for word in l1])
	    lemma_list_of_words.append(l2)
	    
	#word tokenize again
	tokenized_docs2=[word_tokenize(doc.lower().encode('utf-8').decode('utf-8')) for doc in lemma_list_of_words]

	return tokenized_docs2

#Remove Punctuation 
def RemovePunctuation(textlist):
	x=re.compile('[%s]' % re.escape(string.punctuation))

	tokenized_docs_no_punctuation = []
	for review in textlist:
	    new_review = []
	    for token in review: 
	        new_token = x.sub(u'', token)
	        if not new_token == u'':
	            new_review.append(new_token)
	    tokenized_docs_no_punctuation.append(new_review)
	return tokenized_docs_no_punctuation

#Remove English Stopwords
def RemoveStopWords(textlist): 
	## Extend Default list of stopwords 
	full_stop_words = ENGLISH_STOP_WORDS.union(["hi", "thanks", "i","wa","a","to"])

	newtexts = []
	for doc in textlist:
	    doc = [word.encode('utf-8') for word in doc if word not in full_stop_words]
	    newtexts.append(doc)
	return newtexts

#Catchall Preprocess check 
def TextPreProcessCleanup(textlist):
	import texttk
	from gensim import corpora

	tp = texttk.TextPreprocesser(decode_error='strict'
	                             , strip_accents='unicode'
	                             #, ignore_list=[]
	                             , lowercase=True
	                             , remove_html=True
	                             , join_urls=True
	                             , use_bigrams=True
	                             , use_ner=False
	                             #, stanford_ner_path="<path_here>"
	                             , use_lemmatizer=False
	                             , max_df=0.8
	                             , min_df=3
	                            # , max_features=None
	                            )

	corpdf = [unicode(newtexts[raw]) for raw in range(len(textlist))]
	COrpus = tp.preprocess_corpus(corpdf)
	                              
	#WORD TOKENIZE AGAIN FOR FINAL TIME
	Corpus=[word_tokenize(doc.lower().encode('utf-8')) for doc in COrpus]


	#create td of corpus, where every unique term is assigned an index 
	dictionary = corpora.Dictionary(Corpus)

	#convert list of docs into tdm using dictonary from above 
	corpus = [dictionary.doc2bow(doc) for doc in Corpus]

	#original corpus dimensions 
	#print(map(len,corpus))

	return corpus #Corpus if you want the simple tokenized list of strings


##FILTER OUT LOW INFORMATION WORDS 
def filterCommonWords(BOWCoprus,low_value_thresh = .02):
	from gensim.models import TfidfModel
	from gensim import models
	#filter out common words 
	#save copy of original corpus 
	CORPUS = list(BOWCoprus)

	#create td-idf model object using dictonary
	tfidf = models.TfidfModel(CORPUS, id2word = dictionary)

	#filter low value words
	low_value = low_value_thresh

	for i in range(0, len(CORPUS)):
	    bow = corpus[i]
	    low_value_words = [] #reinitialize to be safe. You can skip this.
	    low_value_words = [id for id, value in tfidf[bow] if value < low_value]
	    new_bow = [b for b in bow if b[0] not in low_value_words]

	    #reassign        
	    CORPUS[i] = new_bow
	    
	#length of each new corpus with stop words removed 
	Original = np.array(map(len,corpus)) 
	NoStopWrds = np.array(map(len,CORPUS))

	#difference in original string vs scrubbed string
	diff = Original-NoStopWrds
	print("No Stop Words Found in:", len(diff[diff==0]),"Strings")
	print("Stop Words removed from:",len(diff[diff>0]),"Strings")

	return CORPUS