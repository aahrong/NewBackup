# -*- coding: utf-8 -*-
"""
Created on Wed Mar  6 14:12:30 2019

@author: caridza
"""

import feedparser 
import re 
import requests 

#packages to enable running behind proxy
from pypac import pac_context_for_url
import ssl
context = ssl._create_unverified_context()

#FINRA – https://www.finra.org/industry/rss-feeds
#OCC – https://www.occ.treas.gov/rss/index-rss.html
#SEC – https://www.sec.gov/about/secrss.shtml
#Investor.gov –  https://www.sec.gov/rss/investor/alerts
#Federal Reserve – https://www.federalreserve.gov/feeds/feeds.htm
#FDIC – https://www.fdic.gov/rss.html
#CFTC – https://www.cftc.gov/RSS/index.htm

#identify RSS FEED 



with pac_context_for_url('https://www.google.com'):

    #parse latest data from cftc rss feed 
    rssfeed = "https://www.federalreserve.gov/feeds/press_enforcement.xml"
    
    payload = feedparser.parse(rssfeed)
 


#process json dictonary payload 
parent_keys = payload.keys()

for key in parent_keys: 
    print(key,payload[key])

#metadata about feed resposne
DtypeKeys = [type(key) for key in parent_keys ]
child_keys = [key.keys() for key in parent_keys if isinstance(key,dict)]