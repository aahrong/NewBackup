"""
Created on Thu Feb 16 01:22:29 2017
@author: mallabi

This script is used to create nodes and edge datasets for the network graphs.
"""
#=========================================================================================================
#1: Import package and dataset
#========================================================================================================= 
import os 
import pandas as pd
import numpy as np
os.chdir("E:\Use Case Testing\NLP\BM")
emails_df_lda = pd.read_pickle('Emails_df_toke_lda.pkl')
print "Total number of emails: ",emails_df_lda.shape[0]


#-------------------------------------------------------------------------------------------------------------
#Create Date Time tags for output file names
#-------------------------------------------------------------------------------------------------------------
from datetime import datetime
date_object = datetime.now()
current_date=date_object.strftime('%Y-%m-%d')
current_time = date_object.strftime('%H%M%S')
filename="output_"+ str(current_date) + "(" + str(current_time) +")"
output_fold="E:\Use Case Testing\NLP\BM\Output"

print(filename)
#=========================================================================================================
#2: Network Analysis - Part0
#=========================================================================================================

#-------------------------------------------------------------------------------------------------------------
#Create a list of user and email address for ~150+ user folders
#-------------------------------------------------------------------------------------------------------------
#Create a unique list of user
user_list=(emails_df_lda[['user']]).drop_duplicates(subset=['user'],keep='first')
user_list.reset_index(level=0,inplace=True)
user_list.drop(['Message-ID'],axis=1,inplace=True)
print(len(user_list))

#-------------------------------------------------------------------------------------------------------------
##Performing wildcard matching to match users with email address
#-------------------------------------------------------------------------------------------------------------

#Create a unique list of user and email addresses
email_list=emails_df_lda[['From_open','user']]
email_list.reset_index(level=0,inplace=True)
email_list=email_list.drop(['Message-ID'],axis=1)

email_list=email_list.join(pd.DataFrame(email_list['user'].str.split('-',1).tolist(),columns = ['lname','finitial']))
email_list['Match_String']=map(lambda x,y: x + "*." + y +"@enron.com",email_list['finitial'],email_list['lname'])

import fnmatch
email_list.loc[:,'Match']=map(lambda x,y: fnmatch.fnmatch(x,y),email_list['From_open'],email_list['Match_String'])
email_list=email_list.ix[email_list['Match']==True,:]
email_list=email_list.drop(['lname','finitial','Match_String','Match'],axis=1)

email_list['Count']=0
email_list['Count'] = email_list.groupby(['From_open','user']).transform('count')

email_list=email_list.drop_duplicates(subset=['From_open','user'],keep='first')
email_list=email_list.sort_values(['user'],ascending=True)
email_list['Count2']=0
email_list['Count2'] = email_list.groupby(['user']).transform('count')

#-------------------------------------------------------------------------------------------------------------
#Merge it with user_list
#-------------------------------------------------------------------------------------------------------------
user_list = pd.merge(user_list, email_list, on='user',how='left',left_index=False,right_index=False)

#---------------------------------------------------------------------------
###Some have Multiple matches
#-----------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------
###Finding 1: One folder corresponds to 2 users in these cases
#-----------------------------------------------------------------------------------------------
user_list[user_list['Count2']>1]

#-----------------------------------------------------------------------------------------------
###Finding 2: Did not find matches for some user folders and will need be manually reviewed
#-----------------------------------------------------------------------------------------------
user_list[pd.isnull(user_list['From_open'])]

#Print to CSV File          
#user_list.to_csv("user_list.csv", sep=';')

##Manually reviewing to find email
select_user=user_list.loc[pd.isnull(user_list['From_open']),['user']]
index=emails_df_lda['user'].apply(lambda x: True if (any(v == x for v in select_user['user'])) else False)
sum(index)

extract=emails_df_lda.loc[index,['From_open','user','To','X-Folder']]
extract.reset_index(level=0,inplace=True)
extract=extract.drop_duplicates(subset=['From_open','To','user','X-Folder'],keep='first')

###Filter to specific user
emails_df_lda.loc[emails_df_lda['user']=='hodge-j',['From_open','To','user','X-Folder']]


###Emails based on manual review                                     
#lucci-p: plucci@ect.enron.com; plucci@enron.com; t..lucci@enron.com(??)
#mims-thurston-p: patrice.mims@enron.com; pmims@enron.com(??); l..mims@enron.com(??)
#ybarbo-p: paul.y'barbo@enron.com;barbo@enron.com(??)
#whalley-l: greg.whalley@enron.com; gwhalle@enron.com; whalley@enron.com
#rodrique-r: robin.rodrigue@enron.com; 
#merriss-s: steven.merris@enron.com;
#williams-w3: bill.williams@enron.com; bill.iii@enron.com(??)
#phanis-s: stephanie.panus@enron.com;
#motley-m: matt.motley@enron.com; 
#stclair-c: carol.clair@enron.com; carol.st.clair@enron.com
#gilbertsmith-d: doug.gilbert-smith@enron.com;
#crandell-s: sean.crandall@enron.com

                         
#from fuzzywuzzy import fuzz
#user_list.loc[:,'Fuzz_ratio']=0
#user_list.loc[:,'Fuzz_ratio']=map(lambda x,y: fuzz.ratio(x,y),user_list['From_open'],user_list['user'])
#user_list=user_list.sort_values(['user','Fuzz_ratio'],ascending=[True,False])

print(len(user_list))

#=========================================================================================================
#Network Analysis - Part1
#=========================================================================================================
columns_include=['From','To','Date','Max1','Subject','content']
df_network=emails_df_lda.ix[:,columns_include]
df_network.rename(columns={'Max1': 'Primary_Topic'}, inplace=True)

#Convert frozenset to lists
df_network['To']=df_network['To'].map(lambda x: list(x) if x!=None else [None])
df_network['From']=df_network['From'].map(lambda x: list(x)[0] if x!=None else None)

#Rename the email addresses
#rename_email={'ben.glisan@enron.com':'Ben Glisan',
#            'jeff.skilling@enron.com':'Jeffrey Skilling','jeffreyskilling@yahoo.com':'Jeffrey Skilling',
#            'kenneth.lay@enron.com':'Kenneth Lay',
#            'andrew.fastow@enron.com':'Andrew Fastow',
#            'mark.koenig@enron.com':'Mark Koenig',
#            'ken.rice@enron.com':'Ken Rice',
#            'greg.whalley@enron.com':'Greg Whalley','gregwhalley@yahoo.com':'Greg Whalley','office.whalley@enron.com':'Greg Whalley',
#            'sherron.watkins@enron.com':'Sherron Watkings',
#            'j.kaminski@enron.com':'J Kaminski','j..kaminski@enron.com':'J Kaminski'
#           }

#Define dictionary to include name for the 150+users
rename_email={
'phillip.allen@enron.com':'Philip Allen',
'richard.sanders@enron.com':'Richard Sanders',
'steven.kean@enron.com':'Steven Kean',
'john.lavorato@enron.com':'John Lavorato',
'mark.taylor@enron.com':'Mark Taylor',
'matthew.lenhart@enron.com':'Matthew Lenhart',
'kay.mann@enron.com':'Kay Mann',
'gerald.nemec@enron.com':'Gerald Nemec',
'charles.weldon@enron.com':'Charles Weldon',
'benjamin.rogers@enron.com':'Benjamin Rogers',
'susan.scott@enron.com':'Susan Scott',
'thomas.martin@enron.com':'Thomas Martin',
'kevin.presto@enron.com':'Kevin Presto',
'plucci@ect.enron.com':'Paul Lucci',
'plucci@enron.com':'Paul Lucci',
't..lucci@enron.com':'Paul Lucci',
'bill.rapp@enron.com':'Bill Rapp',
'mark.whitt@enron.com':'Mark Whitt',
'kim.ward@enron.com':'Kim Ward',
'patrice.mims@enron.com':'Patrice Mims',
'pmims@enron.com':'Patrice Mims',
'l..mims@enron.com':'Patrice Mims',
'theresa.staab@enron.com':'Theresa Staab',
'jay.reitmeyer@enron.com':'Jay Reitmeyer',
'james.steffes@enron.com':'James Steffes',
'andy.zipper@enron.com':'Andy Zipper',
'hunter.shively@enron.com':'Hunter Shively',
'richard.shapiro@enron.com':'Richard Shapiro',
'judy.townsend@enron.com':'Judy Townsend',
'matt.smith@enron.com':'Matt Smith',
'barry.tycholiz@enron.com':'Barry Tycholiz',
'susan.pereira@enron.com':'Susan Pereira',
'mike.maggi@enron.com':'Michael Maggi',
'larry.may@enron.com':'Lawrence May',
'scott.neal@enron.com':'Scott Neal',
'kevin.ruscitti@enron.com':'Kevin Ruscitti',
'jim.schwieger@enron.com':'Jim Schwieger',
'dutch.quigley@enron.com':'Dutch Quigley',
'stacey.white@enron.com':'Stacey White',
'mark.mcconnell@enron.com':'Mark McConnell',
'mike.mcconnell@enron.com':'Mike McConnell',
"paul.y'barbo@enron.com":'Paul Barbo',
'barbo@enron.com':'Paul Barbo',
'greg.whalley@enron.com':'Greg Whalley',
'gwhalle@enron.com':'Greg Whalley',
'whalley@enron.com':'Greg Whalley',
'jeff.skilling@enron.com':'Jeffery Skilling',
'greg.whalley@enron.com':'Greg Whalley',
'jeffrey.shankman@enron.com':'Jeffrey Shankman',
'sara.shackleton@enron.com':'Sara Shackleton',
'kimberly.watson@enron.com':'Kimberly Watson',
'brad.mckay@enron.com':'Bradley Mckay',
'jane.tholt@enron.com':'Jane Tholt',
'joe.stepenovitch@enron.com':'Joe Stepenovitch',
'joe.parks@enron.com':'Joe Parks',
'danny.mccarty@enron.com':'Danny McCarty',
'richard.ring@enron.com':'Richard Ring',
'vladi.pimenov@enron.com':'Vladi Pimenov',
'andrew.lewis@enron.com':'Andrew Lewis',
'geoff.storey@enron.com':'Geoffery Storey',
'paul.thomas@enron.com':'Paul Thomas',
'holden.salisbury@enron.com':'Holden Salisbury',
'phillip.m.love@enron.com':'Phillip Love',
'phillip.love@enron.com':'Phillip Love',
'errol.mclaughlin@enron.com':'Errol McLaughlin',
'diana.scholtes@enron.com':'Diana Scholtes',
'jason.williams@enron.com':'Jason Williams',
'fletcher.sturm@enron.com':'Fletcher Sturm',
'teb.lokey@enron.com':'Teb Lokey',
'ryan.slinger@enron.com':'Ryan Slinger',
'jason.wolfe@enron.com':'Jason Wolfe',
'robin.rodrigue@enron.com':'Robin Rodrigues',
'michelle.lokay@enron.com':'Michelle Lokay',
'michele.lokay@enron.com':'Michelle Lokay',
'eric.linder@enron.com':'Eric Linder',
'kate.symes@enron.com':'Kate Symes',
'mike.swerzbin@enron.com':'Mike Swerzbin',
'steven.merris@enron.com':'Steven Merris',
'monique.sanchez@enron.com':'Monique Sanchez',
'bill.williams@enron.com':'Bill Williams',
'bill.iii@enron.com':'Bill Williams',
'debra.perlingiere@enron.com':'Debra Perlingiere',
'stephanie.panus@enron.com':'Stephanie Panus',
'chris.stokley@enron.com':'Chris Stokley',
'phillip.platter@enron.com':'Phillip Platter',
'elizabeth.sager@enron.com':'Elizabeth Sager',
'stephanie.panus@enron.com':'Stephanie Panus',
'joe.quenet@enron.com':'Joe Quenet',
'cooper.richey@enron.com':'Cooper Richey',
'john.zufferli@enron.com':'John Zufferli',
'andrea.ring@enron.com':'Andrea Ring',
'jonathan.mckay@enron.com':'Jonathan Mckay',
'matt.motley@enron.com':'Matthew Motley',
'cara.semperger@enron.com':'Cara Semperger',
'louise.kitchen@enron.com':'Louise Kitchen',
'kenneth.lay@enron.com':'Kenneth Lay',
'jeff.king@enron.com':'Jeff King',
'vince.kaminski@enron.com':'Vince Kaminski',
'peter.keavey@enron.com':'Peter Keavey',
'peter.f.keavey@enron.com':'Peter Keavey',
'kam.keiser@enron.com':'Kam Keiser',
'eric.saibi@enron.com':'Eric Saibi',
'tori.kuykendall@enron.com':'Tori Kuykendall',
'geir.solberg@enron.com':'Geir Solberg',
'steven.south@enron.com':'Steven South',
'carol.clair@enron.com':'Carol St.Clair',
'carol.st.clair@enron.com':'Carol St.Clair',
'darrell.schoolcraft@enron.com':'Darrell Schoolcraft',
'michelle.cash@enron.com':'Michelle Cash',
'mark.e.haedicke@enron.com':'Mark Haedicke',
'mark.haedicke@enron.com':'Mark Haedicke',
'tana.jones@enron.com':'Tana Jones',
'stan.horton@enron.com':'Stanley Horton',
'stanley.horton@enron.com':'Stanley Horton',
'john.griffith@enron.com':'John Griffith',
'marie.heard@enron.com':'Marie Heard',
'john.hodge@enron.com':'John Hodge',
'jeffrey.hodge@enron.com':'John Hodge',
'james.derrick@enron.com':'James Derrick',
'drew.fossum@enron.com':'Drew Fossum',
'rod.hayslett@enron.com':'Rod Hayslett',
'scott.hendrickson@enron.com':'Scott Hendrickson',
'monika.causholli@enron.com':'Monika Causholli',
'dan.hyvl@enron.com':'Dan Hyvl',
'jeff.dasovich@enron.com':'Jeff Dasovich',
'shelley.corman@enron.com':'Shelley Corman',
'tracy.geaccone@enron.com':'Tracy Geaccone',
'craig.dean@enron.com':'Craig Dean',
'clint.dean@enron.com':'Clint Dean',
'larry.campbell@enron.com':'Larry Campbell',
'mike.carson@enron.com':'Mike Carson',
'chris.dorland@enron.com':'Chris Dorland',
'doug.gilbert-smith@enron.com':'Douglas Gilbert-Smith',
'judy.hernandez@enron.com':'Judy Hernanez',
'juan.hernandez@enron.com':'Juan Hernandez',
'martin.cuilla@enron.com':'Martin Cuilla',
'john.forney@enron.com':'John Forney',
'steven.harris@enron.com':'Steven Harris',
'mary.hain@enron.com':'Mary Hain',
'keith.holst@enron.com':'Keith Holst',
'dana.davis@enron.com':'Dana Davis',
'kevin.hyatt@enron.com':'Kevin Hyatt',
'lindy.donoho@enron.com':'Lindy Donoho',
'sean.crandall@enron.com':'Sean Crandall',
'mike.grigsby@enron.com':'Michael Grigsby',
'daren.farmer@enron.com':'Daren Farmer',
'tom.donohoe@enron.com':'Tom Donohoe',
'mark.guzman@enron.com':'Mark Guzman',
'albert.meyers@enron.com':'Albert Meyers',
'mary.fischer@enron.com':'Mary Fischer',
'darron.giron@enron.com':'Daron Giron',
'chris.germany@enron.com':'Chris Germany',
'rick.buy@enron.com':'Rick Buy',
'frank.ermis@enron.com':'Frank Ermis',
'david.delainey@enron.com':'David Delainey',
'eric.bass@enron.com':'Eric Bass',
'don.baughman@enron.com':'Don Baughman',
'susan.bailey@enron.com':'Susan Bailey',
'steve.beck@enron.com':'Steve Beck',
'sally.beck@enron.com':'Sally Beck',
'sandra.brawner@enron.com':'Sandra Brawner',
'randall.gay@enron.com':'Randall Gay',
'rob.gay@enron.com':'Rob Gay',
'harry.arora@enron.com':'Harpreet Arora',
'robert.benson@enron.com':'Robert Benson',
'robert.badeer@enron.com':'Robert Badeer',
'john.arnold@enron.com':'John Arnold',
'lynn.blair@enron.com':'Lynn Blair',
'stacy.dickson@enron.com':'Stacy Dickson',
}

#-----------------------------------------------------------------------------------------------
#Rename 'From' addresses2: 
#-----------------------------------------------------------------------------------------------
df_network['From_2']=df_network['From'].apply(lambda x: rename_email[x] if (x in rename_email) else "Others")
df_network.reset_index(level=0,inplace=True)
print(df_network.head())

print "Total number of emails: ",df_network.shape[0]
print "Total number of Employee: ",len(set(df_network['From_2']))

#Count of emails by Sender
freq_tbl=pd.value_counts(df_network.From_2)
##Others = 91264, Remaining = 37642

#=========================================================================================================
#Network Analysis - Part2
#=========================================================================================================
#Split 'To' addresses into individual rows
df_set=[]
for i in range(0,len(df_network)):
    for val_to in (df_network['To'][i]):
        if val_to==None: val_to="None" 
        a=[df_network['Message-ID'][i],df_network['From'][i], df_network['From_2'][i],df_network['Date'][i],df_network['Subject'][i],df_network['content'][i],df_network['Primary_Topic'][i],val_to]
        df_set.append(a)
            
df_set=pd.DataFrame(df_set,columns=['Message-ID','From','From_2','Date','Subject','content','Primary_Topic','To'])
#print(df_set.head())

#Rename 'To' addresses
df_set['To_2']=df_set['To'].apply(lambda x: rename_email[x] if (x in rename_email) else "Others")

#Exclude "Others" from dataset
df_set=df_set[(df_set.From!="Others")]                            
print "Total number of emails: ",len(set(df_set['Message-ID']))       
                    
df_set=df_set[(df_set.To_2!="Others")]
print "Total number of emails: ",len(set(df_set['Message-ID']))       

df_set.head()


#Add field for counts of email
counts=1/pd.DataFrame(pd.value_counts(df_set['Message-ID'].values, sort=False))
counts.reset_index(level=0, inplace=True)
counts.columns=['Message-ID','Count']

df_network=df_set.merge(counts,how='left', left_on='Message-ID',right_on='Message-ID',)

df_network['Edge']=list(zip(df_network['From'], df_network['To_2']))
df_network['Period']=df_network['Date'].apply(lambda x: x.strftime('%Y-%m')+"-01")
print(df_network.head())

print "Total number of rows:", df_network.shape[0]
print "Total number of emails: ", np.ceil(sum(df_network.Count))

#Create a copy, restore points
df_copy=df_network.copy(deep=True)
#df_network=df_copy

#Create output dataset for graph database

df_graph=df_network[['Message-ID','From','From_2','Date','Subject','content','Count','Primary_Topic','To','To_2']]
df_graph=df_graph.groupby(['Message-ID','Date','From','From_2','Subject','content','Primary_Topic'])['To','To_2'].agg(lambda x: ', '.join(set(x))).reset_index()

df_graph_sample=df_graph[:100]

#Export CSV file
path="E:\Use Case Testing\NLP\BM\Output"
os.chdir(path)

df_graph_sample.to_csv("sample_graph_data"+ filename + ".csv",encoding='utf-8')




#=========================================================================================================
#3: Preparing Nodes and Edge Table
#=========================================================================================================


#Edge counts across the whole period
edge_weights=df_network['Edge'].value_counts()
edge_weights=pd.DataFrame(edge_weights)
edge_weights.reset_index(level=0,inplace=True)
edge_weights.columns=['Edge','Edge_Weight']
_edge_list=pd.DataFrame(list(edge_weights['Edge'].str)).transpose()
_edge_list.columns=['source','target']
edge_weights=pd.concat([edge_weights, _edge_list], axis=1)
print(edge_weights.head())
print "Total number of rows: ", (sum(edge_weights.Edge_Weight))


#Edge counts across the whole period by month
edge_weights_ByPeriod=df_network[['Edge','Date']]
edge_weights_ByPeriod['Period']=edge_weights_ByPeriod['Date'].apply(lambda x: x.strftime('%Y-%m')+"-01")
edge_weights_ByPeriod=pd.DataFrame(edge_weights_ByPeriod.groupby(['Edge','Period']).size())
edge_weights_ByPeriod.reset_index(level=0,inplace=True)
edge_weights_ByPeriod.reset_index(level=0,inplace=True)
edge_weights_ByPeriod.columns=['Period','Edge','Edge_Weight_ByP']
_edge_list=pd.DataFrame(list(edge_weights_ByPeriod['Edge'].str)).transpose()
_edge_list.columns=['source','target']
edge_weights_ByPeriod=pd.concat([edge_weights_ByPeriod, _edge_list], axis=1)
print(edge_weights_ByPeriod.head())
print "Total number of rows: ", (sum(edge_weights.Edge_Weight))


#Node counts across the whole period
node_weights=df_network.groupby('From')['Count'].agg('sum')
node_weights=pd.DataFrame(node_weights,columns=['Count'])
node_weights.reset_index(level=0,inplace=True)
#node_weights['Count']=np.ceil(node_weights['Count'])
node_weights=node_weights.drop_duplicates(subset=['From','Count'],keep='first')

#Add nodes from Edge List
df=list(set(edge_weights['target']) - set(node_weights['From']))
df=pd.DataFrame(df,columns=["From"])
df['Count']=0
node_weights=node_weights.append(df,ignore_index=True)

print(node_weights.head())
print "Total number of emails: ", (sum(node_weights.Count))


#Node counts across the whole period by month
node_weightsByPeriod=df_network.groupby(['From','Period'])['Count'].agg('sum')
node_weightsByPeriod=pd.DataFrame(node_weightsByPeriod,columns=['Count'])
node_weightsByPeriod.reset_index(level=0,inplace=True)
node_weightsByPeriod.reset_index(level=0,inplace=True)
node_weightsByPeriod['Count']=node_weightsByPeriod['Count'].astype(int)
node_weightsByPeriod=node_weightsByPeriod.drop_duplicates(subset=['From','Period','Count'],keep='first')

#Add nodes from Edge List
df1 = edge_weights_ByPeriod[['target','Period']]
df1['ID']=df1['target'].str.cat(df1['Period'])
df2 = node_weightsByPeriod[['From','Period']]
df2['ID']=df2['From']+df2['Period']
_lst=list(set(df1['ID']) - set(df2['ID']))
df=df1.loc[df1['ID'].isin(_lst),['Period','target']]
df.drop_duplicates(inplace=True)
df=df.rename(columns={'target':'From'})
df['Count']=0

node_weightsByPeriod=node_weightsByPeriod.append(df,ignore_index=True)
print(node_weightsByPeriod.head())
print "Total number of emails: ", (sum(node_weights.Count))


#Get counts of two way edge
df_count=edge_weights[['source','target','Edge_Weight']]
df_count['ID1']=df_count['source']+"_"+df_count['target']

ID_List=list(df_count['target']+"_"+df_count['source'])


test=df_count[df_count['ID1'].isin(ID_List)]
#-----------------------------------------------------------------------------------------------
###Function to add labels to the dataframe
#-----------------------------------------------------------------------------------------------
def Add_TopicEdgeLabels(dframe,groupby_cols,topic_col):
    df=dframe[groupby_cols+topic_col]
    df=df.sort_values(groupby_cols+topic_col)
    df['Total']=df.groupby(groupby_cols).transform('count')
    df['SubTotal']=df.groupby(groupby_cols+topic_col).transform('count')
    df['Percent']=(100*(df['SubTotal']/df['Total']))
    df['Percent']=df['Percent'].apply(lambda x: int(x))
    df=df.sort_values(groupby_cols+['Percent'],ascending=False)
    df=df.drop_duplicates(subset=groupby_cols+topic_col,keep='first')
   
    del df['SubTotal']
    df['String1']="N="+df['Total'].map(str)
    df['String2']=df['Primary_Topic'].map(str)+"("+df['Percent'].map(str)+"%)"
    df=df[groupby_cols+['String1','String2']]
    df=df.groupby(groupby_cols+['String1'])['String2'].apply(';'.join).reset_index()
    df['Edge_Label']="Topic#(%):"+df['String2']+"["+df['String1']+"]"
    df=df[groupby_cols+['Edge_Label']]
    return df

##Attach Topics from LDA model across the whole period
groupby_cols=['Edge']
topic_col=['Primary_Topic']
edge_topic=Add_TopicEdgeLabels(df_network,groupby_cols,topic_col)
print(edge_topic.head())

#Attach Topics from LDA model across the whole period by month
groupby_cols=['Edge','Period']
edge_topic_ByPeriod=Add_TopicEdgeLabels(df_network,groupby_cols,topic_col)
edge_topic_ByPeriod=edge_topic_ByPeriod.rename(columns={'Edge_Label': 'Edge_Label_ByP'})
print(edge_topic_ByPeriod.head())


#Attaching weights and labels to dataset
df=df_network

#Merge Edge Weights and Edge Labels
df=df.merge(edge_weights,how='left', left_on='Edge',right_on='Edge')
df=df.merge(edge_weights_ByPeriod,how='left', left_on=['Edge','Period','source','target'],right_on=['Edge','Period','source','target'])

df=df.merge(edge_topic,how='left', left_on='Edge',right_on='Edge')
df=df.merge(edge_topic_ByPeriod,how='left', left_on=['Edge','Period'],right_on=['Edge','Period'])

df_network=df
print (df_network.head())
  
                
#-----------------------------------------------------------------------------------------------
#Preparing graph data for edge_list
#-----------------------------------------------------------------------------------------------
edge_list=df_network[['Edge','Edge_Weight','Edge_Label']]
edge_list=edge_list.drop_duplicates(subset=['Edge','Edge_Weight','Edge_Label'],keep='first')

_edge_list=pd.DataFrame(list(edge_list['Edge'].str)).transpose()
_edge_list.columns=['source','target']
edge_list=pd.concat([edge_list, _edge_list], axis=1)

print(edge_list.head())

#-----------------------------------------------------------------------------------------------
#Preparing graph data for edge_list by Period
#-----------------------------------------------------------------------------------------------
edge_list_ByP=df_network[['Edge','Period','Edge_Weight_ByP','Edge_Label_ByP']]
edge_list_ByP=edge_list_ByP.drop_duplicates(subset=['Edge','Period','Edge_Weight_ByP','Edge_Label_ByP'],keep='first')
#edge_list_ByP.reset_index(inplace=True)

_edge_list=pd.DataFrame(list(edge_list_ByP['Edge'].str)).transpose()
_edge_list.columns=['source','target']
edge_list_ByP=pd.concat([edge_list_ByP, _edge_list], axis=1)

print(edge_list_ByP.head())

#-----------------------------------------------------------------------------------------------
#Limit to 2001 only
node_weightsByPeriod=node_weightsByPeriod[node_weightsByPeriod.Period.str[:4]=="2001"]
print "Total number of emails: ", (sum(node_weightsByPeriod.Count))

edge_list_ByP=edge_list_ByP[edge_list_ByP.Period.str[:4]=="2001"]
print "Total number of edges: ", (sum(edge_list_ByP.Edge_Weight_ByP))




#Get counts of two way edge
df_count=edge_list_ByP[['source','target','Edge']]
df_count.drop_duplicates(inplace=True)

print "No of Edges",len(df_count)

df_count['ID1']=df_count['source']+"_"+df_count['target']
ID_List=list(df_count['target']+"_"+df_count['source'])
df_count['Type']=df_count['ID1'].apply(lambda x: "Bi-Directional" if (x in (ID_List)) else "")
df_count.loc[df_count['source']==df_count['target'],['Type']]="Self-Directional"

pd.value_counts(df_count['Type'])
              
#-----------------------------------------------------------------------------------------------

#-----------------------------------------------------------------------------------------------
#Create Dynamic Data for Gephi, Not Split by Month
#-----------------------------------------------------------------------------------------------

df=node_weightsByPeriod
df['Score']=df['Period'].astype(str).str.cat(df['Count'].astype(str), sep=',')
df=df[['From','Period','Score']]

df1=df.groupby(['From'])['Period'].apply(lambda x: ','.join(list(x))).reset_index()
df1['Period']="<["+df1['Period']+"]>"

#df1=df[['From','Period']]
#df1="<["+df1.groupby('From').first()+","+df1.groupby('From').last()+"]>"
#df1.reset_index(level=0,inplace=True)   

df2=df.groupby(['From'])['Score'].apply(lambda x: '];['.join(list(x))).reset_index()
df2['Score']="<["+df2['Score']+"]>"
nodes_dynamic=df1.merge(df2,how='left', left_on='From',right_on='From')
nodes_dynamic=nodes_dynamic.rename(columns={'From':'Id','Period':'Timestamp','Score':'Weight'})
print(nodes_dynamic.head())


df=edge_list_ByP
df['Score']=df['Period'].astype(str).str.cat(df['Edge_Weight_ByP'].astype(str), sep=',')
df['Label']=df['Period'].astype(str).str.cat('"'+df['Edge_Label_ByP'].astype(str)+'"', sep=',')

df=df[['source','target','Period','Score','Label']]

df1=df.groupby(['source','target'])['Period'].apply(lambda x: ','.join(list(x))).reset_index()
df1['Period']="<["+df1['Period']+"]>"

#df1=("<["+df1.groupby('Edge').first()+","+df1.groupby('Edge').last()+"]>").reset_index()

df2=df.groupby(['source','target'])['Score'].apply(lambda x: '];['.join(list(x))).reset_index()
df2['Score']="<["+df2['Score']+"]>"

df3=df.groupby(['source','target'])['Label'].apply(lambda x: '];['.join(list(x))).reset_index()
df3['Label']="<["+df3['Label']+"]>"


edges_dynamic=df1.merge(df2,how='left', left_on=['source','target'],right_on=['source','target'])
edges_dynamic=edges_dynamic.merge(df3,how='left', left_on=['source','target'],right_on=['source','target'])


nodes_dynamic=nodes_dynamic.rename(columns={'Period':'Timestamp','Score':'Weight'})
edges_dynamic=edges_dynamic.rename(columns={'Period':'Timestamp','Label':'Label2'})

print(edges_dynamic.head())


#-----------------------------------------------------------------------------------------------
#Create Dynamic Data for Gephi; Split by Month
#-----------------------------------------------------------------------------------------------
node_weightsByPeriod['Period']="<["+ node_weightsByPeriod['Period'] + "]>"
node_weightsByPeriod['Score']="<["+node_weightsByPeriod['Score']+"]>"
node_weightsByPeriod=node_weightsByPeriod.rename(columns={'Period':'Timestamp','Score':'Weight','From':'Id'})
node_weightsByPeriod=node_weightsByPeriod[['Id','Timestamp','Weight']]
print(node_weightsByPeriod.head())


df=edge_list_ByP[['Period','source','target','Edge_Weight_ByP','Edge_Label_ByP']]
df['Weight2']=df['Period'].astype(str).str.cat(df['Edge_Weight_ByP'].astype(str), sep=',')
df['Weight2']="<["+ df['Weight2'] + "]>"

df['Period']="<["+ df['Period'] + "]>"

df=df.rename(columns={'Period':'Timestamp','Edge_Label_ByP':'Label'})
df=df[['source','target','Timestamp','Weight2','Label']]

edge_weights_ByPeriod=df
print(edge_weights_ByPeriod.head())


#=========================================================================================================
#4: Converting Nodes and Edges to Node IDs
#=========================================================================================================
#Create network graph
import networkx as nx
import matplotlib.pyplot as plt

#Directed Graphs
def prep_graph(edge,weights,val):
    
    # create directed networkx graph
    G=nx.DiGraph()
    if val==1:
        for i in range(0,len(weights)):
            G.add_node(weights['From'][i],size=weights['Count'][i])
    #    
        for i in range(0,len(edge)):
            G.add_edge(edge['Edge'][i][0],edge['Edge'][i][1],weight=edge['Edge_Weight'][i],label=edge['Edge_Label'][i])
  
    if val==2:
        for i in range(0,len(weights)):
            G.add_node(weights['From'][i],size=weights['Count'][i],period=weights['Period'][i])
    #    
        for i in range(0,len(edge)):
            G.add_edge(edge['Edge'][i][0],edge['Edge'][i][1],weight=edge['Edge_Weight_ByP'][i],label=edge['Edge_Label_ByP'][i],period=edge['Period'][i])
    
    #Add size to nodes that are added from edge table
    for i in G.node:
        if G.node[i]=={}:
            G.node[i]['size']=0
#    for n in G.edges_iter(): 
#        G.edge[n[0]][n[1]]['label']='X'
    return G

#Prepare graph data
from networkx.readwrite import json_graph
GG=prep_graph(edge_list,node_weights,1)
data=json_graph.node_link_data(GG)


#GG_ByP=prep_graph(edge_list_ByP,node_weightsByPeriod,2)
#data_ByP=json_graph.node_link_data(GG_ByP)

#=========================================================================================================
#5: Exporting Nodes and Edges Table
#=========================================================================================================
edge_table=pd.DataFrame(data['links'])
nodes_table=pd.DataFrame(data['nodes'])

path="E:\Use Case Testing\NLP\BM\Output"
os.chdir(path)

edge_table.to_csv("edge_list_"+ filename + ".csv", sep=';')
nodes_table.to_csv("nodes_list_"+ filename + ".csv", sep=';')






path="E:\Use Case Testing\NLP\BM\Output"
os.chdir(path)

for i in range(1,13):
    month_string="2001-"+str(i).zfill(2)+"-01"

    df1=  edge_weights_ByPeriod[edge_weights_ByPeriod['Timestamp']=="<["+month_string+"]>"]
    df2=  node_weightsByPeriod[node_weightsByPeriod['Timestamp']=="<["+month_string+"]>"]
    df1.to_csv("edge_list_ByP_"+str(i).zfill(2)+"_"+ filename + ".csv", sep=',')
    df2.to_csv("nodes_list_ByP_"+str(i).zfill(2)+"_"+ filename + ".csv", sep=',')
   
    
edges_dynamic.to_csv("edge_list_dynamic_01_"+ filename + ".csv", sep='\t')
nodes_dynamic.to_csv("node_list_dynamic_01_"+ filename + ".csv", sep='\t')

###Testing
nodes_dynamic.to_csv("node_list_test"+ filename + ".csv", sep='\t')
edge_weights_ByPeriod.to_csv("edge_list_test"+ filename + ".csv", sep='\t')

###Using Packages to visualize network graphs
#=========================================================================================================
#6: Drawing Graph Data
#=========================================================================================================
def draw_graph(g_data):       
    graph_pos = nx.shell_layout(g_data)
    sizes = []
    for v in g_data.node:
        x=g_data.node[v]['size']
        sizes.append(200*x)
        
    edgewidth = [ d['weight'] for (u,v,d) in g_data.edges(data=True)]
    edgelabel = [ d['label'] for (u,v,d) in g_data.edges(data=True)]
    
    nx.draw_networkx_nodes(g_data, graph_pos, node_color='blue', alpha=0.3,node_size=sizes)
    
    # we can now added edge thickness and edge color
    nx.draw_networkx_edges(g_data, graph_pos, width=edgewidth, alpha=0.5, edge_color='red')
    nx.draw_networkx_labels(g_data, graph_pos, font_size=8, font_family='sans-serif')
    
    #labels = range(len(df_set))
    #edge_labels = dict(zip(graph, labels))
    
    nx.draw_networkx_edge_labels(g_data, graph_pos, edge_label =edgelabel)
    plt.figure(figsize=(30,50))
    plt.show()

###Draw Graphs
draw_graph(GG)
