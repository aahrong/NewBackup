# -*- coding: utf-8 -*-
"""
Created on Tue Mar 07 00:32:09 2017

This script creates a mock data for email diagnostic exercise. It uses the /
sample from Enron dataset,assuming certain distributions.

@author: mallabi
"""
#------------------------------------------------------------------------------
#Import necessary packages
#------------------------------------------------------------------------------
import email
import os
import numpy as np 
import pandas as pd
import seaborn as sns; sns.set_style('whitegrid')
import random
from time import time
from datetime import timedelta

#Custom functions
path = "E:\Use Case Testing\NLP\BM\Script\Function"
os.chdir(path)
import Fx_Email_Extract as email_extract
#------------------------------------------------------------------------------
## Helper functions
#------------------------------------------------------------------------------
def remove_strings(string):
    '''To remove reply/forward indicating strings from email subject line'''
    remove_list = ['re:','fwd:','fw:','(fwd)']
    for key in remove_list:
        if string.strip().lower().startswith(key):
            string = string.lower().replace(key, '').strip()
            remove_list.remove(key)
    return string

def clean_subject(string):
    '''To remove reply/forward strings; repeat to capture all instances '''
    return remove_strings(remove_strings(remove_strings(string))).lower()

def reverse_string(string):
    '''To reverse string'''
    return (string[::-1]).strip()

def keep_letters_only(string):
    '''To keep letters only'''
    return ''.join(filter(str.isalpha, string))
    
def tag_threads_subject(dataset):
    '''To tag threads by subject line, after removing re/fwds'''
    df = dataset.copy(deep=True)
    df['Subject_Clean_Rev'] = df['Subject_Clean'].apply(lambda x: 
                                                        reverse_string(
                                                        clean_subject(x)))
    df.sort_values('Subject_Clean_Rev', inplace=True)
    df["Thread_ID"] = df.groupby(["Subject_Clean"]).grouper.group_info[0]
    df["Thread_Count"] = df.groupby(["Thread_ID"])['Thread_ID'].transform('count')

    del df['Subject_Clean_Rev']
    return df

def tag_threads_content(dataset):
    '''To tag threads by content; The content of the email is limited to letters/
    only, reversed and sorted. Then the emails are compared on the sorted list /
    of see if the email is the subset of the next email'''        
    
    df = dataset.copy(deep=True)
    df['Thread_content_ID'] = 10e10 #Initiate a big value
    df['Content_Short_Rev'] = df['content'].apply(lambda x: (
                                                    reverse_string(
                                                    keep_letters_only(x))))
    df.sort_values('Content_Short_Rev', inplace=True)
    
    for i in range(1,len(df)):
        first_string = df['Content_Short_Rev'].iloc[i-1].lower()
        second_string = df['Content_Short_Rev'].iloc[i].lower()
        if first_string not in ['']:
            if ((first_string in second_string) or
                (second_string in first_string)):
                df['Thread_content_ID'].iloc[i] = min(df['ID'].iloc[i],
                                                      df['ID'].iloc[i-1], 
                                                      df['Thread_content_ID'].iloc[i],
                                                      df['Thread_content_ID'].iloc[i-1])
                df['Thread_content_ID'].iloc[i-1] = df['Thread_content_ID'].iloc[i]
    df['Thread_content_ID'] = df['Thread_content_ID'].apply(lambda x: -1 
                                                            if (x == 10e10) 
                                                            else x)
    df['Thread_content_ID_Count'] = df.groupby(['Thread_content_ID'])['Thread_content_ID'].transform('count')

    del df['Content_Short_Rev']
    return df
        
#------------------------------------------------------------------------------
#Import Raw Data File and PreProcess
#------------------------------------------------------------------------------
emails_df = pd.read_csv("E:/Use Case Testing/NLP/Raw Data/emails.csv")
print('shape of the dataframe:', emails_df.shape) 
emails_df.head()

print(emails_df['message'][0])                  #Each email looks like this
print(emails_df['message'][1])

#Preprocess data
emails_df = Fx_Email_Extract.preprocess_email(emails_df)

#Generate Frequency
pd.value_counts(emails_df.Email_Group)
pd.value_counts(emails_df.Email_Group2)
    
#------------------------------------------------------------------------------
#Flag threads by Subject and Content
#------------------------------------------------------------------------------    
t0 = time()
emails_df = tag_threads_content(emails_df) 
print("Done in %0.3fs" %(time() - t0))

#Rename Columns
emails_df.rename(columns = {'Thread_content_ID': 'Thread_ID',
                              'Thread_content_ID_Count': 'Thread_Count'}, 
                              inplace = True)

#Get a list of Thread ID
Thread_Table = pd.DataFrame(pd.value_counts(emails_df['Thread_ID'].values, 
                                            sort=False))
Thread_Table=Thread_Table.reset_index()
Thread_Table.columns = ['Thread_ID','Count']
Thread_Table = Thread_Table[(Thread_Table.Thread_ID >= 0) & 
                            (Thread_Table.Count <20) & 
                            (Thread_Table.Count >1)]
Thread_Table = Thread_Table.sort_values('Count', ascending = False)
Thread_Table

#------------------------------------------------------------------------------------------------------------------------
#Get Random Sample using Thread_ID
#------------------------------------------------------------------------------------------------------------------------
#Input parameters
N = 2000
date_dist = [(0,5,0.2), (6,10,.4), (11,100,0.4)]

#Get list of N Thread_ID           
Thread_smpl = pd.DataFrame(Thread_Table.Thread_ID).sample(n = N, random_state = 787)
               
#Limit dataset to the selected Thread_ID
df = emails_df[emails_df['Thread_ID'].isin(list(Thread_smpl.Thread_ID))]
df = df.reset_index()
df = df[['Date','From_open','To_open','Subject','Thread_ID','Thread_Count']]
df.rename(columns = {'From_open': 'From', 'To_open': 'To'}, inplace=True)
df.head()

#Attaching simulated distribution of DateTime, based on date_dist
b = np.empty([], dtype = int)
for i in date_dist:
    a = np.random.randint(low = i[0], 
                          high = (i[1] * (24 * 3600)) + 1, 
                          size = int(N * i[2]))
    b = np.append(b, a)
d_set = np.delete(b, [0])
    
#Add length of thread randomly selected
Thread_smpl['Thread_length'] = d_set.tolist()

#Add Thread length and Group IDs
df = df.merge(Thread_smpl, how = 'left', 
              left_on = 'Thread_ID', right_on = 'Thread_ID')
df = df.sort_values(['Thread_ID', 'Date'], ascending = True)
df['Group_ID'] = df.groupby('Thread_ID').cumcount() + 1
df.head()

#Repopulate DateTime Stamps
df['Thread_Entry'] = list(map(lambda x , y, z: 0 if (x == 1) else z 
                                                    if (x == y) else 
                                                    sorted(random.sample(
                                                        range(1, z), y-2))[x-2] 
                                                    if (y>2) else -1,
                                                    df['Group_ID'], 
                                                    df['Thread_Count'], 
                                                    df['Thread_length']))
df['Min_Date'] = df.groupby('Thread_ID')['Date'].transform('min')
df['Date'] = list(map(lambda x, y: timedelta(seconds = (float(x))) + y,
                                                        df['Thread_Entry'], 
                                                        df['Min_Date']))

#Keep selected fields only
df = df[['Date', 'From', 'To', 'Subject', 
         'Thread_ID', 'Group_ID', 'Thread_Count']]