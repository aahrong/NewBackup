# -*- coding: utf-8 -*-
"""
Created on Thu Feb 02 07:47:16 2017

@author: DLUSER3
"""

import os

os.chdir("E:\Use Case Testing\NLP\BM")

import pandas as pd
emails_df_lda = pd.read_pickle('Emails_df_toke_lda.pkl')


def show_byTopic(TopicNo,N,dframe=emails_df_lda):
    ID_list=dframe.index[dframe.Max1==TopicNo]
    print(dframe['content'][ID_list[int(N % len(ID_list))]])
    return ID_list

#Search for examples by Topics

#Example 1: Find examples where primary topic is 2: Legal / Regulatory - only one found to have the word 'Legal' in it
ID=show_byTopic(2,20) #no.....
    """"
    Let me know if you can make it. Thanks Alex ios Kollaros , Andrew Chun/, Bali Buke= nya <>@, Brain Kascsak @, Brent Samuel , Carlos Mattiol= i <>@, Dan Mckay <>@SM= , David Olvey/, Freddy Mattioli <= hoo.com>@, Ihor Petrashko/, Jack Lorenz @SM= , John Henderson <>@= , Kenneth Martinez/, Layne Loessin/, Lino M= astrangelo , Maxim Philippov/, Michael Jacobson/= , Rene Bisono/, Roger Persson , = stephen fisher/, Tim Carter/, Timothy Weil/= Team, We have a game this Wednesday the 26th at 7:00 at Cullen. Please note that= the game is at 7:00 . . . I strongly recommend taking the HOV lane down I1= 0. If you dont then the traffic could make it tough to be there by kick of= f. Just a recommendation. =20 I will not be at this game so I will need someone to be an acting manager. = . . basically just fill out the form at half time and pay the ref twenty bu= cks. I can give you the money at work on Wednesday or we can just work out= how I will pay you back. I will be out of the office on Tuesday so if you= can do it let me know when you reply to this message. Please reply Yes or No if you will be able to play this week. Stephen Fisher Enron Net Works, LLC (713) 345-3743
    """"
ID=show_byTopic(2,2) #no.....
    """"
    More info. on the blue dog invoice LD/retention issue.. Rebecca 02:32 PM --------------------------- 
    Ben The way we actually paid the invoices changed slightly after Chris had sent the letter to GE. 
    We deducted the LD's and the retention amount from the April 25th invoice (since the May invoice was not due until May 25th). 
    On May 8th, a wire totalling $1,671,039 was sent to GE -- this represented $469,000 for the c/o #2 invoice and $1,202,039 
    for the April 25th invoice less the LD's and retention. To respond to Jeff Darst's letter, we can say that we are planning on 
    paying the May 25th invoice in full (assuming we're not planning on deducting additional LD's for May 8-May 25). We just need 
    to clarify with Jeff that both the LD and the retention were deducted from the April invoice, and then we can deal with resolving 
    the issues he discusses in his letter. Regards, Rebecca 01:22 PM --------------------------- on 05/09/2001 01:18:59 PM , Chris, 
    Please see attached letter, original to follow via FedEx. <> <> - Microsoft Word - BDM002.pdf - Microsoft Word - BDM002.pdf
    """"
ID=show_byTopic(2,3) 
    """"
    Hi Kay. Can you please forward the faxed invoice you received to Sheila Tweed. 
    I believe she may have some insight on this invoice, the due date was 6/18/2000. 
    Per Brian Barto it is ok to pay this invoice but we need someone in Legal to review and give the ok to pay. 
    Thanks- Tonya Tonya Dennis Specialist- Reporting & Analysis Enron -North America 713-345-3775
    """"
ID=show_byTopic(2,4)  #no....
    """"
    Here is the August Invoice analysis/breakdown. <>
    """"
ID=show_byTopic(2,10)
""""
Updated by: CN=Mark McConnell/O=Enron Communications
""""

ID=show_byTopic(2,15)
""""
sherry x1182 cynthia x1155
""""

ID=show_byTopic(2,100)
""""
causholli tnu587f2
""""

ID=show_byTopic(2,201)
""""
Please do not reply to this e-mail. You are receiving this message because you have an unresolved invoice in your iBuyit Payables in-box that is past due. Please login to iBuyit Payables and resolve this invoice as soon as possible. To launch iBuyit Payables, click on the link below: Note: Your iBuyit Payables User ID and Password are your eHRonline/SAP Personnel ID and Password. First time iBuyit Payables user? For training materials, click on the link below: Need help? Please contact the ISC Call Center at (713) 345-4727.
""""

ID=show_byTopic(2,1001)
""""
09:24 AM --------------------------- juan hernandez <> on 09/22/2000 11:23:31 PM The Hernandez Clan keeps getting larger. 
__________________________________________________ Do You Yahoo!? Send instant messages & get email alerts with Yahoo! 
Messenger. - Alexdrew.jpg - Myhomey.jpg - Family.jpg
""""

#Example 2: Find examples where primary topic is 4: Energy / Electric - no

ID=show_byTopic(4,1001) #no....
""""
Thanks for your voicemail regarding CT Corporation. My fax number is (713) 646-3490. When I receive the information, I will insert in into the ISDA Master Agreement and will return a fully executed copy to you. Again, thank you for your assistance and attention to this matter. Marie Marie Heard Senior Legal Specialist Enron North America Corp. Phone: (713) 853-3907 Fax: (713) 646-3490
""""

ID=show_byTopic(4,1002) #no....
""""
Ms. Rosenthal: Sara Shackleton just left for vacation until after Labor Day, but asked me to respond to your e-mail regarding sending us your completed ISDA schedule. Our Credit Department has said that Enron Corp. will provide a parent guaranty for ECT Investments, Inc., however, they would like for CSFB to also provide a guaranty since CSFB (Europe) is not a rated entity, or provide independent financial statements for CSFB (Europe). Our Credit Department did not provide us with a cap for the Enron Corp. guaranty. You can send your ISDA Schedule to my attention and we will proceed with reviewing same. Thank you. Marie Heard Senior Legal Specialist Enron North America Corp. Phone: (713) 853-3907 Fax: (713) 646-3490
""""

ID=show_byTopic(4,2020) #no....
""""
I will deliver a new version which you can "fix" and send to Elizabeth. SS 10:31 AM --------------------------- Elizabeth 05/08/2000 06:49 AM Robert H George/, , , Sara , Brent Hendry/, Rick Hopkinson/, Andrea Gavino/SA/, Mary Ann Oliveira/, Cecilia Morellato/, Kaye , Ana Lucia Liria/, Luiz Watanabe/, Nilza Rabaneda/ Please send me your updated report today till 5:00 p.m. Brazil time. Regards, Elizabeth.
""""

ID=show_byTopic(4,2150) #no....
""""
Frank and Francisco: Haven't seen you two in awhile! ENA is considering a financial deal with an offshore entity located in Panama. We have no research for this jurisdiction. I will need to hire local counsel and send a deriviatives questionnaire for response. Have you used Panamanian counsel before? Please send info. Sara Sara Shackleton Enron North America Corp. 1400 Smith Street, EB 3801a Houston, Texas 77002 713-853-5620 (phone) 713-646-3490 (fax)
""""

#Example 2: Find examples where primary topic is 11: Sports / Football 

ID=show_byTopic(11,1)
""""
Continental Airlines flight 722 departs Houston George Bush International (IAH) on-time at 8:33PM Gate C-27 and arrives Denver International (DEN) at 9:57PM. Your Orbitz record locator for this trip is OM7JOI.
""""

ID=show_byTopic(11,102)
""""
Dick, Here is my info: 2403 N. Washington #303 Dallas, TX 75204 214-812-5330 WORK 214-202-4596 MOBL 214-812-8908 FAX
""""

ID=show_byTopic(11,993)
""""
open 7am-6pm M-F
""""





