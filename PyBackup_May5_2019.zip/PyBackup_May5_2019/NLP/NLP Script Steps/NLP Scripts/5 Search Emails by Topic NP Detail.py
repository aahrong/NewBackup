# -*- coding: utf-8 -*-
"""
Created on Fri Feb 03 06:54:13 2017

@author: DLUSER3

Borrowed logic from BM's script "5 Search Emails by Topic" first to set up key functions

"""

import os

os.chdir("E:\Use Case Testing\NLP\BM")

import pandas as pd
emails_df_lda = pd.read_pickle('Emails_df_toke_lda.pkl')

# define functions
def show_byTopic(TopicNo,N,dframe=emails_df_lda):
    ID_list=dframe.index[dframe.Max1==TopicNo]
    print(dframe['content'][ID_list[int(N % len(ID_list))]])
    return ID_list
    
def pull_orig_message(example_set,topic,N,orig_dframe):
    msg_id=example_set.index[example_set['Max1']==topic][N]
    for i in range(0,len(orig_dframe)):
        if msg_id in orig_dframe['message'][i]:
            print ("Doc #: "+ str(i))
            print('-----------------------------------------------------------------')
            print(orig_dframe['message'][i])
            return

            
#Get Top 20 Examples for Each Topic
N=50
example_set_top=pd.DataFrame()
for topic in range(0,50):
    temp=emails_df_lda.ix[emails_df_lda['Max1']==topic,]
    temp=temp.sort_values([str(topic)],ascending=False)[:N]
    example_set_top=pd.concat([example_set_top,temp],axis=0)
            
# Show 20th example for Topic 19    
ID=show_byTopic(2,20,example_set_top)

# pull the full original message based on topic#, rank within topic            
pull_orig_message(example_set_top,1,1,emails_df_original)


# 14	Market Movements -- Mostly daily stock market run-down from INO.COM
ID=show_byTopic(14,1,example_set_top) # A forwarded email (does not have FWD in subject) with energy securities advice
ID=show_byTopic(14,2,example_set_top) # An email from security.console@enron.com warning of flooding from storm Allison
ID=show_byTopic(14,3,example_set_top) # Daily stock market run-down sent from INO.COM 
ID=show_byTopic(14,4,example_set_top) # Daily stock market run-down sent from INO.COM  
ID=show_byTopic(14,5,example_set_top)# Daily stock market run-down sent from INO.COM 
ID=show_byTopic(14,6,example_set_top)# Daily stock market run-down sent from INO.COM 
ID=show_byTopic(14,7,example_set_top)# Daily stock market run-down sent from INO.COM 
ID=show_byTopic(14,11,example_set_top)# Info on a hurricane approaching

pull_orig_message(example_set_top,14,11,emails_df_original)

# 18	News - Top 50 are mostly news articles or summaries of magazines
ID=show_byTopic(18,1,example_set_top) # List of countries where US has entered into income tax treaties
ID=show_byTopic(18,2,example_set_top) # An update on presidential polls
ID=show_byTopic(18,3,example_set_top) # A bunch of news clippings and headlines from newspapers
ID=show_byTopic(18,4,example_set_top) # A bunch of news clippings and headlines from newspapers
ID=show_byTopic(18,5,example_set_top) # An email promoting the next issue of The Washington Quarterly
ID=show_byTopic(18,10,example_set_top) # Subscription email
ID=show_byTopic(18,20,example_set_top) # Subscription email from the Economist
ID=show_byTopic(18,30,example_set_top) # Subscription email from www.sbsc.org
ID=show_byTopic(18,40,example_set_top) # Newsline email specific to ENRON sent from one employee to several others
ID=show_byTopic(18,48,example_set_top) # News brief from National Journal 
ID=show_byTopic(18,45,example_set_top) # News brief from National Journal 

pull_orig_message(example_set_top,18,40,emails_df_original)


# 22	Regulation / Legislation -- No subscription emails or spam in top! Really good examples
ID=show_byTopic(22,1,example_set_top) # News article shared by an employee about Cal-PX being subpoenaed over price spikes. 
ID=show_byTopic(22,2,example_set_top) # An email from Richard Shapiro to an external email with a statement on pressuring the FERC to enforce "robust competition"
ID=show_byTopic(22,3,example_set_top) # Email from employee w. weekly report of state(?) goverment activity?
ID=show_byTopic(22,4,example_set_top) # Email from emplyee notifing a commissions decision to vote down some proposed legislation
ID=show_byTopic(22,5,example_set_top) # email from employee notifying of passing of several bills
ID=show_byTopic(22,10,example_set_top) # employee emailing about an update on several CA energy issues including FERC and state government budget issues
ID=show_byTopic(22,15,example_set_top) # Statement issued in response to a lawsuit filed against Enron in San Diego !!!!!!
ID=show_byTopic(22,25,example_set_top) # Email update on senator support for some proposed legislation
ID=show_byTopic(22,35,example_set_top) # executive sumamry of hat just passed
ID=show_byTopic(22,45,example_set_top)

pull_orig_message(example_set_top,22,35,emails_df_original)


# 26	Financial - Mostly emails from NYMEX.COM notifying about general on the mercentile exchange
ID=show_byTopic(26,1,example_set_top) # employee email summary list of swaps, options, and futures prices  from NYMEX.COM
ID=show_byTopic(26,2,example_set_top) # employee email forwarding a message about various markets closing early from NYMEX.COM
ID=show_byTopic(26,3,example_set_top) # another employee email forwarding a message about various markets closing early from NYMEX.COM
ID=show_byTopic(26,4,example_set_top) # same as above....
ID=show_byTopic(26,5,example_set_top) # same as above....
ID=show_byTopic(26,6,example_set_top) # same as above....
ID=show_byTopic(26,15,example_set_top) # notice from NYMEX.COM about final settlment prices
ID=show_byTopic(26,25,example_set_top) # Email from employee with trade counts and volumes for a given date
ID=show_byTopic(26,35,example_set_top) # Notice from NYMEX.COM
ID=show_byTopic(26,45,example_set_top) # Notice from NYMEX.COM
ID=show_byTopic(26,40,example_set_top) # Notice from NYMEX.COM
ID=show_byTopic(26,41,example_set_top) # Notice from NYMEX.COM

pull_orig_message(example_set_top,26,35,emails_df_original)


# 30	Legal
ID=show_byTopic(30,1,example_set_top) # subscription from THELAW.NET
ID=show_byTopic(30,2,example_set_top) # Note from employee mentioning Panel... subject: aba program.... hard to tell what this is about... why is it so high here? Panel is not a high prob word
ID=show_byTopic(30,3,example_set_top) # Subscription from THELAW.NET
ID=show_byTopic(30,4,example_set_top) # Subscription from THELAW.NET
ID=show_byTopic(30,5,example_set_top)# Subscription from THELAW.NET
ID=show_byTopic(30,15,example_set_top)# Invitation to a meeting of Insurance Law Section
ID=show_byTopic(30,25,example_set_top)# Subscription from THELAW.NET
ID=show_byTopic(30,35,example_set_top)# Subscription from THELAW.NET
ID=show_byTopic(30,45,example_set_top)# Subscription from THELAW.NET

pull_orig_message(example_set_top,30,45,emails_df_original)


# 33	Financial
ID=show_byTopic(2,20,example_set_top)
ID=show_byTopic(2,20,example_set_top)
ID=show_byTopic(2,20,example_set_top)
ID=show_byTopic(2,20,example_set_top)
ID=show_byTopic(2,20,example_set_top)

# 38	Energy
ID=show_byTopic(38,1,example_set_top) # Forwarded news article about a major energy company offshore activity being inspected by the Public Utilities Commission
ID=show_byTopic(38,2,example_set_top) # Forwarded news article about a major energy company selling a power plant
ID=show_byTopic(38,3,example_set_top) # long list of powerplants and deatils about them
ID=show_byTopic(38,4,example_set_top) # short news brief about a power plant beginngin commercial operations
ID=show_byTopic(38,5,example_set_top) # news article about CA State discloses spot power  buys
ID=show_byTopic(38,15,example_set_top) # email detailing "WHAT WE KNOW" about a recent powerplant purchase by rival energy company
ID=show_byTopic(38,25,example_set_top) # online meeting invitation sent from PGE (National energy group) - no contents but a signature from PGE with lots of energy-type words....
ID=show_byTopic(38,35,example_set_top) # message from PGE about a contract being suspended.... again the signature probably triggered this
ID=show_byTopic(38,45,example_set_top)
ID=show_byTopic(38,40,example_set_top)

pull_orig_message(example_set_top,38,35,emails_df_original)


# 41	Financial
ID=show_byTopic(2,20,example_set_top)
ID=show_byTopic(2,20,example_set_top)
ID=show_byTopic(2,20,example_set_top)
ID=show_byTopic(2,20,example_set_top)
ID=show_byTopic(2,20,example_set_top)

# 48	Financial
ID=show_byTopic(2,20,example_set_top)
ID=show_byTopic(2,20,example_set_top)
ID=show_byTopic(2,20,example_set_top)
ID=show_byTopic(2,20,example_set_top)
ID=show_byTopic(2,20,example_set_top)

# 49	Purchase/Sale
ID=show_byTopic(49,1,example_set_top) # Daily inventory of 'real time deals'
ID=show_byTopic(49,2,example_set_top) # Daily inventory of 'real time deals'
ID=show_byTopic(49,5,example_set_top) # Daily inventory of 'real time deals'
ID=show_byTopic(49,10,example_set_top) # Daily inventory of 'real time deals'
ID=show_byTopic(49,15,example_set_top)  # Daily inventory of 'real time deals'
ID=show_byTopic(49,25,example_set_top)  # Daily inventory of 'real time deals'
ID=show_byTopic(49,35,example_set_top)  # Daily inventory of 'real time deals'
ID=show_byTopic(49,45,example_set_top)  # Daily inventory of 'real time deals'
ID=show_byTopic(49,48,example_set_top)  # Daily inventory of 'real time deals'

pull_orig_message(example_set_top,49,5,emails_df_original)



#Get 20 Random Examples for Each Topic
import random
random.seed(1000)
N=30
example_set=pd.DataFrame()
for topic in range(0,50):
    temp=emails_df_lda.ix[emails_df_lda['Max1']==topic,]
    random_index = random.sample(temp.index, N)
#    temp=temp.sort_values([str(topic)],ascending=False)[:N]
    example_set=pd.concat([example_set,temp.ix[random_index]],axis=0)

# Show 20th example for Topic 19    
ID=show_byTopic(19,20,example_set)
# pull the full original message based on topic#, rank within topic            
pull_orig_message(example_set,22,1,emails_df_original) #No - this is a schedule for a conference
pull_orig_message(example_set,22,2,emails_df_original) #Yes - a notice about a planned tariff they want to protest
pull_orig_message(example_set,22,3,emails_df_original) #NA - newsletter
pull_orig_message(example_set,22,4,emails_df_original) #NA - newsletter
pull_orig_message(example_set,22,5,emails_df_original) #NA - newsletter 
pull_orig_message(example_set,22,6,emails_df_original) #Yes - a forwarded note about new proposed regulation and the FERC
pull_orig_message(example_set,22,7,emails_df_original) #Yes - this is commentary on an article regarding CA regulations
pull_orig_message(example_set,22,8,emails_df_original) #kind of - this is a weekly report which summarizes key info from several sources including regulations
pull_orig_message(example_set,22,9,emails_df_original) #Yes - this is an update on legislation tha tjust passed
pull_orig_message(example_set,22,10,emails_df_original) #yes - talking about a bill / FERC / legislation
pull_orig_message(example_set,22,11,emails_df_original) #yes - press release from governor talking about legilsation
pull_orig_message(example_set,22,12,emails_df_original) #yes - this is asking for thoughts on a legal brief
pull_orig_message(example_set,22,13,emails_df_original) #yes - this is an update on legislations
pull_orig_message(example_set,22,14,emails_df_original) #yes - this is aquestion about a judge's ruling
pull_orig_message(example_set,22,15,emails_df_original) #yes - a note confirming receipt of an agreement related to some memorandum of public records law
pull_orig_message(example_set,22,16,emails_df_original) #no - this is about ISDA and the stock market
pull_orig_message(example_set,22,17,emails_df_original) #yes - summary of some legislation
pull_orig_message(example_set,22,18,emails_df_original) #yes - summary of some legislation
pull_orig_message(example_set,22,19,emails_df_original) #yes - commentary on filing to the FERC
pull_orig_message(example_set,22,20,emails_df_original) #kind of... blank email from a congressman
# of 20 emails, 2 nos, 3 NAs, kind ofs, 15 yes = 15/17 = 88% accuracy

pull_orig_message(example_set,38,1,emails_df_original) #No - this should fall under regulatory but it does 
pull_orig_message(example_set,38,2,emails_df_original) #Kind of - talks about executive order from Gov Davis about air pollution from power plants
pull_orig_message(example_set,38,3,emails_df_original) #Yes - talking about a project for constructions of new power supply
pull_orig_message(example_set,38,4,emails_df_original) #Yes - forwarded note from the NYT on power crisis in CA
pull_orig_message(example_set,38,5,emails_df_original) # Kind of - discusses regulations specific to energy emissions
pull_orig_message(example_set,38,6,emails_df_original) #Yes - forwarding of a news article about Harrah's signing a deal for energy with enron
pull_orig_message(example_set,38,7,emails_df_original) #Yes - energy company info in a newsline email
pull_orig_message(example_set,38,8,emails_df_original) #Yes - instructions for running a plant and to sell for the best price possible
pull_orig_message(example_set,38,9,emails_df_original) #Yes - article about CA pipeline expansion
pull_orig_message(example_set,38,10,emails_df_original) #Yes - article on the effect of FERC prices on energy supply
# of 10 emails, 1 nos, 2 kind ofs, 7 yes = 7/8 = 87% accuracy



pull_orig_message(example_set,14,8,emails_df_original)


