from os import listdir
import pandas
from nltk import RegexpTokenizer
from nltk.corpus import stopwords
import gensim

def get_documents(dir):
    docLabels = [f for f in listdir(dir) if f.endswith('.txt')]
    data = []
    docs = []
    df = pandas.DataFrame()
    for doc in docLabels:
        data.append((dir + doc, 'r'))
    for item in data:
        file = open(item[0], item[1])
        tmp_file = file.read()
        docs.append(tmp_file)
    df = df.append(docs)
    df = df.rename(columns={0: 'Documents'})
    return df

def pre_process(data):
   new_data = []
   tokenizer = RegexpTokenizer(r'\w +')
   stopword_set = set(stopwords.words('english'))
   for d in data:
      new_str = d.lower()
      dlist = tokenizer.tokenize(new_str)
      dlist = list(set(dlist).difference(stopword_set))
      new_data.append(dlist)
   return new_data

class LabeledLineSentence(object):
    def __init__(self, doc_list, labels_list):
        self.labels_list = labels_list
        self.doc_list = doc_list
    def __iter__(self):
        for idx, doc in enumerate(self.doc_list):
              yield gensim.models.doc2vec.TaggedDocument(doc,[self.labels_list[idx]])

def model_wrapper(iterator):
    model = gensim.models.Doc2Vec(size=300, min_count=0, alpha=0.025, min_alpha=0.025)
    model.build_vocab(iterator)
    # training of model
    for epoch in range(100):
        print('iteration' + str(epoch + 1))
        model.train(iterator)
        model.alpha -= 0.002
        model.min_alpha = model.alpha
        model.train(iterator)
    # saving the created model
    model.save('doc2vec.model')
    return model


