# -*- coding: utf-8 -*-
"""
Created on Tue Jan 31 17:09:18 2017

@author: DLUSER3
"""

#Import initial necessary packages
import os, sys, email
import numpy as np 
import pandas as pd
# Plotting
import matplotlib.pyplot as plt
%matplotlib inline
import seaborn as sns; sns.set_style('whitegrid')
#import plotly
#plotly.offline.init_notebook_mode()
#import plotly.graph_objs as go
#import wordcloud 

#comment to test if I can edit this file

# NLP
from nltk.tokenize.regexp import RegexpTokenizer


#################################################################################################
#################################################################################################
##
## Incorporate LSA
##
##################################################################################################

from gensim import corpora, models, utils
import logging
logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)

corpus = corpora.MmCorpus("E:/Use Case Testing/NLP/BM/corpus.mm")
id2word = corpora.Dictionary.load("E:/Use Case Testing/NLP/BM/dictionary.dict")

lsi = models.LsiModel(corpus, id2word=id2word, num_topics=2, chunksize=1, distributed=False, nthreads=10)

#lsi = gensim.models.LsiModel(corpus_tfidf, id2word=dictionary, num_topics=2)



lda_50=models.LdaModel.load('E:\Use Case Testing\NLP\BM\lda_model_50.model')
corpus=corpora.MmCorpus('E:\Use Case Testing\NLP\BM\corpus.mm')

topics = lda_50[corpus]

from gensim.matutils import corpus2dense

TopicMatrix = corpus2dense(topics, num_terms = 50)

df_main = pd.DataFrame(df_emails.ID)
for i in range(0,len(text)):
    df_main['topic' + str(i+1)] = text[i]
df_main.to_csv("LDA200_Doc2Topicdf_20170130.csv")



