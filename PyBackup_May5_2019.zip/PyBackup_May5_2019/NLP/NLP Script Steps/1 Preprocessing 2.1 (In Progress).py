"""
Created on Thu Feb 02 01:22:29 2017

This script is used to preprocess the email datast.

@author: mallabi
"""
#-----------------------------------------------------------------------------
#IMPORT initial necessary packages
#-----------------------------------------------------------------------------
import os
import re
import pandas as pd
import seaborn as sns; sns.set_style('whitegrid')
from datetime import datetime

#Custom Functions
path = "E:\Use Case Testing\NLP\BM\Script\Function"
os.chdir(path)
import Fx_String_Search as string_search
import Fx_Email_Extract as email_extract

#-----------------------------------------------------------------------------
#Create DateTime tags for output file names
#-----------------------------------------------------------------------------
date_object = datetime.now()
current_date = date_object.strftime('%Y-%m-%d')
current_time = date_object.strftime('%H%M%S')
filename = "output_"+ str(current_date) + "(" + str(current_time) + ")"
output_fold = "E:\Use Case Testing\NLP\BM\Output"
print(filename)

#-----------------------------------------------------------------------------
#IMPORT raw data file
#-----------------------------------------------------------------------------
emails_df = pd.read_csv("E:/Use Case Testing/NLP/Raw Data/emails.csv")
print('SHAPE OF THE DATAFRAME:', emails_df.shape) 
emails_df.head()

#Each email looks like this
print(emails_df['message'][0])
print(emails_df['message'][115])

#Create a copy of dataframe; This view is easier to look at messages
emails_df_original = emails_df.copy(deep=True)

##Parsing emails into separate,readable formats and removing duplicates
emails_df = email_extract.preprocess_email(emails_df) 

#Limit dataset to 2000-2001
emails_df = emails_df[(emails_df['Date'].dt.year == 2000)|
                      (emails_df['Date'].dt.year == 2001)]

# Find number of unique values in each columns
print('SHAPE OF THE TRANSFORMED DATAFRAME:', emails_df.shape)  

#Generate Frequency
pd.value_counts(emails_df.Email_Group)
pd.value_counts(emails_df.Email_Group2)

#Save a copy of dedup dataframe before additional preprocessing
emails_df_deduped = emails_df.copy(deep=True)


#---------------------------------------------------------------------------------------  
##Helper Functions
#---------------------------------------------------------------------------------------
#Function to find string between two strings
def find_between(s, first, last):
    first = first.lower()
    last = last.lower()
    try:
        start = s.lower().index( first ) + len( first )
        end = s.lower().index( last, start )
        return s[start:end]
    except ValueError:
        return ""

#Function to remove encoded message from attachments
def clean_attach_encoding(content):
    bound_id = ['boundary=', '_=']
    for first in bound_id:
        if content.find(first) >= 0:
            last = ' ' #This has been changed from '\n'
            bnd = find_between(content, first, last)
            bnd = bnd.replace('--', '').replace('"', '')
            print(bnd)
            if len(bnd) > 5:
                import re
                bnd = re.sub("\n", "", bnd)
                bnd = re.sub('["{}]', "", bnd)
                content = content.split(bnd)
            
                parts = []
                for i in content:
                    if "Content-Disposition: attachment;" not in i:
                        parts.append(i)
                parts = ''.join(parts)
                parts = re.sub("[\n]+", "\n", parts).strip()
                content = parts
    return content

###---------------------------------------------------------------------------
#PRE-PROCESSING STEP -- CLEANING EMAIL BODY
###---------------------------------------------------------------------------
def clean_content(emails_df):
    #1. Remove URL addresses
    emails_df['content'] = emails_df['content'].apply(lambda x: 
                                                email_extract.remove_urls(x))
    
    #2. Remove Email MIME info in Replied or Forwarded messages 
    rem_words = ['Date: ', 'To:', 'From: ', 'cc: ', 'bcc: ', 
             'Subject: ', 'Sent: ', '-Original Message-',
             'Forwarded by', 'Importance: ', 'X-From:', 
             'X-To:', 'X-cc:', 'X-bcc:', 'X-Folder: ', 
             'X-Origin: ', 'X-FileName: ', 'X-Mailer:']
    emails_df['content'] = emails_df['content'].apply(lambda x: email_extract.remove_email_noncontent(x, rem_words))

    #3. Remove Selected String based on observation of data
    rem_string = ['/HOU/', '/NA/', '/PDX/', '/CAL/', '/Corp/']
    for word in rem_string:
        emails_df['content'] = emails_df['content'].apply(lambda x: x.replace(word, ' '))
            
    #4. Remove Email addresses from Email Body Content
    emails_df['content'] = emails_df['content'].apply(lambda x: 
                                                    email_extract.remove_email_addresses(x))
    
    #5. Cleaning for HTML Codes
        #1 replace "> >" with spaces
        #2 replace "\n>" with spaces
        #3 replace all tabs, newlines and other "whitespace-like" characters
    emails_df['content'] = emails_df['content'].apply(lambda x: x.replace("> >", ""))
    emails_df['content'] = emails_df['content'].apply(lambda x: x.replace("\n>", " "))
    emails_df['content'] = emails_df['content'].apply(lambda x: re.sub( '\s+', ' ', x).strip())

    #Applying BeautifulSoup to remove HTML tags <>
    from bs4 import BeautifulSoup
    import warnings
    warnings.filterwarnings("ignore", category=UserWarning, module='bs4')
    #Noticed the tags were not removed completely on first pass so repeating the parsing twice
    emails_df['content'] = emails_df['content'].apply(lambda x: BeautifulSoup(BeautifulSoup(x, 'html.parser').get_text(), 'html.parser').get_text())

    #6. Cleaning up for attachments
    emails_df['Has_Attachment'] = 0
    emails_df['Has_Attachment'] = emails_df['content'].apply(lambda x: 1 if ("content-disposition: attachment" in x.lower()) else 0)
    emails_df['content'][emails_df.Has_Attachment == 1] = emails_df['content'][emails_df.Has_Attachment == 1].apply(lambda x: clean_attach_encoding(x))

    #7. Cleaning the MIME residue from attachments
    rem_words = ['Content-Type: ','Content-Disposition: ','Content-Description: ',
                 'Content-Transfer-Encoding: ','Message-ID: ','MIME-Version: ',
                 'Received:','Mime-Version:']
    emails_df['content'] = emails_df['content'].apply(lambda x: email_extract.remove_email_noncontent(x,rem_words))

    #8. Exclude certain emails
    emails_df_exclude1 = emails_df[emails_df.From_open == "no.address@enron.com"]
    print("Dropped " + str(len(emails_df_exclude1)) + " emails sent by no.address\
          @enron.com. This includes emails such as Enron Recruitment Tech, OMNI Notes, \
          Virus Alerts etc")
    emails_df = emails_df[emails_df.From_open != "no.address@enron.com"]
    
    return emails_df

#Clean content of the email
emails_df=clean_content(emails_df)    

#Generate Frequency
print ('After DEDUPING and EXCLUDING SELECTED EMAILS')
pd.value_counts(emails_df.Email_Group)
pd.value_counts(emails_df.Email_Group2)

#=============================================================================
#Prepare input for modeling, limiting to Dedeuped set and Original emails only
emails_df = emails_df[emails_df['Email_Group'] == 'Original']
    



#=============================================================================
#PRE-PROCESSING STEP -- REVIEW EXAMPLES PRE AND POST CLEANING
#=============================================================================
#-----------------------------------------------------------------------------
#1. Remove URL addresses
#-----------------------------------------------------------------------------
a1 = string_search.search_content(emails_df_deduped, "http", 1, True)
print("Estimated number of documents with http addresses in the email\
 content: " + str(len(a1)))
#Some examples
for i in range(0, 3):
    print emails_df_deduped['content'][a1[i]]
    print('===============================================================')

print('===============================================================')
print("AFTER CLEANING")
print('===============================================================')

a2 = string_search.search_content(emails_df, "http", 1, True)
print("Estimated number of documents with http addresses in the email\
 content: " + str(len(a2)))
#Some examples
for i in range(0, 3):
    print emails_df['content'][a1[i]]
    print('===============================================================')    
    
#-----------------------------------------------------------------------------
#2. Remove Email MIME info in Replied or Forwarded messages
#-----------------------------------------------------------------------------
a1 = string_search.search_content(emails_df_deduped, "To:" , 1, True)
print("Estimated number of documents with http addresses in the email\
 content: " + str(len(a1)))
#Some examples
b1 = emails_df_deduped.ix[a1[100], :]
print(b1['content'])

b1 = emails_df_deduped.ix[a1[150], :]
print(b1['content'])

b1 = emails_df_deduped.ix[a1[300], :]
print(b1['content'])

print('===============================================================')
print("AFTER CLEANING")
print('===============================================================')

a2 = string_search.search_content(emails_df, "To:" , 1, True)
print("Estimated number of documents with http addresses in the email\
 content: " + str(len(a2)))

#Some examples
b1 = emails_df.ix[a1[100], :]
print(b1['content'])

b1 = emails_df.ix[a1[150], :]
print(b1['content'])

b1 = emails_df.ix[a1[300], :]
print(b1['content'])
#---------------------------------------------------------------------------------------
#5. Cleaning for HTML Codes
#---------------------------------------------------------------------------------------
#Example of email with HTML code - 22492435.1075858965006.JavaMail.evans@thyme(Doc # on original dataset: 290318)
a5 = string_search.search_content(emails_df_deduped, "<td", 1, True)
print("Estimated number of documents with HTML tags in the email content: " + str(len(a5)))

#Some examples
b1 = emails_df['content'][a5[1]]
print(b1)

#Remove specific symbols before apply HTML cleaning
b2 = emails_df['content'][a5[1]]
print(b2)

#Message after removing HTML tags
c1 = emails_df['content'][a5[1]]
print(c1)

#---------------------------------------------------------------------------------------
##6. Cleaning up for attachments
#---------------------------------------------------------------------------------------
#Generate Frequency
a = pd.value_counts(emails_df.Has_Attachment)
print("Estimated number of documents with attachments: " + str(a.values[1]))

#---------------------------------------------------------------------------------------
## Cleaning the encoded messages from attachments
#---------------------------------------------------------------------------------------
#Examples
doc_ID = emails_df.ID[emails_df.Has_Attachment == 1]

#Reviewing some examples, original message and cleaned up versions
for i in range(0, 5):
    msg = string_search.show_orig_message(doc_ID.index[i])
    print(msg)
    try:
        input("Press enter to continue")
    except SyntaxError:
        pass
    print("======================================================================")

for i in range(0, 5):
    msg = string_search.show_message(doc_ID.index[i])
    print(msg)
    try:
        input("Press enter to continue")
    except SyntaxError:
        pass
    print("======================================================================")



#---------------------------------------------------------------------------------------      

#Examples after parsing out the encoded comment
msg = emails_df['content'][emails_df.index == doc_ID[1]]
print(msg.values)

#---------------------------------------------------------------------------------------

#---------------------------------------------------------------------------------------
    
