# -*- coding: utf-8 -*-
"""
Created on Thu Feb 02 01:22:29 2017
@author: mallabi
"""

#=====================================================================================================
import os
import pandas as pd

os.chdir("E:\Use Case Testing\NLP\BM")
emails_df_lda = pd.read_pickle('Emails_df_toke_lda.pkl')
emails_df_original=pd.read_csv("E:/Use Case Testing/NLP/Raw Data/emails.csv")

#=====================================================================================================
#Creating Custom Functions
#=====================================================================================================
#-----------------------------------------------------------------------------------------------------
#Show examples of emails by Topic Number from LDA model
#-----------------------------------------------------------------------------------------------------
def show_byTopic(TopicNo,N,dframe=emails_df_lda):
    ID_list=dframe.index[dframe.Max1==TopicNo]
    print(dframe['content'][ID_list[int(N % len(ID_list))]])
    return ID_list

#-----------------------------------------------------------------------------------------------------
#Show original emails for the examples set by Topic Number from LDA model
#-----------------------------------------------------------------------------------------------------
def pull_orig_message(example_set,topic,N,orig_dframe):
    msg_id=example_set.index[example_set['Max1']==topic][N]
    for i in range(0,len(orig_dframe)):
        if msg_id in orig_dframe['message'][i]:
            print ("Doc #: "+ str(i))
            print('-----------------------------------------------------------------')
            print(orig_dframe['message'][i])
            return
            
#-----------------------------------------------------------------------------------------------------
#Show original emails using string search 
#-----------------------------------------------------------------------------------------------------            
def show_orig_byString(string,N,dframe,showTotMatch=False):
    if type(string)==str:
        string=[string]
    else:
        string=list(string)
    print('Emails Subjects with the string: '+str(string))
    j=1
    doc_ID=[]
    for i in range(0,len(dframe)):
        if any(word.lower() in (dframe['content'][i]).lower() for word in string):
            if j==N:
                print('Email #: '+str(j))
                print('Doc #: '+str(i))
                Msg_ID='Message-ID: '+ dframe.index[i]
                print(Msg_ID)
                print('-----------------------------------------------------------------')
                print("From: "+ dframe['From_open'][i])
                print("Subject: "+ dframe['Subject'][i])
                print("Body: "+ dframe['content'][i])
                print('-----------------------------------------------------------------')
                print(Msg_ID) 
                Msg_ID='Message-ID: '+ dframe.index[i]
                #print (tokenized[i])
                if not showTotMatch:
                    return
            j=j+1
            doc_ID.append(dframe.index[i])
    print('-----------------------------------------------------------------')               
    print ('Showing Document ' + str(N)+ ' of Total Documents: '+str(j-1))      
    return doc_ID

#-----------------------------------------------------------------------------------------------------
#Get Message-ID where columns is equal to string/list of strings
#-----------------------------------------------------------------------------------------------------   
def get_data_string(string,column,dframe):
    if type(string)==str:
        string=string.split()
    else:
        string=list(string)
    index=dframe[column].apply(lambda x: True if (any(v in x for v in string)) else False)
    return dframe[index]

#-----------------------------------------------------------------------------------------------------
#Show contents of the dataframe, one-by-one
#-----------------------------------------------------------------------------------------------------   
def show_content(dframe):
    for i in range(0,len(dframe)):
        msg=dframe['content'][i]
        try:
            print('----------------------------------------------------------------------------')
            print("Display "+str(i+1)+" of "+str(len(dframe))+" Documents.")
            print(msg)
            input("Press enter to continue")
        except SyntaxError:
            pass
        print("======================================================================")
#=====================================================================================================

#----------------------------------------------------------------------
#Search for examples by Topics
#----------------------------------------------------------------------

#Example 1: Find 20th example where primary topic is 19.
ID=show_byTopic(19,20)

#Example 2: Find first example where primary topic is 49.
ID=show_byTopic(49,1)

#Example 3: Find first example where primary topic is 13.
ID=show_byTopic(13,1)

#----------------------------------------------------------------------
##Get Top 20 Examples for Each Topic
#----------------------------------------------------------------------

N=20
example_set_top=pd.DataFrame()
for topic in range(0,50):
    temp=emails_df_lda.ix[emails_df_lda['Max1']==topic,]
    temp=temp.sort_values([str(topic)],ascending=False)[:N]
    example_set_top=pd.concat([example_set_top,temp],axis=0)
    
   
# Show 20th example for Topic 19    
ID=show_byTopic(2,20,example_set_top)

pull_orig_message(example_set_top,1,1,emails_df_original)

filepath = "E:\Use Case Testing\NLP\BM\Output\Top20emails_LDA50Topic.csv"
example_set_top.to_csv(filepath, encoding='utf-8',delimiter='\t')
#----------------------------------------------------------------------
#Get 20 Random Examples for Each Topic
#----------------------------------------------------------------------
import random
random.seed(1000)
N=20
example_set=pd.DataFrame()
for topic in range(0,50):
    temp=emails_df_lda.ix[emails_df_lda['Max1']==topic,]
    random_index = random.sample(temp.index, N)
#    temp=temp.sort_values([str(topic)],ascending=False)[:N]
    example_set=pd.concat([example_set,temp.ix[random_index]],axis=0)

filepath = "E:\Use Case Testing\NLP\BM\Output\Random20emails_LDA50Topic.csv"
example_set.to_csv(filepath, encoding='utf-8',delimiter='\t')

#----------------------------------------------------------------------
# Show 20th example for Topic 19    
#----------------------------------------------------------------------
ID=show_byTopic(19,20,example_set)

#----------------------------------------------------------------------
# Show 1st example for Topic 1
#----------------------------------------------------------------------
path="E:\Use Case Testing\NLP\BM\Script\Function"
os.chdir(path)
import Fx_String_Search as String_search

topic_no=8
for i in range(0,N):
    ID=String_search.show_orig_byTopic(topic_no,i,example_set,emails_df_original)
    try:
        print('----------------------------------------------------------------------------')
        print("Display "+str(i+1)+" of "+str(N)+" Documents for Topic "+str(topic_no))
        input("Press enter to continue")
    except SyntaxError:
        pass
    print("======================================================================")

    
#----------------------------------------------------------------------
#Identify list serves emails
#----------------------------------------------------------------------
keyword_list=["unsubscribe from",
"to unsubscribe",
"remove your email address",
"not receive future e-mail",
"not to receive future e-mail",
"To be removed permanently from our mailing list",
"prefer not to receive these types of offers",
"To be removed from our mailing list",
"do not wish to receive e-mail from us in the future",
"UNSUBSCRIBE in the subject line",
"you wish to have removed",
"to be removed from the mailing list",
"Replace the Subject field with the word REMOVE",
"do not wish to receive future e-mails",
"wish to be excluded from  our future mailings",
"click on the unsubscribe button",
'reply with the words "unsubscribe',
'if you wish to unsubscribe',
'put your email address in body of email to get removed',
'update your request to unsubscribe',
'To unsubscribe send a blank email to',
'TO UNSUBSCRIBE OR CHANGE your subscription'
]    
  
#a5=show_orig_byString("to unsubscribe",15,emails_df_lda,True)

a5=show_orig_byString(keyword_list,1,emails_df_lda,True)
user_list=emails_df_lda['From_open'][emails_df_lda.index.isin(a5)]

#Assign ListServe
emails_df_lda['Possible_ListServe']=emails_df_lda.apply(lambda x: "Yes" if ((x['From_open'] in set(user_list)) and (x['Email_Group2']=="Non-Enron Email")) else "",axis=1)


#Creating a sample Dataset
df_test=emails_df_lda[emails_df_lda['Email_Group2']=='Non-Enron Email']
df_test=df_test[df_test['Possible_ListServe']=='']
df_test=list(set(df_test['From_open']))

df_test_2=df_test[20:40]

for i,word in enumerate(df_test_2):
    msg=emails_df_lda['content'][emails_df_lda['From_open']==word]
    try:
        print('----------------------------------------------------------------------------')
        print("Display "+str(i+1)+" of "+str(len(df_test))+" Documents. Email Address: "+str(word))
        print(msg.values)
        input("Press enter to continue")
    except SyntaxError:
        pass
    print("======================================================================")

    

#----------------------------------------------------------------------
#Identify ENRON Execs
#----------------------------------------------------------------------
select_email=[
'enw.office.of.the.chairman@enron.com',
'ect.chairman@enron.com',
'office.chairman-@enron.com',
'ees.chairman@enron.com',
'chairman.eim@enron.com',
'chairman.ets@enron.com',
'enron.chairman@enron.com',
'chairman.enron@enron.com',
'chairman.ews@enron.com',
'chairman.office@enron.com',
'chairman.ken@enron.com',
'office.chairman@enron.com',
'ken.lay-.chairman.of.the.board@enron.com',
'chairman.ees@enron.com',
'chairman@enron.com',
'klay@enron.com']


select_email=['ken.lay-.chairman.of.the.board@enron.com','klay@enron.com','chairman@enron.com']

select_email=['phillip.m.love@enron.com','phillip.love@enron.com']
aa=get_data_string(select_email,'From_open',emails_df_lda)

import datetime as dt
aa=aa[aa['Date'].dt.year==2001]

index=df_network['Message-ID'][(df_network['To_2']=='Phillip Love') & (df_network['From']=='Eric Bass') &(df_network['Date'].dt.year==2001)&(df_network['Date'].dt.month==1)]
print(len(index))

for i in index:
    aa=show_orig_message(i,emails_df_original)
    print(aa)

aa=get_data_string(index,'Message-ID',df_network)
