#====================================================================================================
"""
Created on Mon Jan 30 22:55:56 2017
@author: mallabi
"""
#====================================================================================================
#Program to use LDA model results to add topic distribution to documents and create the 
#top 3 topics for each document
#====================================================================================================
import pandas as pd
import numpy as np
import os

from gensim.corpora import MmCorpus, Dictionary
from gensim import models, corpora, matutils

os.chdir("E:\Use Case Testing\NLP\BM")

lda20=models.LdaModel.load('lda_model_20.model')
lda50=models.LdaModel.load('lda_model_50.model')

corpus=MmCorpus('corpus.mm')
dictionary=Dictionary.load('dictionary.dict')

#for i in range(0,len(text)):\
#    df_main['topic' + str(i+1)] = text[i]
#
#df_main.to_csv("LDA200_Doc2Topicdf_20170130.csv")


#Create Dense Matrix from Sparse Corpus
from time import time
t0 = time()

Doc_top_mat_20 = matutils.corpus2dense(lda20[corpus],num_terms = 20)
Doc_top_mat_50 = matutils.corpus2dense(lda50[corpus],num_terms = 50)

print("Analysis done in %0.3fm" %((time() - t0)/60))

#df = pd.read_csv('E:\Use Case Testing\NLP\Network\LDA200_Doc2Topicdf_20170130.csv')


#Get top 3 topics for each document
no_terms=20
df_20=pd.DataFrame(Doc_top_mat_20)
df_20=df_20.T

no_terms=50
df_50=pd.DataFrame(Doc_top_mat_50)
df_50=df_50.T

def create_doc_top_matrix(df,no_terms):
    
    df['Max1'] = df.ix[:,0:no_terms].idxmax(axis=1)
    
    df['Range1']=df['Max1'].apply(lambda x:df.columns[0:no_terms].drop(x))
    df['Max2']=map(lambda x,y: df.ix[x,y].idxmax(axis=1),df['Range1'].index,df['Range1'])
    
    df['Range2']=map(lambda x,y: x.drop(y),df['Range1'],df['Max2'])
    df['Max3']=map(lambda x,y: df.ix[x,y].idxmax(axis=1),df['Range2'].index,df['Range2'])
    
    df.drop(['Range1','Range2'], axis=1,inplace=True)    
    df.head()
    
    D1=pd.DataFrame(pd.value_counts(df['Max1'],sort='Max1'))
    D2=pd.DataFrame(pd.value_counts(df['Max2'],sort='Max2'))
    D3=pd.DataFrame(pd.value_counts(df['Max3'],sort='Max3'))
    
    
    D =pd.concat([D1, D2,D3], axis=1)
    return D,df

#D_20,=create_doc_top_matrix(df_20,20)
D_50,df_50=create_doc_top_matrix(df_50,50)

df_50['Message-ID']=emails_df_toke.index
df_50=df_50.set_index('Message-ID')

emails_df_lda=pd.concat([emails_df_toke,df_50],axis=1)

#Save Files
import pandas as pd
#emails_df_lda.to_pickle('Emails_df_toke_lda.pkl')
