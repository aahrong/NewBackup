# -*- coding: utf-8 -*-
"""
Created on Fri Mar 03 02:15:48 2017

@author: mallabi
"""
#-------------------------------------------------------------------------------------------------------------
#Import initial necessary packages
#-------------------------------------------------------------------------------------------------------------
import os, sys, email
import numpy as np 
import pandas as pd
# Plotting packages
import matplotlib.pyplot as plt
get_ipython().magic('matplotlib inline')
import seaborn as sns; sns.set_style('whitegrid')

#-------------------------------------------------------------------------------------------------------------
#import raw data file
#-------------------------------------------------------------------------------------------------------------
emails_df = pd.read_csv("E:/Use Case Testing/NLP/Raw Data/emails.csv")
#emails_df=emails_df[:10000]
print('shape of the dataframe:', emails_df.shape) 
emails_df.head()

#Each email looks like this
print(emails_df['message'][0])
print(emails_df['message'][1])

#Create a copy of dataframe; This view is easier to look at messages
#emails_df_original=emails_df.copy(deep=True)


#-------------------------------------------------------------------------------------------------------------
## Helper functions
#-------------------------------------------------------------------------------------------------------------
def get_text_from_email(msg):
    '''To get the content from email objects'''
    parts = []
    for part in msg.walk():
        if part.get_content_type() == 'text/plain':
            parts.append( part.get_payload() )
    return ''.join(parts)

def split_email_addresses(line):
    '''To separate multiple email addresses'''
    if line:
        addrs = line.split(',')
        addrs = frozenset(map(lambda x: x.strip(), addrs))
    else:
        addrs = None
    return addrs
#-------------------------------------------------------------------------------------------------------------
##Parsing emails into separate,readable formats
#-------------------------------------------------------------------------------------------------------------

# Parse the emails into a list email objects
messages = list(map(email.message_from_string, emails_df['message']))
emails_df.drop('message', axis=1, inplace=True)

# Get fields from parsed email objects
keys = messages[0].keys()
for key in keys:
    emails_df[key] = [doc[key] for doc in messages]

# Parse content from emails
emails_df['content'] = list(map(get_text_from_email, messages))

# Split multiple email addresses
emails_df['From'] = emails_df['From'].map(split_email_addresses)
emails_df['To'] = emails_df['To'].map(split_email_addresses)

# Extract the root of 'file' as 'user'
emails_df['user'] = emails_df['file'].map(lambda x:x.split('/')[0])
del messages

emails_df.head()

# Find number of unique values in each columns
print('shape of the dataframe:', emails_df.shape)  
for col in emails_df.columns:
    print(col, emails_df[col].nunique())

#Set index and drop useless columns
emails_df = emails_df.set_index('Message-ID').drop(['file','Mime-Version','Content-Type','Content-Transfer-Encoding'],                                                  axis=1)

#Parse datetime
emails_df['Date'] = pd.to_datetime(emails_df['Date'], infer_datetime_format=True)
emails_df.dtypes

#Make a copy before deduping
#emails_df_copy=emails_df.copy(deep=True)

#Restore point
#emails_df=emails_df_copy.copy(deep=True)
     

#Flag Duplicate emails
#Group emails by From, Date and content variables
emails_df=pd.DataFrame(emails_df)
emails_df["ID"]=emails_df.groupby(["From","Date","content"]).grouper.group_info[0]
emails_df.sort(["ID"], ascending = True, inplace = True)

#Generate Frequency
a=pd.value_counts(emails_df.ID).head()

#Example of duplicate emails
emails_df[emails_df.ID==a.index[0]].head()

#Create additional columns
#Variables to include 'From' email address out of frozenset and length of content
emails_df['From_open']=emails_df['From'].map(lambda x: next(iter(x)))
emails_df['To_open']=emails_df['To'].map(lambda x: list(x) if x!=None else [None])

emails_df['Content_length']=emails_df['content'].apply(lambda x: len(str.split(x)))

#Store total rows before deduping
a=len(emails_df)

#Email group - (Original/Reply/Forwarded)
emails_df['Email_Group']=""
emails_df['Email_Group']=emails_df['Subject'].apply(lambda x: 'Reply' if (x.strip().lower()[:3]=="re:") else ('Forwarded' if (x.strip().lower()[:4]=="fwd:") else 'Original'))

#Email Group2 - (Enron/External)
emails_df['Email_Group2']=""
emails_df['Email_Group2']=emails_df['From_open'].apply(lambda x: 'Enron Email' if ("@enron.com" in x) else ('Non-Enron Email'))

#Generate Frequency
pd.value_counts(emails_df.Email_Group)
pd.value_counts(emails_df.Email_Group2)

#Drop duplicate emails, keep the first row. EMAILS HAVE DIFFERENT USERS
emails_df=emails_df.drop_duplicates(subset="ID",keep='first')
b=len(emails_df)

print ('Dropped emails due to duplication:',a-b)

#Generate Frequency
pd.value_counts(emails_df.Email_Group)
pd.value_counts(emails_df.Email_Group2)

#-------------------------------------------------------------------------------------------------------------------------
#Define functions for flagging and analysing email threads
#-------------------------------------------------------------------------------------------------------------------------

#Remove list of selected strings
def rem_strings(string):
    rem_list=['re:','fwd:','fw:','(fwd)']
    for key in rem_list:
        if string.strip().lower().startswith(key):
            string=string.lower().replace(key,'').strip()
            rem_list.remove(key)
    return string

#Remove all re/fwd strings from subject line#Multiple loops to account for different orders when 2 or more strings may occur    
def clean_subject(string):
    string=rem_strings(rem_strings(rem_strings(string))).lower()
    return string

#Reverse String
def rev_string(string):
    return (string[::-1]).strip()

#Keep letters only
def keep_letters(string):
    return ''.join(filter(str.isalpha, string))

#ID emails with same subject line
def tag_threads_Subject(dataset):
    df=dataset.copy(deep=True)
    df['Subject_Clean']=df['Subject'].apply(lambda x: clean_subject(x))
    df['Subject_Clean_Rev']=df['Subject_Clean'].apply(lambda x:rev_string(x))
    df.sort_values('Subject_Clean_Rev',inplace=True)
    df["Thread_ID"]=df.groupby(["Subject_Clean"]).grouper.group_info[0]

    #Add field for counts of email
    counts=pd.DataFrame(pd.value_counts(df['Thread_ID'].values, sort=False))
    counts.reset_index(level=0, inplace=True)
    counts.columns=['Thread_ID','Thread_Count'] 
    
    df=df.reset_index()
    df=df.merge(counts,how='left', left_on='Thread_ID',right_on='Thread_ID')
    
    del df['Subject_Clean_Rev']
    return df

#ID emails with subset of content = Limits content to letters, reverse contents, sort by content to identify if messages are subset of one below it
def tag_threads_Content(dataset):
    df=dataset.copy(deep=True)
    df['Thread_content_ID']=10e10
    df['Content_Short_Rev']=df['content'].apply(lambda x:(rev_string(keep_letters(x))))
    df.sort_values('Content_Short_Rev',inplace=True)
    
    for i in range(1,len(df)):
        first_string=df['Content_Short_Rev'].iloc[i-1].lower()
        second_string=df['Content_Short_Rev'].iloc[i].lower()
        if first_string not in ['']:
                  if ((first_string in second_string)|(second_string in first_string)):
                      df['Thread_content_ID'].iloc[i]=min(df['ID'].iloc[i],df['ID'].iloc[i-1],df['Thread_content_ID'].iloc[i],df['Thread_content_ID'].iloc[i-1])
                      df['Thread_content_ID'].iloc[i-1]=df['Thread_content_ID'].iloc[i]
    #    del df['Content_Rev']
    df['Thread_content_ID']=df['Thread_content_ID'].apply(lambda x: -1 if (x==10e10) else x)
    
        #Add field for counts of email
    counts=pd.DataFrame(pd.value_counts(df['Thread_content_ID'].values, sort=False))
    counts.reset_index(level=0, inplace=True)
    counts.columns=['Thread_content_ID','Thread_content_ID_Count'] 
    
    df=df.reset_index()
    df=df.merge(counts,how='left', left_on='Thread_content_ID',right_on='Thread_content_ID')
    del df['Content_Short_Rev']
    return df

#ID emails with subset of content = Old algorithm with doube loops checking every emails below an email,TOO SLOW
def tag_threads_Content_old(dataset):
    df=dataset.copy(deep=True)
    df['Thread_content_ID']=10e10
    df['Content_Short']=df['content'].apply(lambda x:(keep_letters(x)))
    df.sort_values('Content_Short',inplace=True)
    
    for i in range(0,len(df)):
        for j in range(0,len(df)):
            if (i<j):
                first_string=df['Content_Short'].iloc[i].lower()
                second_string=df['Content_Short'].iloc[j].lower()
                if first_string not in ['']:
                    if ((first_string in second_string)|(second_string in first_string)):
                        prev_value=df['Thread_content_ID'].iloc[i]
                        df['Thread_content_ID'].iloc[i]=min(df['ID'].iloc[i],df['ID'].iloc[j],df['Thread_content_ID'].iloc[i],df['Thread_content_ID'].iloc[j])
                        df['Thread_content_ID'].iloc[j]=df['Thread_content_ID'].iloc[i]
                        if ((prev_value !=df['Thread_content_ID'].iloc[i]) & (prev_value!=10e10)):
                             df['Thread_content_ID']= df['Thread_content_ID'].apply(lambda x:  df['Thread_content_ID'].iloc[i] if (x==prev_value) else x)
    del df['Content_Rev']
    df['Thread_content_ID']=df['Thread_content_ID'].apply(lambda x: -1 if (x==10e10) else x)  
    return df

#Create Edge dataset
def edge_data(dataset):
    df_set=[]
    for i in range(0,len(dataset)):
        for val_to in (dataset['To_open'].iloc[i]):
            if val_to==None: val_to="None" 
            a=[dataset['From_open'].iloc[i],dataset['Date'].iloc[i],dataset['Subject'].iloc[i],dataset['content'].iloc[i],val_to]
            df_set.append(a)
            
    df_set=pd.DataFrame(df_set,columns=['From','Date','Subject','content','To'])
    #print(df_set.head())
    df_set['Edge']=list(zip(df_set['From'], df_set['To']))
    
    return df_set

#collapse dataset column into single list
def collapse(x):
    uniq = x.unique()
    if len(uniq) == 1:
        return uniq[0]
    else:
        return list(uniq)
        
#count number of times a string appears in a dataset column
def count_rows(dataset,string):
    a=0
    for i in range(0,len(dataset)):
        if (string in dataset[i]):
            a+= 1
    return a
    
def min_value(dataset,string,column):
    index=dataset['Participant'].apply(lambda x: string in x)
    return dataset[column][index].min()

def avg_value(dataset,string,column):
    index=dataset['From_open'].apply(lambda x: string in x)
    return dataset[column][index].mean()
    
#Count the order in which string appears in a dataset of emails
def get_email_order(dataset,lst,string):
    dataset.reset_index(inplace=True,drop=True)
    for i in range(0,len(dataset)):
        if (string in dataset[lst][i]):
            return (i+1)

#Pull examples using Thread_ID/Thread_content_ID
def get_example(dataset,column,ID):
    df=dataset[dataset[column]==ID]
    df=df[['ID','Message-ID','Date','From_open','To_open','Subject','content','Thread_ID','Thread_content_ID']]
    return df            
            
#-------------------------------------------------------------------------------------------------------------------------
#Create Stats within Thread
#-------------------------------------------------------------------------------------------------------------------------    
dataset=emails_df
Thread_content_ID=58846
sel_col='Thread_content_ID'

2559
threadID=121003

def create_thread_stats(dataset,sel_col,Thread_content_ID):
    df_set=dataset[dataset[sel_col]==Thread_content_ID]
    df_set=df_set.sort_values('Date')
    df_set.reset_index(level=0, inplace=True)
    
    df_set['From_open']=df_set['From'].map(lambda x: list(x) if x!=None else [None])
    df_set['To_open']=df_set['To'].map(lambda x: list(x) if x!=None else [None])    
    df_set['Participant']=df_set['From_open']+df_set['To_open']
    
    df_set['Date'] = pd.to_datetime( df_set['Date'], infer_datetime_format=True)    
    df_set['Time_Lapse']=df_set['Date'].apply(lambda x:x-df_set['Date'][0])
    df_set['Response_time']=df_set['Date']-df_set['Date'].shift(1)
    
#    df_set['Time_Lapse']=(df_set['Time_Lapse'].days*24*60)+(df_set['Time_Lapse'].seconds/60)
    
    
    originator=next(iter(df_set.loc[0,'From']))
    original_subject=df_set.loc[0,'Subject']
    
    import itertools
    contributors=set(df_set['From'].map(lambda x: next(iter(x))))
    recipients=set(list(itertools.chain.from_iterable(df_set['To'].map(lambda x: list(x) if x!=None else [None]))))
    participants=set(df_set['From'].map(lambda x: next(iter(x)))).union(set(list(itertools.chain.from_iterable(df_set['To'].map(lambda x: list(x) if x!=None else [None])))))
        
    df_part=pd.DataFrame(list(participants))
    df_part.columns=['Participant']
    df_part['Email_N']=df_part['Participant'].apply(lambda x: count_rows(df_set['Participant'],x))
    df_part=df_part.sort_index()
    df_part['EntryPoint']=df_part['Participant'].apply(lambda x: get_email_order(df_set,'Participant',x))
    df_part['TimeEntry']=df_part['Participant'].apply(lambda x: min_value(df_set,x,'Time_Lapse'))
    df_part.sort_values('EntryPoint',ascending=True,inplace=True)
    df_part['SenderN']=df_part['Participant'].apply(lambda x: count_rows(df_set['From'],x))
    df_part['ReceiverN']=df_part['Participant'].apply(lambda x: count_rows(df_set['To_open'],x))
    df_part['AvgResponseTime']=df_part['Participant'].apply(lambda x: avg_value(df_set,x,'Response_time'))
  
    
    print "Originator:",originator
    print "Original Subject:",original_subject
    print "Total number of emails:",len(df_set)
    print "Number of participant(s):",len(participants)

    print "Number of contributor(s):",len(contributors)
    print "Number of recipients(s):",len(recipients)
    print
    print(df_part)
    return df_set, df_part
#-------------------------------------------------------------------------------------------------------------------------
#Flag threads by Subject and Content
#-------------------------------------------------------------------------------------------------------------------------    
from time import time
t0 = time()
emails_df=tag_threads_Subject(emails_df) 
emails_df=tag_threads_Content(emails_df) 
print("Done in %0.3fs" %(time() - t0))


#Get counts of Threads
pd.value_counts(emails_df.Thread_ID)

Thread_Table=pd.DataFrame(emails_df.groupby(['Thread_ID', 'Subject'],as_index=False)['Message-ID'].count())
Thread_Table.columns=['Thread_ID','Subject','Count']
Thread_Table=Thread_Table[(Thread_Table.Thread_ID>=4) & (Thread_Table.Count >1)]
Thread_Table=Thread_Table.sort_values('Count',ascending=False)
Thread_Table

Thread_Table[(Thread_Table.Count >20)&(Thread_Table.Count <=40)]

#Create a list of examples for Thread__ID
Example_set=[69235,33510, 108772]


#GET EXAMPLE
get_example(emails_df,'Thread_ID',Example_set[1])



#Get counts of Thread_Content_ID
pd.value_counts(emails_df.Thread_content_ID)

Thread_Content_Table=pd.DataFrame(emails_df.groupby(['Thread_content_ID', 'Subject'],as_index=False)['Message-ID'].count())
Thread_Content_Table.columns=['Thread_content_ID','Subject','Count']
Thread_Content_Table=Thread_Content_Table[(Thread_Content_Table.Thread_content_ID>=4) & (Thread_Content_Table.Count >1)]
Thread_Content_Table=Thread_Content_Table.sort_values('Count',ascending=False)
Thread_Content_Table

Thread_Content_Table[(Thread_Content_Table.Count >50)&(Thread_Content_Table.Count <=80)]

#Create a list of examples for Thread__ID
Example_set2=[58846,28202,232482,13848,22215,28202]


#GET EXAMPLE
get_example(emails_df,'Thread_content_ID',Example_set2[1])

#GET THREADS
a,b=create_thread_stats(emails_df,'Thread_content_ID',58846)
a[['Date','From','To','Subject']]

a,b=create_thread_stats(emails_df,'Thread_ID',108772)
a[['Date','From','To','Subject']]

df_re=emails_df[emails_df['Subject'].str.contains("Superbowl Party")]
print(df_re.Subject)





#edge_data_sample=edge_data(example)
#
#d=c[c['Thread']=="Y"]
#d.sort_values('ThreadID',inplace=True)
#e=pd.DataFrame(d.groupby('ThreadID')['ThreadID'].count(),columns=['ThreadID','ThreadCount'])
#d=d.merge(e,left_on='ThreadID',right_on='ThreadID',how='outer')



#
#
##-------------------------------------------------------------------------------------------------------------------------
##Filter to Subject Re
#df=emails_df[emails_df['Subject'].str.contains("Re:")]
#print(df.Subject)
#
#
#
#fields_list=['To:','cc:','Subject:']
#
#def get_email_fields(msg):
#    b=1
#    fields_list=re.findall("([0-9]{2}\/[0-9]{2}\/[0-9]{4})",msg)
#    frm = []
#    date=[]
#    to=[]
#    cc=[]
#    for line in msg.split('\n\t'):
#        if any(s in line for s in ['@ENRON','@ECT'] if all(t not in line for t in ['To:','cc:'])) :
#            frm.append(line) 
#        if any(s in line for s in fields_list) :
#            date.append(line)  
#        if any(s in line for s in ['To:']):
#            to.append(line)               
#        if any(s in line for s in ['cc:']):
#            cc.append(line)
#    print(frm)
#    print(date)
#    print(to)
#    print(cc)
#            
##get_email_fields(msg)

#
#import re
#
#for i, line in enumerate(msg):
#    print (line) if not (re.match('\r?\n', line)) 
#    

