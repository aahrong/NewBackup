# -*- coding: utf-8 -*-
"""
Created on Sat Jan 28 03:17:00 2017

@author: mallabi
"""
import re
import pandas as pd
import email
#-------------------------------------------------------------------------------------------------------------
## Helper functions
#-------------------------------------------------------------------------------------------------------------
def get_text_from_email(msg):
    '''To get the content from email objects'''
    parts = []
    for part in msg.walk():
        if part.get_content_type() == 'text/plain':
            parts.append( part.get_payload() )
    return ''.join(parts)

def split_email_addresses(line):
    '''To separate multiple email addresses'''
    if line:
        addrs = line.split(',')
        addrs = frozenset(map(lambda x: x.strip(), addrs))
    else:
        addrs = None
    return addrs

def remove_email_addresses(text):
    '''To remove email addresses from text'''
    match = re.findall(r'[\w\.-]+@[\w\.-]+', text)
  
#    match = re.findall(r'[\w\.-]+@[\w.-]+|\{(?:\w+, *)+\w+\}@[\w.-]+', text)
    for i in match:
        text = text.replace(i, '')
    return text
        
def remove_email_noncontent(text, rem_words):
    '''To remove selected words from text'''
    parts = []
    for line in text.splitlines():
        if not any(word in line for word in rem_words):
            parts.append(line + '\n')
    return ''.join(parts)
    
def remove_urls(text):
    '''To remove url addresses from text'''

    text = re.sub(r'(https|http|www)*:\/\/(\w|\.|\~|/~|\/|\?|\=|\&|\%)*(/|\b)', '', text,flags=re.MULTILINE)
    text = text.replace("http", "")
    return text

def parse_email_data(emails_df):
    '''To parse the emails into a list of email objects'''
    messages = list(map(email.message_from_string, emails_df['message']))
    emails_df.drop('message', axis=1, inplace=True)
    
    # Get fields from parsed email objects
    keys = messages[0].keys()
    for key in keys:
        emails_df[key] = [doc[key] for doc in messages]
    
    # Parse content from emails
    emails_df['content'] = list(map(get_text_from_email, messages))
    
    # Split multiple email addresses
    emails_df['From'] = emails_df['From'].map(split_email_addresses)
    emails_df['To'] = emails_df['To'].map(split_email_addresses)
    
    # Extract the root of 'file' as 'user'
    emails_df['user'] = emails_df['file'].map(lambda x: x.split('/')[0])
    del messages
        
    # Find number of unique values in each columns
    print('shape of the dataframe:', emails_df.shape)  
    for col in emails_df.columns:
        print(col, emails_df[col].nunique())
    
    #Set index and drop useless columns
    emails_df = emails_df.set_index('Message-ID').drop(['file','Mime-Version',
                                                        'Content-Type',
                                                        'Content-Transfer-Encoding'], 
                                                        axis=1)
    #Parse datetime
    emails_df['Date'] = pd.to_datetime(emails_df['Date'], 
                                       infer_datetime_format=True)
    emails_df.dtypes
    return emails_df
    
def remove_duplicates(emails_df):
    ''' To drop duplicate emails and keep the first row. Group emails by From,\
    Date and content variables. These are emails sent to multiple users and \
    appear within different user folders.'''
    
    emails_df = pd.DataFrame(emails_df)
    emails_df["ID"] = emails_df.groupby(["From",
                                        "Date",
                                        "content"]).grouper.group_info[0]
    emails_df.sort_values(["ID"], ascending=True, inplace=True)
    
    #Store total rows before deduping
    a = len(emails_df)
    
    #Drop duplicate emails, keep the first row. EMAILS HAVE DIFFERENT USERS
    emails_df = emails_df.drop_duplicates(subset="ID", keep='first')
    b = len(emails_df)
    
    print ('Dropped emails due to duplication:', a - b)
    return emails_df

def tag_replies(emails_df): #Tag Email group - (Original/Reply/Forwarded)
    emails_df['Email_Group'] = ""
    emails_df['Email_Group'] = emails_df['Subject'].apply(lambda x: 'Reply' \
            if (x.strip().lower()[:3] == "re:") 
            else ('Forwarded' if (x.strip().lower()[:4] == "fwd:") 
            else 'Original'))
    return emails_df    
    
def preprocess_email(emails_df):
    emails_df = parse_email_data(emails_df)     #Parsing emails into separate,readable formats and removing duplicates
    emails_df = remove_duplicates(emails_df)    #Remove duplicates
    emails_df = tag_replies(emails_df)          #Tag Email group - (Original/Reply/Forwarded)
    
    #Variables to include 'From' email address out of frozenset and length of content
    emails_df['From_open'] = emails_df['From'].map(lambda x: next(iter(x)))
    emails_df['To_open'] = emails_df['To'].map(lambda x: list(x) if (x != None) 
                                                                    else ([None]))
    emails_df['Content_length'] = emails_df['content'].apply(lambda x: len(str.split(x)))
    emails_df['Email_Group2'] = emails_df['From_open'].apply(lambda x: 'Enron Email' 
                                                                if ("@enron.com" in x) 
                                                                else ('Non-Enron Email'))
    return emails_df