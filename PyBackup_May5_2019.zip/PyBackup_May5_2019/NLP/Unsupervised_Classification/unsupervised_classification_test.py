# -*- coding: utf-8 -*-
"""
Created on Wed Jun 21 18:05:24 2017

@author: DLUser19
"""

import os
os.chdir('C:\Anaconda\Engagement\word2vec archive')
from gensim.models.keyedvectors import KeyedVectors
from sklearn import cluster

word_vectors = KeyedVectors.load_word2vec_format('GoogleNews-vectors-negative300.bin', binary=True)

keys=word_vectors.vocab.iterkeys()
vector_set=[word_vectors.word_vec(key) for key in keys]
            
k_means=cluster.KMeans(n_clusters=10) # 10 classes, I use k_means for the first step. Other method could be used as well.
k_means.fit(vector_set) # Model fitting takes some time, around 40 mins on the old server

word_vectors_labels = k_means.labels_
word_vectors_class_centers=k_means.cluster_centers_ #The cluster centers could be used to categorize words. i.e. there are 10 centers. 
#Given a word, the distance between the word factor and center factor could be calculated. Then the word should be categorized to the nearist center(class).
