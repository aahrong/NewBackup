# -*- coding: utf-8 -*-
"""
Created on Sat Jan 28 03:17:00 2017

@author: mallabi
"""
#-------------------------------------------------------------------------------------------------------------
## Helper functions
#-------------------------------------------------------------------------------------------------------------
def get_text_from_email(msg):
    '''To get the content from email objects'''
    parts = []
    for part in msg.walk():
        if part.get_content_type() == 'text/plain':
            parts.append( part.get_payload() )
    return ''.join(parts)

def split_email_addresses(line):
    '''To separate multiple email addresses'''
    if line:
        addrs = line.split(',')
        addrs = frozenset(map(lambda x: x.strip(), addrs))
    else:
        addrs = None
    return addrs

def remove_email_addresses(text):
    import re
    match = re.findall(r'[\w\.-]+@[\w\.-]+', text)
    
#    match = re.findall(r'[\w\.-]+@[\w.-]+|\{(?:\w+, *)+\w+\}@[\w.-]+', text)
    for i in match:
        text=text.replace(i,'')
    return text
        
def remove_email_noncontent(text,rem_words):
    parts = []
    for line in text.splitlines():
        if not any(word in line for word in rem_words):
            parts.append(line+'\n')
    return ''.join(parts)
    
def remove_urls (text):
    import re
    text = re.sub(r'(https|http|www)*:\/\/(\w|\.|\~|/~|\/|\?|\=|\&|\%)*(/|\b)', '', text, flags=re.MULTILINE)
    text=text.replace("http","")
    return(text)
