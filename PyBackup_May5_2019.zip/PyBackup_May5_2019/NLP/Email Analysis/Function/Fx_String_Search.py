# -*- coding: utf-8 -*-
"""
Created on Sat Jan 28 05:29:18 2017
@author: mallabi
"""
#Number of functions to search within emails

#=============================================================================================================
##Various search functions
#=============================================================================================================

#1. Search for one string or set of strings in the email subject
def search_subject(dframe,string):
    if type(string)==str:
        string=string.split()
    else:
        string=list(string)
    print('Emails Subjects with the string: '+str(string))
    print('-----------------------------------------------------------------')
    Doc_id=[]
    for i in range(0,len(dframe)):
        if any(n in (dframe['Subject'][i].lower()) for n in string.lower()):
            print (dframe['Subject'][i])
            Doc_id.append(dframe.index[i])
    return Doc_id

##Examples
#search_subject(emails_df,"impacts")
#
#a=['impacts','rate']
#search_subject(emails_df,a)


#----------------------------------------------------------------------
#2. Show message for the given range            
def orig_message(start,end,orig_dframe):
    for i in range(start,end):
        print('Message #: '+str(i))
        print(orig_dframe['message'][i])
        
##Examples
#orig_message(0,2)

#----------------------------------------------------------------------
#3. Pull Nth message with a string or set of strings in the original dataframe, message viewed as a single message
def search_orig_content(string,N,orig_dframe,showTotMatch=False,):
    if type(string)==str:
        string=string.split()
    else:
        string=list(string)
    print('Emails Subjects with the string: '+str(string))
    j=1
    for i in range(0,len(orig_dframe)):
        if any(n in (orig_dframe['message'][i].lower()) for n in string.lower()):
            if j==N:
                print('Email #: '+str(j))
                print('Doc #: '+str(i))
                print('-----------------------------------------------------------------')
                print (orig_dframe['message'][i])
                if not showTotMatch:
                    return
            j=j+1
    print('-----------------------------------------------------------------')
    print ('Showing Document ' + str(N)+ ' of Total Documents: '+str(j)) 

##Examples
##Shows the 1st message it finds with "impacts" in the content field
#search_orig_content("impacts",1)
#
##Shows the 2nd message if finds with the set of strings. Including 'True' as the 3rd arguments includes the total number of matches found, but runs slower.
#a=['impacts','transport']
#search_orig_content(a,2,True)


#----------------------------------------------------------------------
#4. Pull Nth message with a string or set of strings in the modified dataframe, message viewed as separate columns

def search_content(dframe,string,N,showTotMatch=False):
    if type(string)==str:
        string=string.split()
        print (string)
    else:
        string=list(string)
    print('Emails Subjects with the string: '+str(string))
    j=1
    Doc_list=[]
    for i in range(0,len(dframe)):
       if any(str(n) in (dframe['content'][i]) for n in string):
            Doc_list.append(i)
            if j==N:
                print('Email #: '+str(j))
                print('Doc #: '+str(i))
                Msg_ID='Message-ID: '+ dframe.index[i]
                print(Msg_ID)
                print('-----------------------------------------------------------------')
                print (dframe['content'][i])
                #print (tokenized[i])
                if not showTotMatch:
                    return
            j=j+1
    print('-----------------------------------------------------------------')
    print ('Showing Document ' + str(N)+ ' of Total Documents: '+str(j-1))
    if showTotMatch:
        return Doc_list      
    
##Examples
##Shows the 1st message it finds with "impacts" in the content field
#search_content("impacts",1)
#
##Shows the 2nd message if finds with the set of strings. Including 'True' as the 3rd arguments includes the total number of matches found, but runs slower.
#a=['impacts','transport']
#search_content(a,2,True)
#   


#----------------------------------------------------------------------
#5. Search the original dataframe by using message_id
def show_orig_message(message_id,orig_dframe):
    for i in range(0,len(orig_dframe)):
        if message_id in orig_dframe['message'][i]:
            print ("Doc #: "+ str(i))
            print('-----------------------------------------------------------------')
            return (orig_dframe['message'][i])
            
##Examples
##Shows the 1st message it finds with "impacts" in the content field
#show_orig_message("32327272.1075848087094.JavaMail.evans@thyme")           

#----------------------------------------------------------------------
#6. Search the cleaned dataframe by using message_id
def show_message(message_id,column,dframe):
    for i in range(0,len(dframe)):
        if message_id in dframe.index[i]:
            print ("Doc #: "+ str(i))
            print('-----------------------------------------------------------------')
            print ('Column Name: ' + column)
            return (dframe[column][i])
            
##Examples
##Shows the message matching the message-ID provided
#show_message("32327272.1075848087094.JavaMail.evans@thyme")           
#
##Shows the message matching the message-ID provided, second argument is 'content' by default but can be manually altered
#show_message("32327272.1075848087094.JavaMail.evans@thyme","From_open")  


#----------------------------------------------------------------------
##Detailed search of a string or set of strings in the tokenized dataframe, message viewed as separate columns
##Searches on emails_df_toke database

def search_token(string,N,showTotMatch=False):
    if type(string)==str:
        string=string.split()
    else:
        string=list(string)
    print('Emails Subjects with the string: '+str(string))
    j=1
    for i in range(0,len(emails_df_toke)):
        if set(string).issubset(set(emails_df_toke['content_toke'][i])):
            if j==N:
                print('Email #: '+str(j))
                print('Doc #: '+str(i))
                Msg_ID='Message-ID: '+ emails_df.index[i]
                print(Msg_ID)
                print('-----------------------------------------------------------------')
                return (emails_df_toke['content'][i])
                print('-----------------------------------------------------------------')
                print(Msg_ID) 
                Msg_ID='Message-ID: '+ emails_df.index[i]
                #print (tokenized[i])
                if not showTotMatch:
                    return
            j=j+1
    print('-----------------------------------------------------------------')               
    print ('Showing Document ' + str(N)+ ' of Total Documents: '+str(j))      
    

##Examples
##Shows the 1st message it finds with "impacts" in the content field
#search_token("impacts",1)
#
##Shows the 2nd message if finds with the set of strings. Including 'True' as the 3rd arguments includes the total number of matches found, but runs slower.
#a=['impacts','transport']
#search_token(a,2,True)
#
#a="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
#search_token(a,1,True)


##Detailed search of a string or set of strings in the dataframe content, original message displayed
##Searches on emails_df database

def show_orig_byString(string,N,showTotMatch=False):
    if type(string)==str:
        string=string.split()
    else:
        string=list(string)
    print('Emails Subjects with the string: '+str(string))
    j=1
    for i in range(0,len(emails_df)):
        if any(word in (emails_df['content'][i]) for word in string):
            if j==N:
                print('Email #: '+str(j))
                print('Doc #: '+str(i))
                Msg_ID='Message-ID: '+ emails_df.index[i]
                print(Msg_ID)
                print('-----------------------------------------------------------------')
                print (emails_df_original[emails_df_original.index==emails_df.index[i]])
                print('-----------------------------------------------------------------')
                print(Msg_ID) 
                Msg_ID='Message-ID: '+ emails_df.index[i]
                #print (tokenized[i])
                if not showTotMatch:
                    return
            j=j+1
    print('-----------------------------------------------------------------')               
    print ('Showing Document ' + str(N)+ ' of Total Documents: '+str(j))      
    

##Detailed search of Nth original message by Topic
##Searches on emails_df_original database    
def show_orig_byTopic(topic,N,dframe):
    ID_list=dframe.index[dframe.Max1==topic]
    print(show_orig_message(ID_list[int(N % len(ID_list))],emails_df_original))
    return ID_list

##Examples   
#show_orig_byTopic(1,2,emails_df_lda)