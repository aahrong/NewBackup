# -*- coding: utf-8 -*-
"""
Created on Thu Jan 26 23:10:00 2017

@author: DLUSER11
"""

from_list=emails_df['From_open']