# coding: utf-8

# In[7]:

####################################################################################################
####################################################################################################
## 
## Now that we have the data seperated out into all the necessry columns/features we can begin
## tokenizing.
##
####################################################################################################


# In[8]:

#import word_tokenizer which tokenizes words
from nltk.tokenize import word_tokenize

# In[9]:

#tokenize entire set of email contents
#tokenized = [word_tokenize(i) for i in emails_df['content']]


# In[10]:

#remove stopwords and turn everything to lower case. Create a function to do this
import re
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
stop = set(stopwords.words('english'))
add_stop = {'subject','please','pm','cc','thanks','enron','would','may','time','get','pt','sat','know','need','let','new','also','call','us','attached','information','original','sent','email','message','forwarded','said','energy','power','company','image','market','gas','price','prices','year','ddddddddddddd','ddddddddddddddddddddddddd'}

stemmer = PorterStemmer()

def content_to_words( content ):
    #1) Take in content and convert to string
    #2) convert to lower case
    #3) remove stop words
    #4) stemming
    #5) return to original dataframe
    
    letters_only = re.sub("[^a-zA-Z\s]", "", content)
    letters_only = str(letters_only)
    message_low = letters_only.lower().split() #NEED THE SPLIT or else stop words reads each character as 
    # a list and removes half the characters
    words = [w for w in message_low if (not w in (stop|add_stop) and len(w)>2)]
    stemmed_words = [stemmer.stem(word) for word in words]
    
    return(" ".join(stemmed_words)) 



# In[5]:

from time import time

# In[14]:

#Call content_to_words function for all emails and tokenize it
#initialize new empty array
clean_contents = []
t0 = time()
for i in xrange(0, len(emails_df)):
    temp = content_to_words(emails_df['content'][i])
    clean_contents.append(temp)

tokenized = [word_tokenize(x) for x in clean_contents]
print("Time to tokenize: %0.3fs." %(time() - t0))

# In[15]:
#create new column/feature of tokenized emails into a new email dataframe
emails_df_toke = emails_df
emails_df_toke['content_toke'] = tokenized


emails_df_toke.head()
print(tokenized[10])

# In[ ]:

#################################################################################################
#################################################################################################
##
## Time to incorporate LDA
##
##################################################################################################


# In[ ]:

#import LDA from sklearn
##from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
##from sklearn.decomposition import NMF, LatentDirichletAllocation

##sklearn implementation of LDA is not real LDA and it took way too long. Time to move to 
##gensim which allows you to do multicore LDA


#Use Tf-idf features for Negative Matrix Factorization model
#tfidf_vectorizer = TfidfVectorizer()
#tfidf = tfidf_vectorizer.fit_transform(clean_contents)
                                       
#t0 = time()
#nmf = NMF.fit(tfidf)
#print("done in %0.3fs." %(time()-t0))
#print("\nTopics in NMF model:")
#tfidf_feature_names = tfidf_vectorizer.get_feature_names()
#tf_feature_names = tf_vectorizer.get_feature_names()
#print_top_words(lda, tf_feature_names, 20)                                       

#tf_vectorizer = CountVectorizer(analyzer = "word", tokenizer = None, preprocessor = None, stop_words = None)
#t0=time()

#tf = tf_vectorizer.fit_transform(clean_contents)
#print("done in %0.3fs." %(time()-t0))



#print(clean_contents_temp[3])

#lda = LatentDirichletAllocation(n_topics = 200)
#print("test")
#t0 = time()
#lda.fit(tf)
#print("done in %0.3fs." %(time()-t0))


# In[17]:

# Function to print out some of the topics
def print_top_words(model, feature_names, n_top_words):
    for topic_idx, topic in enumerate(model.components_):
        print("Topic #%d:" % topic_idx)
        print(" ".join([feature_names[i]
                        for i in topic.argsort()[:-n_top_words - 1:-1]]))
    print()


# In[ ]:

#Move our tokenized list into a csv so we save it for later use. Also save the cleaned dataframe


# In[21]:

import unicodecsv as csv
filepath = "E:/Use Case Testing/NLP/BM/tokenized.csv"

with open(filepath, "w") as output:
    writer = csv.writer(output, lineterminator='\n')
    writer.writerows(tokenized)


filepath2 = "E:/Use Case Testing/NLP/BM/structured_email.csv"
    
emails_df_toke.to_csv(filepath2, encoding='utf-8')


from gensim import corpora, models

#go through and collect data on each unique word. Also asign a unique ID to each word
dictionary = corpora.Dictionary(tokenized) 

#Code to see unique ID list for tokens
#print(dictionary.token2id)


# In[ ]:

print(len(dictionary))
#230276

# In[ ]:

print(dictionary[50000])


# In[24]:

#convert dictionary to bag of words
t0 = time()
corpus = [dictionary.doc2bow(text) for text in tokenized]
print("Done in %0.3fs" %(time() - t0))
print(corpus[3]) #prints out (termID, term frequency)


# In[25]:

#get a shorter version of the corpus for testing purposes
#test_corpus = corpus[:100000]


# In[26]:

#save dictionary
dictionary.save("E:/Use Case Testing/NLP/BM/dictionary.dict")
#save corpus as a matrix market file. MM type is good for sparse matrices such as the corpus
corpora.MmCorpus.serialize("E:/Use Case Testing/NLP/BM/corpus.mm", corpus)

# In[27]:

######## Use this code for whenver you need to rerun LDA from a fresh boot

import os, sys, email
import numpy as np 
import pandas as pd
from gensim import corpora, models
from time import time

dictionary = corpora.Dictionary.load("E:/Use Case Testing/NLP/BM/dictionary.dict")
corpus = corpora.MmCorpus("E:/Use Case Testing/NLP/BM/corpus.mm")
#test_corpus = corpus[:100000]


# In[27]:
#/**LDA Multicore**/
    
t0 = time()
#id2word maps ids to strings using our dictionary that we made earlier. it is required
lda_2 = models.LdaMulticore(corpus, num_topics=2, id2word = dictionary, workers = 23, batch = True)
print("LDA (2 topics) done in %0.3fm" %((time() - t0)/60))

t0 = time()
#id2word maps ids to strings using our dictionary that we made earlier. it is required
lda_5 = models.LdaMulticore(corpus, num_topics=5, id2word = dictionary, workers = 23, batch = True)
print("LDA (5 topics) done in %0.3fm" %((time() - t0)/60))

t0 = time()
#id2word maps ids to strings using our dictionary that we made earlier. it is required
lda_10 = models.LdaMulticore(corpus, num_topics=10, id2word = dictionary, workers = 23, batch = True)
print("LDA (10 topics) done in %0.3fm" %((time() - t0)/60))

t0 = time()
#id2word maps ids to strings using our dictionary that we made earlier. it is required
lda_20 = models.LdaMulticore(corpus, num_topics=20, id2word = dictionary, workers = 23, batch = True)
print("LDA (20 topics) done in %0.3fm" %((time() - t0)/60))



#save lda
lda_2.save("E:/Use Case Testing/NLP/BM/lda_2.model")
lda_5.save("E:/Use Case Testing/NLP/BM/lda_5.model")
lda_10.save("E:/Use Case Testing/NLP/BM/lda_10.model")
lda_20.save("E:/Use Case Testing/NLP/BM/lda_20.model")


# In[14]:
#/**LDA Model, alpha=auto**/
#/Limited to deduped, preprocessesd, original messages
    
t0 = time()
#id2word maps ids to strings using our dictionary that we made earlier. it is required
lda_model_20 = models.LdaModel(corpus, num_topics=20, id2word = dictionary, alpha='auto',passes=4)
print("LDA (20 topics - auto alpha, passes=4) done in %0.3fm" %((time() - t0)/60))
#This took 40 minutes
#save lda
lda_model_20.save("E:/Use Case Testing/NLP/BM/lda_model_20.model")

#/**LDA Model, alpha=auto**/
#/Limited to deduped, preprocessesd, original messages
   
t0 = time()
#id2word maps ids to strings using our dictionary that we made earlier. it is required
lda_model_50 = models.LdaModel(corpus, num_topics=50, id2word = dictionary, alpha='auto',passes=4)
print("LDA (50 topics - auto alpha, passes=4) done in %0.3fm" %((time() - t0)/60))
#This took for ever -- 1020 minutes (17 hours)
#save lda
lda_model_50.save("E:/Use Case Testing/NLP/BM/lda_model_50.model")

