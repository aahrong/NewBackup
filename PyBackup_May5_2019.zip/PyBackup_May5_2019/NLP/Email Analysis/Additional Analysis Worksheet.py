# -*- coding: utf-8 -*-
"""
Created on Wed Feb 08 17:31:49 2017

@author: DLUSER11
"""

##--------------------------------------------------------------------------------------
#Additional Analysis
##--------------------------------------------------------------------------------------
   
#emails_df['Email_Category']=""
#system_emails = ['arsystem@ect.enron.com','system.administrator@enron.com','webrequests@enron.com']
#filter_list=['arsystem@ect.enron.com','system.administrator@enron.com','webrequests@enron.com','status_updates@enron.com','enron.expertfinder@enron.com','border@enron.com','omaha.helpdesk@enron.com','security.console@enron.com','ecthou-domweb1@enron.com','enron.chairman@enron.com','clickathome@enron.com','ecn3125b.conf.@enron.com','40ect@enron.com','cuttings.enron@enron.com','40ect@enron.com','trent@enron.com']
#'webmaster@earnings.com'

#emails_df['Email_Category']=emails_df['From_open'].apply(lambda x: 'System Emails' if (x in filter_list) else 'Others')
#for col in emails_df.columns:
#    print(col, emails_df[col].nunique())
#
#emails_df[emails_df.Email_Category != 'Others']
    

#------------------------------------------------------------------------------------------------------
#Clean encoded messages
#------------------------------------------------------------------------------------------------------

b=['Content-transfer-encoding:','base64']
search_content(emails_df,b,1)

#Excluding words greater than 40 characters will remove the codes like "aaa..aaaaa" (76 in length)

#Get list of documents that have "aaa..aaaaa" as tokent
def getDoc_search_token(string):
    if type(string)==str:
        string=string.split()
    else:
        string=list(string)
    print('Emails Subjects with the string: '+str(string))
    doc_ID=[]
    for i in range(0,len(emails_df_toke)):
        if set(string).issubset(set(emails_df_toke['content_toke'][i])):
            doc_ID.append(i)
    return doc_ID
    
a="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
doc_ID_list=getDoc_search_token(a)

m=emails_df['content'][doc_ID_list[1]]
import email
msg = email.message_from_string(m)
msg.keys()
content=get_text_from_email(msg)
print(content)

print(m)
print('-----------------------------------------------------------')
content2=clean_attach_encoding(str(m))  
content2 = email.message_from_string(content2) 
print(content2) 


#Examples

m=emails_df_original['message'][270785]
import email
msg = email.message_from_string(m)
msg.keys()
content=get_text_from_email(msg)
print(content)

print(m)
print('-----------------------------------------------------------')
content2=clean_attach_encoding(str(m))  
content2 = email.message_from_string(content2) 
print(content2) 


##Email Categorization
from_emails=pd.DataFrame(emails_df.loc[:,['From_open','Email_Group2']])
from_emails=from_emails.drop_duplicates()
from_emails.shape

#Generate Frequency
pd.value_counts(from_emails.Email_Group2)

##Filter message by 'From' email address
email_list=['enw.office.of.the.chairman@enron.com','gary.allen.-.safety.specialist@enron.com','enron.general.announcements.enronxgate@enron.com','ken.lay-.chairman.of.the.board@enron.com','enron.corporate.administrative.services@enron.com']
#p=emails_df['From_open'].apply(lambda x: emails_df.index if set(x).issubset(email_list))
#print(p)

#---------------------------------------------------------------------------------------
##Exclude Delivery Notification Failure Message
#---------------------------------------------------------------------------------------
string=['Delivery Notification','Delivery Status Notification','Delivery failure']
Doc_ID=search_subject(emails_df,string)

for i in range(0,5):
    msg=show_orig_message(Doc_ID[i])
    print(msg)
    try:
        input("Press enter to continue")
    except SyntaxError:
        pass
    print("======================================================================")
