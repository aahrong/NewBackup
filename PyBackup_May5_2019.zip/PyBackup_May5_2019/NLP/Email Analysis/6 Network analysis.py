#Import package and dataset
import os
import pandas as pd

os.chdir("E:\Use Case Testing\NLP\BM")
emails_df_lda = pd.read_pickle('Emails_df_toke_lda.pkl')

#Network Analysis
df_network=emails_df_lda.ix[:,['From','To','Date','Max1']]
df_network['To']=df_network['To'].map(lambda x: list(x) if x!=None else [None])
df_network['From']=df_network['From'].map(lambda x: list(x)[0] if x!=None else None)

#print(df_network.head())
                    
enron_exec=['ken.rice@enron.com','greg.whalley@enron.com']
#'kenneth.lay@enron.com','jeff.skilling@enron.com','jeffreyskilling@yahoo.com','andrew.fastow@enron.com','ben.glisan@enron.com','mark.koenig@enron.com',
#'ken.rice@enron.com','greg.whalley@enron.com','gregwhalley@yahoo.com','office.whalley@enron.com','sherron.watkins@enron.com',
#'j.kaminski@enron.com','vince.kaminski@enron.com','j..kaminski@enron.com','kaminski@enron.com']
                      
index=df_network['From'].apply(lambda x: True if (any(v in x for v in enron_exec)) else False)

df_network=df_network[index]
df_network=df_network.reset_index()
print(df_network.head)


counts=pd.DataFrame(pd.value_counts(df_network['From'].values, sort=False))
counts.reset_index(level=0, inplace=True)
counts.columns=['From','Count']

df_network=df_network.merge(counts, left_on='From',right_on='From')

df_set=[]
      
for i in range(0,len(df_network)):
    for val_to in (df_network['To'][i]):
        a=[df_network.index[i],df_network['From'][i], val_to,df_network['Count'][i]]
        df_set.append(a)

      
df_set=pd.DataFrame(df_set,columns=['Index','From','To','Count'])
print(df_set)

df_set['Edge']=list(zip(df_set['From'], df_set['To']))

#Preparing graph data
graph=df_set['Edge']
weights=df_set['Count']

#Create network graph
import networkx as nx
import matplotlib.pyplot as plt

#Directed Graphs
def draw_graph(graph,weights):
    # create directed networkx graph
    G=nx.DiGraph()

    # add edges
    G.add_edges_from(graph)

#    graph_pos = nx.shell_layout(G)
    graph_pos = nx.spring_layout(G)
#    graph_pos = nx.spectral_layout(G)


    #d = nx.degree(G)
    #print(d)
    
    # draw nodes, edges and labels
    nx.draw_networkx_nodes(G, graph_pos, node_color='blue', alpha=0.3,node_size=[weights])
    
    # we can now added edge thickness and edge color
    nx.draw_networkx_edges(G, graph_pos, width=2, alpha=0.5, edge_color='green')
    nx.draw_networkx_labels(G, graph_pos, font_size=8, font_family='sans-serif')
    
    labels = range(len(df_set))
    edge_labels = dict(zip(graph, labels))
    nx.draw_networkx_edge_labels(G, graph_pos, edge_labels=edge_labels)
    
    plt.figure(figsize=(5,5))
    plt.show()

draw_graph(graph, weights)