# -*- coding: utf-8 -*-
"""
@author: mallabi
"""
# In[1]:
    
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

class Visuals_LDA():
    import matplotlib.pyplot as plt
    import numpy as np
    import pandas as pd

    ##Function to get the top n_word (Default=10) words for each topic
    def get_words_byTopic(self,model,n_words=10):
        self.topics = []  
        self.top_wds=[]
        
        print ('Mix of Top '+str(n_words)+' words by Topic')
        for i in range(0,model.num_topics):
            for j in range(0,n_words):
                self.top_wds.append(model.show_topic(i,topn=n_words)[j][0])
            self.topics.append(self.top_wds)
            self.top_wds=[]
            print('*Topic {}\n- {}'.format(i+1, ' '.join(self.topics[i])))
    
    #Function to get probabilistic distribution of top words within selected 'topic_n' Topic    
    def get_worddist_byTopic(self,model,topic_n):
        self.D=model.show_topic(topic_n-1)
        self.df=pd.DataFrame(list(self.D),columns=['Word','Prob'])
        
        self.N, self.K = self.df.shape
        self.ind = np.arange(self.N)  # points on the x-axis
        self.width = 0.5
        
        fig,ax = plt.subplots()
        ax.barh(self.ind, self.df['Prob'], self.width,label="N",color='g')
        ax.set(yticks=self.ind + self.width/2, yticklabels=self.df['Word'], ylim=[2*self.width -1, self.N])
        plt.ylabel('Top Words', fontsize=12)
        plt.xlabel('Probability Distribution', fontsize=12)
        plt.title('Distribution of Top Words for Topic '+str(topic_n),fontsize=15)
        plt.show()
        
    #Function to get counts of documents for primary topic within each document          
    def get_docCount_byTopic(self,model,corpus):
        import pandas as pd
        self.doc_n=[]
        self.main_topic=[]
        for i in range(0,len(corpus)):
            self.D=model.get_document_topics(corpus[i])
            for j in range(0,len(self.D)):
                self.df=pd.DataFrame(list(self.D),columns=['Topic','Prob'])
                self.df=self.df.sort_values(['Prob'],ascending=False)
            self.doc_n.append(i)
            self.main_topic.append('Topic '+str(int(self.df.iloc[0][0])+1))
        self.df=pd.concat([pd.Series(self.doc_n,name="Document"), pd.Series(self.main_topic,name="Topic")], axis=1)
        self.df=self.df.groupby('Topic').count()
        self.df=self.df.sort_values(['Document'],ascending=False)
        
        self.N, self.K = self.df.shape
        self.ind = np.arange(self.N)  # points on the x-axis
        self.width = 0.5
        fig,ax = plt.subplots()
        plt.bar(self.ind, self.df.Document, width=self.width)
        plt.xticks(self.ind + self.width/2, self.df.index)  # put labels in the center
        ax.set_xticklabels(ax.xaxis.get_majorticklabels(),rotation=45)
        plt.xlabel('Topic Number', fontsize=12)
        plt.ylabel('Frequency of Documents', fontsize=12)
        plt.title('Count of Documents by Primary Topic (Across '+str(int(len(corpus)))+' Documents)',fontsize=15)    
        plt.show()
        
    ##Function to get the distribution of Topics for the selected document ('doc_n')
    def get_topics_forDocID(self,model,corpus,doc_n):
        self.D=model.get_document_topics(corpus[doc_n-1])
        for j in range(0,len(self.D)):
            self.df=pd.DataFrame(list(self.D),columns=['Topic','Prob'])
#            self.df=self.df.sort_values(['Prob'],ascending=True)
        self.ind = np.arange(len(self.df['Topic']))
        self.width = .5
        plt.bar(self.ind, self.df['Prob'], self.width)     
        plt.xticks(self.ind + self.width/2, self.df.index+1)
        plt.title('Distribution of Topic(s) for Document '+ str(doc_n), fontsize=15)
        plt.ylabel('Probability Distribution', fontsize=12)
        plt.xlabel('Topic', fontsize=12)
        plt.show()
            
    ##Function to get the 'top_n' words (Default=20) across all documents
    def Freq_TopTerms(self,dictionary,start=1,end=21):
        from operator import itemgetter
        import itertools
        
#        self.flat_tokens=list(itertools.chain.from_iterable(text))
        
        self.D = []
        for k,v in dictionary.dfs.iteritems():
            self.D.append((str(dictionary.get(k)),v))
        
#        self.unique, self.counts = np.unique(self.flat_tokens, return_counts=True)
#        self.D=dict(zip(self.unique, self.counts))
        self.D=sorted(self.D, key=itemgetter(1),reverse=True)
        self.D=pd.DataFrame(list(self.D),columns=['Words','Count'])[start-1:end-1]

        self.ind = np.arange(len(self.D['Words']))
        self.width = .5
        fig, ax = plt.subplots()
        plt.suptitle('Frequency of Top '+ str(start) +' - '+ str (end) + ' Words Across All Documents', fontsize=15)
        plt.xlabel('Count', fontsize=12)
        ax.barh(self.ind, self.D['Count'], self.width, label='N', color='g')
        ax.set(yticks=self.ind + self.width/2, yticklabels=self.D['Words'], ylim=[2*self.width -1, len(self.D)])
        plt.show()
        return self.D
        
     ##Function to apply pyLDAvis for visualization
    def call_pyLDAvis(self,model,corpus,dictionary):
        import logging
        from gensim import corpora, models, similarities
        import os 
        from pprint import pprint
        import json
        import numpy as np
        import warnings
        import pyLDAvis
        warnings.filterwarnings('ignore')
        import pyLDAvis.gensim
        
        pyLDAvis.enable_notebook()
        self.p=pyLDAvis.gensim.prepare(model, corpus, dictionary)
        pyLDAvis.display(self.p)
        return self.p
   
# In[2]:
##Examples of calling functions defined above

a=Visuals_LDA()

import os
import pandas as pd
os.chdir("E:\Use Case Testing\NLP\BM")

from gensim.corpora import MmCorpus, Dictionary
from gensim import models

lda5=models.LdaModel.load('lda_5.model')
lda10=models.LdaModel.load('lda_10.model')
lda20=models.LdaModel.load('lda_20.model')

lda_model_200=models.LdaModel.load('lda_model_200.model')



corpus=MmCorpus('corpus.mm')
dictionary=Dictionary.load('dictionary.dict')

#Get 5 top words within each topic, default is 10 words
#a.get_words_byTopic(lda5)
#a.get_words_byTopic(lda10)
#a.get_words_byTopic(lda20)
#model_results=a.get_words_byTopic(lda_model_200)

D20=lda20.show_topics(num_topics=20,num_words=10,log=False,formatted=True)
D50=lda50.show_topics(num_topics=50,num_words=10,log=False,formatted=True)
#
##Get word distribution for Topic 1
#a.get_worddist_byTopic(lda,1)
#
##Get counts of document by Topic
#a.get_docCount_byTopic(lda,corpus)
#
##Get top topic for the document number 333
#a.get_topics_forDocID(lda,corpus,1)
#
##Get top 15 words used across all documents
#a.Freq_TopTerms(dictionary,1, 15)

##pyLDAvis Output
#p=a.call_pyLDAvis(lda,corpus,dictionary)


