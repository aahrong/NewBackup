# -*- coding: utf-8 -*-
"""
Created on Mon May  6 10:34:03 2019

@author: caridza
"""


import os 
import tarfile
import pandas as pd
import numpy as np
import io
import gzip
import urllib.request 



#load data (ex dataset 1)
#https://bigml.com/user/czuriaga/gallery/dataset/50d845a2035d073999000132
directory= "C:\\Users\\caridza\\Desktop\\pythonScripts\\Data\\BigML\\"
train_data = pd.read_csv(directory+'FaceBook_Activity.csv',error_bad_lines=False)
#test_data = pd.read_csv(directory+'test.csv',error_bad_lines=False)

#load data (ex dataset 2)
#https://www.kaggle.com/c/santander-value-prediction-challenge/discussion/62378
directory= "C:\\Users\\caridza\\Desktop\\pythonScripts\\Data\\avazu-ctr-prediction\\"
train_data = pd.read_csv(directory+'train.csv',error_bad_lines=False)
test_data = pd.read_csv(directory+'test.csv',error_bad_lines=False)

#load data from website directly (example dataset 3)
url = 'https://archive.ics.uci.edu/ml/machine-learning-databases/msnbc-mld/msnbc990928.seq.gz'
urllib.request.urlretrieve(url,directory+"msnbc990928.seq.gz")
dat = []
gz = gzip.open(directory+"msnbc990928.seq.gz",'rb')
f = io.BufferedReader(gz)
for line in f.readlines():
    dat.append(line)
gz.close()









