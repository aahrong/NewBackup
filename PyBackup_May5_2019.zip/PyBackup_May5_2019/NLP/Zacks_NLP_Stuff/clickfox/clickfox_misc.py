# -*- coding: utf-8 -*-
"""
Created on Fri May  3 06:32:27 2019

@author: caridza
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Apr 22 08:23:01 2019
#indidviual dataset analysis 
@author: caridza
"""
import os 
import tarfile
import pandas as pd
import numpy as np
import researchpy as rp
from functools import reduce

import eif as iso 
import numpy as np 
from sklearn.decomposition import PCA 
import matplotlib.pyplot as plt
import itertools
import numpy as np 
from operator import itemgetter

from matplotlib.pyplot import figure, show,xticks,suptitle
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', -1)


from sklearn.ensemble import IsolationForest
from collections import Counter
import missingno

#3d offline plotting
import plotly
import plotly.graph_objs as go
import plotly.plotly as py
from plotly.offline import plot 
import seaborn as sb

from   kmodes import kmodes
from   kmodes import kprototypes
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn import preprocessing
%matplotlib inline

#funcs
def extract_targz(filepath):
    tf = tarfile.open(filepath)
    tf.extractall()

def CSVs2DictOfDFs(directory,extension):
    df_dict = {}
    for root,dirs,files in os.walk(directory):
        for f in files:
            if f.endswith(extension):
                key = f.replace(extension,'')
                value = os.path.join(root,f)
                df_dict[key]= pd.read_csv(value)
    return df_dict

def drop_constant_column(dataframe):
    """
    Drops constant value columns of pandas dataframe.
    """
    return dataframe.loc[:, (dataframe != dataframe.iloc[0]).any()]


def String2Int_Check(col,unique_thresh =4):
    try:
        if (isinstance(int(col[0]),int)) and (len(col.unique())>unique_thresh):
            return True
        else:
            return False
    except: 
        return False

def fillNas_convert_to_categoric(DF,NumCols,CatCols,Targets,NumMisConst=0,CatMisConst='0'):
    for col in DF.columns:
        #if column has > 19 levels and can be converted to int, treat as numeric and fill NaNs with numeric constant
        if col in NumCols:
                if any(np.isnan(np.array(DF[col],dtype=np.float64))):
                    DF[col].fillna(NumMisConst,inplace=True)
            
        if col in CatCols:
            categories = np.array(DF[col].unique())
       
            if type(categories[0]).__name__ in ['int64','numpy.float64','float64','bool_']:
                if any(np.isnan(np.array(categories,dtype=np.float64))):
                    DF[col].fillna(NumMisConst,inplace=True)
                    categories = np.array(DF[col].unique())
                    categories.sort()
                    DF[col] =DF[col].astype('category',categories = categories, copy=False,ordered=True)
                else:
                    categories = np.array(DF[col].unique())
                    categories.sort()
                    DF[col] =DF[col].astype('category',categories = categories, copy=False,ordered=True)
    
            else:
                if any(pd.isnull(categories)):
                    print(col ,'has nulls')
                    DF[col].fillna(CatMisConst,inplace=True)
                    categories = np.array(DF[col].unique())
                    DF[col] =DF[col].astype('category',categories = categories, copy=False,ordered=False)
                else:
                    DF[col] =DF[col].astype('category',categories = categories, copy=False,ordered=False)
                    
        if col in Targets:
            categories = np.array(DF[col].unique())
            DF[col].fillna(NumMisConst,inplace=True)
            categories = np.array(DF[col].unique())
            categories.sort()
            DF[col] =DF[col].astype('category',categories = categories, copy=False,ordered=True)
        
    return DF

def plot_corr(df,size=10):
    '''Function plots a graphical correlation matrix for each pair of columns in the dataframe.

    Input:
        df: pandas DataFrame
        size: vertical and horizontal size of the plot'''

    corr = df.corr()
    fig, ax = plt.subplots(figsize=(size, size))
    ax.matshow(corr)
    plt.xticks(range(len(corr.columns)), corr.columns);
    plt.yticks(range(len(corr.columns)), corr.columns);
    
def eif_isolationForest(DF,Cols2Model,ntrees=100,sample_size=33,contamination=.05,max_depth = 3):

    
    #build forest 
    if_eif=iso.iForest(DF[Cols2Model].values, ntrees=ntrees,sample_size=sample_size,ExtensionLevel=len(Cols2Model)-1,limit =max_depth)
    
    
    # calculate anomaly scores
    # sort the scores
    # retrieve indices of anomalous observations
    anomaly_scores = if_eif.compute_paths(X_in = DF[Cols2Model].values)
    anomaly_scores_sorted = np.argsort(anomaly_scores)
    indices_with_preds = anomaly_scores_sorted[-int(np.ceil(contamination * DF.shape[0])):]
    
    # create predictions 
    y_pred = np.zeros_like(DF.iloc[:,1])
    y_pred[indices_with_preds] = 1
    
    #assign outlier column to original dataframe
    DF['eif_iso_out']= y_pred
    
    #plot anomoli scores 
    plotscores = list(anomaly_scores)
    plotscores.sort(reverse=False)
    plotscores = pd.DataFrame(plotscores,columns = ['score'])
    plotscores['pchange']=plotscores.pct_change(periods = 1,fill_method='pad')
    plotscores['xrange'] = plotscores.index.values
 
    fig,axes=plt.subplots(nrows=1,ncols=2,figsize=(10,8))
    plotscores.plot(kind='line',x='xrange',y='score',ax=axes[0])
    plotscores.plot(kind='line',x='xrange',y='pchange',ax=axes[1],color='red')
    
    fig,axes1=plt.subplots(nrows=1,ncols=1)
    sb.distplot(anomaly_scores_sorted, kde=True, color="b",bins=205,ax=axes1)
    plt.title('extended')
    plt.show()
    return DF

#3d plot in ploty 
def plot_3d_offline(x,y,z,color,DF_textcol = None):
    # Import dependencies
    # Configure Plotly to be rendered inline in the notebook.
    plotly.offline.init_notebook_mode()
    # Configure Plotly to be rendered inline in the notebook.
    #plotly.offline.init_notebook_mode()
    
    # Configure the trace.
    trace = go.Scatter3d(
        x=x,
        y=y,
        z=z,
        mode='markers',
        text = list(DF_textcol),
        marker={
            'color':color,
            'colorscale':'Viridis',
            'size': 8,
            'opacity': 0.8,
        },
    
    )
    
    # Configure the layout.
    layout = go.Layout(
        margin={'l': 0, 'r': 0, 'b': 0, 't': 0}
    )
    
    layout = go.Layout(dict(
        width=1200,
        height=700,
        autosize=True,
        title='Outliers in dataset',
        scene=dict(
            xaxis=dict(
                gridcolor='rgb(255, 255, 255)',
                zerolinecolor='rgb(255, 255, 255)',
                showbackground=True,
                backgroundcolor='rgb(230, 230,230)'
            ),
            yaxis=dict(
                gridcolor='rgb(255, 255, 255)',
                zerolinecolor='rgb(255, 255, 255)',
                showbackground=True,
                backgroundcolor='rgb(230, 230,230)'
            ),
            zaxis=dict(
                gridcolor='rgb(255, 255, 255)',
                zerolinecolor='rgb(255, 255, 255)',
                showbackground=True,
                backgroundcolor='rgb(230, 230,230)'
            ),
            #aspectratio = dict( x=1, y=1, z=0.7 ),
            aspectmode = 'manual'        
        ),
    ))
    data = [trace]
    plot_figure = go.Figure(data=data, layout=layout)
    
    # Render the plot.
    plot(plot_figure)
    

def plot_by_pca(X,pcs=3,var2hue='eif_iso_out'):
    #X = Dataframe or matrix 
    #fit pca

    pca=PCA(pcs)
    projected = pca.fit_transform(X)
    #pca = PCA().fit(X)
    
    #cumulative variance explained by PC 
    plt.plot(np.cumsum(pca.explained_variance_ratio_))
    plt.title('{} Cumulative Explained Variance by PC'.format('The'))
    plt.xlabel('number of components');plt.ylabel('cumulative explained variance');plt.show()
    
    #cumulative variance explained by PC 
    plt.bar(height=np.cumsum(pca.explained_variance_ratio_),x=[int(i) for i in range(0,pcs)])
    plt.title('{} Cumulative Explained Variance by PC'.format(''))
    plt.xlabel('number of components');plt.ylabel('cumulative explained variance');plt.show()
    
    #join the pca projections to original data
    for i in range(0,len(projected.T)):
        var = 'pc{}'.format(i)
        X[var] =  projected[:,i]
           
    #get list of all 2 way combinations of the PCs(store as tuples)
    combos = list(itertools.combinations([i for i in range(0,len(projected.T))], 2))
    
    #plot ALL COMBINATIONS OF PRINCIPLE COMPONENTS AGAINST EACH OTHER 
    #HUE OF EACH PC BIPLOT IS OUTLIER, PLOTS SHOW OUTLIERS ON EDGES OF PCA PLOTS 
    for one,two in combos:
        plt.scatter(projected[:, one], projected[:, two],
                         c=X[var2hue].astype('category'), edgecolor='none', alpha=0.5,
                         cmap=plt.cm.get_cmap('RdYlBu', 2))
    
        plt.xlabel('component {}'.format(one))
        plt.ylabel('component {}'.format(two))
        plt.title('PC breakout for {}'.format('')+'\n'+'(Color Key: 1=outlier, 0=Normality)')
        plt.colorbar()
        plt.show()
    
    #plot first 3/ all 3 principle components on same graph 
    #NOTE: must import plot_3d_offline from rolling_list_of_functions   
    if pcs>2: 
        x=projected[:, 0]
        y=projected[:, 1]
        z=projected[:, 2]
        color=X[var2hue]
        plot_3d_offline(x,y,z,color, DF_textcol = X.index)
     
def get_Silhouette_scores(DF_OutsIn,DF_Noout,N_clusters=[2,3,4,5,6,7,8,9],init='Cao',verbose=0):
    #leverage silluehtte analysis to identify potentially optimal number of clusters(NOTE ONLY LOOKING AT THE NUMERIC VARIABLE CLUSTERING)
    from sklearn.metrics import silhouette_samples, silhouette_score
    import matplotlib.cm as cm
    outscores = []
    for n_clusters in N_clusters:
        for dataset in [DF_OutsIn, DF_Noout]:
            #get the model object (initialize grid)
            kproto = kprototypes.KPrototypes(n_clusters=n_clusters,init=init,verbose=verbose, random_state=10)
            
            #fit the model 
            clusters = kproto.fit_predict(dataset.values,categorical=CatIndicies)
            
            #Silhouette score gives average avlue for all samples 
            #gives perspective into the density and separation of the formed clusters 
            silhouette_avg = silhouette_score(dataset[NumCols2Cluster], clusters,metric='cosine')
            print("For n_clusters =", n_clusters,"The average silhouette_score is :", silhouette_avg)
            outscores.append((dataset.shape[0],n_clusters,silhouette_avg))
    return outscores

def plotbyColType(DF,NumCols,CatCols,Targets):
    #numeric plots
    cols = [col for col in NumCols]   
    if len(cols)>0:
        numcols = DF[cols].describe().T.index
        numcols = numcols
        print('DATAFRAME: {}'.format(key))
        print(DF[numcols].isnull().sum()/len(DF)*100)   
        print([(col,len(DF[col].unique())) for col in DF.columns])
        DF[numcols].hist(figsize=(30,16),layout=(2,5))
        
    #categorical plots 
    cols = [col for col in CatCols]   
    for col in cols:
        if len(list(DF[col].unique()))<1000:
          
            if len(list(DF[col].unique()))>19:
                figure(figsize=(10,5))
                suptitle('DATFRAME: {}'.format(key))
                sns.countplot(data=DF,x=col)  
                xticks(rotation=90)
                show()
            else:
                if len(list(DF[col].unique()))>9:
                    figure(figsize=(7,5))
                    sns.countplot(data=DF,x=col)    
                    xticks(rotation=90)
                    show()
                else:
                    figure(figsize=(5,3))
                    sns.countplot(data=DF,x=col)    
                    show()
    
    #plot targets
    for col in Targets:
        figure(figsize=(3,3))
        sns.countplot(data=DF,x=col)    
        show()

import math
import numpy as np
import pandas as pd
import seaborn as sns
import scipy.stats as ss
import matplotlib.pyplot as plt
from collections import Counter
from dython._private import convert


def conditional_entropy(x, y):
    """
    Calculates the conditional entropy of x given y: S(x|y)
    Wikipedia: https://en.wikipedia.org/wiki/Conditional_entropy
    :param x: list / NumPy ndarray / Pandas Series
        A sequence of measurements
    :param y: list / NumPy ndarray / Pandas Series
        A sequence of measurements
    :return: float
    """
    # entropy of x given y
    y_counter = Counter(y)
    xy_counter = Counter(list(zip(x,y)))
    total_occurrences = sum(y_counter.values())
    entropy = 0.0
    for xy in xy_counter.keys():
        p_xy = xy_counter[xy] / total_occurrences
        p_y = y_counter[xy[1]] / total_occurrences
        entropy += p_xy * math.log(p_y/p_xy)
    return entropy

#uncertainty coefficent for nominal cateogrical variable associations 
def theils_u(x, y):
    s_xy = conditional_entropy(x,y)
    x_counter = Counter(x)
    total_occurrences = sum(x_counter.values())
    p_x = list(map(lambda n: n/total_occurrences, x_counter.values()))
    s_x = ss.entropy(p_x)
    if s_x == 0:
        return 1
    else:
        return (s_x - s_xy) / s_x
###       ###
###       ###
### START ###
###       ###
###       ###
#ex.Use:plot_outs_by_pca(X,pcs=3,var2hue='eif_iso_out')
#directory of data to extract 
directory= "C:\\Users\\caridza\\Desktop\\EY\\AI\\COE\\AA COE\\ClickFox_Stratifyd\\"
targz_filenames = ["foxjds.sample.tar.gz","foxjds.sample.twotable.tar.gz"]
extension = '.csv' #extension of files contained within the tar.gz file 

#Only set to true if it is the iniital run where we extract all files fromt the tar.gz object
extract_targ = False 

#extract all tar.gz files into current folder 
if extract_targ == True:
    [extract_targz(file) for file in targz_filenames ]

#convert all csv's extract from tar.gz to dataframes 
DFS = CSVs2DictOfDFs(directory,extension)
[print('{} -> {}'.format(df,DFS[df].shape)) for df in DFS.keys()]

################################################
#########drop NAN and constant columns##########
################################################
for key in DFS.keys():
    #drop constant columns 
    DFS[key] = drop_constant_column(DFS[key])
    #drop NAN columns 
    DFS[key].dropna(how='all',axis=1,inplace=True)
    print(key,DFS[key].shape)
    
################################################
#####SPECIFY INDIVIDUAL DF TO ANALYIZE###########
################################################
DF = DFS['jds_tt_session_sample'].copy()
DF2 = DFS['jds_tt_eventdetail_sample'].copy()
DF['session_hour'] = pd.to_datetime(DF['session_date']).dt.hour
DF['session_day'] = pd.to_datetime(DF['session_date']).dt.day

Cols2Remove = ['uuid','visitor_key','session_date','CDD_fox_journey_steps']

Targets = ['TASK_Agent_to_Web_COMPLETED',
'TASK_Repeat_Agent_COMPLETED',
'TASK_Repeat_Web_COMPLETED',
'TASK_Web_Account_Activation_COMPLETED',
'TASK_Web_to_Agent_COMPLETED',]

CatCols = [
'CDD_fox_number_interactions_web',
'CDD_fox_number_of_channels',
'CDD_fox_number_interactions_agent',
'CDD_seg_product',
'CDD_seg_customer_tier',
'CDD_fox_channel_sequence',
'CDD_fox_channel_unique',
'CDD_fox_number_of_channels',
'CDD_fox_channel_last',
'CDDFILTER_Call_with_NY_agent',
'TIMEINTASKFILTER_Web_to_Agent_2_hrs',
'session_day']

NumCols = ['session_steps','session_start_epoch','session_duration',
           'CDD_fox_total_interaction_time','CDD_fox_total_interaction_time_agent','CDD_fox_percentage_of_total_interaction_time_web',
           'CDD_fox_journey_time','CDD_fox_total_interaction_time_web','CDD_fox_percentage_of_total_interaction_time_agent','session_hour'
           ]

DateCol = ['session_start_datetime']

#plot missing data 
missingno.heatmap(DF)
colsmissingdata = DF.isnull().sum()>0

#plot cols 
plotbyColType(DF,NumCols,CatCols,Targets)
##########################################################################
########CREAETE DISTRIBUTIONAL PROFILING FOR EACH DATASET#################
##########################################################################

#fill nas' and convert cats to categoric
DF = fillNas_convert_to_categoric(DF,NumCols,CatCols,Targets,NumMisConst = 0,CatMisConst = '0')
DF.info()

#nomralize numerics 
DF[NumCols].hist(figsize=(15,10))
#log normalize to scale
DF[NumCols] = DF[NumCols].apply(lambda x: np.log(x+1))
#min max normalize to create uniform ranges 
mm_scaler = preprocessing.MinMaxScaler()
DF[NumCols]= mm_scaler.fit_transform(DF[NumCols])

#idnetify outliers 
ntrees = 4000
sample_size = 20
contamination = .02
max_depth = 3
outlier2use ='eif_iso_out'
rng = np.random.RandomState(1)

#build isolation tree and ouput dataset 
DF = eif_isolationForest(DF,NumCols,ntrees=ntrees,sample_size = sample_size, contamination=contamination)
DF_Nout = DF[DF[outlier2use]==0]
plot_by_pca(DF[NumCols+[outlier2use]],pcs=3,var2hue=outlier2use)
print('Total Outliers Flagged:{}'.format(DF[DF['eif_iso_out']==1].shape[0]))

#corrolation matrix 
fig, ax = plt.subplots(figsize=(10,10))    
corr = DF_Nout[NumCols].corr()
sns.heatmap(corr, 
            xticklabels=corr.columns.values,
            yticklabels=corr.columns.values,cmap='coolwarm',annot=True,cbar=False,ax=ax,fmt=".2f",linecolor='black',linewidths=1)
sns.clustermap(corr,robust=True,col_cluster=True,metric='euclidean',cmap='coolwarm',annot=True,fmt=".2f")


#ordered categorical variable corrolatations(SPEARMAN RANK CORROLATION)
import scipy
from scipy import stats
OrderCats =[col for col in DF_Nout if (type(DF_Nout[col].values).__name__ == 'Categorical') and (DF_Nout[col].values.ordered==True)]
rho, pval = stats.spearmanr(DF_Nout[OrderCats])
Spearman_Corr_Matrix = pd.DataFrame(np.asmatrix(rho),columns = [OrderCats],index=[OrderCats])
sns.clustermap(Spearman_Corr_Matrix,robust=True,col_cluster=True,metric='euclidean',cmap='coolwarm',annot=True,fmt=".2f")


#nominal categorical corroaltions 
#Theil’s U, also referred to as the Uncertainty Coefficient, 
#based on the conditional entropy between x and y 
#given the value of x, how many possible states does y have
#and how often do they occur. 
UnorderedCats=[col for col in DF_Nout if (type(DF_Nout[col].values).__name__ == 'Categorical') and (DF_Nout[col].values.ordered==False)]
#get list of all 2 way combinations of the PCs(store as tuples)
combos = list(itertools.combinations([i for i in UnorderedCats], 2))
UnorderedCorrs =[]
for tup in combos:
    UnorderedCorrs.append([tup[0],tup[1],theils_u(DF[tup[0]],DF[tup[1]])])
UC_Corrs = pd.DataFrame(UnorderedCorrs)


#full mixed corrolation matrix 
DF_Encoded=numerical_encoding(DF, nominal_columns=UnorderedCats, drop_single_label=True, drop_fact_dict=True)
    















type(DF[col])
#plot columns by target 
for col in CatCols:
    vals = len(DF[col].unique())
    
    #only use subplots if <13 unique cats
    if vals < 13:
        #figures
        fig, ((ax1, ax2, ax3), (ax4, ax5, ax6)) = plt.subplots(nrows=2, ncols=3, sharex=True, sharey=True, figsize=(18,8))
        axes = [ax1,ax2,ax3,ax4,ax5]
        
        for target ,ax in zip(Targets,axes):
            DF.groupby([col, target]).size().unstack().plot(kind='bar', stacked=True,ax=ax,legend=False)
            ax.set_title("{}".format(target))     
    else:
        for target ,ax in zip(Targets,axes):
            DF.groupby([col, target]).size().unstack().plot(kind='bar', stacked=True,legend=True)
        


###############################################################################
#identify numeric columns to include in outlier detection and those to exclude#
###############################################################################
cols2exclude = ['visitor_key','CDD_vk_spoid','uuid','session_date','dession_start_datetime']

for col in CatCols:
c=DF.groupby([col,target]).size().rename("count")

c / c.groupby(level=[0,1]).size()
###############################################################################
####################DISTRIBUTIONAL INFORMATION#################################
###############################################################################
normdist_stats = pd.DataFrame()
normdist_stats['NUnique']= [len(DF[col].unique()) for col in  list(DF[numcols])]
normdist_stats['NMissing']= [DF[col].isnull().sum() for col in numcols]
normdist_stats['kurtosis']= [DF[col].kurtosis() for col in numcols]
normdist_stats['skew']= [DF[col].skew() for col in numcols]
normdist_stats['mean']= [DF[col].mean() for col in numcols]
normdist_stats['median']= [DF[col].median() for col in numcols]

#plot data before imputation
DF[numcols].hist(figsize=(15,10))
print(DF[numcols].isnull().sum()/len(DF)*100)
       
#FILL NA VALUES AND CONVERT STRINGS TO CATEGORIC AND PLOT NEW DISTRIBUTIONS
DF = cols_to_categoric(DF,NumMisConst = 0,CatMisConst = 0)
DF[numcols].hist(figsize=(15,10))
print(DF[numcols].isnull().sum()/len(DF)*100)

#identify numeric variables to normalize 
cols2exclude = ['visitor_key','CDD_vk_spoid','uuid','session_date','session_start_datetime']
columns_to_normalize= [col for col in  DF if (DF[col].dtype.name !='category' and DF[col].dtype.name !='object' and col not in cols2exclude and len(DF[col].unique())>8)]
[print(col,':',len(DF[col].unique())) for col in columns_to_normalize]

#normalize numeric columns 
#DF[columns_to_normalize] = DF[columns_to_normalize].apply(lambda x: (x - x.mean()) / np.std(x))
DF[columns_to_normalize] = DF[columns_to_normalize].apply(lambda x: np.log(x+1))

#plot data that has been normalized
DF[columns_to_normalize].hist(figsize=(15,10))
print(DF[numcols].isnull().sum()/len(DF)*100)
       
#convert categorical variables with >9 levels to numeric indexes
cat2numCols= [col for col in DF.select_dtypes(['category']).columns if len(DF[col].unique())>9]
DF[cat2numCols] = DF[cat2numCols].apply(lambda x: x.cat.codes.astype(int))

#identify numeric variables after all transformations and conversions 
cols2exclude = ['visitor_key','CDD_vk_spoid','uuid','session_date','session_start_datetime','session_start_epoch']
Cols2Model= [col for col in  DF if (DF[col].dtype.name !='category' and col not in cols2exclude)]

#plot corrolation matrix of independent variables
#plot_corr(DF[columns_to_normalize],size=10)
import seaborn as sns
fig, ax = plt.subplots(figsize=(10,10))    
corr = DF[Cols2Model].corr()
sns.heatmap(corr, 
            xticklabels=corr.columns.values,
            yticklabels=corr.columns.values,cmap='coolwarm',annot=True,cbar=False,ax=ax,fmt=".2f",linecolor='black',linewidths=1)

 

###############################################
#########OUTLIER ANALYSIS AND REMOVAL##########
###############################################
#eif EXTENDED isolation forest  ,ExtensionLevel=len(Cols2Model)-1
ntrees = 4000
sample_size = 44
contamination = .15
max_depth = 6
outlier2use ='eif_iso_out'
rng = np.random.RandomState(1)

#build isolation tree and ouput dataset 
DF = eif_isolationForest(DF,Cols2Model,ntrees=ntrees,sample_size = sample_size, contamination=contamination)
print('Total Outliers Flagged:{}'.format(DF[DF['eif_iso_out']==1].shape[0]))

#view outliers in principle components 
plot_by_pca(DF[NumCols+[outlier2use]],pcs=3,var2hue=outlier2use)

    

for col in Cols2Model: 
   g = sns.FacetGrid(DF, hue=outlier2use)
   g = g.map(sns.distplot, col)
###############################################
#########K-Prototype Clustering################
###############################################
Cols2Cluster= [col for col in  DF if  col not in cols2exclude+[outlier2use]]
CatCols2Cluster=[col for col in Cols2Cluster if DF[col].dtype.name =='category']
NumCols2Cluster =[col for col in Cols2Cluster if DF[col].dtype.name !='category'] 
CatIndicies = [CatCols2Cluster.index(col) for col in CatCols2Cluster]

DF_Noout = DF[DF[outlier2use]==0][CatCols2Cluster+NumCols2Cluster].copy()
DF_OutsIn = DF[CatCols2Cluster+NumCols2Cluster].copy()

#identify optimal clustering solution and Dataframe used
S_Scores = get_Silhouette_scores(DF_OutsIn,DF_Noout,N_clusters=[2,3,4,5,6,7],init='Cao',verbose=0)
OptimalClusters = max(S_Scores ,key=itemgetter(2))[1] 
OptimalDF = DF_Noout if max(S_Scores ,key=itemgetter(2))[0] == DF_Noout.shape[0] else DF_OutsIn

#define model parameters 
init       = 'Cao'                    # init can be 'Cao', 'Huang' or 'random'
n_clusters  =OptimalClusters          # how many clusters (hyper parameter)
max_iter   = 300                      # default 100
verbose = 0 

#get the model object (initialize grid)
kproto = kprototypes.KPrototypes(n_clusters=n_clusters,init=init,verbose=verbose)
clusters = kproto.fit_predict(OptimalDF.values,categorical=CatIndicies )

#Print cluster centroids of the trained model.
## Print training statistics
print(kproto.cluster_centroids_)
print(kproto.cost_)
print(kproto.n_iter_)


#ploting by groups
test = [item for item in kproto.cluster_centroids_ for sublist in item]
out = pd.DataFrame(kproto.cluster_centroids_[0]).T
out.columns = ['cluster'+str(i) for i in range(0,n_clusters)]
outm = out.melt()
groups = outm.groupby('variable')

# Plot centroids by cluster 
fig, ax = plt.subplots()
ax.margins(0.05) # Optional, just adds 5% padding to the autoscaling
for name, group in groups:   
    ax.plot(group.variable, group.value, marker='o', linestyle='', ms=12, label=name)    
ax.legend()
plt.show()
    
#combine dataframe entries with resultant cluster_id 
OptimalDF['cluster_id'] = clusters
#clustered_df.set_index('cluster_id',drop=False,inplace=True)

# Clustered result
for var in CatCols2Cluster+NumCols2Cluster:
    fig1, ax3 = plt.subplots()
    scatter = ax3.scatter(OptimalDF[var], pd.Series(clusters).astype(str), c=pd.Series(clusters), s=50)
    ax3.set_xlabel(var)
    ax3.set_ylabel('Cluster')
    plt.colorbar(scatter)
    ax3.set_title('Data points classifed according to known centers')
    plt.show()

#assign clusters to columns 
result = zip(OptimalDF, kproto.labels_)
sortedR = sorted(result, key=lambda x: x[1])
print(sortedR)

for var in CatCols2Cluster+NumCols2Cluster:
    # Iterate through the five airlines
    for cluster in list(OptimalDF['cluster_id'].unique()):
        # Subset to the airline
        subset = OptimalDF[OptimalDF['cluster_id'] == cluster]
        
        try:
            # Draw the density plot
            sns.distplot(subset[var], hist = False, kde = True,
                         kde_kws = {'shade': True, 'linewidth': 3}, 
                          label = cluster)
        except:
            continue
    # Plot formatting
    plt.legend(prop={'size': 16}, title = 'Cluster')
    plt.title('Density Plot of {} by cluster'.format(var))
    plt.xlabel(var)
    plt.ylabel('Density')
    plt.show()



