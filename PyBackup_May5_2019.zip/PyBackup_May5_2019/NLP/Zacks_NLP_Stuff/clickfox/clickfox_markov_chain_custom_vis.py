# -*- coding: utf-8 -*-
"""
Created on Fri Apr 26 10:20:59 2019

@author: caridza
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Apr 26 09:24:25 2019

@author: caridza
"""

import os
os.environ["PATH"] += os.pathsep + 'C:/Users/caridza/Downloads/WPy-3662/ZackScripts/docclassify/Lib/site-packages/graphviz-2.38/release/bin/'

from graphviz import Digraph
import numpy as np
from markovclick.models import MarkovClickstream


def visualise_markov_chain(markov_chain: MarkovClickstream,Seq2CatDic=None,DicParser = None,depth=2) -> Digraph:
    """
    Visualises Markov chain for clickstream as a graph, with individual pages
    as nodes, and edges between the first and second most likely nodes (pages).
    Probabilities for these transitions are annotated on the edges (arrows).

    Args:
        markov_chain (MarkovClickstream): Initialised MarkovClickstream object
            with probabilities computed.

    Returns:
        Digraph: Graphviz Digraph object, which can be rendered as an image or
            PDF, or displayed inside a Jupyter notebook.
    """
    if not isinstance(markov_chain, MarkovClickstream):
        raise TypeError(
            f'Argument `markov_chain` must be of type '
            f'MarkovClickstream. {type(markov_chain)} object provided '
            f'instead.'
        )
    graph = Digraph()
    prob = markov_chain.prob_matrix
    prob_matrix_sorted = np.argsort(markov_chain.prob_matrix, axis=1)
    
    #ZJC 
    if Seq2CatDic == None:
        nodes = markov_chain.pages
    else: 
        nodes =[DicParser(Seq2CatDic,val)[0] for val in markov_chain.pages]
    
    
    for i, node in enumerate(nodes):
        if node in ['journey.entry','journey.exit']:
            graph.node(
            node, node, style='filled', fillcolor='#00FF2060',
            fontname='Helvetica', penwidth='0', fontcolor='#1a237e'
            )
        else:
            graph.node(
            node, node, style='filled', fillcolor='#DFBF20',
            fontname='Helvetica', penwidth='0', fontcolor='#1a237e'
            )

        trans = []
        for j in range(1,depth):
            first_trans = nodes[prob_matrix_sorted[i, -j]]
            trans.append(first_trans)
            most_prob = prob[i, prob_matrix_sorted[i, -j]]
            
            print(most_prob)
            
            if most_prob >.5:
                color = "#76ff03"
            else:
                color = "#90caf9"
            
            if most_prob>0:
                graph.edge(
                    node, first_trans,
                    label=f'{most_prob:.2f}',
                    fontname='Helvetica', penwidth='1.5',
                    color=color, arrowsize='0.75'
                )
    
            
        if node  not in trans and prob[i, i]>0:
            print('first and second transition not equal',node)
            graph.edge(
                node, node,
                label=f'   {prob[i, i]:.2f}',
                fontname='Helvetica', penwidth='1.8',
                fontsize='10', color='#FF2020', arrowsize='0.5'
            )
    return graph
