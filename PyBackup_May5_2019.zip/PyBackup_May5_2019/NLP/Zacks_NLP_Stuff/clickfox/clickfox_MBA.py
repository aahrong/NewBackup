# -*- coding: utf-8 -*-
"""
Created on Mon Apr 29 08:36:01 2019

@author: caridza
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Apr 25 08:32:31 2019

@author: caridza
#https://galaxydatatech.com/2018/07/20/apriori-algorithm/
"""
import os
os.environ["PATH"] += os.pathsep + 'C:/Users/caridza/Downloads/WPy-3662/ZackScripts/docclassify/Lib/site-packages/graphviz-2.38/release/bin'

import graphviz
import os 
import tarfile
import pandas as pd
import numpy as np
import researchpy as rp
import itertools
from operator import itemgetter
from functools import reduce
from collections import Counter
import matplotlib.pyplot as plt
from matplotlib.pyplot import figure, show,xticks,suptitle

#3d offline plotting
import plotly
import plotly.graph_objs as go
import plotly.plotly as py
from plotly.offline import plot 
import seaborn as sns
import statsmodels.api as sm
import markovclick
from markovclick.models import MarkovClickstream
from markovclick import dummy
import graphviz

#ignore all warnings (remove in production)
import warnings
warnings.filterwarnings("ignore")

#print settings
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', -1)
%matplotlib inline

def encode_units(x):
    if x <= 0:
        return 0
    if x >= 1:
        return 1
    
#Only set to true if it is the iniital run where we extract all files fromt the tar.gz object
extract_targ = False         

#DFS to compare change in marketing on markov transition state probabilities
DF_Orig = 'jds_tt_eventdetail_sample'
DF_Compare = 'jds_tt_eventdetail_sample_alt1'

#extract all tar.gz files into current folder 
if extract_targ == True:
    [extract_targz(file) for file in targz_filenames ]

#convert all csv's extract from tar.gz to dataframes 
DFS = CSVs2DictOfDFs(directory,extension)
[print('{} -> {}'.format(df,DFS[df].shape)) for df in DFS.keys()]

################################################
#########drop NAN and constant columns##########
################################################
for key in DFS.keys():
    #drop constant columns 
    DFS[key] = drop_constant_column(DFS[key])
    #drop NAN columns 
    DFS[key].dropna(how='all',axis=1,inplace=True)
    print(key,DFS[key].shape)
    
################################################
#####SPECIFY INDIVIDUAL DF TO ANALYIZE###########
################################################
#evaluating nominal associations 
DF = DFS[DF_Orig].copy()
DF2 = DFS[DF_Compare].copy()


######################################
####MBA mlxtend implementaiton########
######################################

#sequences to model 
import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import association_rules
from mlxtend.frequent_patterns import apriori

#consolidate all sequences into 1 line per vistorid. 
basket = (DF.groupby(['visitor_key', 'event_name'])['event_seqid']
          .sum().unstack().reset_index().fillna(0)
          .set_index('visitor_key'))

#There are a lot of zeros in the data but we also need to make sure any positive values are converted to a 1 
#and anything less the 0 is set to 0. 
basket_sets = basket.applymap(encode_units)

#generate frequent item sets 
frequent_itemsets = apriori(basket_sets, min_support=0.07, use_colnames=True)

#generate mba rules 
rules = association_rules(frequent_itemsets, metric="lift", min_threshold=1)
rules.head()

#filter rules to include onlyu those with high liift and confidence 
rules[ (rules['lift'] >= 6) &
       (rules['confidence'] >= 0.8) ]


######################################
####apyori implementaiton#############
######################################
#create one hot encoded dataframe 
Seq_col = 'event_name'
id_col = 'visitor_key'
LongDF = DF.pivot(index = id_col,columns = 'event_seqid',values = 'event_name').T
seq_list = [list(LongDF[x].T) for x in LongDF.columns]
Seq2Mod = [[var for var in Seq if str(var)!='nan'] for Seq in  seq_list]
te = TransactionEncoder()
te_ary = te.fit(Seq2Mod).transform(Seq2Mod)
df = pd.DataFrame(te_ary,columns = te.columns_)
df.set_index(DF.visitor_key.unique())

#use apyrori for mine association rules 
from apyori import apriori
data = Seq2Mod
assoc_rules = apriori(data, min_support = .03, min_confidence = .1, min_lift = 1, max_length=None)
result = list(assoc_rules )
df = pd.DataFrame(result)


#results appear as a list of multiople RelationRecords , which reflects all associated with a specific itemset that has relevant rules. 
#ordered_statistic reflects a list of all rules that met our min_confidence and min_lift required parametrized when apriori() called. 
#each orderedStatistic contains the antecedent(items_base) and consequent(items_add) for the rule, as well as the associated confidence and lift 
#items: items in the rule 
for item in assoc_rules:

    # first index of the inner list
    # Contains base item and add item
    pair = item[0] 
    items = [x for x in pair]
    print("Rule: " + items[0] + " -> " + items[1])

    #second index of the inner list
    print("Support: " + str(item[1]))

    #third index of the list located at 0th
    #of the third index of the inner list

    print("Confidence: " + str(item[2][0][2]))
    print("Lift: " + str(item[2][0][3]))
    print("=====================================") 


######################################
####efficet - apriori implementaiton##
######################################
from efficient_apriori import apriori 
transactions = Seq2Mod

itemsets, rules = apriori(transactions, min_support=0.2,  min_confidence=1)

# Print out every rule with 2 items on the left hand side,
# 1 item on the right hand side, sorted by lift
rules_rhs = filter(lambda rule: len(rule.lhs) == 2 and len(rule.rhs) == 1, rules)
for rule in sorted(rules_rhs, key=lambda rule: rule.lift):
  print(rule) # Prints the rule and its confidence, support, lift, ...





#generate markov sequences to model 
def Build_Markov_Seqs(DF=None,Seq_col=None,id_col = None):
    #model preprocessing
    #convert categoric into labels
    import sklearn
    le = sklearn.preprocessing.LabelEncoder()
    le.fit(DF['event_name']);#cats = le.inverse_transform(DF['event_name'])
    Seq2CatMap = list(set([(le.inverse_transform(val),val,'P'+str(int(val)+1//1)) for val in le.transform(DF[Seq_col]) ]))
    Seq2CatDic= {k:{'lemap':lemap,'seqval':seqval} for k,lemap,seqval in Seq2CatMap}
    
    #add columns to dataframe
    DF['event_sequence'] = DF[Seq_col].apply(lambda x: Seq2CatDic[x]['seqval'])
    DF['event_label'] = DF[Seq_col].apply(lambda x: Seq2CatDic[x]['lemap'])
    
    #plotting view of steps across numeric index 
    DF.groupby(id_col).event_label.hist(alpha=.4)

    #sequences to model 
    LongDF = DF.pivot(index = id_col,columns = 'event_seqid',values = 'event_sequence').T
    seq_list = [list(LongDF[x].T) for x in LongDF.columns]
    Seq2Mod = [[var for var in Seq if str(var)!='nan'] for Seq in  seq_list]
    return Seq2Mod,Seq2CatDic



