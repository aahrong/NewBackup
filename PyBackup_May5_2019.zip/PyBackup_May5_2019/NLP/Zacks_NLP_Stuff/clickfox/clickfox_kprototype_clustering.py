# -*- coding: utf-8 -*-
"""
Created on Tue Apr 23 09:43:52 2019

@author: caridza
"""
from   kmodes import kmodes
from   kmodes import kprototypes
import matplotlib.pyplot as plt
import seaborn as sns

jds_tt_session_sample = DFS['jds_tt_session_sample']
summary_dict['jds_tt_session_sample']['NumVarStats']
summary_dict['jds_tt_session_sample']['CatColStats']

##
##
##K-Prototype clustering for mixed data
##
##

#define categorical features
ids2remove = ['uuid','visitor_key','session_start_datetime','session_date']
cat_feild_names = list(summary_dict['jds_tt_session_sample']['CatColStats'].index.values)
num_feild_names = list(summary_dict['jds_tt_session_sample']['NumVarStats'].Variable.values)

#remove variables we dont want to cluster on 
for var in ids2remove:
    try:
        num_feild_names.remove(var)
    except:
        cat_feild_names.remove(var)
    

#identify categorical caolumns 
categoricals_indicies = []
for col in cat_feild_names:
        categoricals_indicies.append(cat_feild_names.index(col))

cat_feild_names = [col for col in  DF if (DF[col].dtype.name=='category' and col not in cols2exclude and col in fields)]
cat_feild_indicies = [DF[fields].columns.get_loc(col) for col in cat_feild_names if col in fields]
num_feild_names = [col for col in  DF if (col not in cat_feild_names and col not in cols2exclude and col in fields)]



#define numeric features 
jds_tt_session_sample['session_hour'] = pd.to_datetime(jds_tt_session_sample['session_date']).dt.hour

fields = list(cat_feild_names) + list(num_feild_names) + list(['session_hour'])
fields = Cols2Cluster

#subset dataset for clustering
data_cats = jds_tt_session_sample.loc[:,fields]
data_cats  = DF[fields]


#normalize numeric columns 
columns_to_normalize     = num_feild_names+['session_hour']
data_cats[columns_to_normalize] = data_cats[columns_to_normalize].apply(lambda x: (x - x.mean()) / np.std(x))
data_cats.info()


#transform datafarme into matrix 
#kprototypes requires an array 
data_cats_matrix = data_cats.values
matrix_cols = list(data_cats)


#define model parameters 
init       = 'Cao'                    # init can be 'Cao', 'Huang' or 'random'
n_clusters = 3                         # how many clusters (hyper parameter)
max_iter   = 100                        # default 100
verbose = 0 

#get the model object (initialize grid)
kproto = kprototypes.KPrototypes(n_clusters=n_clusters,init=init,verbose=verbose)

#fit the model 
clusters = kproto.fit_predict(data_cats_matrix,categorical=categoricals_indicies)

#Print cluster centroids of the trained model.
## Print training statistics
print(kproto.cluster_centroids_)
print(kproto.cost_)
print(kproto.n_iter_)




#ploting by groups
test = [item for item in kproto.cluster_centroids_ for sublist in item]
out = pd.DataFrame(kproto.cluster_centroids_[0]).T
out.columns = ['cluster'+str(i) for i in range(0,n_clusters)]
outm = out.melt()
groups = outm.groupby('variable')

# Plot centroids by cluster 
fig, ax = plt.subplots()
ax.margins(0.05) # Optional, just adds 5% padding to the autoscaling
for name, group in groups:   
    ax.plot(group.variable, group.value, marker='o', linestyle='', ms=12, label=name)    
ax.legend()
plt.show()
    
#combine dataframe entries with resultant cluster_id 
proto_cluster_assignments = zip(data_cats_matrix,clusters)
clustered_df = jds_tt_session_sample.loc[:,fields]
clustered_df['cluster_id'] = clusters
#clustered_df.set_index('cluster_id',drop=False,inplace=True)

# Clustered result
for var in fields:
    fig1, ax3 = plt.subplots()
    scatter = ax3.scatter(clustered_df[var], pd.Series(clusters).astype(str), c=pd.Series(clusters), s=50)
    ax3.set_xlabel(var)
    ax3.set_ylabel('Cluster')
    plt.colorbar(scatter)
    ax3.set_title('Data points classifed according to known centers')
    plt.show()
result = zip(clustered_df, kproto.labels_)
sortedR = sorted(result, key=lambda x: x[1])
print(sortedR)


#plot each variable by its cluster assignment 
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
sns.set(style="darkgrid")
for col in num_feild_names:
    g = sns.FacetGrid(clustered_df, col="cluster_id", margin_titles=True)
    bins = np.linspace(0, 60, 13)
    g.map(plt.hist, col, color="green", bins=bins)



# plot distributions of variables 
cluster_ids=  list(set(clustered_df['cluster_id']))

for var in num_feild_names:
    # Iterate through the five airlines
    for cluster in cluster_ids:
        # Subset to the airline
        subset = clustered_df[clustered_df['cluster_id'] == cluster]
        
        try:
            # Draw the density plot
            sns.distplot(subset[var], hist = False, kde = True,
                         kde_kws = {'shade': True, 'linewidth': 3}, 
                          label = cluster)
        except:
            continue
    # Plot formatting
    plt.legend(prop={'size': 16}, title = 'Airline')
    plt.title('Density Plot with Multiple Airlines')
    plt.xlabel('Delay (min)')
    plt.ylabel('Density')
    plt.show()
    
#leverage silluehtte analysis to identify potentially optimal number of clusters(NOTE ONLY LOOKING AT THE NUMERIC VARIABLE CLUSTERING)
from sklearn.metrics import silhouette_samples, silhouette_score

import matplotlib.cm as cm
verbose = 0
n_clusters=4
y_lower = 10
init = 'Cao'
for n_clusters in [2,3,4,5,6,7,8,9,10,11]:
    fig, (ax1, ax2) = plt.subplots(1, 2)
    fig.set_size_inches(18, 7)


    # The 1st subplot is the silhouette plot
    # The silhouette coefficient can range from -1, 1 but in this example all
    # lie within [-0.1, 1]
    ax1.set_xlim([-0.1, 1])
    # The (n_clusters+1)*10 is for inserting blank space between silhouette
    # plots of individual clusters, to demarcate them clearly.
    #ax1.set_ylim([0, data_cats.shape[0] + (n_clusters + 1) * 10])

    #get the model object (initialize grid)
    kproto = kprototypes.KPrototypes(n_clusters=n_clusters,init=init,verbose=verbose, random_state=10)
    
    #fit the model 
    clusters = kproto.fit_predict(data_cats_matrix,categorical=categoricals_indicies)
    
    #Silhouette score gives average avlue for all samples 
    #gives perspective into the density and separation of the formed clusters 
    silhouette_avg = silhouette_score(data_cats[num_feild_names], clusters,metric='cosine')
    print("For n_clusters =", n_clusters,"The average silhouette_score is :", silhouette_avg)

    # Compute the silhouette scores for each sample
    sample_silhouette_values = silhouette_samples(data_cats[num_feild_names], clusters)

    for i in range(n_clusters):
        
        # Aggregate the silhouette scores for samples belonging to
        # cluster i, and sort them
        ith_cluster_silhouette_values = \
            sample_silhouette_values[clusters == i]
     
        ith_cluster_silhouette_values.sort()
    
        size_cluster_i = ith_cluster_silhouette_values.shape[0]
        y_upper = y_lower + size_cluster_i
    
        color = cm.nipy_spectral(float(i) / n_clusters)
        ax1.fill_betweenx(np.arange(y_lower, y_upper),
                          0, ith_cluster_silhouette_values,
                          facecolor=color, edgecolor=color, alpha=0.7)
    
        # Label the silhouette plots with their cluster numbers at the middle
        ax1.text(-0.05, y_lower + 0.5 * size_cluster_i, str(i))
    
        # Compute the new y_lower for next plot
        y_lower = y_upper + 10  # 10 for the 0 samples
    
    ax1.set_title("The silhouette plot for the various clusters.")
    ax1.set_xlabel("The silhouette coefficient values")
    ax1.set_ylabel("Cluster label")
    
    # The vertical line for average silhouette score of all the values
    ax1.axvline(x=silhouette_avg, color="red", linestyle="--")
    
    ax1.set_yticks([])  # Clear the yaxis labels / ticks
    ax1.set_xticks([-0.1, 0, 0.2, 0.4, 0.6, 0.8, 1])
    
    # 2nd Plot showing the actual clusters formed
    colors = cm.nipy_spectral(clusters.astype(float) / n_clusters)
    ax2.scatter(data_cats['CDD_fox_total_interaction_time'], data_cats['session_duration'], marker='.', s=30, lw=0, alpha=0.7,
                c=colors, edgecolor='k')
    
    # Labeling the clusters
    centers = kproto.cluster_centroids_[0]
    # Draw white circles at cluster centers
    ax2.scatter(centers[:, 0], centers[:, 1], marker='o',
                c="white", alpha=1, s=200, edgecolor='k')
    
    for i, c in enumerate(centers):
        ax2.scatter(c[0], c[1], marker='$%d$' % i, alpha=1,
                    s=50, edgecolor='k')
    
    ax2.set_title("The visualization of the clustered data.")
    ax2.set_xlabel("Feature space for the 1st feature")
    ax2.set_ylabel("Feature space for the 2nd feature")
    
    plt.suptitle(("Silhouette analysis for KMeans clustering on sample data "
                  "with n_clusters = %d" % n_clusters),
                 fontsize=14, fontweight='bold')

plt.show()








#visualize initital distributions of each series
def plot_summary(DICT,key):
    df =  DICT[key]['DataFrame'] 
    
    #numeric plots
    cols = [col for col in df if col in DICT[key]['NumCols']]   
    if len(cols)>0:
        numcols = df[cols].describe().T.index
        numcols = numcols
        print('DATAFRAME: {}'.format(key))
        print(df[numcols].isnull().sum()/len(df)*100)   
        df[numcols].hist(figsize=(20,20))
        
    #categorical plots 
    cols = [col for col in df if col in DICT[key]['Catcols']]   
    for col in cols:
        if len(list(df[col].unique()))<1000:
          
            if len(list(df[col].unique()))>19:
                figure(figsize=(15,5))
                suptitle('DATFRAME: {}'.format(key))
                sns.countplot(data=df,x=col)  
                xticks(rotation=90)
                show()
            else:
                figure(figsize=(15,5))
                sns.countplot(data=df,x=col)    
                show()
                

def isoforest_out(df = DFS['jds_tt_session_sample'][num_vars['jds_tt_session_sample']],cols2exclude = [],returnFull=True ):
    DocData_NO = df.copy()
    
    Row_idxs = []
    Row_idxs_info = []
    
    numcols = DocData_NO.describe().T.index
    numcols = [col for col in numcols if col not in cols2exclude]


    df_sub =DocData_NO[numcols]
    X_train=X_test = df_sub
    
    clf = IsolationForest(n_jobs=6,n_estimators=500, max_samples=256, random_state=23)
    clf.fit(X_train)
    y_pred_train = clf.predict(X_train)
    df_sub['iso_outlier'] = y_pred_train
    print(Counter(y_pred_train))
    
    return(df_sub)
    
    
out= isoforest_out(df = DFS['jds_tt_session_sample'][num_vars['jds_tt_session_sample']],cols2exclude = [],returnFull=True )



######ENHANCED LOOPS THROUGH DF WITH AND WITHOUT OUTLIERS
#leverage silluehtte analysis to identify potentially optimal number of clusters(NOTE ONLY LOOKING AT THE NUMERIC VARIABLE CLUSTERING)
from sklearn.metrics import silhouette_samples, silhouette_score

import matplotlib.cm as cm
verbose = 0
n_clusters=4
y_lower = 10
init = 'Cao'
for n_clusters in [2,3,4,5,6,7,8,9,10,11]:
    
    for dataset in [DF[CatCols2Cluster+NumCols2Cluster].copy(), DF[DF[outlier2use]==0][CatCols2Cluster+NumCols2Cluster].copy()]:

        fig, (ax1, ax2) = plt.subplots(1, 2)
        fig.set_size_inches(18, 7)
    
    
    
        # The 1st subplot is the silhouette plot
        # The silhouette coefficient can range from -1, 1 but in this example all
        # lie within [-0.1, 1]
        ax1.set_xlim([-0.1, 1])
        # The (n_clusters+1)*10 is for inserting blank space between silhouette
        # plots of individual clusters, to demarcate them clearly.
        #ax1.set_ylim([0, data_cats.shape[0] + (n_clusters + 1) * 10])
    
        #get the model object (initialize grid)
        kproto = kprototypes.KPrototypes(n_clusters=n_clusters,init=init,verbose=verbose, random_state=10)
        
        #fit the model 
        clusters = kproto.fit_predict(dataset.values,categorical=CatIndicies)
        
        #Silhouette score gives average avlue for all samples 
        #gives perspective into the density and separation of the formed clusters 
        silhouette_avg = silhouette_score(dataset[NumCols2Cluster], clusters,metric='cosine')
        print("For n_clusters =", n_clusters,"The average silhouette_score is :", silhouette_avg)
    
        # Compute the silhouette scores for each sample
        sample_silhouette_values = silhouette_samples(dataset[NumCols2Cluster], clusters)
    
        for i in range(n_clusters):
            
            # Aggregate the silhouette scores for samples belonging to
            # cluster i, and sort them
            ith_cluster_silhouette_values = \
                sample_silhouette_values[clusters == i]
         
            ith_cluster_silhouette_values.sort()
        
            size_cluster_i = ith_cluster_silhouette_values.shape[0]
            y_upper = y_lower + size_cluster_i
        
            color = cm.nipy_spectral(float(i) / n_clusters)
            ax1.fill_betweenx(np.arange(y_lower, y_upper),
                              0, ith_cluster_silhouette_values,
                              facecolor=color, edgecolor=color, alpha=0.7)
        
            # Label the silhouette plots with their cluster numbers at the middle
            ax1.text(-0.05, y_lower + 0.5 * size_cluster_i, str(i))
        
            # Compute the new y_lower for next plot
            y_lower = y_upper + 10  # 10 for the 0 samples
        
        ax1.set_title("The silhouette plot for the various clusters.")
        ax1.set_xlabel("The silhouette coefficient values")
        ax1.set_ylabel("Cluster label")
        
        # The vertical line for average silhouette score of all the values
        ax1.axvline(x=silhouette_avg, color="red", linestyle="--")
        
        ax1.set_yticks([])  # Clear the yaxis labels / ticks
        ax1.set_xticks([-0.1, 0, 0.2, 0.4, 0.6, 0.8, 1])
        
        # 2nd Plot showing the actual clusters formed
        colors = cm.nipy_spectral(clusters.astype(float) / n_clusters)
        ax2.scatter(dataset['CDD_fox_total_interaction_time'], dataset['session_duration'], marker='.', s=30, lw=0, alpha=0.7,
                    c=colors, edgecolor='k')
        
        # Labeling the clusters
        centers = kproto.cluster_centroids_[0]
        # Draw white circles at cluster centers
        ax2.scatter(centers[:, 0], centers[:, 1], marker='o',
                    c="white", alpha=1, s=200, edgecolor='k')
        
        for i, c in enumerate(centers):
            ax2.scatter(c[0], c[1], marker='$%d$' % i, alpha=1,
                        s=50, edgecolor='k')
        
        ax2.set_title("The visualization of the clustered data.")
        ax2.set_xlabel("Feature space for the 1st feature")
        ax2.set_ylabel("Feature space for the 2nd feature")
        
        plt.suptitle(("Silhouette analysis for KMeans clustering on sample data "
                      "with n_clusters = %d" % n_clusters),
                     fontsize=14, fontweight='bold')
    
    plt.show()