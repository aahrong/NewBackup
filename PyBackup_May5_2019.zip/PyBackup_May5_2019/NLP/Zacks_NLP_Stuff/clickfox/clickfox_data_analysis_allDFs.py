# -*- coding: utf-8 -*-
"""
Created on Mon Apr 22 08:23:01 2019

@author: caridza
"""
import os 
import tarfile
import pandas as pd
import numpy as np
import researchpy as rp
from matplotlib.pyplot import figure, show,xticks,suptitle
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', -1)

def extract_targz(filepath):
    tf = tarfile.open(filepath)
    tf.extractall()

def CSVs2DictOfDFs(directory,extension):
    df_dict = {}
    for root,dirs,files in os.walk(directory):
        for f in files:
            if f.endswith(extension):
                key = f.replace(extension,'')
                value = os.path.join(root,f)
                df_dict[key]= pd.read_csv(value)
    return df_dict

################################
#Exploratory analysis functions#
################################
def numcols(df=None,numeric=True):
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    cols = []
    for idx in df.index:
        for col in df.columns:
             if idx == df.index[0]:
                dype = type(df.loc[idx,col]).__name__
                
                if (numeric == True) & (dype in numerics):
                    #print('yes')
                    cols.append(col)
                if (numeric == False) & (dype not in numerics):
                    cols.append(col)
    return cols

def df_rowtypes(df,cols=None):
    df_copy = df.copy()
    df_copy.index = df.index
    df_copy.columns = df.columns
    #loop over indexes for each column and determine the type of data in each row of each column 
    #assignment to new dataframe based on idx location
    if cols is None: 
        cols = list(df)
        
    for col in cols:
        for i in df.index:
            try:
                val = type(df.loc[i, col]).__name__ 
                #print(val)
                if val =='list':
                    df_copy.loc[i, col] = len(df.loc[i, col])
                elif val =='dict':
                    df_copy.loc[i, col] = len(df.loc[i, col].keys())
                else:
                    df_copy.loc[i, col] = val
            except Exception: 
                print(Exception)
                print(val)
                df_copy.loc[i, col] = df_copy.loc[i, col]                 
    return df_copy

def drop_constant_column(dataframe):
    """
    Drops constant value columns of pandas dataframe.
    """
    return dataframe.loc[:, (dataframe != dataframe.iloc[0]).any()]


#visualize initital distributions of each series
def plot_summary(DICT,key):
    df =  DICT[key]['DataFrame'] 
    
    #numeric plots
    cols = [col for col in df if col in DICT[key]['NumCols']]   
    if len(cols)>0:
        numcols = df[cols].describe().T.index
        numcols = numcols
        print('DATAFRAME: {}'.format(key))
        print(df[numcols].isnull().sum()/len(df)*100)   
        df[numcols].hist(figsize=(20,20))
        
    #categorical plots 
    cols = [col for col in df if col in DICT[key]['Catcols']]   
    for col in cols:
        if len(list(df[col].unique()))<1000:
          
            if len(list(df[col].unique()))>19:
                figure(figsize=(15,5))
                suptitle('DATFRAME: {}'.format(key))
                sns.countplot(data=df,x=col)  
                xticks(rotation=90)
                show()
            else:
                figure(figsize=(15,5))
                sns.countplot(data=df,x=col)    
                show()
                
#directory of data to extract 
directory= "C:\\Users\\caridza\\Desktop\\EY\\AI\\COE\\AA COE\\ClickFox_Stratifyd\\"
targz_filenames = ["foxjds.sample.tar.gz","foxjds.sample.twotable.tar.gz"]
extension = '.csv' #extension of files contained within the tar.gz file 

#Only set to true if it is the iniital run where we extract all files fromt the tar.gz object
extract_targ = False 

#extract all tar.gz files into current folder 
if extract_targ == True:
    [extract_targz(file) for file in targz_filenames ]

#convert all csv's extract from tar.gz to dataframes 
DFS = CSVs2DictOfDFs(directory,extension)
[print('{} -> {}'.format(df,DFS[df].shape)) for df in DFS.keys()]

#########################################################################
#create mapping of all tables and columns to identify primary join keys## 
#Identify overlapping columns across datasets
#########################################################################
from functools import reduce

#identify all unique columns across all datasets
Unique_cols = pd.DataFrame(list(set([item for sublist in [list(DFS[key]) for key in DFS.keys()] for item in sublist])),columns=['AllCols'])
#identify unique columns in each individual dataset
df_cols =  [pd.DataFrame(list(DFS[key]),columns = [key]) for key in DFS.keys()]  
#create metadata table indicating which dataframes contain which columns 
for i in range(0,len(df_cols)): 
    Unique_cols = Unique_cols.merge(df_cols[i],left_on='AllCols',right_on = list(df_cols[i]),how='left')
for col in Unique_cols.columns:
    if col !='AllCols':
        Unique_cols[col] = Unique_cols[col].apply(lambda x: 0 if pd.isnull(x)==True else 1)

Unique_cols.set_index('AllCols',drop=True,inplace=True)
Unique_cols['TotalDfsWithCol'] = Unique_cols.sum(axis=1)# Unique_cols.apply(lambda x: sum(x),axis=1)
Unique_cols.sort_values(by = ['TotalDfsWithCol','jds_tt_session_sample'], ascending = False,inplace=True)
list(Unique_cols[Unique_cols['TotalDfsWithCol']>1].index)

################################################
#########drop NAN and constant columns##########
################################################
for key in DFS.keys():
    #drop constant columns 
    DFS[key] = drop_constant_column(DFS[key])
    #drop NAN columns 
    DFS[key].dropna(how='all',axis=1,inplace=True)
    print(DFS[key].shape)
    
#####################################################
#########identify and evaluate missing data##########
#####################################################
#missingno.matrix(DFS[df],figsize=(10,10))
# missingno.matrix(filtered,figsize=(10,10))
#missingno.bar(DFS[df], p=.1)
#missingno.dendrogram(DFS[df],figsize=(10,5),fontsize=8)
import missingno
%matplotlib inline
DFs_Mis = ['jds_tt_session_sample','jds_tt_eventdetail_sample']
for df in DFs_Mis:
    filtered = missingno.nullity_sort(
            missingno.nullity_filter(
                    DFS[df],
                    filter="bottom",
                    n=10,
                    p=.965)
            ,sort='ascending')

    missingno.heatmap(filtered,figsize=(6,6),fontsize=16)   
    missingno.bar(filtered,figsize=(6,3))
    missingno.matrix(filtered,figsize=(6,6),sparkline=True)
    #suptitle('DATFRAME: {}'.format(df))
    
for df in DFS.keys():
    try:   
        missingno.heatmap(DFS[df], filter='top', sort='descending',figsize=(5,5),fontsize=8,p=.4)
        suptitle('DATFRAME: {}'.format(df))
    except:
        continue
    
#The dendrogram uses a hierarchical clustering algorithm (courtesy of scipy) 
#to bin variables against one another by their nullity correlation 
#(measured in terms of binary distance). 
#use to identify required attributes : those attributes when linked together have a distance of 0 are always present 
#Cluster leaves which split close to zero, but not at it, predict one another very well, but still imperfectly. 
#If your own interpretation of the dataset is that these columns actually are or ought to be match each other in nullity      
##########################################################################
#create dictonary with summary of missing values for each dataframe######
##########################################################################
import collections
missing_dict = {}
num_vars = {}
cat_vars = {}
for key in DFS.keys():
    val = str(key)
    missing_dict[val] = DFS[key].isnull().sum() 
    num_vars[val] = list((DFS[key].select_dtypes(include=[np.number]).columns.values))
    cat_vars[val] = DFS[key].columns.difference(list(DFS[key].select_dtypes(include=[np.number]).columns.values))
    
#
######################################################
##########identify and evaluate outliers in data######
######################################################
#from sklearn.preprocessing import StandardScaler
#from sklearn.cluster import DBSCAN
##NON PARAMETRIC OUTLIER DETECTION (FOR SKEWED DISTRIBUTIONS)
## scale data first
#X = StandardScaler().fit_transform( DFS['jds_tt_session_sample'][num_vars['jds_tt_session_sample']])
#
#db = DBSCAN(eps=3.0, min_samples=10).fit(X)
#labels = db.labels_
#pd.Series(labels).value_counts()
#
#plt.figure(figsize=(10,10))
#
#unique_labels = set(labels)
#colors = ['blue', 'red']
#
#for color,label in zip(colors, unique_labels):
#    sample_mask = [True if l == label else False for l in labels]
#    plt.plot(X[:,0][sample_mask], X[:, 1][sample_mask], 'o', color=color);
#plt.xlabel(label);
#plt.ylabel('Standardized Price');


###############################################
#####FILL MISSING VALUES FOR THE DF WE WANT####
########TO PERFORM CLUSTERING ON ##############
   
##preview and fill na values 
#missingno.heatmap( DFS['jds_tt_session_sample'])
#
#missingvars = []
#for key in missing_dict['jds_tt_session_sample'].index:
#    
#    #profile levels of each attribute with missing avlues
#    if missing_dict['jds_tt_session_sample'][key]>0:
#        missingvars.append(key)
#        print( DFS['jds_tt_session_sample'][key].value_counts(dropna=False))
#        
#        #fill all NA's with 0 to enable clustering (after verifiying 0 is not significant in any of the categories)
#        DFS['jds_tt_session_sample'][key].fillna(0,inplace=True)
#               

########################################
#convert numeric variables to categoric#
########################################
#1.If variable has natrual ordality (1,2,3,...,) we create orderd categoric varaiible to retain the rankings 
#2.If variable is binary , we create non-ordered categorical variable 
#3. If variable is a string we simply convert to categoric with no order 
#for each dataset in dictonary 
for key in DFS.keys():
    #for each column in dataset
    for col in DFS[key].columns:
        #if unique items in column < 10 
        if len(DFS[key][col].unique())<20:
            #Create list of unique categories in column
            categories = np.array(DFS[key][col].unique())
            
            try:
                #if the categories are NUMERIC in nature
                if isinstance(int(categories[0]),int):
                    
                    #if there are >4 levels of the numeric variable, treat it as numeric and continue to loop over next variable
                    if len(categories)>4:
                        if any(np.isnan(categories)):
                            DFS[key][col].fillna(0,inplace=True)
                        continue
                    else:
                        #loop through categories
                         for category in categories:
                             #check for nan category values 
                             #if category !=category:
                             if np.isnan(category):
                                 #fill nan category values with constant
                                  DFS[key][col].fillna(0,inplace=True)
                                  #DFS[key][col].fillna(np.NaN,inplace=True)
                        
                        #create ordinal categorical variables form numeric values where available 
                         if type(categories[0]).__name__ in ['int64','numpy.float64','float64']:
                             print('numeric')
                             categories = np.array(DFS[key][col].unique())
                             categories.sort()
                             print(categories)
                             DFS[key][col] =DFS[key][col].astype('category',categories = categories, copy=False,ordered=True)
                        #create non orderd categorical variables for all other numeric like categorical variables (booleans)
                         else:
                             print('Numeric type not captured',type(categories[0]).__name__)
                             categories = np.array(DFS[key][col].unique())
                             print(categories)
                             DFS[key][col] =DFS[key][col].astype('category',categories = categories, copy=False,ordered=False)
       
            #if the first category in the list of categories is not an integer, we skip the creation / identification 
            #of ordnality and generate non ordered categorical variables 
            except:
                #loop through each category 
                for category in categories:
                    #check if any NANs in category list
                    if category !=category:
                        #if nan is present as a category, fill all nan values with constant string that will be a new categorical level 
                        DFS[key][col].fillna("MISSING",inplace=True)
                
                #return new list of values to be converted to categorical after accounting for NAN 
                categories = np.array(DFS[key][col].unique())
                #Convert column to categorical with levels specified
                DFS[key][col] =DFS[key][col].astype('category',categories = categories, copy=False,ordered = False)
       
##########################################################################
#create default dictonary with summary statistics for each dataframe######
##########################################################################
import collections
summary_dict = collections.defaultdict(dict)
for key in DFS.keys():
    val = str(key)
    summary_dict[val]['DataFrame'] = DFS[key] 
    summary_dict[val]['JoinKeys'] = list(set(DFS[key]).intersection(list(Unique_cols[Unique_cols['TotalDfsWithCol']>1].index)))
    summary_dict[val]['VarTypes'] = df_rowtypes(DFS[key].head(1))  
    summary_dict[val]['NumCols'] = list((DFS[key].select_dtypes(include=[np.number]).columns.values))
    summary_dict[val]['Catcols'] = DFS[key].columns.difference(list(DFS[key].select_dtypes(include=[np.number]).columns.values))
    
    NumCol_stats = rp.summary_cont(DFS[key][summary_dict[val]['NumCols']])[['Variable','N','Mean','SD','SE']]
    NumCol_stats['kurtosis'] = DFS[key][summary_dict[val]['NumCols']].kurtosis().values
    NumCol_stats['skew']=DFS[key][summary_dict[val]['NumCols']].skew().values
    NumCol_stats['Nunique']=[len(DFS[key][col].unique()) for col in  list(DFS[key][summary_dict[val]['NumCols']])]
    NumCol_stats['NMissing'] = [DFS[key][col].isnull().sum() for col in list(DFS[key][summary_dict[val]['NumCols']])]
    CatCol_Stats= DFS[key][summary_dict[val]['Catcols']].describe().T
    
    summary_dict[val]['NumVarStats'] = NumCol_stats
    summary_dict[val]['CatColStats'] = CatCol_Stats
    
    

##########################################################################
########CREAETE DISTRIBUTIONAL PROFILING FOR EACH DATASET#################
##########################################################################
import matplotlib.pyplot as plt
import seaborn as sns

#visualize initital distributions of each series
for key in summary_dict:
    df =  summary_dict[key]['DataFrame'] 
    
    #numeric plots
    cols = [col for col in df if col in summary_dict[key]['NumCols']]   
    if len(cols)>0:
        numcols = df[cols].describe().T.index
        numcols = numcols
        print('DATAFRAME: {}'.format(key))
        print(df[numcols].isnull().sum()/len(df)*100)   
        df[numcols].hist(figsize=(20,20))
        
    #categorical plots 
    cols = [col for col in df if col in summary_dict[key]['Catcols']]   
    for col in cols:
        if len(list(df[col].unique()))<1000:
          
            if len(list(df[col].unique()))>19:
                figure(figsize=(15,5))
                suptitle('DATFRAME: {}'.format(key))
                sns.countplot(data=df,x=col)  
                xticks(rotation=90)
                show()
            else:
                figure(figsize=(15,5))
                sns.countplot(data=df,x=col)    
                show()
    













