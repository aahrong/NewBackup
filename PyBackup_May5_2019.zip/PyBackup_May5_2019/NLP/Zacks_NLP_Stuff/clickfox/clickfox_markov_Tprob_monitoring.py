# -*- coding: utf-8 -*-
"""
Created on Mon Apr 29 08:36:01 2019

@author: caridza
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Apr 25 08:32:31 2019

@author: caridza
"""
import os
os.environ["PATH"] += os.pathsep + 'C:/Users/caridza/Downloads/WPy-3662/ZackScripts/docclassify/Lib/site-packages/graphviz-2.38/release/bin'

import graphviz
import os 
import tarfile
import pandas as pd
import numpy as np
import researchpy as rp

import itertools
from operator import itemgetter
from functools import reduce
from collections import Counter

import matplotlib.pyplot as plt
from matplotlib.pyplot import figure, show,xticks,suptitle

#3d offline plotting
import plotly
import plotly.graph_objs as go
import plotly.plotly as py
from plotly.offline import plot 
import seaborn as sns

import statsmodels.api as sm

import markovclick
from markovclick.models import MarkovClickstream
from markovclick import dummy
import graphviz

#ignore all warnings (remove in production)
import warnings
warnings.filterwarnings("ignore")

#print settings
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', -1)
%matplotlib inline



#generate markov sequences to model 
def Build_Markov_Seqs(DF=None,Seq_col=None,id_col = None):
    #model preprocessing
    #convert categoric into labels
    import sklearn
    le = sklearn.preprocessing.LabelEncoder()
    le.fit(DF['event_name']);#cats = le.inverse_transform(DF['event_name'])
    Seq2CatMap = list(set([(le.inverse_transform(val),val,'P'+str(int(val)+1//1)) for val in le.transform(DF[Seq_col]) ]))
    Seq2CatDic= {k:{'lemap':lemap,'seqval':seqval} for k,lemap,seqval in Seq2CatMap}
    
    #add columns to dataframe
    DF['event_sequence'] = DF[Seq_col].apply(lambda x: Seq2CatDic[x]['seqval'])
    DF['event_label'] = DF[Seq_col].apply(lambda x: Seq2CatDic[x]['lemap'])
    
    #plotting view of steps across numeric index 
    DF.groupby(id_col).event_label.hist(alpha=.4)

    #sequences to model 
    LongDF = DF.pivot(index = id_col,columns = 'event_seqid',values = 'event_sequence').T
    seq_list = [list(LongDF[x].T) for x in LongDF.columns]
    Seq2Mod = [[var for var in Seq if str(var)!='nan'] for Seq in  seq_list]
    return Seq2Mod,Seq2CatDic


#Only set to true if it is the iniital run where we extract all files fromt the tar.gz object
extract_targ = False         

#DFS to compare change in marketing on markov transition state probabilities
DF_Orig = 'jds_tt_eventdetail_sample'
DF_Compare = 'jds_tt_eventdetail_sample_alt1'

#extract all tar.gz files into current folder 
if extract_targ == True:
    [extract_targz(file) for file in targz_filenames ]

#convert all csv's extract from tar.gz to dataframes 
DFS = CSVs2DictOfDFs(directory,extension)
[print('{} -> {}'.format(df,DFS[df].shape)) for df in DFS.keys()]

################################################
#########drop NAN and constant columns##########
################################################
for key in DFS.keys():
    #drop constant columns 
    DFS[key] = drop_constant_column(DFS[key])
    #drop NAN columns 
    DFS[key].dropna(how='all',axis=1,inplace=True)
    print(key,DFS[key].shape)
    
################################################
#####SPECIFY INDIVIDUAL DF TO ANALYIZE###########
################################################
#evaluating nominal associations 
DF = DFS[DF_Orig].copy()
DF2 = DFS[DF_Compare].copy()

Orig_Seq2Mod,Orig_Seq2CatDic = Build_Markov_Seqs(DF=DF,Seq_col='event_name',id_col='visitor_key')
New_Seq2Mod,New_Seq2CatDic = Build_Markov_Seqs(DF=DF2,Seq_col='event_name',id_col='visitor_key')

######################
#build markov modekl##
######################      
#clickstream = dummy.gen_random_clickstream(n_of_streams=100,n_of_pages= 10)
m_orig = MarkovClickstream(Orig_Seq2Mod)
m_new =  MarkovClickstream(New_Seq2Mod)


P_change =pd.DataFrame(( m_new.prob_matrix- m_orig.prob_matrix )/ m_orig.prob_matrix,
                       columns = [find_key(Seq2CatDic,val)[0] for val in  m_orig.pages],
                       index = [find_key(Seq2CatDic,val)[0] for val in  m_orig.pages]
                       )
P_change.replace(0,np.nan,inplace=True)
P_change.replace(np.inf,1,inplace=True)


transP_new = pd.DataFrame(m_new.prob_matrix,
                          columns = [find_key(New_Seq2CatDic,val)[0] for val in  m_new.pages],
                          index = [find_key(New_Seq2CatDic,val)[0] for val in  m_new.pages]
                          )
transP_new.reset_index(inplace=True)
transP_newM = transP_new.melt(id_vars='index')
transP_newM.shape


transP_orig = pd.DataFrame(m_orig.prob_matrix,
                          columns = [find_key(Orig_Seq2CatDic,val)[0] for val in  m_orig.pages],
                          index = [find_key(Orig_Seq2CatDic,val)[0] for val in  m_orig.pages]
                          )
transP_orig .reset_index(inplace=True)
transP_origM  = transP_orig.melt(id_vars='index')
transP_origM.shape

#changes in tranistion state matrix 
transP_All = transP_origM.merge(transP_newM, on =['index','variable'],how='left')
transP_All['PoP_Change'] = transP_All['value_y']-transP_All['value_x']
transp_changes = transP_All[transP_All['PoP_Change']!=0]



plot_transition_matrix(m_orig.prob_matrix,Orig_Seq2CatDic,annot=False,title='Baseline Transition Probability matrix')
plot_transition_matrix(m_new.prob_matrix,New_Seq2CatDic,annot = False, title = 'Post implementatino Transition Probability Matrix')
plot_transition_matrix(P_change,New_Seq2CatDic,annot=True, title = 'Change in transition state probailities from P1 to P2')

def plot_transition_matrix(markov_prob_matrix,Seq2CatDic,annot=False,title = None):
    #TRANSITION STATE PROBABILITY 
    fig, ax = plt.subplots(figsize=(15,10))   
    sns.heatmap(markov_prob_matrix, xticklabels=[find_key(Seq2CatDic,val)[0] for val in  m.pages],
                                            yticklabels=[find_key(Seq2CatDic,val)[0] for val in  m.pages],
                                            annot=annot,
                                            linewidths=.5,
                                            ax = ax
                                            ).set_title(title)


#Visualize markov chains to n'th depth 
graph = visualise_markov_chain(m,Seq2CatDic=Seq2CatDic,DicParser = find_key,depth=5) 
graph.render('C:\\Users\\caridza\\Downloads\\test_markovImageFULL2.pdf')
























#funcs
def extract_targz(filepath):
    tf = tarfile.open(filepath)
    tf.extractall()

def CSVs2DictOfDFs(directory,extension):
    df_dict = {}
    for root,dirs,files in os.walk(directory):
        for f in files:
            if f.endswith(extension):
                key = f.replace(extension,'')
                value = os.path.join(root,f)
                df_dict[key]= pd.read_csv(value)
    return df_dict

def drop_constant_column(dataframe):
    """
    Drops constant value columns of pandas dataframe.
    """
    return dataframe.loc[:, (dataframe != dataframe.iloc[0]).any()]

#check if string can convert to int
def String2Int_Check(col,unique_thresh =4):
    try:
        if (isinstance(int(col[0]),int)) and (len(col.unique())>unique_thresh):
            return True
        else:
            return False
    except: 
        return False
    
#find parent key in nested dictonary
def find_key(d, value):
    for k,v in d.items():
        if isinstance(v, dict):
            p = find_key(v, value)
            if p:
                return [k] + p
        elif v == value:
            return [k]


def visualise_markov_chain(markov_chain: MarkovClickstream,Seq2CatDic=None,DicParser = find_key,depth=2) -> Digraph:
    """
    Visualises Markov chain for clickstream as a graph, with individual pages
    as nodes, and edges between the first and second most likely nodes (pages).
    Probabilities for these transitions are annotated on the edges (arrows).

    Args:
        markov_chain (MarkovClickstream): Initialised MarkovClickstream object
            with probabilities computed.

    Returns:
        Digraph: Graphviz Digraph object, which can be rendered as an image or
            PDF, or displayed inside a Jupyter notebook.
    """
    if not isinstance(markov_chain, MarkovClickstream):
        raise TypeError(
            f'Argument `markov_chain` must be of type '
            f'MarkovClickstream. {type(markov_chain)} object provided '
            f'instead.'
        )
    graph = Digraph()
    prob = markov_chain.prob_matrix
    prob_matrix_sorted = np.argsort(markov_chain.prob_matrix, axis=1)
    
    #ZJC 
    if Seq2CatDic == None:
        nodes = markov_chain.pages
    else: 
        nodes =[DicParser(Seq2CatDic,val)[0] for val in markov_chain.pages]
    
    
    for i, node in enumerate(nodes):
        if node in ['journey.entry','journey.exit']:
            graph.node(
            node, node, style='filled', fillcolor='#00FF2060',
            fontname='Helvetica', penwidth='0', fontcolor='#1a237e'
            )
        else:
            graph.node(
            node, node, style='filled', fillcolor='#DFBF20',
            fontname='Helvetica', penwidth='0', fontcolor='#1a237e'
            )

        trans = []
        for j in range(1,depth):
            first_trans = nodes[prob_matrix_sorted[i, -j]]
            trans.append(first_trans)
            most_prob = prob[i, prob_matrix_sorted[i, -j]]
            
            print(most_prob)
            
            if most_prob >.5:
                color = "#76ff03"
            else:
                color = "#90caf9"
            
            if most_prob>0:
                graph.edge(
                    node, first_trans,
                    label=f'{most_prob:.2f}',
                    fontname='Helvetica', penwidth='1.5',
                    color=color, arrowsize='0.75'
                )
    
            
        if node  not in trans and prob[i, i]>0:
            print('first and second transition not equal',node)
            graph.edge(
                node, node,
                label=f'   {prob[i, i]:.2f}',
                fontname='Helvetica', penwidth='1.8',
                fontsize='10', color='#FF2020', arrowsize='0.5'
            )
    return graph



#visualize initital distributions of each series
def plot_summary(DF):      
    #numeric plots
    cols = [col for col in DF if DF[col].dtypes.name !='object']
    if len(cols)>0:
        numcols = DF[cols].describe().T.index
        numcols = numcols
        print(DF[numcols].isnull().sum()/len(DF)*100)   
        DF[numcols].hist(figsize=(20,20))
        
    #categorical plots 
    cols = [col for col in DF if DF[col].dtypes.name =='object']   
    for col in cols:
        if len(list(DF[col].unique()))<1000:          
            if len(list(DF[col].unique()))>19:
                figure(figsize=(15,5))
                suptitle('DATFRAME: {}'.format(col))
                sns.countplot(data=DF,x=col)  
                xticks(rotation=90)
                show()
            else:
                figure(figsize=(15,5))
                sns.countplot(data=DF,x=col)    
                show()
                


