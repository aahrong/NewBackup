# -*- coding: utf-8 -*-
"""
Created on Mon Nov 12 11:53:30 2018

@author: caridza
"""
#VirtualEnv: docclassify
#VirtualEnv Location: C:\Users\caridza\Downloads\WPy32-3662\ZacksScripts\docclassify

#######################
#######IMPORTS#########
#######################
#install tensorflow: pip3 install --upgrade https://storage.googleapis.com/tensorflow/mac/cpu/tensorflow-1.12.0-py3-none-any.whl
#base modules 
import sys
from itertools import islice #iterating over vectorized objects (countvectorizer, tfidfvectorizer,etc..)
import numpy as np
import pandas as pd

#third party modules
#import required modules for data preprocessing , feature engineering and model training
from sklearn import model_selection, preprocessing, linear_model, naive_bayes, metrics, svm
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn import decomposition, ensemble
import pandas, xgboost, numpy, textblob, string
from keras.preprocessing import text, sequence
from keras import layers, models, optimizers

#custom modules 
#sys.path.insert(0,"C:/Users/caridza/Desktop/pythonScripts/")
sys.path.insert(0,"C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/")
from DocClassFuncs.ClassificationFuncs  import read_corp ,topn_tfidf_freq, create_model_architecture ,create_cnn,create_rnn_lstm, create_rnn_gru,create_bidirectional_rnn

#####################
#Dataset Preperation#
##################### 
# load the dataset
datapath="C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/corpus"
data =read_corp(datapath)

#define 2 lists: labels=target_series, texts=text to train target with
labels, texts = [], []

#file delimited with new line character
#target is alwasy the first word in each new string
for i, line in enumerate(data.split("\n")):
    #split each entry into a list delimited by a space (Word tokenized)
    content = line.split()
    #target value is the first element in each string (delimited by space)
    labels.append(content[0])
    #text is contained in all remaining elments of the list after the label
    texts.append(content[1:])

#create a dataframe using texts and lables
trainDF = pandas.DataFrame()
trainDF['text'] = [" ".join(x) for x in texts] #each row is a string  #trainDF['text'] = texts # each row is a list of word tokenized sentences 
trainDF['label'] = labels

#describe / view dataframe 
trainDF.info()
trainDF.describe()
trainDF.head()
trainDF.groupby('label').describe()
plotdf = trainDF.copy()
plotdf['txt_len'] = plotdf['text'].apply(len)

import matplotlib.pyplot as plt
import matplotlib
import seaborn as sns
%matplotlib inline
plotdf['txt_len'].plot(bins=50,kind = 'hist')
plotdf.hist(column='txt_len',by='label',bins=50, figsize=(10,4))
######################
##Data partioning#####
##& Target Encoding###
######################
# split the dataset into training and validation datasets 
#random_state=10 used to proivde constant seed to splitting algo to ensure reproducability 
#help(model_selection.train_test_split)
train_x, valid_x, train_y, valid_y = model_selection.train_test_split(trainDF['text'], trainDF['label'],shuffle=False, stratify=None,test_size=.25, random_state=10)

#label and encode target variable so it can be used in ML models 
#encoder takes the target pandas sereies of labels and converts them to numeric indecies for modeling 
encoder = preprocessing.LabelEncoder()
train_y  = encoder.fit_transform(train_y)
valid_y = encoder.fit_transform(valid_y)

#######################
##Feature Engineering##
#######################
#here raw text data will be transformed into feature vectors and new features will be created using the existing dataset
#features will be derived from: count vectors, tf-idf vectors(word level, n-gram levle, character level), word embeddings, text/nlp features , topic models 

#
#1.COUNT VECTORS AS FEATURES
#
#Count Vector is a matrix notation of the dataset in which every row represents a document from the corpus
#every column represents a term from the corpus, and every cell represents the frequency count of a particular term in a particular document.

#create count vectorizer object: Converts a collection of text documents to a matrix of token counts
#Note: Must convert list of toeknized words back to strings to enable word tokenization 
#count_vect.fit_transform(trainDF['text'].apply(lambda x: " ".join(x) ))
count_vect = CountVectorizer(analyzer='word', token_pattern=r'\w{1,}',encoding='utf-8',strip_accents=None,decode_error='strict',preprocessor=None,stop_words=None, lowercase=True,max_df=.5, min_df=.01,max_features=10000 , binary=False)
count_vect.fit_transform(trainDF['text'])
count_vect._validate_vocabulary()
print('feature names','/n',count_vect.get_feature_names())

# transform the training and validation data using count vectorizer object
#Note: Must convert list of toeknized words back to strings to enable word tokenization 
xtrain_count =  count_vect.transform(train_x.apply(lambda x: " ".join(x) ))
xvalid_count =  count_vect.transform(valid_x.apply(lambda x: " ".join(x) ))


#
#2.TF-idf Vectors as features 
#
#TF-IDF score represents the relative importance of a term in the document and the entire corpus. 
##  TF(t) = (Number of times term t appears in a document) / (Total number of terms in the document)
##  IDF(t) = log_e(Total number of documents / Number of documents with term t in it)
#TF-IDF Vectors can be generated at different levels of input tokens (words, characters, n-grams)
##  a. Word Level TF-IDF : Matrix representing tf-idf scores of every term in different documents
##  b. N-gram Level TF-IDF : N-grams are the combination of N terms together. This Matrix representing tf-idf scores of N-grams
##  c. Character Level TF-IDF : Matrix representing tf-idf scores of character level n-grams in the corpus

#building tfidf with pipelines: https://buhrmann.github.io/sklearn-pipelines.html
#evaluating tfidf: https://buhrmann.github.io/tfidf-analysis.html

# word level tf-idf
tfidf_vect = TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000,smooth_idf=True, sublinear_tf=False)
tfidf_vect.fit(trainDF['text'])
xtrain_tfidf =  tfidf_vect.transform(train_x)
xvalid_tfidf =  tfidf_vect.transform(valid_x)
print('TFIDF Descriptive Information')
print('Top 20 items in vocab {}'.format(list(islice(tfidf_vect.vocabulary_.items(), 20)))) #extract elements from sequence using isslice
print('Total unique tokens in vocab: {}'.format(len(tfidf_vect.vocabulary_)))
print('sparse matrix shape:', xtrain_tfidf.shape)
print('nonzero count:', xtrain_tfidf.nnz)
print('sparsity: %.2f%%' % (100.0 * xtrain_tfidf.nnz / (xtrain_tfidf.shape[0] * xtrain_tfidf.shape[1])))
print('top n terms from tfidf','\n',topn_tfidf_freq(tfidf_vect, xtrain_tfidf)[0])
print('top n weights from top n terms from tfidf','\n',topn_tfidf_freq(tfidf_vect, xtrain_tfidf)[1])

# ngram level tf-idf 
tfidf_vect_ngram = TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', ngram_range=(2,3), max_features=5000)
tfidf_vect_ngram.fit(trainDF['text'])
xtrain_tfidf_ngram =  tfidf_vect_ngram.transform(train_x)
xvalid_tfidf_ngram =  tfidf_vect_ngram.transform(valid_x)

# characters level tf-idf
tfidf_vect_ngram_chars = TfidfVectorizer(analyzer='char', token_pattern=r'\w{1,}', ngram_range=(2,3), max_features=5000)
tfidf_vect_ngram_chars.fit(trainDF['text'])
xtrain_tfidf_ngram_chars =  tfidf_vect_ngram_chars.transform(train_x) 
xvalid_tfidf_ngram_chars =  tfidf_vect_ngram_chars.transform(valid_x) 


#
#3.Word Embeddings as Features 
#
#A word embedding is a form of representing words and documents using a dense vector representation. 
#The position of a word within the vector space is learned from text and is based on the words that surround the word when it is used. 

#four steps for using pretrained embeddings in a model 
##  1.Load pretrained embeddings
##  2.create a tokenizer object 
##  3.Transform text docs to seq of tokens and pad 
##  4.createmapping of token and their respective embedding


# load the pre-trained word-embedding vectors 
embedding_path ='C:/Users/caridza/Desktop/pythonScripts/NLP/Embeddings/wiki-news-300d-1M.vec'
embeddings_index = {}
for i, line in enumerate(open(embedding_path,encoding='utf-8')):
    values = line.split()
    embeddings_index[values[0]] = numpy.asarray(values[1:], dtype='float32')

# create a tokenizer 
token = text.Tokenizer()
token.fit_on_texts(trainDF['text'])
word_index = token.word_index

# convert text to sequence of tokens and pad them to ensure equal length vectors 
train_seq_x = sequence.pad_sequences(token.texts_to_sequences(train_x), maxlen=70)
valid_seq_x = sequence.pad_sequences(token.texts_to_sequences(valid_x), maxlen=70)

# create token-embedding mapping
embedding_matrix = numpy.zeros((len(word_index) + 1, 300)) #empty matrix to hold embedding vectos
for word, i in word_index.items():
    embedding_vector = embeddings_index.get(word) #get embedding associated with each word , if it is none , then default to te blank of 0's associated with that position in the 
    if embedding_vector is not None:
        embedding_matrix[i] = embedding_vector

#
#4.Text / NLP based features 
#
#A number of extra text based features can also be created which sometimes are helpful for improving text classification models. 
#below are a few features that can be generated , but are experimental and should change in application to reflect buisness problem 
#Word Count of the documents – total number of words in the documents
#Character Count of the documents – total number of characters in the documents
#Average Word Density of the documents – average length of the words used in the documents
#Puncutation Count in the Complete Essay – total number of punctuation marks in the documents
#Upper Case Count in the Complete Essay – total number of upper count words in the documents
#Title Word Count in the Complete Essay – total number of proper case (title) words in the documents
#Frequency distribution of Part of Speech Tags: 
#Noun Count, Verb Count,Adjective Count,Adverb Count,Pronoun Count
trainDF['char_count'] = trainDF['text'].apply(len)
trainDF['word_count'] = trainDF['text'].apply(lambda x: len(x.split()))
trainDF['word_density'] = trainDF['char_count'] / (trainDF['word_count']+1)
trainDF['punctuation_count'] = trainDF['text'].apply(lambda x: len("".join(_ for _ in x if _ in string.punctuation))) 
trainDF['title_word_count'] = trainDF['text'].apply(lambda x: len([wrd for wrd in x.split() if wrd.istitle()])) #Bolean: checks weather all case based characters in string follow non-casebased letters are upercase and all other case-based characters are lowercase
trainDF['upper_case_word_count'] = trainDF['text'].apply(lambda x: len([wrd for wrd in x.split() if wrd.isupper()]))

#
#5.Topic Models as Features 
#
# Topic Modelling is a technique to identify the groups of words (called a topic) from a collection of documents that contains best information in the collection.
# LDA is an iterative model which starts from a fixed number of topics. Each topic is represented as a distribution over words, and each document is then represented as a distribution over topics. Although the tokens themselves are meaningless
# the probability distributions over words provided by the topics provide a sense of the different ideas contained in the documents

# train a LDA Model
help(decomposition.LatentDirichletAllocation)
lda_model = decomposition.LatentDirichletAllocation(n_components=20
                                                    , learning_method='online' #online variational Bayes method. in each EMupdate, use mini-batch of training data to update the ''components_'' variable incrementally. learning rate is controlled by learning_decay and the learning_offset parameters
                                                    , learning_decay = .7 #kappa: controls learning rate in the ONLINE learning method. range(.5,1) ensures asymptotic convergence
                                                    , batch_size = 128 #number of documents to use in each EM iteration 
                                                    , evaluate_every = 0 #how often to evaluate perplexity. Only used in fit method. can be used to help check convergence when set to value > 0 
                                                    , perp_tol = .01 # perplexity tolerance in batch learning. only used when evaluate_every > 0 
                                                    , mean_change_tol = .001 #stopping toleance for updating doctument distribution in E-step
                                                    , max_iter=20 # tau_0: postive parameter that downweights early iterations in online learning. should be greater than 1 
                                                    , doc_topic_prior = None #alpha: defaults to 1/n_components if value = None
                                                    , topic_word_prior = None #beta: defauls to 1/n_components if value = None
                                                    #, n_jobs = None #number of jobs to use in the E-step , None means 1 , -1 means use all processors
                                                    , random_state = None #if int random_state is the seed used by the random number generator for replication 
                                                    )
X_topics = lda_model.fit_transform(xtrain_count)
topic_word = lda_model.components_ 
vocab = count_vect.get_feature_names()

# view the topic models
n_top_words = 10
topic_summaries = []
for i, topic_dist in enumerate(topic_word):
    topic_words = numpy.array(vocab)[numpy.argsort(topic_dist)][:-(n_top_words+1):-1]
    topic_summaries.append(' '.join(topic_words))

#lda output overview 
#soure: https://www.machinelearningplus.com/nlp/topic-modeling-python-sklearn-examples/
print(lda_model.get_params())


#######################
#####MODEL BUILDING####
#######################
#We will implement following different classifiers for this purpose:
#Naive Bayes Classifier
#Linear Classifier
#Support Vector Machine
#Bagging Models
#Boosting Models
#Shallow Neural Networks
#Deep Neural Networks 
#Convolutional Neural Network (CNN)
#Long Short Term Modelr (LSTM)
#Gated Recurrent Unit (GRU)
#Bidirectional RNN
#Recurrent Convolutional Neural Network (RCNN)
#Other Variants of Deep Neural Networks


#
#1.Naives base model 
#
#Naive Bayes is a classification technique based on Bayes’ Theorem with an assumption of independence among predictors.
# A Naive Bayes classifier assumes that the presence of a particular feature in a class is unrelated to the presence of any other feature 
# Naive Bayes on Count Vectors
accuracy = train_model(naive_bayes.MultinomialNB(), xtrain_count, train_y, xvalid_count)
print("NB, Count Vectors: ", accuracy)

# Naive Bayes on Word Level TF IDF Vectors
accuracy = train_model(naive_bayes.MultinomialNB(), xtrain_tfidf, train_y, xvalid_tfidf)
print("NB, WordLevel TF-IDF: ", accuracy)

# Naive Bayes on Ngram Level TF IDF Vectors
accuracy = train_model(naive_bayes.MultinomialNB(), xtrain_tfidf_ngram, train_y, xvalid_tfidf_ngram)
print("NB, N-Gram Vectors: ", accuracy)

# Naive Bayes on Character Level TF IDF Vectors
accuracy = train_model(naive_bayes.MultinomialNB(), xtrain_tfidf_ngram_chars, train_y, xvalid_tfidf_ngram_chars)
print("NB, CharLevel Vectors: ", accuracy)


#
#2.Linear Classifier
#
#Logistic regression measures the relationship between the categorical dependent variable 
#and one or more independent variables by estimating probabilities using a logistic/sigmoid function
# Linear Classifier on Count Vectors
accuracy = train_model(linear_model.LogisticRegression(), xtrain_count, train_y, xvalid_count)
print("LR, Count Vectors: ", accuracy)

# Linear Classifier on Word Level TF IDF Vectors
accuracy = train_model(linear_model.LogisticRegression(), xtrain_tfidf, train_y, xvalid_tfidf)
print("LR, WordLevel TF-IDF: ", accuracy)

# Linear Classifier on Ngram Level TF IDF Vectors
accuracy = train_model(linear_model.LogisticRegression(), xtrain_tfidf_ngram, train_y, xvalid_tfidf_ngram)
print("LR, N-Gram Vectors: ", accuracy)

# Linear Classifier on Character Level TF IDF Vectors
accuracy = train_model(linear_model.LogisticRegression(), xtrain_tfidf_ngram_chars, train_y, xvalid_tfidf_ngram_chars)
print("LR, CharLevel Vectors: ", accuracy)

#
#3.SVM
#
#Support Vector Machine (SVM) is a supervised machine learning algorithm which can be used for both classification or regression challenges. 
#The model extracts a best possible hyper-plane / line that segregates the two classes.
# SVM on Ngram Level TF IDF Vectors
accuracy = train_model(svm.SVC(), xtrain_tfidf_ngram, train_y, xvalid_tfidf_ngram)
print("SVM, N-Gram Vectors: ", accuracy)

#
#4.Random Forest(Bagging)
#
# RF on Word Level TF IDF Vectors
accuracy = train_model(ensemble.RandomForestClassifier(), xtrain_tfidf, train_y, xvalid_tfidf)
print("RF, WordLevel TF-IDF: ", accuracy)


#
#5.Boosting Model
#
#Boosting models are another type of ensemble models part of tree based models. 
#Boosting is a machine learning ensemble meta-algorithm for primarily reducing bias, and also variance in supervised learning, 
#and a family of machine learning algorithms that convert weak learners to strong ones. 
#A weak learner is defined to be a classifier that is only slightly correlated with the true classification (it can label examples better than random guessing). 
# Extereme Gradient Boosting on Count Vectors
accuracy = train_model(xgboost.XGBClassifier(), xtrain_count.tocsc(), train_y, xvalid_count.tocsc())
print("Xgb, Count Vectors: ", accuracy)

# Extereme Gradient Boosting on Word Level TF IDF Vectors
accuracy = train_model(xgboost.XGBClassifier(), xtrain_tfidf.tocsc(), train_y, xvalid_tfidf.tocsc())
print("Xgb, WordLevel TF-IDF: ", accuracy)

# Extereme Gradient Boosting on Character Level TF IDF Vectors
accuracy = train_model(xgboost.XGBClassifier(), xtrain_tfidf_ngram_chars.tocsc(), train_y, xvalid_tfidf_ngram_chars.tocsc())
print("Xgb, CharLevel Vectors: ", accuracy)

#
#6.Shallow Nueral Network 
#
#These models are used to recognize complex patterns and relationships that exists within a labelled data.
# A shallow neural network contains mainly three types of layers – input layer, hidden layer, and output layer
#note: create_model_architecture() from rolling_list_of_funcitons.py used 
classifier = create_model_architecture(xtrain_tfidf_ngram.shape[1])
accuracy = train_model(classifier, xtrain_tfidf_ngram, train_y, xvalid_tfidf_ngram, is_neural_net=True)
print("NN, Ngram Level TF IDF Vectors",  accuracy)

#
#7.Deep Nueral Network - Convolutional NN
#
#Deep Neural Networks are more complex neural networks in which the hidden layers performs much more complex 
#operations than simple sigmoid or relu activations. Different types of deep learning models can be applied in text classification problems.
#In Convolutional neural networks, convolutions over the input layer are used to compute the output. 
#This results in local connections, where each region of the input is connected to a neuron in the output. 
#Each layer applies different filters and combines their results.


#
#8.Deep Nueral Network - Convolutional NN
#
classifier = create_cnn()
accuracy = train_model(classifier, train_seq_x, train_y, valid_seq_x, is_neural_net=True)
print("CNN, Word Embeddings",  accuracy)    

#
#9.Deep Nueral Network - Recurrent Neural Networks
#
#unlike Feed-forward neural networks in which activation outputs are propagated only in one direction, the activation outputs from neurons propagate in 
#both directions (from inputs to outputs and from outputs to inputs) in Recurrent Neural Networks. 
#RNN's remind me of time series modeling with neural networks
#Issue with basic RNN: Vanishing Gradient is associated with them. In this problem, while learning with a large number of layers
#, it becomes really hard for the network to learn and tune the parameters of the earlier layers.
#Solution: LSTMS
classifier = create_rnn_lstm()
accuracy = train_model(classifier, train_seq_x, train_y, valid_seq_x, is_neural_net=True)
print("RNN-LSTM, Word Embeddings",  accuracy)    

#
#9.Deep Nueral Network - Recurrent Neural Networks - Gated Recurrent Units (GRU)
#
classifier = create_rnn_gru()
accuracy = train_model(classifier, train_seq_x, train_y, valid_seq_x, is_neural_net=True)
print("RNN-GRU, Word Embeddings",  accuracy)

#
#10.Deep Nueral Network - Bidirectional RNN + GRUs
#
classifier = create_bidirectional_rnn()
accuracy = train_model(classifier, train_seq_x, train_y, valid_seq_x, is_neural_net=True)
print("RNN-Bidirectional, Word Embeddings",  accuracy)













#import inspect 
#print(inspect.getargspec(model_selection.train_test_split))
#print(inspect.getfullargspec(model_selection.train_test_split))