# -*- coding: utf-8 -*-
"""
Created on Wed Feb 13 16:28:31 2019

@author: caridza
"""

#DEFINING CUSTOM METRICS TO USE WITH KERAS 
import keras 
import numpy as np
from keras.callbacks import Callback
from sklearn.metrics import confusion_matrix, f1_score, precision_score, recall_score
import keras.backend as K 



class Metrics(keras.callbacks.Callback):
    
    def mpce(self,y_true, y_pred):
        y_pred_pos = K.round(K.clip(y_pred, 0, 1))
        y_pred_neg = 1 - y_pred_pos
        y_pos = K.round(K.clip(y_true, 0, 1))
        y_neg = 1 - y_pos
        tp = K.sum(y_pos * y_pred_pos) / K.sum(y_pos)
        tn = K.sum(y_neg * y_pred_neg) / K.sum(y_neg)
        
        #class_0_err = 1-(tn / (tn+max(y_pred_neg-y_neg,0)))
        #class_1_err = 1-(tp / (tp+max(y_pred_pos-y_pos,0)))
        #mpce = (class_0_err + class_1_err)/ 2
        #return mpce
        return tp+tn
        

    def precision(self, y_true, y_pred):
        # Calculates the precision
        true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
        predicted_positives = K.sum(K.round(K.clip(y_pred, 0, 1)))
        precision = true_positives / (predicted_positives + K.epsilon())
        return precision


    def recall(self,y_true, y_pred):
        # Calculates the recall
        true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
        possible_positives = K.sum(K.round(K.clip(y_true, 0, 1)))
        recall = true_positives / (possible_positives + K.epsilon())
        return recall

    def fbeta_score(self,y_true, y_pred, beta=1):
        # Calculates the F score, the weighted harmonic mean of precision and recall.

        if beta < 0:
            raise ValueError('The lowest choosable beta is zero (only precision).')

        # If there are no true positives, fix the F score at 0 like sklearn.
        if K.sum(K.round(K.clip(y_true, 0, 1))) == 0:
            return 0

        p = self.precision(y_true, y_pred)
        r = self.recall(y_true, y_pred)
        bb = beta ** 2
        fbeta_score = (1 + bb) * (p * r) / (bb * p + r + K.epsilon())
        return fbeta_score

    def fmeasure(self,y_true, y_pred):
        # Calculates the f-measure, the harmonic mean of precision and recall.
        return self.fbeta_score(y_true, y_pred, beta=1)

   
    
    def on_train_begin(self, logs={}):
        self.confusion = []
        self.precision = []
        self.recall = []
        self.f1s = []

    def on_epoch_end(self, epoch, logs={}):
        score = np.asarray(self.model.predict(self.validation_data[0]))
        predict = np.round(np.asarray(self.model.predict(self.validation_data[0])))
        targ = self.validation_data[1]

        self.f1s.append(sklearn.metrics.f1_score(targ, predict,average='micro'))
        self.confusion.append(sklearn.metrics.confusion_matrix(targ.argmax(axis=1),predict.argmax(axis=1)))

        return
