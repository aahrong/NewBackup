# -*- coding: utf-8 -*-
"""
Created on Mon Jan 21 15:56:59 2019

@author: caridza
"""
# -*- coding: utf-8 -*-
#VirtualEnv: docclassify
#VirtualEnv Location: C:\Users\caridza\Downloads\WPy32-3662\ZacksScripts\docclassify
#######################
#######IMPORTS#########
#######################
#install tensorflow: pip3 install --upgrade https://storage.googleapis.com/tensorflow/mac/cpu/tensorflow-1.12.0-py3-none-any.whl
#base modules 
import pandas as pd
import string, pickle, sys
from itertools import islice #iterating over vectorized objects (countvectorizer, tfidfvectorizer,etc..)
#required modules for data preprocessing and modeling
import sklearn
from sklearn import decomposition, ensemble,model_selection, preprocessing, metrics
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer,TfidfTransformer
from sklearn.pipeline import Pipeline,make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split,GridSearchCV
from sklearn.pipeline import FeatureUnion 
from sklearn.neural_network import MLPClassifier
#text parsing
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
from nltk import word_tokenize
#plotting
import numpy as np
import joblib
import re
#pipeliness
from imblearn.over_sampling import SMOTE  # or: import RandomOverSampler
from imblearn.pipeline import Pipeline as imbPipeline
#custom modules 
from negative_news2.consumer.utils.nn_modelutils  import TextSelector,replace_words, NumberSelector,orig_text_clean,load_and_score,remove_punctuation,remove_stop,stem_words,remove_nonchars,pipelinize,sk_model_stats, encode_categoric

#punctuation to remove, stopwords to remove, stemming and lemmatizing objects for preprocessing
stemmer = SnowballStemmer('english')
wordnet_lemmatizer = WordNetLemmatizer()
exclude = set(string.punctuation)
stopwords = stopwords.words('english')
newStopWords = ['.','?','%']
stopwords.extend(newStopWords)
stopwords=set(stopwords)
NonStopWords2Remove = ['Google','Wells Fargo','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December']

#####################
#Dataset Preperation#
##################### 
#https://www.kaggle.com/baghern/a-deep-dive-into-sklearn-pipelines
#https://scikit-learn.org/stable/auto_examples/model_selection/grid_search_text_feature_extraction.html
#https://scikit-learn.org/stable/auto_examples/text/plot_document_classification_20newsgroups.html#sphx-glr-auto-examples-text-plot-document-classification-20newsgroups-py
#http://zacstewart.com/2014/08/05/pipelines-of-featureunions-of-pipelines.html
#https://zablo.net/blog/post/pandas-dataframe-in-scikit-learn-feature-union
datapath = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/SentDF.pickle"
target = 'Disqualification'
inputtxt = 'Sentence'

# load the dataset
data = pd.read_pickle(datapath)
data.drop(columns=['date'])
data.info()

#being data processing for modeling 
#1.remove Proper Nouns and uninteresting non stop words from sentences 
#2.remove stopwords, stem, and clean sentences 
data[inputtxt] = data[inputtxt].apply(lambda x: replace_words(x,NonStopWords2Remove))
trainDF = orig_text_clean(data,target=target , txtfeild='Sentence' , maplabelvars=['source'],stopwords=stopwords,stemmer=stemmer)
list(trainDF);trainDF.info();trainDF.describe()

#categorical and numerical columns in dataframe 
vars2rmv = ['ChangeManagment','TradeSuspension','StatutoryDisqual','entity','date','source','title','url',target,'label','label_id','text']
catvars  = list(trainDF.filter(like='_id').columns.values);catvars.append(inputtxt)
numvars = list(trainDF.filter(like='txt_').columns.values)
features= [c for c in catvars if c  not in vars2rmv]
numeric_features= [c for c in numvars if c not in vars2rmv]
features.extend(numeric_features)

#####SKLEARN PIPELINE DEVELOPMENT
#define text transformations to generate
text_feats = {'tfidf_pipe':{'analyzer':'word','ngram_range':(1,1)}}

#apply text_feats transformations iterativly into tfidf tranformation pipeline
catfeat_pipe_dic = {key : Pipeline([('selector', TextSelector(key=inputtxt)),
                            ('tfidf',  TfidfVectorizer(analyzer=val['analyzer'], ngram_range=val['ngram_range'], 
                                             max_features=50000,min_df=2 ,stop_words='english', max_df=.4
                                             , smooth_idf=True, norm='l2',sublinear_tf=True,lowercase=True,))
                            ]) for key,val in text_feats.items()
                    }   

#create pipe for each numerical features generated by orig_text_clean 
#numfeat_pipe_dic= {val: Pipeline([('selector', NumberSelector(key=val)),('standard', StandardScaler(with_std=True,with_mean=True))]) for val in numeric_features}

#create final list of pipelines, starting with text preprocessing, and finishing with the numeric column normalizations(items listed in order of exectuion so we build initial list with text processing and append all numeric processing tasks after)
final_pipeline = [(k,v) for k, v in catfeat_pipe_dic.items()]
#final_pipeline.extend([(k,v) for k, v in numfeat_pipe_dic.items()])

#make a pipeline from all of our pipelines, we dao the same thing, but now we use a FeatureUnion to join the feature processing pipelines.
feats = FeatureUnion(final_pipeline)
#feats_fit = feats.fit_transform(trainDF)

#class weights 
#from secrets import randbelow
#class_weights = [{0: round(NegCounts,0), 1: PosCounts*(int(round(int(randbelow(9))+int(w),0))) } for w in [.8]]
NegCounts = pd.value_counts(trainDF['label_id'].values, sort=False)[0]
PosCounts = pd.value_counts(trainDF['label_id'].values, sort=False)[1]
NegProp = NegCounts / (NegCounts + PosCounts)
PosProp = PosCounts/ (NegCounts + PosCounts)
ClassWeight = round(NegCounts / PosCounts,0)
ClassWeights = [{0:PosProp,1:NegProp},{0:PosProp*1.1,1:(1-PosProp*1.1)},{0:PosProp*1.5, 1:(1-PosProp*1.5)},{0:PosProp*2,1:(1-PosProp*2)},{0:PosProp*5,1:(1-PosProp*5)}]
                

#construct final model pipeline 
#mlp:MLPClassifier trains iteratively since at each time step the partial derivatives of the loss function with respect to the model parameters are computed to update the parameters.
#It can also have a regularization term added to the loss function that shrinks model parameters to prevent overfitting.
#NOTE IF YOU DONT USE SMOTE U MUST SPECIFY class_weight = {classlabel:ratio of total,classlabel:ratio of total} in the model.fit() statement 
pipe_mlp = imbPipeline([('features',feats),
                        ('oversample',SMOTE(random_state=444,n_jobs=1)),
                        ('clf', MLPClassifier(solver='adam',tol=.0001,max_iter=50,activation='relu',learning_rate='adaptive',shuffle=True,verbose=2,n_iter_no_change=10))])


#save and print coefficents that can be used in grid search for each model 
pipes = [pipe_mlp]
for pipe in pipes:print(vars(pipe.named_steps['clf']))

#Example
grid_params_mlp= [{
                   #'clf__alpha': [.1,.01,.001,.0001,.00000001],
                   #'clf__beta_1':[.1,.02,.01,.001,.0001,.0000001],#[.999,.99,.9,.8,.5,.1],
                   #'clf__beta_2':[.999,.99],    
                   #'class_weight': [{0: NegCounts*w,1:1} for w in [.01,.1,.2,.5,.8,1,1.2,1.5,2]]
                   'oversample__sampling_strategy':[.1,.2,.3,.4,.5,.8,.9,1]#class_weights#
                   }]

#define scoring metrics to use in gridsearch model selection 
scoring = {'Accuracy':'accuracy' ,
           'Recall':'recall' ,
           #'BalancedAccuracy':metrics.make_scorer(metrics.balanced_accuracy_score),
           #'TP':metrics.make_scorer(tp) ,
           'f1':metrics.make_scorer(sklearn.metrics.f1_score),
           #'FBeta':metrics.make_scorer(metrics.fbeta_score,beta=.5) ,
           #'Avg_Prec':metrics.make_scorer(metrics.average_precision_score),
           #'MedianAbsoluteError':metrics.make_scorer(metrics.median_absolute_error),
           }

#execute grid search using wrappers
jobs=-1
gs_mlp = GridSearchCV(estimator=pipe_mlp,
			param_grid=grid_params_mlp,
			scoring=scoring,
			cv=2,
            verbose=3 ,
			n_jobs=jobs, 
            refit = 'f1')

# Dictionary of pipelines and classifier types for ease of reference
grid_dict = {0: 'Multi-Layer-Perceptrion'}

#create dictonary of models and gs objects to loop through 
gridmod_dict = {'MLP':gs_mlp}

#define train vs test 
train_x,valid_x,train_y,valid_y= model_selection.train_test_split(trainDF[features],trainDF['label_id'],shuffle=True, stratify=trainDF['label_id'],test_size=.02, random_state=10)

#fit grid for each model 
mod_obs ={}
for key,value in gridmod_dict.items():
    mod_obs.update({key:value.fit(train_x,train_y)})   

#store results in object 
res_obs ={}
for key,value in gridmod_dict.items():
   res_obs.update({key:value.cv_results_})   

#extract model stats 
train=sk_model_stats(gridmod_dict,train_x,train_y*1,data_type='train')
valid=sk_model_stats(gridmod_dict,valid_x,valid_y*1,data_type='valid')
stats = train.append(valid).T;stats.columns = [x+"_"+y for x,y in zip(stats.iloc[[0],:].values[0],stats.iloc[[1],:].values[0])]
results = gs_mlp.cv_results_
list(results)


# Plot the weights vs f1 score
mets = ['std_test_Accuracy','mean_test_Recall','mean_test_f1']
for met in mets:
    dataz = pd.DataFrame({ 'score': gs_mlp.cv_results_[met],
                       'weight': gs_mlp.cv_results_['param_oversample__sampling_strategy'] })
    dataz.plot(x='weight')

#plot scorers by hyperparameter being tuned 
plot_scorers(results,"param_clf__beta_2")


#final best model 
#view parameters that resulted in best model 
optimized_parms = gs_mlp.best_params_
optimized_clf= gs_mlp.best_estimator_

############################################
###BUILD FINAL MODEL BASED ON ABOVE RESULTS#
############################################
#view parameters that resulted in best model 
    #model Parameters
final_mlp = imbPipeline([('features',feats),
                        ('oversample',SMOTE(random_state=444, sampling_strategy=.4)),
                        ('clf', MLPClassifier(solver='adam'
                                              ,tol=.0001
                                              ,max_iter=150
                                              ,learning_rate='adaptive'
                                              ,shuffle=True
                                              ,verbose=2
                                              , activation ='relu'
                                              #, alpha = .99999
                                              #, beta_1 = .9999999
                                              #, beta_2 = .999999999
                                              #, hidden_layer_sizes = (100,50)
                                              , epsilon = 1e-8
                                              , n_iter_no_change=20
                                              , early_stopping=True
                                              , validation_fraction=.2
                                              ))])
    
#refitting on entire training data using best settings
#view predictions and probabilities of each class 
resultdic = {}
for weights in ClassWeights:
    resultdic[weights]=final_mlp.fit(train_x,train_y,class_weight = weights)

X = valid_x
Y = valid_y
preds = final_mlp.predict(X)
probs = final_mlp.predict_proba(X)
print('mean accuracy:{}'.format(np.mean(preds == Y)))
cf = metrics.confusion_matrix(Y,preds)


#save model to file 
#import joblib
filename = 'C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/FinalModel/NN_MLP_{}.sav'.format(target)

#joblib.dump(pipe_mlp, filename)


















#######SAVING MODEL AND LOADING MODEL FOR LATER USE#######
#NOTE: Generate requirements.txt when exporting model so you can replicate the requirments needed to run the saved model 
#save best model to pickle for use on future data 
filename = 'nn_finalmodel.sav'
pickle.dump(pip_log, open(filename,'wb'))

#load pickled model for evaluation on unseen data 
loaded_model = pickle.load(open(filename,'rb'))
OOS_predictions = loaded_model.score(valid_x,valid_y)
print(OOS_predictions)

#option 2:save model using joblib(useful when algo requires a lot of parameters or store the entire dataset)
#save model 
joblib.dump(pip_log, filename)
#load model 
loaded_model = joblib.load(filename)
OOS_predictions = loaded_model.score(valid_x,valid_y)
print(OOS_predictions)




#confusion matrix breakouts     
def tn(y_true, y_pred): return sklearn.metrics.confusion_matrix(y_true, y_pred)[0, 0]
def fp(y_true, y_pred): return sklearn.metrics.confusion_matrix(y_true, y_pred)[0, 1]
def fn(y_true, y_pred): return sklearn.metrics.confusion_matrix(y_true, y_pred)[1, 0]
def tp(y_true, y_pred): return sklearn.metrics.confusion_matrix(y_true, y_pred)[1, 1]
