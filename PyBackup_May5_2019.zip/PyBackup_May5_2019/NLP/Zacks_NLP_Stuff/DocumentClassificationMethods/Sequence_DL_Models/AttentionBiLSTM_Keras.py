import os 
import sys
import pandas as pd 
import pymagnitude
import re
import string 

from sklearn import preprocessing , model_selection

import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk import regexp_tokenize
from nltk.tokenize import word_tokenize , sent_tokenize

import gensim
from tensorflow.python.keras.preprocessing.text import Tokenizer 
from tensorflow.python.keras.preprocessing.sequence import pad_sequences 
from tensorflow.python.keras.callbacks import ModelCheckpoint, EarlyStopping

from imblearn.over_sampling import SMOTE  # or: import RandomOverSampler
from imblearn.pipeline import Pipeline as imbPipeline

stemmer = SnowballStemmer('english')
exclude = set(string.punctuation)
stopwords = stopwords.words('english')
newStopWords = ['.','?','%','Google','Wells Fargo','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December']
stopwords.extend(newStopWords)
stopwords=set(stopwords)

#### Configuratble Inputs Data 
datapath = "//home//nlpsomnath//NegNews/zackc//Misc Notebooks//Python Misc//Data//SentDF.pickle"
max_features = 100000 #maximum number of words to consider in analysis 
EMBEDDING_DIM = 300 #NOTE: becuase we use pymag this must be set to 300 
stop_list = stop_list
stemmer = stemmer
target = 'RegulatoryRefrence'

#### Clean Data, Sequence Tokenize, and Split data into train and test
xtr,ytr,xte,yte,word_index, maxlen = make_df(datapath,      #path to sentence level data 
                                             max_features,  #maximum number of words to consider in model 
                                             EMBEDDING_DIM, #number of dims form embedding vector to use(if pymag used this must be 300)
                                             stop_list,
                                             stemmer,
                                             target)

#### Generate Embedding Vectors for each word index in Vocabulary 
#cat =wv.query('car')
nb_words = min(max_features, len(word_index)+1) #total features to consider, min of the max feats vs total feats 
embedding_vector =  make_embeddings_pymag(wv, max_features,words, word_index, EMBEDDING_DIM, nb_words)

#compile model 
model = BidLstm(maxlen, nb_words, EMBEDDING_DIM, embedding_vector)
model.compile(loss='binary_crossentropy', optimizer='adam',metrics=['accuracy'])

#define checkpoints 
file_path = ".model.hdf5"
ckpt = ModelCheckpoint(file_path, monitor='val_loss', verbose=1,save_best_only=True, mode='min')
early = EarlyStopping(monitor="val_loss", mode="min", patience=1)

#build model 
model_out = model.fit(xtr, ytr, batch_size=256, epochs=15, validation_split=0.2)

#score on new data 
#model.load_weights(file_path)
y_test = model.predict(xte)




###################################################
###################################################
####################FUNCTIONS######################
###################################################
###################################################

#TEXT CLEANING 
def orig_text_clean(data,target='LegalAction',txtfeild='origtext',maplabelvars=['source']
                    ,stopwords=['the','is','a','i','are','it'],stemmer=None,score_new=False):
    trainDF = pd.DataFrame()
    trainDF['text'] = data[txtfeild].apply(lambda x: remove_punctuation(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_nonchars(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_stop(x,stopwords=stopwords))
    trainDF[txtfeild] = trainDF['text'].apply(lambda x: stem_words(x,stemmer=stemmer))
    
    if score_new==False:
        trainDF['label'] = data[target]
        le = preprocessing.LabelEncoder() 
        le.fit(trainDF['label'])
        trainDF['label_id'] =le.transform(trainDF['label'])
            
    trainDF=trainDF.reset_index(drop=True)
    return trainDF 

#preprocess data 
#func to remove punc from string and return string
def remove_punctuation(text,excluded_punct={'+', ':', '[', '^', '"', '|', '{', '@', '=', ')', '%', '#', '`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}):
    return ' '.join([word for word in nltk.word_tokenize(text) if word not in excluded_punct])

#func to remove stop words 
def remove_stop(text,stopwords=['the','is','a','i','are','it']):
    return ' '.join([word for word in text.split(' ') if word.lower() not in stopwords])

#func to stem words 
def stem_words(text,stemmer=None):
    return ' '.join([stemmer.stem(word) for word in text.split(' ')])

#remove non alpha characters from text 
def remove_nonchars(text):
    return ' '.join([re.sub('[^A-Za-z|^\$|^\.]+', ' ', word) for word in text.split(' ') if (word.isalnum() and len(word)>2)])




#PLOTTING FUNCTIONS 
    #plot model training history 
import matplotlib.pyplot as plt
plt.style.use('ggplot')
def plot_history(history,metric='acc'):
    #https://www.kaggle.com/danbrice/keras-plot-history-full-report-and-grid-search
    acc = history.history[metric]
    val_acc = history.history['val_'+metric]
    loss = history.history['loss']
    val_loss = history.history['val_'+metric]
    x = range(1, len(acc) + 1)

    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1)
    plt.plot(x, acc, 'b', label='Training acc')
    plt.plot(x, val_acc, 'r', label='Validation acc')
    plt.title('Training and validation accuracy')
    plt.legend()
    plt.subplot(1, 2, 2)
    plt.plot(x, loss, 'b', label='Training loss')
    plt.plot(x, val_loss, 'r', label='Validation loss')
    plt.title('Training and validation loss')
    plt.legend()
    
def plot_confusion_matrix(cm, classes,
                          normalize=False,
                          cmap=plt.cm.Blues):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        title='Normalized confusion matrix'
    else:
        title='Confusion matrix'

    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.show()



######################################
#ATTENTION CLASS REQUIRED FOR BI-LSTM#
##CAN BE USED IN KERAS MODEL DIRECTLY#
######################################
    from keras import backend as K
from keras.engine.topology import Layer
from keras import initializers, regularizers, constraints


class Attention(Layer):
    def __init__(self, step_dim,
                 W_regularizer=None, b_regularizer=None,
                 W_constraint=None, b_constraint=None,
                 bias=True, **kwargs):
        """
        Keras Layer that implements an Attention mechanism for temporal data.
        Supports Masking.
        Follows the work of Raffel et al. [https://arxiv.org/abs/1512.08756]
        # Input shape
            3D tensor with shape: `(samples, steps, features)`.
        # Output shape
            2D tensor with shape: `(samples, features)`.
        :param kwargs:
        Just put it on top of an RNN Layer (GRU/LSTM/SimpleRNN) with return_sequences=True.
        The dimensions are inferred based on the output shape of the RNN.
        Example:
            model.add(LSTM(64, return_sequences=True))
            model.add(Attention())
        """
        self.supports_masking = True
        self.init = initializers.get('glorot_uniform')

        self.W_regularizer = regularizers.get(W_regularizer)
        self.b_regularizer = regularizers.get(b_regularizer)

        self.W_constraint = constraints.get(W_constraint)
        self.b_constraint = constraints.get(b_constraint)

        self.bias = bias
        self.step_dim = step_dim
        self.features_dim = 0
        super(Attention, self).__init__(**kwargs)

    def build(self, input_shape):
        assert len(input_shape) == 3

        self.W = self.add_weight((input_shape[-1],),
                                 initializer=self.init,
                                 name='{}_W'.format(self.name),
                                 regularizer=self.W_regularizer,
                                 constraint=self.W_constraint)
        self.features_dim = input_shape[-1]

        if self.bias:
            self.b = self.add_weight((input_shape[1],),
                                     initializer='zero',
                                     name='{}_b'.format(self.name),
                                     regularizer=self.b_regularizer,
                                     constraint=self.b_constraint)
        else:
            self.b = None

        self.built = True

    def compute_mask(self, input, input_mask=None):
        return None

    def call(self, x, mask=None):
        features_dim = self.features_dim
        step_dim = self.step_dim

        eij = K.reshape(K.dot(K.reshape(x, (-1, features_dim)),
                        K.reshape(self.W, (features_dim, 1))), (-1, step_dim))

        if self.bias:
            eij += self.b

        eij = K.tanh(eij)

        a = K.exp(eij)

        if mask is not None:
            a *= K.cast(mask, K.floatx())

        a /= K.cast(K.sum(a, axis=1, keepdims=True) + K.epsilon(), K.floatx())

        a = K.expand_dims(a)
        weighted_input = x * a
        return K.sum(weighted_input, axis=1)

    def compute_output_shape(self, input_shape):
        return input_shape[0],  self.features_dim


#KERAS BI-DIRECTIONAL LSTM 
from keras.models import Model
from keras.layers import Dense, Embedding, Input
from keras.layers import LSTM, Bidirectional, Dropout


def BidLstm(maxlen, max_features, embed_size, embedding_matrix):
    inp = Input(shape=(maxlen, ))
    x = Embedding(max_features, embed_size, weights=[embedding_matrix],
                  trainable=False)(inp)
    x = Bidirectional(LSTM(300, return_sequences=True, dropout=0.25,
                           recurrent_dropout=0.25))(x)
    x = Attention(maxlen)(x)
    x = Dense(256, activation="relu")(x)
    x = Dropout(0.25)(x)
    x = Dense(1, activation="sigmoid")(x)
    model = Model(inputs=inp, outputs=x)

    return model



#MAKE DATAFRAME 
def make_df(datapath , max_features,EMBEDDING_DIM,stop_list,stemmer,target):
    data = pd.read_pickle(datapath)
    trainDF = orig_text_clean(data,target=target , txtfeild='Sentence',stopwords=stop_list,stemmer=stemmer) 
    X = trainDF['Sentence']
    Y = trainDF['label_id']
    

    sentences = []
    lines = X.values.tolist()
    lines = [word_tokenize(sent) for sent in lines]
    model=gensim.models.Word2Vec(sentences=lines, size=EMBEDDING_DIM,window=5,workers=4,min_count=1)
    words = list(model.wv.vocab)
    
    #model process 

    # #fit tokenizer to words and turn to sequences 
    tokenizer_obj = Tokenizer()
    tokenizer_obj.fit_on_texts(X)
    sequences = tokenizer_obj.texts_to_sequences(X)
    
    #define max length for padding and total vocab size
    max_length = max([len(s.split()) for s in X]) 
    vocab_size = len(tokenizer_obj.word_index)+1
    
    #pad sequences 
    word_index = tokenizer_obj.word_index
    review_pad = pad_sequences(sequences,maxlen=max_length)
    label = Y.values
    
    #split data 
    x_train,x_test,y_train,y_test = model_selection.train_test_split(review_pad, label,shuffle=True, stratify=Y,test_size=.3, random_state=10)
    sm = SMOTE(random_state=2)
    x_train, y_train = sm.fit_sample(x_train, y_train)
    
    return x_train, y_train, x_test, y_test, word_index, max_length


#BUILDING EMBEDDINGS 
def make_embeddings_pymag(wv, max_features,words, word_index, embed_size, nb_words):
    #embeddings using pymagnitude 
    embeddings_index = {}
    for w in words:
        word =w
        coefs = wv.query(word) #np.asarray(values[1:])
        embeddings_index[word]=coefs

    embedding_matrix = np.zeros((nb_words, embed_size))
    for word, i in word_index.items():
        if i >= max_features:
            continue
        embedding_vector = embeddings_index.get(word)
        if embedding_vector is not None:
            embedding_matrix[i] = embedding_vector
    return embedding_matrix



