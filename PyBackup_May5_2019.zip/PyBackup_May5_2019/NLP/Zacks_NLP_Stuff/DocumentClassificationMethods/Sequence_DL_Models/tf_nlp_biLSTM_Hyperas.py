from comet_ml import Experiment, Optimizer

from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from sklearn.preprocessing import MultiLabelBinarizer
from keras.layers import Dense, Activation, Embedding, Flatten, GlobalMaxPool1D, Dropout, Conv1D, InputLayer, LSTM, Bidirectional, BatchNormalization
from sklearn.model_selection import train_test_split
from keras.callbacks import ReduceLROnPlateau, EarlyStopping, ModelCheckpoint, TensorBoard
from keras.models import load_model
from keras.models import Sequential
from keras.optimizers import Adam
from keras import regularizers
from keras_self_attention import SeqSelfAttention 

from hyperopt import Trials, STATUS_OK, tpe, rand
from hyperas import optim
from hyperas.distributions import choice, uniform

import numpy as np
import pandas as pd
from collections import Counter

import gensim
from pymagnitude import *

from imblearn.over_sampling import SMOTE

# utilities file
from DLmodelUtilities import getLayerOutput, getLabelPredsDF, custom_categorical_accuracy

def data():
    # global variables
    max_features = 100000
    # magFile = "wiki-news-300d-1M-subword.magnitude"
    magFile = "glove.6B.50d.magnitude"
    wv_pymag = Magnitude("./"+magFile)
    EMBEDDING_DIM = 50 # change according to the pymag dimension

    def getPyMagVectorEmbeddings(wv_pymag, words, word_index, nb_words):
        print("PyMag Vector....")
        embedding_idx = {}
        for w in words:
            vect = wv_pymag.query(w)
            embedding_idx[w] = vect
        
        embedding_matrix = np.zeros((nb_words, EMBEDDING_DIM))
        
        for word, i in word_index.items():
            if i >= max_features:
                continue
            embedding_vect = embedding_idx.get(word)
            if embedding_vect is not None:
                embedding_matrix[i] = embedding_vect
        
        return embedding_matrix

    def getFeaturesfromDF(df):
        X = df["text"]
        text_tokens_ls = X.tolist()
        text_tokens_ls = [thisL.split(" ") for thisL in text_tokens_ls]
        model = gensim.models.Word2Vec(sentences=text_tokens_ls, size=EMBEDDING_DIM, workers=4, min_count=1)
        # get list of unique words
        words = list(model.wv.vocab)

        # convert from words to sequences
        tokenizer = Tokenizer()
        tokenizer.fit_on_texts(X)
        sequences = tokenizer.texts_to_sequences(X)

        # define max length for padding
        max_length = max([len(thisL) for thisL in text_tokens_ls])
        word_index = tokenizer.word_index
        # vocab_size = len(word_index) + 1

        # pad sequences
        pads = pad_sequences(sequences, maxlen=max_length)
        print("-"*80+" Pads shape", pads.shape)
        
        # multilabel binarizer
        labels = df["label"].values
        mlb = MultiLabelBinarizer()
        mlb.fit(labels)
        num_classes = len(mlb.classes_)
        labels = mlb.transform(labels)
        print("-"*80+" labels shape", labels.shape)

        return pads, labels, words, word_index, max_length, num_classes, mlb


    train = pd.read_csv("./new_train_data_5_class.csv", names=['text', 'label'], dtype={'text': str}).dropna()
    train['label'] = train['label'].apply(lambda x: x.split("_and_"))
    
    # get fratures from train dataset
    x,y,words,word_index,max_length,num_classes, mlb = getFeaturesfromDF(train)
    print("Max # tokens in docs --------- ",max_length)
    print("# Classes in docs --------- ",num_classes)

    # get pymag embedding vectors as features
    nb_words = min(max_features, len(word_index)+1)
    print("Total number of unique words --------- ",nb_words)
    
    embedding_filename = "embedding_vectors_glove50d" # change according to which pre-saved embedding you would want to use
    # embedding_filename = "embedding_vectors_fasttext300d"
    embedding_vector = getPyMagVectorEmbeddings(wv_pymag, words, word_index, nb_words)
    np.save(embedding_filename, embedding_vector)
    # embedding_vector = np.load(embedding_filename+".npy")
    print(embedding_vector.shape)
    
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=9000)
    x_train, x_val, y_train, y_val = train_test_split(x_train, y_train, test_size=0.1, random_state=9000)

    return x_train, x_val, x_test, y_train, y_val, y_test


def createModel(x_train, y_train, x_val, y_val):
    # global variables
    EMBEDDING_DIM = 50 # change according to the pymag dimension
    
    model = Sequential()
   
    model.add(Embedding(input_dim = nb_words, 
                        output_dim = EMBEDDING_DIM, 
                        weights=[embedding_vector],
                        input_length = max_length, 
                        name = "PymagEmbedding", 
                        embeddings_regularizer = regularizers.l2({{choice([0, 0.001,0.0001])}})))
    model.add(Bidirectional(LSTM(units = {{choice([3,5,10,20,30])}}, 
                                return_sequences=True,
                                dropout={{uniform(0.1,0.5)}},
                                recurrent_dropout={{uniform(0.1,0.5)}},
                                recurrent_regularizer=regularizers.L1L2(l1={{choice([0.0,0.001])}}, l2={{choice([0.001,0.0001])}}),
                                kernel_regularizer = regularizers.L1L2(l1={{choice([0.0,0.001])}}, l2={{choice([0.001,0.0001])}}),
                                )))
    model.add(SeqSelfAttention(attention_width={{choice([5,7,10])}},
                        attention_type=SeqSelfAttention.ATTENTION_TYPE_MUL,
                        attention_activation=None,
                        kernel_regularizer=regularizers.L1L2(l1={{choice([0.0,0.001])}}, l2={{choice([0, 0.001,0.0001])}}),
                        bias_regularizer=regularizers.L1L2(l1={{choice([0.0,0.001])}}, l2={{choice([0, 0.001,0.0001])}}),
                        use_attention_bias=False,    
                        attention_regularizer_weight={{choice([0.0, 0.01, 0.001])}},
                        name='Attention',))
    model.add(GlobalMaxPool1D())
    model.add(Dense(num_classes, activation="sigmoid"))
    
    model.compile(optimizer=Adam({{choice([1, 0.1, 0.01,0.001, 0.0001])}}), loss='binary_crossentropy', metrics=['categorical_accuracy', 'accuracy'])

    # print(model.summary())
    # print([w.shape for w in model.get_weights()])
    # return 
tensor_board = TensorBoard(log_dir='./tb', histogram_freq=0, write_graph=True, write_images=True)
checkpoint = ModelCheckpoint(filepath='mymodel.h5',
                             monitor='val_acc',
                             verbose=1,
                             save_best_only=True)

lr_reduce = ReduceLROnPlateau(monitor='val_loss', factor=0.1, patience=10, verbose=1, mode='auto', min_delta=0.0001, cooldown=0, min_lr=0),

callbacks = [tensor_board, checkpoint, lr_reduce]
                
        #EarlyStopping(patience=5),
        # ModelCheckpoint(filepath='nlp_doc_cls_model_pymag.h5', save_best_only=True)

  
    model.fit(x_train, y_train,
                epochs=5,
                batch_size={{choice([4, 8, 16, 32,64,128, 256])}},
                # validation_split=0.1,
                validation_data = (x_val, y_val),
                callbacks=callbacks)
    predict = model.predict(x_val)
    label_preds, acc = custom_categorical_accuracy(predict, y_val)
    # print("Val Acc.", acc)
    return {'loss': -acc, 'status': STATUS_OK, 'model': model}


if __name__ == "__main__":
    best_run, best_model, space = optim.minimize(model = createModel,
                                            data=data,
                                            algo=tpe.suggest,
                                            max_evals=250,
                                            eval_space=True,
                                            return_space=True,
                                            trials=Trials())
    
    print("Best Parameters:")
    print(best_run)
    
    x_train, x_val, x_test, y_train, y_val, y_test = data()
    
    print("Best performing model:")
    predict = best_model.predict(x_test)
    label_preds, acc = custom_categorical_accuracy(predict, y_test)
    # save model
    best_model.save("best_pymag_model.h5")
