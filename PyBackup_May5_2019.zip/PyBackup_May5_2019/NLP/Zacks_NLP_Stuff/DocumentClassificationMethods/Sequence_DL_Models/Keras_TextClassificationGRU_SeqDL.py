# -*- coding: utf-8 -*-
"""
Created on Thu Jan 17 17:43:37 2019
https://towardsdatascience.com/machine-learning-word-embedding-sentiment-classification-using-keras-b83c28087456
https://realpython.com/python-keras-text-classification/
https://towardsdatascience.com/nlp-sequence-to-sequence-networks-part-2-seq2seq-model-encoderdecoder-model-6c22e29fd7e1
@author: caridza
"""
import pandas as pd
import string 
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from sklearn import preprocessing

from negative_news2.consumer.utils  import TextSelector, NumberSelector,orig_text_clean,load_and_score,remove_punctuation,remove_stop,stem_words,remove_nonchars
exclude = set(string.punctuation)
stemmer = SnowballStemmer('english')
stopwords = stopwords.words("english")

#data
data = pd.read_pickle("C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/NN_ClassificationModelData2.pickle")#raw source data, must apply orig_text_clean()
data = pd.read_pickle("C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/SentDF.pickle") #sentences have already gone through preprocessing

#create a dataframe using texts and lables and conduct preprocessing
#trainDF = orig_text_clean(data,target='LegalAction',maplabelvars=['source'],stopwords=stopwords,stemmer=stemmer)
#X = trainDF['cleantxt']
#Y = trainDF['label_id']
X = data['Sentence']
Y = data['RegulatoryRefrence']

from sklearn import model_selection 
x_train,x_test,y_train,y_test = model_selection.train_test_split(X, Y,shuffle=True, stratify=Y,test_size=.2, random_state=10)

#model process begin
#
from tensorflow.python.keras.preprocessing.text import Tokenizer 
from tensorflow.python.keras.preprocessing.sequence import pad_sequences 
from keras.models import Sequential 
from keras.layers import Dense,Embedding,LSTM,GRU
from keras.layers.embeddings import Embedding

##1.Learn embeddings
#iniatilize sequence tokenizer
tokenizer_obj=Tokenizer()
#tokenize texts 
tokenizer_obj.fit_on_texts(X)
#tokenizer_obj.index_docs
#tokenizer_obj.index_word

#pad sequences 
max_length = max([len(s.split()) for s in X]) #define max length of string. this indicates the padding required to make each string equal length 
vocab_size = len(tokenizer_obj.word_index)+1#define vocabulary size 

#split tokens into test and train 
x_train_tokens = tokenizer_obj.texts_to_sequences(x_train)
x_test_tokens = tokenizer_obj.texts_to_sequences(x_test)
x_train_pad = pad_sequences(x_train_tokens,maxlen=max_length,padding='post')
x_test_pad = pad_sequences(x_test_tokens,maxlen=max_length,padding='post')

#2.build embedding model 
EMBEDDING_DIM = 100 
model = Sequential()
model.add(Embedding(vocab_size,EMBEDDING_DIM,input_length=max_length))
model.add(GRU(units=32,dropout=.2,recurrent_dropout=.2))
model.add(Dense(1,activation='sigmoid'))

#try using differnt optimizers and different optimizer configs
model.compile(loss='binary_crossentropy',optimizer='adam',metrics=['accuracy'])
print(model.summary()) #embedding_param_count = (vocab_size*EMBEDDING_DOM)
print('training model')
model.fit(x_train_pad,y_train,batch_size=128,epochs=25 , validation_data=(x_test_pad,y_test),verbose=2)

#2.use pretrained model 
import string 
from nltk.tokenize import word_tokenize 
from nltk.corpus import stopwords 
import gensim
import pymagnitude

#model inputs(list of sentences)
sentences = []
lines = X.values.tolist()
lines = [word_tokenize(sent) for sent in lines]
model=gensim.models.Word2Vec(sentences=lines, size=EMBEDDING_DIM,window=5,workers=4,min_count=1)
words = list(model.wv.vocab)

#save embedding to file 
filename = 'NegNews_embedding_w2v.txt'
model.wv.save_word2vec_format(filename,binary=False)

#USE PRETRAINED EMBEDDING 
embeddings_index = {}
f = open(os.path.join('',filename),encoding='utf-8')
for line in f :
    values = line.split()
    word = values[0]
    coefs = np.asarray(values[1:])
    embeddings_index[word]=coefs
f.close()


#convert word embedding into tokenized vector 
#Recall that the review documents are integer encoded prior to 
#passing them to the Embedding layer. The integer maps to the index of a 
#specific vector in the embedding layer. Therefore, it is important that we 
#lay the vectors out in the Embedding layer such that the encoded words map to the correct vector.
tokenizer_obj = Tokenizer()
tokenizer_obj.fit_on_texts(lines)
sequences = tokenizer_obj.texts_to_sequences(lines)

#pad sequences 
word_index = tokenizer_obj.word_index
print('found %s unique tokens. ' % len(word_index))

review_pad = pad_sequences(sequences,maxlen=max_length)
label = Y.values

print('shape of text tensor:',review_pad.shape)
print('shape of label tensor:',label.shape)

#map embeddings from loaded w2v model for each word to the tokenizer_obj.word_index vocabulary and create a matrix of word vectors 
num_words = len(word_index)+1
embedding_matrix = np.zeros((num_words,EMBEDDING_DIM))

for word, i in word_index.items():
    if i>num_words:
        continue
    embedding_vector = embeddings_index.get(word)
    if embedding_vector is not None:
        embedding_matrix[i]=embedding_vector 
print(num_words)


#use trained embedding vector directly in embedding layer 
#trainable = False:  embedding layers have already been trained for us 
from tensorflow.python.keras.preprocessing.text import Tokenizer 
from tensorflow.python.keras.preprocessing.sequence import pad_sequences 
from keras.models import Sequential 
from keras.layers import Dense,Embedding,LSTM,GRU
from keras.layers.embeddings import Embedding
from keras.initializers import Constant

#define model 
model = Sequential()
embedding_layer = Embedding(num_words, EMBEDDING_DIM,embeddings_initializer=Constant(embedding_matrix),input_length=max_length,trainable=False)
model.add(embedding_layer)
model.add(GRU(units=32,dropout=.2,recurrent_dropout=.2))
model.add(Dense(1,activation='sigmoid'))

#compile model with hpyerparameters 
model.compile(loss='binary_crossentropy',optimizer='adam',metrics=['accuracy'])

#set up training and validation data
VALIDATION_SPLIT = .2 
indices = np.arange(review_pad.shape[0])
np.random.shuffle(indices)
review_pad = review_pad[indices]
label = label[indices]
num_validation_samples = int(VALIDATION_SPLIT*review_pad.shape[0])

X_train_pad = review_pad[:-num_validation_samples]
Y_train= label[:-num_validation_samples]
X_test_pad = review_pad[-num_validation_samples:]
Y_test= label[-num_validation_samples:]

print('shape of x_pad tensor:',X_train_pad.shape)

#fit model 
model_out = model.fit(X_train_pad,Y_train,batch_size=128,epochs=25 , validation_data=(X_test_pad,Y_test),verbose=2)
model_out.summary()
y_preds = model.predict(x=X_test_pad)
matrix = metrics.confusion_matrix(y_test, y_preds)
scores = model.evaluate(X_test_pad, Y_test, verbose=0)









def orig_text_clean(data,target='LegalAction',maplabelvars=['source'],stopwords=['the','is','a','i','are','it'],stemmer=None,score_new=False):
    trainDF = pd.DataFrame()
    trainDF['text'] = data['origtext'].apply(lambda x: remove_punctuation(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_nonchars(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_stop(x,stopwords=stopwords))
    trainDF['cleantxt'] = trainDF['text']#.apply(lambda x: stem_words(x,stemmer=stemmer))
    
    #if score_new==False:
    trainDF['label'] = data[target]
    le = preprocessing.LabelEncoder() 
    le.fit(trainDF['label'])
    trainDF['label_id'] =le.transform(trainDF['label'])
    
    trainDF['source'] = data['source']
    trainDF['txt_lngth'] = trainDF['cleantxt'].apply(lambda x: len(x))
    trainDF['txt_words'] = trainDF['cleantxt'].apply(lambda x: len(x.split(' ')))
    trainDF['txt_nonstopwords'] = trainDF['cleantxt'].apply(lambda x: len([t for t in x.split(' ') if t not in stopwords]))
    trainDF['total_commas'] = data['origtext'].apply(lambda x: x.count(','))
    le.fit(trainDF['source'])
    trainDF['source_id'] =le.transform(trainDF['source'])
    
    for var in maplabelvars: 
        le.fit(trainDF[var])
        trainDF[var+'_id'] =le.transform(trainDF[var])
        
    trainDF=trainDF.reset_index(drop=True)
    return trainDF 