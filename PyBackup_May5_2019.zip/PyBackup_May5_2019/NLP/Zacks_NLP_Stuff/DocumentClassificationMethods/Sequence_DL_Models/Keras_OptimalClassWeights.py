# -*- coding: utf-8 -*-
"""
Created on Tue Feb 12 11:03:38 2019

@author: caridza
"""
#imports
import sys 
import nltk
import matplotlib
import pandas as pd 
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
from nltk import word_tokenize
import sklearn
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer,TfidfTransformer
import keras
import string
import numpy as np
from negative_news2.consumer.utils import replace_words,remove_punctuation,remove_stop,stem_words,remove_nonchars

#punctuation to remove, stopwords to remove, stemming and lemmatizing objects for preprocessing
stemmer = SnowballStemmer('english')
wordnet_lemmatizer = WordNetLemmatizer()
exclude = set(string.punctuation)
stopwords = stopwords.words('english')
newStopWords = ['.','?','%','Google','Wells Fargo','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December']
stopwords.extend(newStopWords)
stop_list=set(stopwords)

#data 
datapath = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/SentDF.pickle"
data = pd.read_pickle(datapath)
data.drop(columns=['date'])

#define target , clean text, and split data into test and train
target = "MandA"
Data = orig_text_clean(data,target=target , txtfeild='Sentence' , stopwords=stop_list,stemmer=stemmer)
train_x,valid_x,train_y,valid_y= sklearn.model_selection.train_test_split(Data['Sentence'],Data['label_id'],shuffle=True, stratify=Data['label_id'],test_size=.3, random_state=10)

#vectorized matrix of tfidf weights for input as independent variables 
#fit tfidf on trianing data and transform the tfidf on the test data 
vocab_size = 10000
vectorizer = TfidfVectorizer(analyzer='word', ngram_range=(1,1), max_features=vocab_size,min_df=2 ,stop_words='english', max_df=.1, smooth_idf=True, norm='l2',sublinear_tf=True,lowercase=True,)
x_train_vec = vectorizer.fit_transform(train_x).toarray()
x_test_vec = vectorizer.transform(valid_x).toarray()

#define basic model to use to identify optimal sample size 
num_labels=1
model = keras.models.Sequential() #0
model.add(keras.layers.Dense(50, input_shape=(vocab_size,),kernel_regularizer=keras.regularizers.l2(.0001),activity_regularizer=keras.regularizers.l2(.0001)))
model.add(keras.layers.Activation('relu')) #2
model.add(keras.layers.Dropout(0.7)) #3
model.add(keras.layers.Dense(num_labels)) #7
model.add(keras.layers.Activation('sigmoid')) #8
model.summary() #9

#determine starting point for class weights 
NegCounts = pd.value_counts(train_y, sort=False)[0]
PosCounts = pd.value_counts(train_y, sort=False)[1]
Ratio_Rare2Common = round(NegCounts/PosCounts,0)
print(Ratio_Rare2Common)

#generate list of class weights to try based on starting ratio 
ClassWeights = [{0:1,1:max(1,round(Ratio_Rare2Common*val,0))} for val in [2,3,.8,.6,.4,.2,.1,.01]]
ClassWeights.extend([{0:2,1:1}])

#add early stopping and model checkpoint
#filepath="C://Users//caridza//Desktop//pythonScripts//NLP//Zacks_NLP_Stuff//DocumentClassificationMethods//FinalModel//test_model_repo//Best_Model.sav"
early = keras.callbacks.EarlyStopping(monitor="val_binary_accuracy", mode="max", patience=2)
#ckpt = keras.callbacks.ModelCheckpoint(filepath, monitor='val_binary_accuracy', verbose=1, save_best_only=True, save_weights_only=False, mode='max')

#set loss function, gds ooptimizer, and metrics to track for callbacks and cross validation 
model.compile(loss='binary_crossentropy',optimizer='adam',metrics=['binary_accuracy'])
 
#fit models(1 for each class_weight specifified)
#class weights used to represent imbalanced data 
result_dic={}
batch_size = 200

#loop through each class_weight setting and execute model and store model results 
#create dataframe to hold metrics and populate for each set of weights 
perf_mets =  pd.DataFrame(columns=['TP','TN','FP','FN','bin_acc','val_loss','class_weight'],index=[str(weights[0])+'_'+str(weights[1]) for weights in ClassWeights])
for weights in ClassWeights:
    result_dic[str(weights[0])+'_'+str(weights[1])] = model.fit(x_train_vec,train_y,
                        batch_size=batch_size,epochs=3,verbose=1,validation_split=0.2,
                        callbacks = [early],
                        class_weight = weights,                       
                        )
    
    #generate preds to populate cm 
    y_preds = model.predict_classes(x_test_vec)
    cm = sklearn.metrics.confusion_matrix(valid_y,y_preds)
    tn = cm[0][0]
    fp = cm[0][1]
    fn = cm[1][0]
    tp = cm[1][1]

    #populate statistics on the model with each set of class_weights 
    perf_mets.loc[str(weights[0])+'_'+str(weights[1])] = pd.Series({'TP':tp, 'TN':tn, 'FP':fp, 'FN':fn
                  ,'bin_acc':np.mean(result_dic[str(weights[0])+'_'+str(weights[1])].history['val_binary_accuracy'])
                  ,'val_loss':np.mean(result_dic[str(weights[0])+'_'+str(weights[1])].history['val_loss'])
                  ,'class_weight':weights
                  })    
   
  
#get optimal class weights 
final_class_weights = perf_mets[perf_mets['val_loss']==min(perf_mets['val_loss'])]['class_weight']

#redefine model 
sys.path.insert(0,'C://Users//caridza//Desktop//pythonScripts//NLP//Zacks_NLP_Stuff//DocumentClassificationMethods//Sequence_DL_Models//')
from Custom_Metrics.metrics import Metrics

metrics = Metrics()

num_labels=1
model = keras.models.Sequential() #0
model.add(keras.layers.Dense(40, input_shape=(vocab_size,),kernel_regularizer=keras.regularizers.l2(.0001),activity_regularizer=keras.regularizers.l2(.0001)))
model.add(keras.layers.GaussianDropout(0.75))
model.add(keras.layers.Activation('selu'))
model.add(keras.layers.Dense(num_labels)) #7
model.add(keras.layers.Activation('sigmoid')) #8
model.compile(loss='binary_crossentropy',optimizer='adam',metrics=['accuracy','binary_accuracy',metrics.recall, metrics.precision, metrics.fmeasure])
model.summary() #9

#fit model 
model_path="C://Users//caridza//Desktop//pythonScripts//NLP//Zacks_NLP_Stuff//DocumentClassificationMethods//FinalModel//test_model_repo//Best_Model_V2.sav"
early = keras.callbacks.EarlyStopping(monitor="val_recall", mode="max", patience=10)
ckpt = keras.callbacks.ModelCheckpoint(model_path, monitor='val_recall', verbose=1, save_best_only=True, save_weights_only=False, mode='max')

final_out = model.fit(x_train_vec,train_y
          ,batch_size=batch_size,epochs=30,verbose=1,validation_split=0.2
          ,callbacks = [early,ckpt],
                    class_weight = final_class_weights,                       
                    )

#generate preds to populate cm 
y_preds = model.predict_classes(x_test_vec)
cm = sklearn.metrics.confusion_matrix(valid_y,y_preds)

#compare to the best saved model 

best_model = keras.models.load_model(model_path,custom_objects={'fmeasure':metrics.fmeasure,'precision':metrics.precision,'recall':metrics.recall})
y_preds = best_model .predict_classes(x_test_vec)
cm = sklearn.metrics.confusion_matrix(valid_y,y_preds)

#get accuracy of model 
_,train_acc = model.evaluate(x_train_vec,train_y,verbose=1)
_,test_acc = model.evaluate(x_test_vec,valid_y,verbose=1)

#create metrics by epoch to identify optimal epochs for final model training 
out_mets = pd.DataFrame.from_dict(final_out.history)
out_mets['loss_diff'] = out_mets['loss']-out_mets['val_loss']
out_mets['binary_acc_diff'] = out_mets['val_binary_accuracy']-out_mets['binary_accuracy']
out_mets['P_change_loss'] = out_mets['loss'].pct_change()
out_mets['P_change_val_loss'] = out_mets['val_loss'].pct_change()
out_mets['P_change_acc'] = out_mets['binary_accuracy'].pct_change()
out_mets['P_change_val_acc'] = out_mets['val_binary_accuracy'].pct_change()

# plot training history
matplotlib.pyplot.plot(final_out.history['loss'], label='train_loss')
matplotlib.pyplot.plot(final_out.history['val_loss'], label='test_loss')
matplotlib.pyplot.legend()
matplotlib.pyplot.show()
matplotlib.pyplot.plot(out_mets['loss_diff'], label='loss_diff')
matplotlib.pyplot.plot(out_mets['binary_acc_diff'], label='bi_acc_diff')
matplotlib.pyplot.legend()
matplotlib.pyplot.show()
matplotlib.pyplot.plot(final_out.history['binary_accuracy'], label='train_acc')
matplotlib.pyplot.plot(final_out.history['val_binary_accuracy'], label='test_acc')
matplotlib.pyplot.legend()
matplotlib.pyplot.show()
matplotlib.pyplot.plot(out_mets['P_change_acc'], label='p_chg_train_acc')
matplotlib.pyplot.plot(out_mets['P_change_val_acc'], label='p_chg_val_acc')
matplotlib.pyplot.legend()
matplotlib.pyplot.show()
matplotlib.pyplot.plot(out_mets['P_change_loss'], label='p_chg_loss')
matplotlib.pyplot.plot(out_mets['P_change_val_loss'], label='p_chg_val_loss')
matplotlib.pyplot.legend()
matplotlib.pyplot.show()

#define refined model with training up to 8 epochs based on the above charts (looking for area of overfit)
#redefine model 
num_labels=1
model = keras.models.Sequential() #0
model.add(keras.layers.Dense(50, input_shape=(vocab_size,),kernel_regularizer=keras.regularizers.l2(.0001),activity_regularizer=keras.regularizers.l2(.0001)))
model.add(keras.layers.GaussianDropout(0.9))
model.add(keras.layers.Activation('selu'))
model.add(keras.layers.Dense(num_labels)) #7
model.add(keras.layers.Activation('sigmoid')) #8
model.compile(loss='binary_crossentropy',optimizer='adam',metrics=['accuracy'])
model.summary() #9

#fit final model 
model_path="C://Users//caridza//Desktop//pythonScripts//NLP//Zacks_NLP_Stuff//DocumentClassificationMethods//FinalModel//test_model_repo//Best_Model_V3.sav"
early = keras.callbacks.EarlyStopping(monitor="val_loss", mode="min", patience=10)
ckpt = keras.callbacks.ModelCheckpoint(model_path, monitor='val_loss', verbose=1, save_best_only=True, save_weights_only=False, mode='min')

final_out = model.fit(x_train_vec,train_y
          ,batch_size=batch_size,epochs=10,verbose=1,validation_split=0.2
          ,callbacks = [early,ckpt],
                    class_weight = final_class_weights,                       
                    )

#generate preds to populate cm 
y_preds = model.predict_classes(x_test_vec)
cm = sklearn.metrics.confusion_matrix(valid_y,y_preds)

#compare to the best saved model 
best_model = keras.models.load_model(model_path)
y_preds = best_model .predict_classes(x_test_vec)
cm = sklearn.metrics.confusion_matrix(valid_y,y_preds)




#clean original text to be used in generation of tfidf and other text transformation objects
def orig_text_clean(data,target='',txtfeild='origtext',stopwords=['the','is','a','i','are','it'],stemmer=None):
    print(list(data))
    trainDF = pd.DataFrame()
    trainDF['text'] = data[txtfeild].apply(lambda x: remove_punctuation(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_nonchars(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_stop(x,stopwords=stopwords))
    
    if stemmer!=None:
        trainDF[txtfeild] = trainDF['text'].apply(lambda x: stem_words(x,stemmer=stemmer))
    else:
        trainDF[txtfeild] = trainDF['text']
        
    if target!='':
        trainDF['label'] = data[target]
        le = sklearn.preprocessing.LabelEncoder() 
        le.fit(trainDF['label'])
        trainDF['label_id'] =le.transform(trainDF['label'])
    else:
        trainDF['DocIndex']=data['DocIndex']
    
    trainDF.drop(['text'],axis=1,inplace=True)
    
    trainDF=trainDF.reset_index(drop=True)
    return trainDF 
