# -*- coding: utf-8 -*-
"""
Created on Mon Feb 11 07:20:22 2019

@author: caridza
"""
wv=pymagnitude.Magnitude('C://Users//caridza//Desktop//pythonScripts//NLP//Embeddings//GoogleNewsvectors_negative300.magnitude')
out_vec = wv.query(['cat','loves','food'])

#functions
#desm.score_all_documents : outputs tuple of lists (doc_index,desm_score)
#desm.desm_pandas_wrapper(wv,query_list,row,norm=False,avg_top_n=3,num_best_docs_to_yield=3,best_doc_char_threshold=50)
#desm.get_all_document_centroids: Returns dict -- a dictionary representing the input and output centroids of all documents of the form {doc_index : (input_centroid, output_centroid)}
                
#desm.desm_pandas_wrapper() inputs: 
    #wv: embeddings 
    #query_list = list of uncorrolated risk terms 
    #row : row function being evaluted on 
    #norm: normalize embedding output(T/F)

#desm.score_all_documents inputs: 
    #model: wv embeddings 
    #query: list of strings representing query with which to preduct desm score 
    #all_doc_tokens: list of lists of strings containing word tokenized documents (all words in document)


def get_all_embeddings(model, phrase_tokenized):
    """Returns list of Word2Vec (PyMagnitude) input embeddings for all words in a given phrase

    Arguments:
        model {pymagnitude} -- Word2Vec (PyMagnitude) object to query for word embeddings
        phrase {list} -- List of strings representing phrase

    Returns:
        list -- a list representing the Word2Vec (PyMagnitude) input embeddings for each token in phrase
    """
    return model.query(phrase_tokenized)




def score_all_documents(model, query, all_doc_tokens, sort=True):
    """Returns the DESM score for a set of documents given a query and a list of document tokens

    Arguments:
        model {pymagnitude} -- Word2Vec (PyMagnitude) object to query for word embeddings
        query {list} -- List of strings representing query with which to produce DESM score
        all_doc_tokens {list} -- List of lists of strings containing word tokenized documents

    Keyword Arguments:
        sort {bool} -- if true, sort the DESM scores in descending fashion (default: {True})

    Returns:
        tuple -- tuple of lists of the form (scores_in_in, scores_in_out); each of these tuple elements
        is a list of tuples of the form (doc_index, desm_score) sorted in a descending fashion
    """
    C_IN = 0  # flag for 'IN' word embeddings
    # C_OUT = 1  # flag for 'OUT' word embeddings

    if type(query) == str:
        query = [query]

    
    #get embeddings from wv model for each string int he list of strings in query
    query_embeddings = get_all_embeddings(model, query)
    
    #return the mean embedding of each sentence in eahc doc 
    centroid_dict = get_all_document_centroids(model, all_doc_tokens)

    scores_in_in = []
    # 'OUT' embeddings not available for pre-trained Google embeddings
    scores_in_out = []

    for doc_index, centroid_tuple in centroid_dict.items():
        in_score = score_document(query_embeddings, centroid_tuple[C_IN])
        # out_score = score_document(query_embeddings, centroid_tuple[C_OUT])

        if not math.isnan(in_score):
            # doc = ' '.join(all_doc_tokens[doc_index])
            scores_in_in.append((doc_index, in_score))

        # if not math.isnan(out_score):
        #     scores_in_out.append((doc_index, in_score))

    if sort:
        scores_in_in = sorted(scores_in_in, key=lambda x: x[1], reverse=True)
        # scores_in_out = sorted(scores_in_out, key = lambda x: x[1], reverse = True)

    return (scores_in_in, scores_in_out)


def desm_pandas_wrapper(
    wv,
    query_list,
    row,
    norm=False,
    avg_top_n=3,
    num_best_docs_to_yield=3,
    best_doc_char_threshold=50,
):
    """DESM score wrapper for pandas
        Flow:

        BEGIN LOOP
        0) For each query in the query list ..
        1) Calculate a DESM score for each sentence in the document based on the query
        2) Take the top {avg_top_n} scoring sentences and average their DESM scores
        END LOOP

        3) For the top scoring query; return the score, the top sentences, and the query

    Arguments:
        wv {pymagnitude} -- Word2Vec (PyMagnitude) object to query for word embeddings
        query_list {list} -- list of strings with which to produce DESM scores
        df {pandas.Series} -- Pandas dataframe row on which to perform DESM analysis

    Keyword Arguments:
        col_name_for_content {str} -- [description] (default: {'content'})
        word_tokenizer {callable} -- callable utilized to word tokenize sentences;
        must accept sentence as single parameter (default: {nltk.tokenize.word_tokenize})
        sent_tokenizer {callable} -- callable utilized to sentence tokenize documents;
        must accept document as single parameter (default: {nltk.tokenize.sent_tokenize})
        norm {bool} -- if true, normalize the DESM scores (default: {False})
        avg_top_n {int} -- max number of sentences with which to produce average DESM score for whole document
                           (default: {3})

    Raises:
        ValueError -- if the query list has a length of 0
        KeyError -- if 'col_name_for_content' does not exist as a column in 'df'

    Returns:
        tuple -- (best DESM score across all queries, corresponding top sentences, corresponding query)
    """
    best_score = 0
    best_term = ""
    best_docs = []
    best_doc_idx = []
    score_dict = {}

    #check if risk terms exist
    if len(query_list) == 0:
        raise ValueError("Query list must contain at least one search term .. ")

    #for each risk term , generate a list of tuples indicating the avg similarity of each sentence to risk term q. 
    #geneate dictonary mapping each risk term to its associated vectors of avg similarity for each sentence 
    for q in query_list:
        scores_in_in = list(
            score_all_documents(wv, q, row["sentence_tokenized_word_tokenized"], norm)[
                0
            ]
        )
        score_dict[q] = scores_in_in

        #unpack list of tuples into to distrinct list of values indicating the doc, and the scores for each sentence for the risk term being processed 
        #take the top 3 risk terms corrolated to the sentences scored 
        try:
            doc_idx, scores = zip(*scores_in_in)
            top_avg = np.mean(scores[:avg_top_n])

            #identify the top risk term associated with the sentences in each article 
            if top_avg > best_score:
                best_score = top_avg
                best_doc_idx = doc_idx
                best_term = q
        except ValueError:
            logger.debug(
                'Error occurred while unpacking "scores_in_in": {}'.format(scores_in_in)
            )

    for idx in best_doc_idx:
        if len(row["sentence_tokenized"][idx]) >= best_doc_char_threshold:
            best_docs.append(row["sentence_tokenized"][idx])
        if len(best_docs) == num_best_docs_to_yield:
            break

    return best_score, best_docs, best_term, score_dict



