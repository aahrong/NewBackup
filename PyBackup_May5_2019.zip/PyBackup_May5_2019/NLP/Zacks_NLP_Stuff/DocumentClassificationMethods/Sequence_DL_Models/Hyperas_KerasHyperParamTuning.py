# -*- coding: utf-8 -*-
"""
Created on Fri Feb 15 12:25:33 2019

@author: caridza
"""


#imports
from __future__ import print_function
from hyperopt import Trials, STATUS_OK, tpe
from hyperas import optim
from hyperas.distributions import choice, uniform
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation
from keras.optimizers import RMSprop

import sys 
import nltk
import matplotlib
import pandas as pd 
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
from nltk import word_tokenize
import sklearn
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer,TfidfTransformer
import keras
import string
import numpy as np
from negative_news2.consumer.utils import replace_words,remove_punctuation,remove_stop,stem_words,remove_nonchars, orig_text_clean_slim
from sklearn import preprocessing 


#define data frunction for hyperas
def data():
    from nltk.corpus import stopwords
    
    num_labels=1
    vocab_size = 10000
    
    #punctuation to remove, stopwords to remove, stemming and lemmatizing objects for preprocessing
    stemmer = SnowballStemmer('english')
    exclude = set(string.punctuation)
    stopwords = stopwords.words('english')
    newStopWords = ['.','?','%','Google','Wells Fargo','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December']
    stopwords.extend(newStopWords)
    stop_list=set(stopwords)
    
    #data 
    datapath = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/SentDF.pickle"
    data = pd.read_pickle(datapath)
    data.drop(columns=['date'])
    
    #define target , clean text, and split data into test and train
    target = "MandA"
    Data = orig_text_clean_slim(data,target=target , txtfeild='Sentence' , stopwords=stop_list,stemmer=stemmer)
    
    #clean data 
    train_x,valid_x,train_y,valid_y= sklearn.model_selection.train_test_split(Data['Sentence'],Data['label_id'],shuffle=True, stratify=Data['label_id'],test_size=.3, random_state=10)
    
    #vectorized matrix of tfidf weights for input as independent variables 
    #fit tfidf on trianing data and transform the tfidf on the test data 
    vectorizer = TfidfVectorizer(analyzer='word', ngram_range=(1,1), max_features=vocab_size,min_df=2 ,stop_words='english', max_df=.1, smooth_idf=True, norm='l2',sublinear_tf=True,lowercase=True,)
    x_train = vectorizer.fit_transform(train_x).toarray()
    x_test = vectorizer.transform(valid_x).toarray()
    y_train=train_y
    y_test=valid_y
    return x_train,y_train,x_test,y_test

def create_model(x_train,y_train,x_test,y_test):
    
    #NOTE: ALL hyperparameters being tuned wrapped in {{}}
    vocab_size = 10000
    num_labels = 1
    
    #define basic model to use to identify optimal sample size 
    model = keras.models.Sequential()
    
    #Fully Connected Dense input layer 
    #First optimizatoin parametr 
    model.add(keras.layers.Dense(units={{choice([10,50,100])}}, 
                                         input_shape=(vocab_size,),
                                         kernel_regularizer=keras.regularizers.l2({{choice([.0001,.001,.01])}}),
                                         activity_regularizer=keras.regularizers.l2({{choice([.0001,.001,.01])}})))
    model.add(keras.layers.Activation({{choice(['relu','selu'])}})) #Second optimzation parametr: choice of activation 
    model.add(keras.layers.Dropout(rate ={{choice([.1,.3,.5,.7,.8])}})) #Third optimization parameter (DROPOUT)#Second optimization parameter (DROPOUT)

    
    #Forth optimization parameter: if three is the choice, add a nother layer to the model 
    if {{choice(['two','three'])}} =='three':
        
        #Fifth and Sixth
        #evaluate a varity of input nodes and regularizatnoi for l2
        model.add(Dense(units={{choice([10,50,100])}},kernel_regularizer=keras.regularizers.l2({{choice([.01,.001])}}),activity_regularizer=keras.regularizers.l1({{choice([.01,.001])}}))) 
        
        #determine if dropout should be used or not 
        model.add({{choice([Dropout(rate=.5),Activation('linear')])}})
        model.add(Activation('relu')) #5
        
    #add final dense layer 
    model.add(keras.layers.Dense(num_labels))
    model.add(keras.layers.Activation('sigmoid')) 
       
    #determine starting point for class weights 
    NegCounts = pd.value_counts(y_train, sort=False)[0]
    PosCounts = pd.value_counts(y_train, sort=False)[1]
    Ratio_Rare2Common = round(NegCounts/PosCounts,0)
    print(Ratio_Rare2Common)
    
    #generate list of class weights to try based on starting ratio 
    ClassWeights = [{0:1,1:max(1,round(Ratio_Rare2Common*val,0))} for val in [2,3,.8,.6,.4,.2,.1,.01]]
    ClassWeights.extend([{0:2,1:1}])

    #set loss function, gds ooptimizer, and metrics to track for callbacks and cross validation 
    model.compile(loss='binary_crossentropy',metrics=['accuracy'],optimizer={{choice(['rmsprop','adam'])}})
     
    #fit model
    result = model.fit(x_train,y_train
              ,batch_size={{choice([64,128,192,256])}}
              ,epochs=2
              ,verbose=2
              ,validation_split=0.2
              ,class_weight = {0:1,1:max(1,round(Ratio_Rare2Common*.5,0))}#{{choice([{0:1,1:max(1,round(Ratio_Rare2Common*val,0))} for val in [2,3,.8,.6,.4,.2,.1,.01]])}},    #{0:1,1:Ratio_Rare2Common},#                   
                        )
    
    #get highest validatoin accuracy of training epochs 
    validation_acc = np.amax(result.history['val_acc'])
    print('Best validation acc of epoch:', validation_acc)
    return {'loss':-validation_acc,'status':STATUS_OK,'model':model}



    
if __name__ == '__main__':
    best_run, best_model = optim.minimize(model=create_model,
                                          data=data,
                                          algo=tpe.suggest,
                                          max_evals=5,
                                          trials=Trials())
    X_train, Y_train, X_test, Y_test = data()
    print("Evalutation of best performing model:")
    print(best_model.evaluate(X_test, Y_test))
    print("Best performing model chosen hyper-parameters:")
    print(best_run)
    
    
    
    
    


