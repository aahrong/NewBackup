# -*- coding: utf-8 -*-
"""
Created on Thu Jan 31 15:37:13 2019
Data Preprocessing Script for Sequence based RNN topographies
@author: caridza
"""
import pandas as pd 
from sklearn.model_selection import StratifiedShuffleSplit

####SEQUENCE BASED NEURAL NETWORK TEXT PREPROCESSING AND TRANSFORMATION FOR INPUT TO bi-lstm with self attention######
#data , Y, X
datapath = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/SentDF.pickle"
target = 'MonetaryFine'

#import data
Data = pd.read_pickle(datapath)

#generate unbalanced holdout and balanecd training data for model training
sss = StratifiedShuffleSplit(n_splits=2, test_size=0.1, random_state=0)
sss.get_n_splits(Data.index.values, Data[target])
indicies  = []
for train_index ,test_index in sss.split(Data.index,Data[target]):
    indicies.extend(test_index)
testrows=indicies

#create holdout with population distributions of target preserved 
holdout= Data.iloc[testrows,:]  

#generate balanced dataframe for testing using data not included in holdout
data = Data.loc[set(Data.index)-set(holdout.index)]
balanced_data = upsample_rare(data,target)


#Convert text to padded sequences of integers representing words 



#####MODEL DATA PREPROCESSING FUNCTION 
def make_df(datapath , max_features,EMBEDDING_DIM,stop_list,stemmer,target):
    '''
    Inputs: 
    ##### datapath = path to dataframe of sentences and label ids 
    ##### max_features = total number of features from text to consider when buildling embedding layer
    ##### EMBEDDING_DIM = total number of dimensions from embedding we want to use in embedding layer (Note: if using pymag you must use 300)
    ##### stop_lsit = list of stopwords to use for preprocessing 
    ##### stemmer = stemming class to use to stem words in sentences 
    ##### target = name of the target feild you are trying to predict in the dataset 
    PROCESS STEPS: 
    ##### 1. toeknize text
    ##### 2. Convert text to sequences
    ##### 3. Pad Sequences 
    ##### 4. Split into Test and Train
    ##### 5. Return X_train , X_Test, Y, WordIndex 
    '''
    
    #clean original sentence level text
    data = pd.read_pickle(datapath)
    trainDF = orig_text_clean(data,target=target , txtfeild='Sentence',stopwords=stop_list,stemmer=stemmer) 
    
    #specify X and Y (these standard columns are created in orig_text_clean)
    X = trainDF['Sentence']
    Y = trainDF['label_id']
    
    #generate list of unique words based on total words specified to consider
    sentences = []
    lines = X.values.tolist()
    lines = [word_tokenize(sent) for sent in lines]
    model=gensim.models.Word2Vec(sentences=lines, size=EMBEDDING_DIM,window=5,workers=4,min_count=1)
    words = list(model.wv.vocab)
    
    #model process 
    #fit tokenizer to words and turn to sequences 
    tokenizer_obj = Tokenizer()
    tokenizer_obj.fit_on_texts(X)
    sequences = tokenizer_obj.texts_to_sequences(X)
    
    #define max length for padding and total vocab size
    max_length = max([len(s.split()) for s in X]) 
    vocab_size = len(tokenizer_obj.word_index)+1
    
    #pad sequences 
    word_index = tokenizer_obj.word_index
    review_pad = pad_sequences(sequences,maxlen=max_length)
    label = Y.values
    
    #split data 
    x_train,x_test,y_train,y_test = model_selection.train_test_split(review_pad, label,shuffle=True, stratify=Y,test_size=.3, random_state=10)
    sm = SMOTE(random_state=2)
    x_train, y_train = sm.fit_sample(x_train, y_train)
    
    return x_train, y_train, x_test, y_test, word_index, max_length , words

