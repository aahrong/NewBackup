# -*- coding: utf-8 -*-
"""
Created on Tue Feb 12 07:30:16 2019
SAMPLING APPROACHES
https://amueller.github.io/COMS4995-s18/slides/aml-13-022818-resampling-imbalanced-data/#43
@author: caridza
"""

import pandas as pd 


import numpy as np 

# load the dataset
datapath = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/SentDF.pickle"
target = 'Disqualification'
inputtxt = 'Sentence'
data = pd.read_pickle(datapath)
data.drop(columns=['date'])
data.info()

#define target 
target = 'LegalAction'
le = preprocessing.LabelEncoder() 
le.fit(data[target])
data['label_id'] = le.transform(data[target]) 

Y = np.array(data['label_id'])
X = np.array(data['Sentence'])
X = X.reshape(-1,1)

#
#random undersampling 
#
from imblearn.under_sampling import RandomUnderSampler 
rus = RandomUnderSampler(replacement=False)
train_x_subsample,train_y_subsample= rus.fit_sample(X,Y)
print(train_x_subsample.shape)
print(np.bincount(train_y_subsample))        
print(np.bincount(Y))        

#
#random oversampling  
#
from imblearn.over_sampling import RandomOverSampler
ros = RandomOverSampler()
train_x_oversample,train_y_oversample= ros.fit_sample(X,Y)
print(train_x_subsample.shape)
print(np.bincount(train_y_subsample))        
print(np.bincount(Y))        

#
#Ensemble sampling 
#
from sklearn.tree import DecisionTreeClassifier
from imblearn.ensemble import BalancedBaggingClassifier
tree = DecisionTreeClassifier(max_features='auto')
resampled_rf = BalancedBaggingClassifier(base_estimator=tree,n_estimators=100, random_state=0)
scores = cross_validate(resampled_rf, X_train, y_train, cv=10, scoring=('roc_auc', 'average_precision'))
scores['test_roc_auc'].mean(), scores['test_average_precision'].mean()

#
#Startified Shuffle Split 
#
def upsample_rare(data, Rare_ColStr):
    '''
    Input: {'data':'dataframe with rare event','Rare_ColStr':'name of the column containing the rare target event we want to oversample'
    Output: Dataframe of equal proportions of target event to be used only in training (MUST SPLIT TEST DATA SET BEFORE RUNNING THIS)

    '''
    negobs = data[data[Rare_ColStr]==False]
    posobs = data[data[Rare_ColStr]==True]

    #create a list of dataframes, where each data frame contains a replica of all postive observations which we can use for oversampling 
    rep_1 =[posobs for x in range(negobs.shape[0]//posobs.shape[0] )]
    keep_1s = pd.concat(rep_1, axis=0)
    train_dat = pd.concat([keep_1s,negobs],axis=0)
    return(train_dat)


#example implementation of Stratifeid Shuffle Split 
#note:first you want to extract a stratified holdout for later testing 
from sklearn.model_selection import StratifiedShuffleSplit
sss = StratifiedShuffleSplit(n_splits=2, test_size=0.1, random_state=0)
sss.get_n_splits(data.index.values, data['label_id'])
indicies  = []
for train_index ,test_index in sss.split(data.index,data['label_id']):
    indicies.extend(test_index)
testrows=indicies
holdout= data.iloc[testrows,:]  
Data = data.loc[set(data.index)-set(holdout.index)] #create balanced dataframe for modeling
balanced_data = upsample_rare(Data,target)


