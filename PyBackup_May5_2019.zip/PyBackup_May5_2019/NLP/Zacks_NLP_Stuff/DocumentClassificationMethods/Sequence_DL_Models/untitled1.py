# -*- coding: utf-8 -*-
"""
Created on Mon Feb 18 16:21:27 2019

@author: caridza
"""

import os 
import sys
import pandas as pd 
import pymagnitude
import re
import string 
from sklearn import preprocessing , model_selection, metrics
import numpy as np
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk import regexp_tokenize
from nltk.tokenize import word_tokenize , sent_tokenize

#inputs requiring path specification
datapath = "C://Users//caridza//Desktop//pythonScripts//NLP//Zacks_NLP_Stuff//Data//SentDF.pickle"
Data = pd.read_pickle(datapath)

#sentiment normlized 
def normalized(x):
    norm = (x-min(x))/(max(x)-min(x))
    return norm 

normalized(Data['LegalAction'].astype(int))

list(Data)

    output_args = {
        "output_path": output_path,
        "url_list": list(df["url"]),
        "NumStartUrls": len(scraped_data),
#GENERATE IN OUTPUT_ARGS        "max_links_for_score": len(df),
        "entity_name": entity_name,
#GENERATE IN OUTPUT_ARGS                "entity_name_translated": entity_name_translated,
#GENERATE IN OUTPUT_ARGS                "entity_fname": entity_fname,
#GENERATE IN OUTPUT_ARGS                "entity_lname": entity_lname,
        "normalized_risk_score": normalized_risk_score,
#GENERATE IN OUTPUT_ARGS (&rename from _final suffix)               "name_fuzzy_score": np.mean(df["name_fuzzy_score_final"]),
#GENERATE IN OUTPUT_ARGS (&rename from _final suffix)               "location_fuzzy_score": 0,
#GENERATE IN OUTPUT_ARGS (&rename from _final suffix)               "employment_fuzzy_score": 0,
        "w2vtopsent": list(df["desm_sentences"]),
        "summary": list(df["summary"]),
        "regnoreg": list(df["regulatory_flag"]),
        "docCat": docCat,
        "percC": percC,
        "newssource": list(df["source"]),
        "datelist": list(df["date"]),
        "docTitles": list(df["title"]),
#GENERATE IN OUTPUT_ARGS        "entity_querylist": list(df["source"].unique()),
#GENERATE IN OUTPUT_ARGS        "top_search_terms": [term.title() for term in df["desm_term"]],
        "all_search_terms": [term.title() for term in search_terms],
#GENERATE IN OUTPUT_ARGS                "fine_reports_list": [list(fine_report) for fine_report in df["fine_report_strings"]],
        "model_weights": model_weights_dict,
        "binned_values": binned_df,
        "unnormalized_doc_scores": list(df["final_score"]),
#GENERATE IN OUTPUT_ARGS         "total_fine_amt": df["fine_total_sum"].max(),
        "risk_rankings": list(df['risk_ranking_final_score']),
    }



MODEL_WEIGHTS_DICT = {
    "WEIGHT_TERM_SIMILARITY": 0.85,
    "WEIGHT_ENTITY_COUNT": 0.05,
    "WEIGHT_SENTIMENT": 0.03,
    "WEIGHT_FINE_AMOUNT": 0.05,
    "WEIGHT_DOCUMENT_AGE": 0.02,
}
#data 
datapath = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/SentDF.pickle"
data = pd.read_pickle(datapath)
data.drop(columns=['date'],inplace=True)

data['constant'] = str(MODEL_WEIGHTS_DICT)#[[str(x) for x in range(0,10)]]

len(data)


for idx,i in enumerate(['Trade','MandA','RegulatoryRefrence']):
    percC[idx]=data[i].sum() /data.shape[0]

    
    print(i)
    
percC = [0,0,0]
 = [0, 0, 'sdf', 1]
percD = [4, 0, 'sdf', 1]


for idx,ll in enumerate(list(zip(data['RegulatoryRefrence'],data['Trade'],data['MandA']))):
    print(sum(ll))
    percC[idx] = sum(ll)/len(ll)

    print(idx,ll)
    
for idx,ll in enumerate(docCat):
    percC[idx] = sum(ll)/len(ll)
print('percC', percC)
print('doccat',docCat)
	

data['constant'].unique()[0]


docCat = [[0 for i in range(0, len(data))] for k in range(0, 4)] #initalize and use first list to represent "other negative news"
percC = [0, 0, 0, 0]

len(docCat)

temp=pd.DataFrame(docCat).transpose()
df = temp.transpose()
df.columns = ['OtherNeg','Reg','MF','Legal']

pd.concat([data,df],axis=1)
pd.DataFrame(docCat,columns =['OtherNegNews','Regulatory','MF','LA'])


     if (docCat[2][t] >0 ) or (len(fine_reports) > 0):
            DocCats.append("Monetary Fine ")
        if docCat[1][t] >0:
            DocCats.append("Legal Action ")
        if docCat[3][t] >0:
            DocCats.append("Regulatory Reference ")
        if docCat[1][t] + docCat[2][t] + docCat[3][t] == 0:
            DocCats.append("Other Negative News")






output_args = {
        "output_path": output_path,
        "url_list": list(df["url"]),
        "NumStartUrls": len(scraped_data),
        "max_links_for_score": len(df),
        "entity_name": entity_name,
        "entity_name_translated": entity_name_translated,
        "entity_fname": entity_fname,
        "entity_lname": entity_lname,
        "normalized_risk_score": normalized_risk_score,
        "name_fuzzy_score": np.mean(df["name_fuzzy_score_final"]),
        "location_fuzzy_score": 0,
        "employment_fuzzy_score": 0,
        "w2vtopsent": list(df["desm_sentences"]),
        "summary": list(df["summary"]),
        "regnoreg": list(df["regulatory_flag"]),
        "docCat": docCat,
        "percC": percC,
        "newssource": list(df["source"]),
        "datelist": list(df["date"]),
        "docTitles": list(df["title"]),
        "entity_querylist": list(df["source"].unique()),
        "top_search_terms": [term.title() for term in df["desm_term"]],
        "all_search_terms": [term.title() for term in search_terms],
        "fine_reports_list": [
            list(fine_report) for fine_report in df["fine_report_strings"]
        ],
        "model_weights": model_weights_dict,
        "binned_values": binned_df,
        "unnormalized_doc_scores": list(df["final_score"]),
        "total_fine_amt": df["fine_total_sum"].max(),
        "risk_rankings": list(df['risk_ranking_final_score']),
    }





    output_args = {
        "output_path": output_path,
        "url_list": list(df["url"]),
        "NumStartUrls": len(scraped_data),
        "max_links_for_score": len(df),
        "entity_name": entity_name,
        "entity_name_translated": entity_name_translated,
        "entity_fname": entity_fname,
        "entity_lname": entity_lname,
        "normalized_risk_score": normalized_risk_score,
        "name_fuzzy_score": np.mean(df["name_fuzzy_score_final"]),
        "location_fuzzy_score": 0,
        "employment_fuzzy_score": 0,
        "w2vtopsent": list(df["desm_sentences"]),
        "summary": list(df["summary"]),
        "regnoreg": list(df["regulatory_flag"]),
        "docCat": docCat,
        "percC": percC,
        "newssource": list(df["source"]),
        "datelist": list(df["date"]),
        "docTitles": list(df["title"]),
        "entity_querylist": list(df["source"].unique()),
        "top_search_terms": [term.title() for term in df["desm_term"]],
        "all_search_terms": [term.title() for term in search_terms],
        "fine_reports_list": [
            list(fine_report) for fine_report in df["fine_report_strings"]
        ],
        "model_weights": model_weights_dict,
        "binned_values": binned_df,
        "unnormalized_doc_scores": list(df["final_score"]),
        "total_fine_amt": df["fine_total_sum"].max(),
        "risk_rankings": list(df['risk_ranking_final_score']),
    }


    return output_args
