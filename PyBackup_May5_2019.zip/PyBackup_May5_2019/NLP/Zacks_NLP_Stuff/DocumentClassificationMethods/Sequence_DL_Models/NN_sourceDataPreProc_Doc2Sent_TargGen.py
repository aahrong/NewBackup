# -*- coding: utf-8 -*-
"""
Created on Fri Jan 18 08:17:11 2019

@author: caridza
"""
import pickle
import re
import pandas as pd
from nltk.tokenize import word_tokenize , sent_tokenize
import multiprocessing
# -*- coding: utf-8 -*-
"""
Created on Fri Jan 18 16:22:47 2019

@author: caridza
"""

import os 
import sys
#sys.path.insert(0, "//home//nlpsomnath//NegNews//rebase//NN_Kafka//")
#os.chdir("//home//nlpsomnath//NegNews//rebase//NN_Kafka//")

#text processing modules
import pymagnitude
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk import regexp_tokenize
from nltk.tokenize import word_tokenize , sent_tokenize
from nltk.stem import WordNetLemmatizer
import string
from gensim import corpora, models, similarities
import string
import re
from fuzzywuzzy import fuzz
import numpy as np
import operator
from scipy import spatial
import pandas as pd
from sklearn import preprocessing 
from datetime import datetime
import json
import datetime

import spacy
import dateparser
#base modules 
import sys
from itertools import islice #iterating over vectorized objects (countvectorizer, tfidfvectorizer,etc..)
#third party modules
#import required modules for data preprocessing , feature engineering and model training
from sklearn import model_selection, preprocessing, linear_model, naive_bayes, metrics, svm
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn import decomposition, ensemble
from sklearn.pipeline import Pipeline
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import FunctionTransformer
import sklearn
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn import svm
from sklearn import tree
import pandas,  numpy, string, textblob
from keras.preprocessing import text, sequence
from keras import layers, models, optimizers
from sklearn.neural_network import MLPClassifier

import matplotlib.pyplot as plt
import matplotlib

import seaborn as sns
pd.set_option('display.max_colwidth', -1)
pd.set_option('display.max_rows', 500)

stop_words = stopwords.words('english')
newStopWords = ['.','?','%']
stop_words.extend(newStopWords)
stop_words=set(stop_words)
stemmer = SnowballStemmer("english")
#nlp = spacy.load('en_core_web_sm')

wv=pymagnitude.Magnitude("C://Users//caridza//Desktop//pythonScripts//NLP//Embeddings//GoogleNewsvectors_negative300.magnitude")

data = pd.read_pickle("C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/All_Source_Data.pickle")
data = data[['entity','date','title','source','origtext']]
data.reset_index(inplace=True)

#preprocess text 
Sentences =  data['origtext'].apply(lambda x: Txt_PreProcess(x))
Sent= list(Sentences)
All_Sent = [item for sublist in Sent for item in sublist]
Filt_Sent = list(set( [x for x in All_Sent if len(x) > 30]))
Sent_df = pd.DataFrame(Filt_Sent,columns =['Sentence'])
Sent_df  = Sent_df .sample(frac=1).reset_index(drop=True) #shuffle data and reindex

#generate unsupervised target flags
Sent_df['MonetaryFine'] = Sent_df.apply(lambda x:stemsims(x['Sentence'],wv,['fined','penalty'],.4),axis=1)
Sent_df['LegalAction'] = Sent_df.apply(lambda x:stemsims(x['Sentence'],wv,['legal', 'judicial', 'action'],.4),axis=1)
Sent_df['RegulatoryRefrence'] = Sent_df.apply(lambda x:stemsims(x['Sentence'],wv,['regulate', 'oversight','FINRA','SEC','OCC'],.4),axis=1)

Sent_df['Statutory'] = Sent_df.apply(lambda x:stemsims(x['Sentence'],wv,['statutory'],.4),axis=1)
Sent_df['Disqualification'] = Sent_df.apply(lambda x:stemsims(x['Sentence'],wv,['disqualify', 'violation'],.4),axis=1)

Sent_df['Trade'] = Sent_df.apply(lambda x:stemsims(x['Sentence'],wv,['exchange', 'trade', 'transaction','traded','trading'],.4),axis=1)
Sent_df['Suspension'] = Sent_df.apply(lambda x:stemsims(x['Sentence'],wv,['suspend', 'revoke'],.4),axis=1)

Sent_df['Managment'] = Sent_df.apply(lambda x:stemsims(x['Sentence'],wv,['managment','CEO', 'CFO', 'COO','CTO','CIO','CRO','Directors','committe','staff','chairman'],.4),axis=1)
Sent_df['Change'] = Sent_df.apply(lambda x:stemsims(x['Sentence'],wv,['change', 'reshuffle','replace','hired','revoke','removed','voluntary','resign','fired','leave'],.4),axis=1)

Sent_df['MandA'] = Sent_df.apply(lambda x:stemsims(x['Sentence'],wv,['merger', 'acquisition','aquire'],.4),axis=1)

#complaint filed
Sent_df['complaint'] = daSent_dfta.apply(lambda x:stemsims(x['Sentence'],wv,['complain','reproach','objection','criticism','accusation'],.4),axis=1)

#save final data to file 
#save pickle file of dataframe 
Sent_df.to_pickle("C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/sendf_output.pickle")


#clean text helper functions 
def clean_text( text):
    text = text.replace('\n', ' ').replace('\t', ' ').replace('\r', ' ')
    text = re.sub(r' +', ' ', text)
    text = text.strip()
    return text

#clean text helper functions 
def chkPeriod(SentTokList):
    p = re.compile(r'[A-Za-z]+[A-Za-z]+[.]+[A-Za-z]+[A-Za-z]{2,}')
    output= []
    for val in SentTokList: 
        if p.search(val):
            newstr = ' '.join([re.sub('[.]+', ' ', y) for y in val.split()])
        else: 
            newstr = val
        output.append(newstr)        
    return output 

#clean text 
def Txt_PreProcess(x):
    step0 = clean_text(x)
    step11 = sent_tokenize(step0)
    step1 = chkPeriod(step11)
    step2 = [x for x in step1 if max(len(w) for w in x.split())<20] #only consider sentences with words < 15 characters 
    step3 = [y for y in step2 if len(y)>29 and len(y)<550] #only consider sentences within a specific character length 
    step4 = [re.sub('[^A-Za-z|^\$|^\.]+', ' ', y) for y in step3] #remove all special characters except periods and $s 
    step5 = [y.strip() for y in step4 if y] #strip leading and trailing white space and only return if y exists(is not none)
    step6 = [y for y in step5 if not y =='']
    step7 = [re.sub("\.{2,}" , " . ",y) for y in step6] #replace multiple periods with a single period 
    step8 = [re.sub(' +',' ',y) for y in step7]
    step9 = step8#' '.join(step8)
    if len(' '.join(step8))<20: 
        step9 = ['There is no relevant information in this text']
    return step9


# Function to get cosine similarity 
def cosine_sim(a, b):
    return 1 - spatial.distance.cosine(a, b)

def isListEmpty(inList):
    if isinstance(inList, list): 
        return all( map(isListEmpty, inList) )
    return False

def mean(numbers):
    return float(sum(numbers)) / max(len(numbers), 1)

#note: phrase must be word tokenized at input 
def avg_phrase(phrase, wv,stems):
    v = np.zeros(300) #create empty vector to hold the average vector of the nword phrase being processed(likley a sentence)ne time when calculating average word vectors. 
    sim = [[] for i in range(len(stems))]
    simmax = [[] for i in range(len(stems))]
    simmean = [[] for i in range(len(stems))]
    stem_index = 0
    for stem in set(stems):
        for w in set(phrase):
       #if the word is found in the google word embeddings 
            try:
                if stem in wv and w in wv:
                    sim[stem_index].append(cosine_sim(wv.query(w),wv.query(stem)))
            except Exception:
                ('Error occurred while executing < sim[{stem_idx}].append(cosine_sim(wv.query({w}),wv.query({stem}))) > for phrase: {phrase}. Rethrowing exception .. '.format(stem_idx = stem_index, w = w, stem = stem, phrase = phrase))
                raise

        #for stem in set(stems):
        #print(sim[stem_index])
        try: 
            simmax[stem_index] = (max(sim[stem_index]), stem)
            simmean[stem_index] = max(sim[stem_index])
        
        except Exception as e: 
            print('sim index{}'.format(phrase),e)
    
        stem_index = stem_index +1        
   #after all words in the sentence have been processed normilize the final vector back to unit length reprsenting the average word embedding vector for the terms in the sentence 

    return  max(sim), sim, simmax, mean(simmean)


def stemsims(text,wv,stems,weight,stopwords=['and']):
    '''
    text: document of text (sentences)
    wv: word embedding file to identify similarity of stems with text 
    stems([stem1,stem2,...,]): stems being used to define the topic we are trying to generate a pseudo target for 
    weight(int between 0 and 1): the min similarity that must be found between at least 1 word in the text and the stems for the doc to be classified as related to the topic
    '''
    #tokenize document 
    text = sent_tokenize(text)
    #print(text)
   
    #lists to hold output
    SentenceListBool = []
    perc = []

    #Initialize
    index = 0
    sentmax = [[] for i in range(len(text))] 
    meanindex = [[] for i in range(len(text))]     

    #Find the maximum match to each stem in each sentence
    #note: text has been sentence tokenized above  
    for sent in text: 
        tempsent = [] 
        word_tokens = word_tokenize(sent)
        sent2 = ' '.join([w for w in word_tokens if (not w in stop_words)])
        sent2 = 'no valuable data' if len(sent2)<20 else sent2
        maxout,simfile,simmax,simmean = avg_phrase(sent2.split(),wv,stems)

        if simmean > weight:
            arg = simmax,simmean,sent2
            tempsent.append(arg)
        else:
            tempsent.append([])

        sentmax[index] = tempsent
        index = index+1

    sentBool = [] #holds similarity associated with the word with the greatest corrolation to, loops through and stores values for each sentence
    for i in range(len(sentmax)):
        sentBool.append(not isListEmpty(sentmax[i]))
    if len(sentBool)>0:
        perc.append(sum(sentBool)/len(sentBool))
    else:
        perc.append(0)
    
    if any(condition==True for condition in sentBool):
        return True 
    else: 
        return False


#
#
#
#    
###
#
#p = re.compile(r'[A-Za-z]+[A-Za-z]+[.]+[A-Za-z]+[A-Za-z]{2,}')
#resp=[p.search(x) for x in list(data['origtext'])]
#resp.group()
#
#test = ['My name is zachary.carideo and i live..in the room.next','i am zack. i like corn']
#step2 = [[re.sub('[.]+', ' ', y) for y in x.split()] for x in test if any([p.search(w) for w in x.split()])]
#
#
#        
#with pd.option_context('display.max_rows', None, 'display.max_columns', None,'max_colwidth',-1):
#    #print(data[['_id','origtext']].head(1))
#    print(step0[0])
#
#x = data['origtext'][0]
