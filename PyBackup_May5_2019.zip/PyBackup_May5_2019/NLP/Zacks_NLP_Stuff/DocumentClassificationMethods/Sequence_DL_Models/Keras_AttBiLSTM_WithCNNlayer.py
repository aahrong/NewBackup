#!/usr/bin/env python
# coding: utf-8


"""
Created on Wed Jan 30 08:19:40 2019
https://www.kaggle.com/takuok/bidirectional-lstm-and-attention-lb-0-043
@author: caridza
"""
#for hpyer parameter tuning
import comet_ml 
from comet_ml import experiment

import os 
import sys
import pandas as pd 
import pymagnitude
import re
import string 
import numpy as np
import nltk
from sklearn import preprocessing , model_selection, metrics
from sklearn.model_selection import StratifiedShuffleSplit
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk import regexp_tokenize
from nltk.tokenize import word_tokenize , sent_tokenize

#MUST IMPORT ALL FROM EITHER KERAS or Tensorflow.python.keras. YOU CANNOT MIX
import keras 
import keras_self_attention
from keras.preprocessing.text import Tokenizer 
from keras.preprocessing.sequence import pad_sequences 
from keras.preprocessing.text import Tokenizer 
from keras.preprocessing.sequence import pad_sequences 
from keras.callbacks import ModelCheckpoint, EarlyStopping
from keras_self_attention import SeqSelfAttention 
from keras.callbacks import Callback

import gensim
from imblearn.over_sampling import SMOTE  # or: import RandomOverSampler
from imblearn.pipeline import Pipeline as imbPipeline
from matplotlib import pyplot
import matplotlib.pyplot as plt

#DEFINING CUSTOM METRICS TO USE WITH KERAS 
import numpy as np
from sklearn.metrics import confusion_matrix, f1_score, precision_score, recall_score

#stopwords, stemmer
datapath = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/SentDF.pickle"
stemmer = SnowballStemmer('english')
exclude = set(string.punctuation)
stopwords = stopwords.words('english')
newStopWords = ['.','?','%','Google','Wells Fargo','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December']
stopwords.extend(newStopWords)
stop_list=set(stopwords)
wv=pymagnitude.Magnitude('C://Users//caridza//Downloads//crawl-300d-2M.magnitude')

#inputs requiring path specification
max_features = 100000 #maximum number of words to consider in analysis 
EMBEDDING_DIM = 300 #NOTE: becuase we use pymag this must be set to 300 
stop_list = stop_list
stemmer = stemmer
target = 'MandA'

#generate unbalanced holdout and balanecd training data for model training
Data = pd.read_pickle(datapath).head(1000)
list(Data)

#NOTE: NOT USING BALANCED DATA , USING CLASS_WEIGHTS
#transform original Df into sequence tokenized data and split into test and train. get list of words in vocab , and maxlen of sequence
xtr,ytr,xte,yte,word_index, maxlen,words = make_df(Data,      #path to sentence level data 
                                             max_features,  #maximum number of words to consider in model 
                                             EMBEDDING_DIM, #number of dims form embedding vector to use(if pymag used this must be 300)
                                             stop_list,
                                             stemmer,
                                             target,
                                            test_size = .2)

#identify class weights
NegCounts = pd.value_counts(ytr, sort=False)[0]
PosCounts = pd.value_counts(ytr, sort=False)[1]
Ratio_Rare2Common = max(1,round((NegCounts/PosCounts)/10,0))
print(NegCounts,PosCounts)
print(Ratio_Rare2Common)
ClassWeights = {0:1,1:Ratio_Rare2Common}


#######################################################
##############BEGIN MODEL DEVELOPMENT##################
#######################################################
#GENERATE EMBEDDING MATRIX FOR EMBEDDING LAYER IN MODEL(using pymagnitude converted vectors)
nb_words = min(max_features, len(word_index)+1) #total features to consider, min of the max feats vs total feats 
embedding_vector =  make_embeddings_pymag(wv, max_features,words, word_index, EMBEDDING_DIM, nb_words)

#BEGIN MODEL LAYER DEFFINITIONS 
#Initialize Sequential Model class  
model=keras.models.Sequential()

#add embedding layer
model.add(keras.layers.Embedding(input_dim = nb_words #max_features
                                 , output_dim= EMBEDDING_DIM #embedding size 
                                 , weights = [embedding_vector]
                                 , mask_zero=False
                                 #, trainable=False  #if True transfer learning is enabled, the weights from the past epoch are used as starting points for the next epoch
                                 , input_length = maxlen #the max sequence length, this is the length that all sequences will be padded to (so all sequences will have same length)
                                 ))

#ADD CNN LAYER WITH SELU ACTIVATION AND GAUSSIAN DROPOUT  
#NOTE:specify guassian dropout befire activation function has been specified
#WARNING: if you specify guassian dropout after activation function  the resulting values may be out-of-range 
#from what the activation function may normally provide. For example, a value with added noise may be less than zero,
#whereas the relu activation function will only ever output values 0 or larger.  
model.add(keras.layers.Conv1D(filters=164, kernel_size=10,padding='valid' ,strides=1))
model.add(keras.layers.MaxPooling1D(pool_size=4))
model.add(keras.layers.GaussianDropout(0.7))
model.add(keras.layers.Activation('selu'))

#ADD BILSTM WITH DROPOUT 
model.add(keras.layers.Bidirectional(keras.layers.LSTM(units = 400, 
                                                       return_sequences=True,
                                                       #dropout=.3, #dropout not applied here becase we apply it via the guassian dropout specificed below
                                                       recurrent_dropout=.7,
                                                       recurrent_regularizer=keras.regularizers.L1L2(l1=0.0, l2=0.01),
                                                       kernel_regularizer = keras.regularizers.L1L2(l1=0,l2=.01),
                                                       bias_regularizer = keras.regularizers.L1L2(l1=0,l2=.01),
                                                       )))
#ADD NON RECURRENT DROPUT TO LSTM 
model.add(keras.layers.GaussianDropout(0.7))
model.add(keras.layers.Activation('selu'))

#SELF ATTENTION LAYER 
model.add(SeqSelfAttention(
                        attention_width=15,
                        attention_type=SeqSelfAttention.ATTENTION_TYPE_MUL,
                        attention_activation=None,
                        kernel_regularizer=keras.regularizers.L1L2(1e-6),
                        bias_regularizer=keras.regularizers.l1(1e-4),
                        use_attention_bias=True,    
                        attention_regularizer_weight=1e-4,
                        name='Attention',))

#FLATTENED LAYER (CONVERTS 2D tensor to 1D)
#model.add(GlobalMaxPool1D())
model.add(keras.layers.Flatten())

#OUTPUT LAYER(units = # target labels, for binary this =1)
model.add(keras.layers.Dense(units =1,activation='sigmoid'))

#COMPILE MODEL WITH CUSTOM KERAS METRICS (functions defined at top of script)
model.compile(optimizer='adam',loss = 'binary_crossentropy',metrics =['accuracy',recall,fmeasure,precision,fbeta_score] )

#SPECIFY KERAS CALLBACKS 
filepath = "best_bilstm.hdf5"
monitor = 'val_fmeasure'
min_max_metric = 'max'
ckpt = ModelCheckpoint(filepath, monitor=monitor , verbose=1, save_best_only=True, save_weights_only=False, mode=min_max_metric)
early = EarlyStopping(monitor=monitor , mode=min_max_metric, patience=10)


#FIT MODEL 
model_out = model.fit(xtr, ytr, batch_size=200, epochs=50
                      , validation_data = (xte,yte)
                      , class_weight=ClassWeights
                      , callbacks=[ckpt, early])


#EVALUATE MODEL FIT 
y_preds = model.predict_classes(xte)
matrix = metrics.confusion_matrix(yte, y_preds)
scores = model.evaluate(xte, yte, verbose=0)
print(matrix)
print(scores)

#PLOT FIT HISTORY 
pyplot.plot(history.history['loss'], label='train')
pyplot.plot(history.history['val_loss'], label='test')
pyplot.legend()
pyplot.show()

#LOAD BEST MODEL AND COMPARE FIT TO LAST EPOCH 
model_path = filepath
model_out = keras.models.load_model(model_path,custom_objects={'SeqSelfAttention':keras_self_attention.SeqSelfAttention,'recall':recall,'fmeasure':fmeasure,'precision':precision,'fbeta_score':fbeta_score})

#GET BEST MODEL ACCURACY 
_,train_acc = model.evaluate(xtr,ytr,verbose=1)
_,test_acc = model.evaluate(xte,yte,verbose=1)
print('Final Model Training Accuracy:{}'.format(train_acc))
print('Final Model Training Accuracy:{}'.format(test_acc))

#PLOT BEST MODEL TRAINING HSITORY 
pyplot.plot(model_out.history['loss'], label='train')
pyplot.plot(model_out.history['val_loss'], label='test')
pyplot.legend()
pyplot.show()

#GET CONFUSION MATRIX FOR BEST MODEL 
y_preds = model_out.predict_classes(xte)
matrix = metrics.confusion_matrix(yte, y_preds)
print('Final Model Confusion Matrix')
print(matrix)

##############################################################################################
##############################################################################################
#######################################FUNCTIONS##############################################
##############################################################################################
##############################################################################################

#FUNCTION TO CLEAN ORIGINAL TEXT FOR MODEL INPUT
def orig_text_clean(data,target='LegalAction',txtfeild='origtext',maplabelvars=['source']
                    ,stopwords=['the','is','a','i','are','it'],stemmer=None,score_new=False):
    trainDF = pd.DataFrame()
    trainDF['text'] = data[txtfeild].apply(lambda x: remove_punctuation(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_nonchars(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_stop(x,stopwords=stopwords))
    trainDF[txtfeild] = trainDF['text'].apply(lambda x: stem_words(x,stemmer=stemmer))
    
    if score_new==False:
        trainDF['label'] = data[target]
        le = preprocessing.LabelEncoder() 
        le.fit(trainDF['label'])
        trainDF['label_id'] =le.transform(trainDF['label'])
            
    trainDF=trainDF.reset_index(drop=True)
    return trainDF 

#preprocess data 
#func to remove punc from string and return string
def remove_punctuation(text,excluded_punct={'+', ':', '[', '^', '"', '|', '{', '@', '=', ')', '%', '#', '`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}):
    return ' '.join([word for word in nltk.word_tokenize(text) if word not in excluded_punct])

#func to remove stop words 
def remove_stop(text,stopwords=['the','is','a','i','are','it']):
    return ' '.join([word for word in text.split(' ') if word.lower() not in stopwords])

#func to stem words 
def stem_words(text,stemmer=None):
    return ' '.join([stemmer.stem(word) for word in text.split(' ')])

#remove non alpha characters from text 
def remove_nonchars(text):
    return ' '.join([re.sub('[^A-Za-z|^\$|^\.]+', ' ', word) for word in text.split(' ') if (word.isalnum() and len(word)>2)])


#####MODEL DATA PREPROCESSING FUNCTION 
def make_df(datapath , max_features,EMBEDDING_DIM,stop_list,stemmer,target,rebalance_data=False,test_size=.2):
    '''
    Inputs: 
    ##### datapath = path to dataframe of sentences and label ids 
    ##### max_features = total number of features from text to consider when buildling embedding layer
    ##### EMBEDDING_DIM = total number of dimensions from embedding we want to use in embedding layer (Note: if using pymag you must use 300)
    ##### stop_lsit = list of stopwords to use for preprocessing 
    ##### stemmer = stemming class to use to stem words in sentences 
    ##### target = name of the target feild you are trying to predict in the dataset 
    PROCESS STEPS: 
    ##### 1. toeknize text
    ##### 2. Convert text to sequences
    ##### 3. Pad Sequences 
    ##### 4. Split into Test and Train
    ##### 5. Return X_train , X_Test, Y, WordIndex 
    '''
    
    #load data
    if isinstance(datapath,object): 
        data = datapath 
    else:
        data = pd.read_pickle(datapath)
    
    #clean original sentence level text
    trainDF = orig_text_clean(data,target=target , txtfeild='Sentence',stopwords=stop_list,stemmer=stemmer) 
    
    #specify X and Y (these standard columns are created in orig_text_clean)
    X = trainDF['Sentence']
    Y = trainDF['label_id']
    
    #generate list of unique words based on total words specified to consider
    sentences = []
    lines = X.values.tolist()
    lines = [word_tokenize(sent) for sent in lines]
    model=gensim.models.Word2Vec(sentences=lines, size=EMBEDDING_DIM,window=5,workers=4,min_count=1)
    words = list(model.wv.vocab)
    
    #model process 
    #fit tokenizer to words and turn to sequences 
    tokenizer_obj = Tokenizer()
    tokenizer_obj.fit_on_texts(X)
    sequences = tokenizer_obj.texts_to_sequences(X)
    
    #define max length for padding and total vocab size
    max_length = max([len(s.split()) for s in X]) 
    vocab_size = len(tokenizer_obj.word_index)+1
    
    #pad sequences 
    word_index = tokenizer_obj.word_index
    review_pad = pad_sequences(sequences,maxlen=max_length)
    label = Y.values
    
    #split data 
    x_train,x_test,y_train,y_test = model_selection.train_test_split(review_pad, label,shuffle=True, stratify=Y,test_size=test_size, random_state=10)
    
    if rebalance_data == True:
        sm = SMOTE(random_state=2)
        x_train, y_train = sm.fit_sample(x_train, y_train)

    return x_train, y_train, x_test, y_test, word_index, max_length , words




#EMBEDDING GENERATION FUNCTIONS:FUNCTIONS TO GENERATE EMBEDDINGS FROM PRETRAINED EMBEDDINGS FOR EMBEDDINGS LAYER IN NN 
#glove vectors
def make_glovevec(glovepath, max_features, embed_size, word_index, veclen=300):
    embeddings_index = {}
    f = open(glovepath)
    for line in f:
        values = line.split()
        word = ' '.join(values[:-300])
        coefs = np.asarray(values[-300:], dtype='float32')
        embeddings_index[word] = coefs.reshape(-1)
    f.close()

    nb_words = min(max_features, len(word_index))
    embedding_matrix = np.zeros((nb_words, embed_size))
    for word, i in word_index.items():
        if i >= max_features:
            continue
        embedding_vector = embeddings_index.get(word)
        if embedding_vector is not None:
            embedding_matrix[i] = embedding_vector
    return embedding_matrix

#pymagnitude vectors 
def make_embeddings_pymag(wv, max_features,words, word_index, embed_size, nb_words):
    #embeddings using pymagnitude 
    embeddings_index = {}
    for w in words:
        word =w
        coefs = wv.query(word) #np.asarray(values[1:])
        embeddings_index[word]=coefs

    embedding_matrix = np.zeros((nb_words, embed_size))
    for word, i in word_index.items():
        if i >= max_features:
            continue
        embedding_vector = embeddings_index.get(word)
        if embedding_vector is not None:
            embedding_matrix[i] = embedding_vector
    return embedding_matrix


#FUNCTIONS TO PLOT OUTPUT FROM KERAS MODEL BUILD 
 #plot model training history 
plt.style.use('ggplot')
def plot_history(history,metric='acc'):
    #https://www.kaggle.com/danbrice/keras-plot-history-full-report-and-grid-search
    acc = history.history[metric]
    val_acc = history.history['val_'+metric]
    loss = history.history['loss']
    val_loss = history.history['val_'+metric]
    x = range(1, len(acc) + 1)

    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1)
    plt.plot(x, acc, 'b', label='Training acc')
    plt.plot(x, val_acc, 'r', label='Validation acc')
    plt.title('Training and validation accuracy')
    plt.legend()
    plt.subplot(1, 2, 2)
    plt.plot(x, loss, 'b', label='Training loss')
    plt.plot(x, val_loss, 'r', label='Validation loss')
    plt.title('Training and validation loss')
    plt.legend()
    
def plot_confusion_matrix(cm, classes,
                          normalize=False,
                          cmap=plt.cm.Blues):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        title='Normalized confusion matrix'
    else:
        title='Confusion matrix'

    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.show()
    
    
    
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 31 13:17:24 2019

@author: caridza
"""

def plot_scorers(gs_cv_results,hyperparm):
    results = gs_cv_results
    plt.figure(figsize=(13, 13))
    plt.title("GridSearchCV evaluating using multiple scorers simultaneously",
              fontsize=16)
    
    plt.xlabel("min_samples_split")
    plt.ylabel("Score")
    
    ax = plt.gca()
    ax.set_xlim(0, 1)
    ax.set_ylim(0.8, 1)
    
    # Get the regular numpy array from the MaskedArray
    X_axis = np.array(results[hyperparm].data, dtype=float)
    
    for scorer, color in zip(sorted(scoring), ['b', 'g', 'r', 'c', 'm', 'y', 'k']):
        print(scorer)
        for sample, style in (('train', '--'), ('test', '-')):
            sample_score_mean = results['mean_%s_%s' % (sample, scorer)]
            sample_score_std = results['std_%s_%s' % (sample, scorer)]
            ax.fill_between(X_axis, sample_score_mean - sample_score_std,
                            sample_score_mean + sample_score_std,
                            alpha=0.1 if sample == 'test' else 0, color=color)
            ax.plot(X_axis, sample_score_mean, style, color=color,
                    alpha=1 if sample == 'test' else 0.7,
                    label="%s (%s)" % (scorer, sample))
    
        best_index = np.nonzero(results['rank_test_%s' % scorer] == 1)[0][0]
        best_score = results['mean_test_%s' % scorer][best_index]
    
        # Plot a dotted vertical line at the best score for that scorer marked by x
        ax.plot([X_axis[best_index], ] * 2, [0, best_score],
                linestyle='-.', color=color, marker='x', markeredgewidth=3, ms=8)
    
        # Annotate the best score for that scorer
        ax.annotate("%0.2f" % best_score,
                    (X_axis[best_index], best_score + 0.005))
    
    plt.legend(loc="best")
    plt.grid('off')
    plt.show()
    
    list(results)
    
#CUSTOM KERAS METRICS 
def upsample_rare(data, Rare_ColStr):
    '''
    Input: {'data':'dataframe with rare event','Rare_ColStr':'name of the column containing the rare target event we want to oversample'
    Output: Dataframe of equal proportions of target event to be used only in training (MUST SPLIT TEST DATA SET BEFORE RUNNING THIS)

    '''
    negobs = data[data[Rare_ColStr]==False]
    posobs = data[data[Rare_ColStr]==True]

    #create a list of dataframes, where each data frame contains a replica of all postive observations which we can use for oversampling 
    rep_1 =[posobs for x in range(negobs.shape[0]//posobs.shape[0] )]
    keep_1s = pd.concat(rep_1, axis=0)
    train_dat = pd.concat([keep_1s,negobs],axis=0)
    return(train_dat)


def precision(y_true, y_pred):
    # Calculates the precision
    true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
    predicted_positives = K.sum(K.round(K.clip(y_pred, 0, 1)))
    precision = true_positives / (predicted_positives + K.epsilon())
    return precision


def recall(y_true, y_pred):
    # Calculates the recall
    true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
    possible_positives = K.sum(K.round(K.clip(y_true, 0, 1)))
    recall = true_positives / (possible_positives + K.epsilon())
    return recall

def fbeta_score(y_true, y_pred, beta=1):
    # Calculates the F score, the weighted harmonic mean of precision and recall.

    if beta < 0:
        raise ValueError('The lowest choosable beta is zero (only precision).')
        
    # If there are no true positives, fix the F score at 0 like sklearn.
    if K.sum(K.round(K.clip(y_true, 0, 1))) == 0:
        return 0

    p = precision(y_true, y_pred)
    r = recall(y_true, y_pred)
    bb = beta ** 2
    fbeta_score = (1 + bb) * (p * r) / (bb * p + r + K.epsilon())
    return fbeta_score

def fmeasure(y_true, y_pred):
    # Calculates the f-measure, the harmonic mean of precision and recall.
    return fbeta_score(y_true, y_pred, beta=1)
