# -*- coding: utf-8 -*-
"""
Created on Mon Jan 28 20:26:27 2019

@author: caridza
"""
###############################################################################################
#BASIC KERAS CLASSIFIER: https://www.opencodez.com/python/text-classification-using-keras.htm
###############################################################################################
import pandas as pd
import numpy as np
import pickle
from keras.preprocessing.text import Tokenizer
from keras.models import Sequential
from keras.layers import Activation, Dense, Dropout
from keras.utils import to_categorical
from keras.callbacks import ModelCheckpoint, EarlyStopping

from sklearn.preprocessing import LabelBinarizer, LabelEncoder
import sklearn.datasets as skds
from pathlib import Path
from sklearn import model_selection
from imblearn.over_sampling import SMOTE 

#data , Y, X
datapath = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/SentDF.pickle"
target = 'Disqualification' #Y
inputtxt = 'Sentence' #X


# config inputs 
num_labels = 1 #binary 
vocab_size = 10000 #total words to use from vocab
batch_size = 100 #minibatch training size 

# load the dataset
data = pd.read_pickle(datapath)
data.drop(columns=['date'])
X = data[inputtxt]
Y = data[target]
#Y  = to_categorical(Y*1,2)

#create test and train 
x_train,x_test,y_train,y_test = model_selection.train_test_split(X, Y,shuffle=True, stratify=Y,test_size=.1, random_state=10)

# define Tokenizer with Vocab Size
tokenizer = Tokenizer(num_words=vocab_size)
tokenizer.fit_on_texts(X)
 
#transform/tokenize text to tfidf format 
x_train = tokenizer.texts_to_matrix(x_train, mode='tfidf')
x_test = tokenizer.texts_to_matrix(x_test, mode='tfidf')
 
#encode the labels to numeric
encoder = LabelEncoder()
encoder.fit(y_train)
y_train = encoder.transform(y_train)
y_test = encoder.transform(y_test)


NegCounts = pd.value_counts(y_train, sort=False)[0]
PosCounts = pd.value_counts(y_train, sort=False)[1]
ClassWeight = round(NegCounts / PosCounts,0)
ClassWeights = {0:ClassWeight,1:1}

#buildl the model 
from keras import regularizers 
#0.Model Type
#1.first hidden layer with TOTAL INPUT VARIABLES = vocab_size and 500 neurons, l2 regularization  and l1 activity regularization
#2.activation function to use on first hidden layer 
#3.dropout funciton to use in first hidden layer 
#4.second hidden layer with 512 neurons 
#5.activation function to use for second hidden layer 
#6.dropout rate for neurons in second hidden layer 
#7.output laye with number of nuerons = total number of target classes 
#8.activation function to use for output layer 
#9.model summary
model = Sequential() #0
#model.add(Dense(200, input_shape=(vocab_size,)))
model.add(Dense(100, input_shape=(vocab_size,),kernel_regularizer=regularizers.l2(0.001),activity_regularizer=regularizers.l2(.001)))
model.add(Activation('relu')) #2
model.add(Dropout(0.6)) #3
#model.add(Dense(200,kernel_regularizer=regularizers.l2(.01),activity_regularizer=regularizers.l1(.01))) #4
#model.add(Dense(50,)) #4
#model.add(Activation('relu')) #5
#model.add(Dropout(0.5)) #6
model.add(Dense(num_labels)) #7
model.add(Activation('sigmoid')) #8
model.summary() #9
 

#add early stopping and model checkpoint
filepath="weights-improvement-{epoch:02d}-{val_acc:.2f}.hdf5"
ckpt = ModelCheckpoint(filepath, monitor='val_acc', verbose=1, save_best_only=False, save_weights_only=False, mode='auto')
early = EarlyStopping(monitor="val_acc", mode="min", patience=4)

#set loss function, gds ooptimizer, and metrics to track for callbacks and cross validation 
model.compile(loss='binary_crossentropy',
              optimizer='adam',
              metrics=['accuracy'])
 
#fit model
#class weights used to represent imbalanced data 
history = model.fit(x_train, y_train,
                    batch_size=batch_size,
                    epochs=10,
                    verbose=1,
                    validation_split=0.2,
                    callbacks = [ckpt,early],
                    class_weight = ClassWeights,
                    )


loss, accuracy = model.evaluate(x_train, y_train, verbose=1)
print("Training Accuracy: {:.4f}".format(accuracy))
loss, accuracy = model.evaluate(x_test, y_test, verbose=1)
print("Testing Accuracy:  {:.4f}".format(accuracy))
plot_history(history, metric='acc')
y_preds = model.predict_classes(x_test)
metrics.confusion_matrix(y_test,y_preds)

###############################################################################################
#NN KERAS CLASSIFIER WITH SKLEARN VECTORIZER AS INPUT (SKLEARN + KERAS)
###############################################################################################


###############################################################################################
#NN KERAS CLASSIFIER:https://machinelearningmastery.com/binary-classification-tutorial-with-the-keras-deep-learning-library/
##NOTE: LEVERAGES SKLEARN PIPELINES
###############################################################################################
import numpy
import pandas
from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

# fix random seed for reproducibility
seed = 7
numpy.random.seed(seed)

# load the dataset
data = pd.read_pickle(datapath)
data.drop(columns=['date'])
X = data[inputtxt]
Y = data[target]

# encode class values as integers
encoder = LabelEncoder()
encoder.fit(Y)
encoded_Y = encoder.transform(Y)


#Our model will have a single fully connected hidden layer with the same number of neurons as input variables. 
#This is a good default starting point when creating neural networks.
#The weights are initialized using a small Gaussian random number. The Rectifier activation function is used. 
#The output layer contains a single neuron in order to make predictions.
#It uses the sigmoid activation function in order to produce a probability output in the range of 0 to 1 that can easily and automatically be converted to crisp class values.
def create_baseline():
	# create model
	model = Sequential()
	model.add(Dense(60, input_dim=60, kernel_initializer='normal', activation='relu'))
	model.add(Dense(1, kernel_initializer='normal', activation='sigmoid'))
	# Compile model
	model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
	return model

#evaluate model using kfold validation 
estimator = KerasClassifier(build_fn=create_baseline, epochs=100, batch_size=5, verbose=0)
kfold = StratifiedKFold(n_splits=10, shuffle=True, random_state=seed)
results = cross_val_score(estimator, X, encoded_Y, cv=kfold)
print("Results: %.2f%% (%.2f%%)" % (results.mean()*100, results.std()*100))



#rerun model with standardization 


# evaluate baseline model with standardized dataset
numpy.random.seed(seed)
estimators = []
estimators.append(('standardize', StandardScaler()))
estimators.append(('mlp', KerasClassifier(build_fn=create_baseline, epochs=100, batch_size=5, verbose=0)))
pipeline = Pipeline(estimators)
kfold = StratifiedKFold(n_splits=10, shuffle=True, random_state=seed)
results = cross_val_score(pipeline, X, encoded_Y, cv=kfold)
print("Standardized: %.2f%% (%.2f%%)" % (results.mean()*100, results.std()*100))


#Tune layers and number of neurons in model 
#One aspect that may have an outsized effect is the structure of the network itself called the network topology. 
#In this section, we take a look at two experiments on the structure of the network: making it smaller and making it larger.

#evaluating a smaller network 
# smaller model
def create_smaller():
	# create model
	model = Sequential()
	model.add(Dense(30, input_dim=60, kernel_initializer='normal', activation='relu'))
	model.add(Dense(1, kernel_initializer='normal', activation='sigmoid'))
	# Compile model
	model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
	return model

#pipeline execution
estimators = []
estimators.append(('standardize', StandardScaler()))
estimators.append(('mlp', KerasClassifier(build_fn=create_smaller, epochs=100, batch_size=5, verbose=0)))
pipeline = Pipeline(estimators)
kfold = StratifiedKFold(n_splits=10, shuffle=True, random_state=seed)
results = cross_val_score(pipeline, X, encoded_Y, cv=kfold)
print("Smaller: %.2f%% (%.2f%%)" % (results.mean()*100, results.std()*100))

#evaluate a larger network 
#A neural network topology with more layers offers more opportunity for the network to extract key features and recombine them in useful nonlinear ways.
#The idea here is that the network is given the opportunity to model all input variables before being bottlenecked and forced to halve the representational capacity, 
#much like we did in the experiment above with the smaller network.


# larger model
def create_larger():
	# create model
	model = Sequential()
	model.add(Dense(60, input_dim=60, kernel_initializer='normal', activation='relu'))
	model.add(Dense(30, kernel_initializer='normal', activation='relu'))
	model.add(Dense(1, kernel_initializer='normal', activation='sigmoid'))
	# Compile model
	model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
	return model
estimators = []
estimators.append(('standardize', StandardScaler()))
estimators.append(('mlp', KerasClassifier(build_fn=create_larger, epochs=100, batch_size=5, verbose=0)))
pipeline = Pipeline(estimators)
kfold = StratifiedKFold(n_splits=10, shuffle=True, random_state=seed)
results = cross_val_score(pipeline, X, encoded_Y, cv=kfold)
print("Larger: %.2f%% (%.2f%%)" % (results.mean()*100, results.std()*100))

#################################################################################################################
####################################KERAS MLP IMPLEMENTATION WITH DROPOUT########################################
#################################################################################################################
#https://github.com/keras-team/keras/blob/master/docs/templates/getting-started/sequential-model-guide.md
import numpy as np
from keras.models import Sequential
from keras.layers import Dense, Dropout

# Generate dummy data
x_train = np.random.random((1000, 20))
y_train = np.random.randint(2, size=(1000, 1))
x_test = np.random.random((100, 20))
y_test = np.random.randint(2, size=(100, 1))

model = Sequential()
model.add(Dense(64, input_dim=20, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(64, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(1, activation='sigmoid'))

model.compile(loss='binary_crossentropy',
              optimizer='rmsprop',
              metrics=['accuracy'])

model.fit(x_train, y_train,
          epochs=20,
          batch_size=128)
score = model.evaluate(x_test, y_test, batch_size=128)
