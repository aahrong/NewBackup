# -*- coding: utf-8 -*-
"""
Created on Tue Nov 13 13:10:51 2018

@author: caridza
"""
#import required modules for data preprocessing , feature engineering and model training
from sklearn import model_selection, preprocessing, linear_model, naive_bayes, metrics, svm
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn import decomposition, ensemble
from sklearn.pipeline import make_pipeline
import sklearn
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn import svm
from sklearn import tree
from sklearn.pipeline import Pipeline

#sklearn pipeline function transformer 
from sklearn.preprocessing import FunctionTransformer
import pandas as pd
import xgboost, numpy, textblob, string
from keras.preprocessing import text, sequence
from keras import layers, models, optimizers
import numpy as np
import nltk
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
import re 

#####################################################################3
#########FUNCTIONS FOR CODE USED IN BELOW PYTHON FILE#################
################DOCUMENTCLASSIFICATIONTECHNIQUES.PY###################

#reading in plain text with open.read()
def read_corp(file_path):
    #determine if var exists 
    def var_exists(var):
        try:
            var
        except NameError:
            var_exists = False
        else:
            var_exists = True
        return var_exists
    

    try: 
        data = open(file_path).read()
    except UnicodeDecodeError:
        data = open(file_path,encoding='utf-8').read()
        print('read in file using utf-8 encoding')
    except Exception as e: 
        print(e)

    if var_exists(data)==False:
        data='NO DATA LOADED'
        
    return data 

#sklearn pipeline function transformer 
#from sklearn.preprocessing import FunctionTransformer
#def pipelinize(function, active=True):
#    def list_comprehend_a_function(list_or_series, active=True):
#        if active:
#            return [function(i) for i in list_or_series]
#        else: # if it's not active, just pass it right back
#            return list_or_series
#    return FunctionTransformer(list_comprehend_a_function, validate=False, kw_args={'active':active})


#pipelinize any preprocessing function into a sklearn pipeline iterable
from sklearn.preprocessing import FunctionTransformer
def list_comprehend_a_function(list_or_series,function, active=True):
    if active:
        return [function(i) for i in list_or_series]
    else: # if it's not active, just pass it right back
        return list_or_series
    
def pipelinize(function, active=True):
    return FunctionTransformer(list_comprehend_a_function, validate=False, kw_args={'active':active,'function':function})

##############################################################
#0.create utility function which can be used to train a model. 
##############################################################
#Inputs:classifier, feature_vector of training data, labels of training data and feature vectors of valid data as inputs.
# Using these inputs, the model is trained and accuracy score is computed

def train_model(classifier, feature_vector_train, label, feature_vector_valid,valid_y, is_neural_net=False):
    #inputs
    ##classifier: the classification model framework being used to build the model (ex. naive_bayes, linear_classifier,etc...)
    ##feature_vector_trian: training data independent variable data series 
    ##label: training target series (the labels we are training the feature_vectors on)
    ##feature_vector_valid: out of sample data we are using to test model stability and performance
    # fit the training dataset on the classifier
    classifier.fit(feature_vector_train, label)
    
    # predict the labels on validation dataset
    predictions = classifier.predict(feature_vector_valid)
    
    if is_neural_net:
        predictions = predictions.argmax(axis=-1)
    
    return metrics.accuracy_score(predictions, valid_y)


##########TFIDF FUNCIONS############
#building tfidf with pipelines: https://buhrmann.github.io/sklearn-pipelines.html
#evaluating tfidf: https://buhrmann.github.io/tfidf-analysis.html

#extract top n terms from tfidf fitted object 
def topn_tfidf_freq(tfidfvectorizer,tfidf_fit_transform,n=20):
    #''' 
    #Source:http://www.ultravioletanalytics.com/blog/tf-idf-basics-with-pandas-scikit-learn
    #extract top n terms from tfidf matrix using the vectorizer object an the tfidf maxtrix fit on the data(tfidf_fit_transform)
    #inputs
    #tfidfvectorizer: object f type TfidfVectorizer() fom sklearn 
    #tfidf_fit_transform: obect of type TfidfVectorizer.fit.transform()
    #output: freq table oftop n items in tfidf ad weights associated with top n terms 
    #'''
    occ = np.asarray(tfidf_fit_transform.sum(axis=0)).ravel().tolist()
    counts_df = pd.DataFrame({'term': tfidfvectorizer.get_feature_names(), 'occurrences': occ})
    freqtable=counts_df.sort_values(by='occurrences', ascending=False).head(n)
    
    weights = np.asarray(tfidf_fit_transform.mean(axis=0)).ravel().tolist()
    weights_df = pd.DataFrame({'term': tfidfvectorizer.get_feature_names(), 'weight': weights})
    weights_dfout=weights_df.sort_values(by='weight', ascending=False).head(n)

    return freqtable, weights_dfout

#function that takes a single row of the tf-idf matrix (corresponding to a particular document)
#and return the n highest scoring words (or more generally tokens or features):
def top_tfidf_feats(row, features, top_n=25):
    ''' Get top n tfidf values in row and return them with their corresponding feature names.'''
    topn_ids = np.argsort(row)[::-1][:top_n]
    top_feats = [(features[i], row[i]) for i in topn_ids]
    df = pd.DataFrame(top_feats)
    df.columns = ['feature', 'tfidf']
    return df

#in order to apply the above function to inspect a particular document, we convert a single row into dense format first:
def top_feats_in_doc(Xtr, features, row_id, top_n=25):
#''' Top tfidf features in specific document (matrix row) '''
    row = np.squeeze(Xtr[row_id].toarray())
    return top_tfidf_feats(row, features, top_n)

#calculate the average tf-idf score of all words across a number of documents (in this case all documents)
# i.e. the average per column of a tf-idf matrix
def top_mean_feats(Xtr, features, grp_ids=None, min_tfidf=0.1, top_n=25):
    ''' Return the top n features that on average are most important amongst documents in rows
        indentified by indices in grp_ids. '''
    if grp_ids:
        D = Xtr[grp_ids].toarray()
    else:
        D = Xtr.toarray()

    D[D < min_tfidf] = 0
    tfidf_means = np.mean(D, axis=0)
    return top_tfidf_feats(tfidf_means, features, top_n)

#calculate the mean tf-idf scores depending on a document’s class label
def top_feats_by_class(Xtr, y, features, min_tfidf=0.1, top_n=25):
    ''' Return a list of dfs, where each df holds top_n features and their mean tfidf value
        calculated across documents with the same class label. '''
    dfs = []
    labels = np.unique(y)
    for label in labels:
        ids = np.where(y==label)
        feats_df = top_mean_feats(Xtr, features, ids, min_tfidf=min_tfidf, top_n=top_n)
        feats_df.label = label
        dfs.append(feats_df)
    return dfs

#plot tfidf 
def plot_tfidf_classfeats_h(dfs):
    ''' Plot the data frames returned by the function plot_tfidf_classfeats(). '''
    fig = plt.figure(figsize=(12, 9), facecolor="w")
    x = np.arange(len(dfs[0]))
    for i, df in enumerate(dfs):
        ax = fig.add_subplot(1, len(dfs), i+1)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.set_frame_on(False)
        ax.get_xaxis().tick_bottom()
        ax.get_yaxis().tick_left()
        ax.set_xlabel("Mean Tf-Idf Score", labelpad=16, fontsize=14)
        ax.set_title("label = " + str(df.label), fontsize=16)
        ax.ticklabel_format(axis='x', style='sci', scilimits=(-2,2))
        ax.barh(x, df.tfidf, align='center', color='#3F5D7D')
        ax.set_yticks(x)
        ax.set_ylim([-1, x[-1]+1])
        yticks = ax.set_yticklabels(df.feature)
        plt.subplots_adjust(bottom=0.09, right=0.97, left=0.15, top=0.95, wspace=0.52)
    plt.show()
    
#VISUALIZE TFIDF MATRIX 
def tfidf_visuals(tf_idf_matrix
                  , num_clusters=10
                  , num_seeds=10
                  , max_iterations=300
                  , pca_num_components = 2
                  , tsne_num_components=2
                  , labels_color_map = {0: '#20b2aa', 1: '#ff7373', 2: '#ffe4e1', 3: '#005073', 4: '#4d0404',5: '#ccc0ba', 6: '#4700f9', 7: '#f6f900', 8: '#00f91d', 9: '#da8c49'}                                       
                                       ):
    import matplotlib.pyplot as plt
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.cluster import KMeans
    from sklearn.decomposition import PCA
    from sklearn.manifold import TSNE
    
    # calculate tf-idf of texts
    #tf_idf_vectorizer = TfidfVectorizer(analyzer="word", use_idf=True, smooth_idf=True, ngram_range=(2, 3))
    #tf_idf_matrix = tf_idf_vectorizer.fit_transform(texts_list)
    
    # create k-means model with custom config
    clustering_model = KMeans(
        n_clusters=num_clusters,
        max_iter=max_iterations,
        precompute_distances="auto",
        n_jobs=-1
    )
    
    labels = clustering_model.fit_predict(tf_idf_matrix)
    # print labels
    
    X = tf_idf_matrix.todense()
    
    # ----------------------------------------------------------------------------------------------------------------------
    
    reduced_data = PCA(n_components=pca_num_components).fit_transform(X)
    # print reduced_data
    
    fig, ax = plt.subplots()
    for index, instance in enumerate(reduced_data):
        # print instance, index, labels[index]
        pca_comp_1, pca_comp_2 = reduced_data[index]
        color = labels_color_map[labels[index]]
        ax.scatter(pca_comp_1, pca_comp_2, c=color)
    plt.show()
    
    if tsne ==True:
        # t-SNE plot
        embeddings = TSNE(n_components=tsne_num_components)
        Y = embeddings.fit_transform(X)
        plt.scatter(Y[:, 0], Y[:, 1], cmap=plt.cm.Spectral)
        plt.show()

    return 'plot complete'


    
#model architecture for shallow neural network used in DOcumentClassificationTechniques.py
from keras import layers, models, optimizers

def create_model_architecture(input_size):
    # create input layer 
    input_layer = layers.Input((input_size, ), sparse=True)
    
    # create hidden layer
    hidden_layer = layers.Dense(100, activation="relu")(input_layer)
    
    # create output layer
    output_layer = layers.Dense(1, activation="sigmoid")(hidden_layer)
    
    classifier = models.Model(inputs = input_layer, outputs = output_layer)
    classifier.compile(optimizer=optimizers.Adam(), loss='binary_crossentropy')
    return classifier 

#model architecture for CNN used in DocumentClassifcationTechniques.py
def create_cnn():
    # Add an Input Layer
    input_layer = layers.Input((70, ))

    # Add the word embedding Layer
    embedding_layer = layers.Embedding(len(word_index) + 1, 300, weights=[embedding_matrix], trainable=False)(input_layer)
    embedding_layer = layers.SpatialDropout1D(0.3)(embedding_layer)

    # Add the convolutional Layer
    conv_layer = layers.Convolution1D(100, 3, activation="relu")(embedding_layer)

    # Add the pooling Layer
    pooling_layer = layers.GlobalMaxPool1D()(conv_layer)

    # Add the output Layers
    output_layer1 = layers.Dense(50, activation="relu")(pooling_layer)
    output_layer1 = layers.Dropout(0.25)(output_layer1)
    output_layer2 = layers.Dense(1, activation="sigmoid")(output_layer1)

    # Compile the model
    model = models.Model(inputs=input_layer, outputs=output_layer2)
    model.compile(optimizer=optimizers.Adam(), loss='binary_crossentropy')
    
    return model

#model architecture for LSTM in DocutmentCLassificationTechniques.py
def create_rnn_lstm(): 
    # Add an Input Layer
    input_layer = layers.Input((70, ))

    # Add the word embedding Layer
    embedding_layer = layers.Embedding(len(word_index) + 1, 300, weights=[embedding_matrix], trainable=False)(input_layer)
    embedding_layer = layers.SpatialDropout1D(0.3)(embedding_layer)

    # Add the LSTM Layer
    lstm_layer = layers.LSTM(100)(embedding_layer)

    # Add the output Layers
    output_layer1 = layers.Dense(50, activation="relu")(lstm_layer)
    output_layer1 = layers.Dropout(0.25)(output_layer1)
    output_layer2 = layers.Dense(1, activation="sigmoid")(output_layer1)

    # Compile the model
    model = models.Model(inputs=input_layer, outputs=output_layer2)
    model.compile(optimizer=optimizers.Adam(), loss='binary_crossentropy')
    
    return model


def create_rnn_gru(): 
    # Add an Input Layer
    input_layer = layers.Input((70, ))

    # Add the word embedding Layer
    embedding_layer = layers.Embedding(len(word_index) + 1, 300, weights=[embedding_matrix], trainable=False)(input_layer)
    embedding_layer = layers.SpatialDropout1D(0.3)(embedding_layer)

    # Add the GRU Layer
    lstm_layer = layers.GRU(100)(embedding_layer)

    # Add the output Layers
    output_layer1 = layers.Dense(50, activation="relu")(lstm_layer)
    output_layer1 = layers.Dropout(0.25)(output_layer1)

    output_layer2 = layers.Dense(1, activation="sigmoid")(output_layer1)

    # Compile the model
    model = models.Model(inputs=input_layer, outputs=output_layer2)
    model.compile(optimizer=optimizers.Adam(), loss='binary_crossentropy')
    
    return model

#bi-directional RNN with GRU's
def create_bidirectional_rnn():
    # Add an Input Layer
    input_layer = layers.Input((70, ))

    # Add the word embedding Layer
    embedding_layer = layers.Embedding(len(word_index) + 1, 300, weights=[embedding_matrix], trainable=False)(input_layer)
    embedding_layer = layers.SpatialDropout1D(0.3)(embedding_layer)

    # Add the LSTM Layer
    lstm_layer = layers.Bidirectional(layers.GRU(100))(embedding_layer)

    # Add the output Layers
    output_layer1 = layers.Dense(50, activation="relu")(lstm_layer)
    output_layer1 = layers.Dropout(0.25)(output_layer1)
    output_layer2 = layers.Dense(1, activation="sigmoid")(output_layer1)

    # Compile the model
    model = models.Model(inputs=input_layer, outputs=output_layer2)
    model.compile(optimizer=optimizers.Adam(), loss='binary_crossentropy')
    
    return model  


#preprocess data 
#func to remove punc from string and return string
def remove_punctuation(text,excluded_punct={'+', ':', '[', '^', '"', '|', '{', '@', '=', ')', '%', '#', '`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}):
    return ' '.join([word for word in nltk.word_tokenize(text) if word not in excluded_punct])

#func to remove stop words 
def remove_stop(text,stopwords=['the','is','a','i','are','it']):
    return ' '.join([word for word in text.split(' ') if word.lower() not in stopwords])

#func to stem words 
def stem_words(text,stemmer=None):
    return ' '.join([stemmer.stem(word) for word in text.split(' ')])

#remove non alpha characters from text 
def remove_nonchars(text):
    return ' '.join([re.sub('[^A-Za-z|^\$|^\.]+', ' ', word) for word in text.split(' ') if (word.isalnum() and len(word)>2)])

#create df-idf df from input text and target 
def tfidf_df(X,Y,TfidfVectzr_obj=TfidfVectorizer(max_df=10, max_features=1000,min_df=1,use_idf=True,ngram_range=(1,2))):
    
    def display_scores(vectorizer, tfidf_result):
        # http://stackoverflow.com/questions/16078015/
        scores = zip(vectorizer.get_feature_names(),np.asarray(tfidf_result.sum(axis=0)).ravel())
        sorted_scores = sorted(scores, key=lambda x: x[1], reverse=True)
        for item in sorted_scores:
            print("{0:50} Score: {1}".format(item[0], item[1]))
            
    tfidf_vectorizer = TfidfVectzr_obj 
    tfidf_matrix = tfidf_vectorizer.fit_transform(X)
    terms = tfidf_vectorizer.get_feature_names()
    tfidf_df = pd.DataFrame(tfidf_matrix.toarray(),columns=terms)
    tfidf_df.reset_index()
    tfidf_df['label']=Y.values
    display_scores(tfidf_vectorizer, tfidf_df)

    return tfidf_df
#def PreProcData(X,Y):
#    '''
#    'Inputs'
#    'X: pandas series of independent variables we want to transform (here a single series of text)
#    'Y: label we are using to trian model on (here a string with label info from pandas df series)
#    '''
#    preprocess_pipeline = make_pipeline(
#            pipelinize(Txt_PreProcess)
#            , pipelinize(stem_words))
#        
#    train_x, valid_x, train_y, valid_y = model_selection.train_test_split(X, Y,shuffle=False, stratify=None,test_size=.25, random_state=10)
#    preprocess_pipeline.fit(train_x,train_y) 
#    #return preprocess_pipeline.transform(train_x.append(valid_x)),train_y.append(valid_y)
#    return preprocess_pipeline.transform(train_x),train_y,preprocess_pipeline.transform(valid_x),valid_y


#step 0: non nlp data preprocessing 
#exclude = set(string.punctuation)
#stemmer = SnowballStemmer('english')
#stopwords = stopwords.words("english")

def orig_text_clean(data,target='LegalAction',maplabelvars=['source'],stopwords=['the','is','a','i','are','it'],stemmer=None):
    trainDF = pd.DataFrame()
    trainDF['text'] = data['origtext'].apply(lambda x: remove_punctuation(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_nonchars(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_stop(x,stopwords=stopwords))
    trainDF['cleantxt'] = trainDF['text'].apply(lambda x: stem_words(x,stemmer=stemmer))
    
    
    trainDF['label'] = data[target]
    trainDF['source'] = data['source']
    trainDF['txt_lngth'] = trainDF['cleantxt'].apply(lambda x: len(x))
    trainDF['txt_words'] = trainDF['cleantxt'].apply(lambda x: len(x.split(' ')))
    trainDF['txt_nonstopwords'] = trainDF['cleantxt'].apply(lambda x: len([t for t in x.split(' ') if t not in stopwords]))
    trainDF['total_commas'] = data['origtext'].apply(lambda x: x.count(','))
    
    le = preprocessing.LabelEncoder() 
    le.fit(trainDF['label'])
    trainDF['label_id'] =le.transform(trainDF['label'])
    le.fit(trainDF['source'])
    trainDF['source_id'] =le.transform(trainDF['source'])
    
    for var in maplabelvars: 
        le.fit(trainDF[var])
        trainDF[var+'_id'] =le.transform(trainDF[var])
        
    trainDF=trainDF.reset_index(drop=True)
    return trainDF 
    


#pipe 1: preprocess input data and split into train and test 
def PreProcData(X,Y,Z=[],test_size=.1,return_pipe=False):
    '''
    'Inputs'
    'X: pandas series of independent variables we want to transform (here a single series of text)
    'Y: label we are using to trian model on (here a string with label info from pandas df series)
    'Z':descriptive column for each row to pass through 
    '''
    preprocess_pipeline = make_pipeline(
            pipelinize(remove_punctuation) #remove punctuatoin
            , pipelinize(remove_nonchars)
            , pipelinize(remove_stop) #remove stopwords
            , pipelinize(stem_words)) #stem words     
    
    if return_pipe==True:
        return preprocess_pipeline
    else:
        if test_size>0:
            train_x, valid_x, train_y, valid_y = model_selection.train_test_split(X, Y,shuffle=True, stratify=Y,test_size=test_size, random_state=10)
            preprocess_pipeline.fit(train_x,train_y)     
            return preprocess_pipeline.transform(train_x),train_y,preprocess_pipeline.transform(valid_x),valid_y   
        if test_size ==0:
            preprocess_pipeline.fit(X,Y)     
            return preprocess_pipeline.transform(X),Y


#pipe2: logistic regression (pass preprocessed data to pipeline to transform input into tfidf and generate logistic classificaiton model) 
def Logistic_TFIDF_Classifer(train_x,train_y,valid_x,valid_y):
    '''
    'Inputs'
    'X: pandas series of independent variables we want to transform (here a single series of text)
    'Y: label we are using to trian model on (here a string with label info from pandas df series)
    '''
    model_pipeline = make_pipeline(
             TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,)
            , linear_model.LogisticRegression())
    
    return model_pipeline.fit(train_x,train_y) 
    #return model_pipeline.score(valid_x,valid_y)

#pipe3: KNN classifier (pass preprocessed data to pipeline to transform input into tfidf and generate knn classificaiton model)  
def KNN_TFIDF_Classifer(train_x,train_y,valid_x,valid_y):
    '''
    'Inputs'
    'X: pandas series of independent variables we want to transform (here a single series of text)
    'Y: label we are using to trian model on (here a string with label info from pandas df series)
    '''
    model_pipeline = make_pipeline(
             TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,)
            , KNeighborsClassifier(n_neighbors=6, metric='euclidean'))
    
    return model_pipeline.fit(train_x,train_y) 

#pipe4: DT Classifier 
def DT_TFIDF_Classifer(train_x,train_y,valid_x,valid_y):
    '''
    'Inputs'
    'X: pandas series of independent variables we want to transform (here a single series of text)
    'Y: label we are using to trian model on (here a string with label info from pandas df series)
    '''
    model_pipeline = make_pipeline(
             TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,)
            , tree.DecisionTreeClassifier(random_state=42))
    
    return model_pipeline.fit(train_x,train_y) 

#pipe4: DT Classifier 
def RF_TFIDF_Classifer(train_x,train_y,valid_x,valid_y,**kwargs):
    '''
    'Inputs'
    'X: pandas series of independent variables we want to transform (here a single series of text)
    'Y: label we are using to trian model on (here a string with label info from pandas df series)
    '''
    model_pipeline = make_pipeline(
             TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,)
            , RandomForestClassifier(n_estimators=num_trees, criterion='gini',max_depth=20,min_samples_split=20,min_samples_leaf=5,max_features=max_features))
    
    return model_pipeline.fit(train_x,train_y) 



#pipe4: Generic pipeline  
def generic_pipeline(train_x,train_y,valid_x,valid_y ,transform_cls , model_cls,transform_args,model_args):
    '''
    'Inputs'
    'X: pandas series of independent variables we want to transform (here a single series of text)
    'Y: label we are using to trian model on (here a string with label info from pandas df series)
    '''
    model_pipeline = make_pipeline(
             transform_cls(**transform_args) 
            , model_cls(**model_args))
    
    return model_pipeline.fit(train_x,train_y) 



#evaluation of model performance 
def model_eval(pipeline, train_x,train_y,valid_x,valid_y):
    #fit pipeline, score validation data, and predict on new data
    pipeline.fit(train_x,train_y) #fit data to pipeline
    pipeline.score(valid_x,valid_y) #evaluate model performance on validation data
    predictions=pipeline.predict(valid_x) #score model on new data (where no target value is available)
    prob_preds = pipeline.predict_proba(valid_x)
    
    #vaildation / performance metrics
    return{'logloss':metrics.log_loss(valid_y, prob_preds)
    ,'accuracy_score':metrics.accuracy_score(valid_y,predictions)
    ,'roc_auc':metrics.roc_auc_score(valid_y,predictions,average='macro')
    ,'recall':metrics.recall_score(valid_y,predictions)
    ,'perfsummary':metrics.classification_report(valid_y,predictions).split('\n')
    ,'confusionmatrix':metrics.confusion_matrix(valid_y,predictions)}
    
       
    
from statistics import mean
import numpy as np

def sk_model_stats(pipe_dict,x,y,data_type='train'):
    cm_stats = []
    x = x
    y = y
    for key,value in pipe_dict.items():
        preds = value.predict(x)
        prob_preds = value.predict_proba(x)
        print('Model Validation Charts {}:'.format(key))
        plotmetrics(y,prob_preds,preds)

        cm = metrics.confusion_matrix(y,preds).flatten()
        df=pd.DataFrame(data={'model':key
                              ,'data':data_type
                              ,'logloss':metrics.log_loss(y, prob_preds)
                              ,'accuracy_score':metrics.accuracy_score(y,preds)
                              ,'roc_auc':metrics.roc_auc_score(y,preds,average='macro')
                              ,'recall':metrics.recall_score(y,preds)
                              ,'precision':metrics.precision_score(y,preds)
                              #,'precision_f1_bal':mean(metrics.precision_recall_fscore_support(y,preds,average='macro'))
                              #,'coverage_error':metrics.coverage_error(y,preds)
                              ,'f1_score':metrics.f1_score(y,preds)
                              ,'fbeta_score': metrics.fbeta_score(y,preds,beta=.75)
                              ,'mae': metrics.mean_absolute_error(y,preds)
                              ,'mse': metrics.mean_squared_error(y,preds)
                              ,'median_absolute_error': metrics.median_absolute_error(y,preds)
                              ,'TrueNeg':[cm[0]]
                              ,'FalseNeg':[cm[1]]
                              ,'FalsePos':[cm[2]]
                              ,'TruePos':[cm[3]]
                              })
        cm_stats.append(df)
    appended_data = pd.concat(cm_stats, axis=0)
    
    out = appended_data.sort_values(by=['f1_score'],ascending=False) 
    return out

    
    
    
    


#grid search wrapper
from sklearn.model_selection import StratifiedKFold
def grid_search_wrapper(X_train,y_train,X_test,y_test,clf,param_grid,scorers,refit_score='precision_score'):
    """
    fits a GridSearchCV classifier using refit_score for optimization
    prints classifier performance metrics
    """
    skf = StratifiedKFold(n_splits=10)
    grid_search = GridSearchCV(clf, param_grid, scoring=scorers, refit=refit_score,
                           cv=skf, return_train_score=True, n_jobs=-1)
    grid_search.fit(X_train, y_train)

    # make the predictions
    y_pred = grid_search.predict(X_test)

    print('Best params for {}'.format(refit_score))
    print(grid_search.best_params_)

    # confusion matrix on the test data.
    print('\nConfusion matrix of Random Forest optimized for {} on the test data:'.format(refit_score))
    print(pd.DataFrame(confusion_matrix(y_test, y_pred),
                 columns=['pred_neg', 'pred_pos'], index=['neg', 'pos']))
    return grid_search


#transformer to select a column from dataframe to be used for processing 
from sklearn.base import BaseEstimator, TransformerMixin
class TextSelector(BaseEstimator, TransformerMixin):
    """
    Transformer to select a single column from the data frame to perform additional transformations on
    Use on text columns in the data
    """
    def __init__(self, key):
        self.key = key

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return X[self.key]
    
    def get_feature_names(self):
        return self.key
    
class NumberSelector(BaseEstimator, TransformerMixin):
    """
    Transformer to select a single column from the data frame to perform additional transformations on
    Use on numeric columns in the data
    """
    def __init__(self, key):
        self.key = key

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return X[[self.key]]
    
    def get_feature_names(self):
        return self.key
#convert sparse to dense matrix 
class DenseTransformer(TransformerMixin):
    
    def fit(self, X, y=None, **fit_params):
        return self
    
    def transform(self, X, y=None, **fit_params):
        return X.todense()

def plotmetrics(valid_y,pred_probs,preds):
    return[
     skplt.metrics.plot_roc(valid_y, pred_probs)#;plt.show()
    ,skplt.metrics.plot_ks_statistic(valid_y, pred_probs)#;plt.show()
    ,skplt.metrics.plot_precision_recall(valid_y, pred_probs)#;plt.show()
    ,skplt.metrics.plot_cumulative_gain(valid_y, pred_probs)#;plt.show()
    ,skplt.metrics.plot_lift_curve(valid_y, pred_probs)#;plt.show()
    ,skplt.metrics.plot_confusion_matrix(valid_y, preds, normalize=True)#;plt.show()
    #feature_importances=pipe_rf.named_steps['clf'].feature_importances_
    #skplt.estimators.plot_learning_curve(pipe_rf, train_x, train_y);plt.show()
    ]
    
    
# Utility function to report best scores
def report(results, n_top=3):
    for i in range(1, n_top + 1):
        candidates = np.flatnonzero(results['rank_test_score'] == i)
        for candidate in candidates:
            print("Model with rank: {0}".format(i))
            print("Mean validation score: {0:.3f} (std: {1:.3f})".format(
                  results['mean_test_score'][candidate],
                  results['std_test_score'][candidate]))
            print("Parameters: {0}".format(results['params'][candidate]))
            print("")





def load_and_score(model_path,data2score):
    import joblib
    
    #Final Prediction on entire dataset
    #load model 
    loaded_model = joblib.load(model_path)
    
    #len(newdata.loc[newdata.index.duplicated(keep='first')])
    newdata = orig_text_clean(data)
    
    #preds on new data 
    predictions = loaded_model.predict_proba(newdata)
    preds = pd.DataFrame(data=predictions, columns = loaded_model.classes_)
    
    #generating a submission file
    results = pd.concat([newdata, preds], axis=1)
    return results






def plot_grid_search(cv_results, grid_param_1, grid_param_2, name_param_1, name_param_2):
    #https://stackoverflow.com/questions/37161563/how-to-graph-grid-scores-from-gridsearchcv
    # Get Test Scores Mean and std for each grid search
    scores_mean = cv_results['mean_test_score']
    scores_mean = np.array(scores_mean).reshape(len(grid_param_2),len(grid_param_1))

    scores_sd = cv_results['std_test_score']
    scores_sd = np.array(scores_sd).reshape(len(grid_param_2),len(grid_param_1))

    # Plot Grid search scores
    _, ax = plt.subplots(1,1)

    # Param1 is the X-axis, Param 2 is represented as a different curve (color line)
    for idx, val in enumerate(grid_param_2):
        ax.plot(grid_param_1, scores_mean[idx,:], '-o', label= name_param_2 + ': ' + str(val))

    ax.set_title("Grid Search Scores", fontsize=20, fontweight='bold')
    ax.set_xlabel(name_param_1, fontsize=16)
    ax.set_ylabel('CV Average Score', fontsize=16)
    ax.legend(loc="best", fontsize=15)
    ax.grid('on')


#clean text helper functions 
def clean_text( text):
    text = text.replace('\n', ' ').replace('\t', ' ').replace('\r', ' ')
    text = re.sub(r' +', ' ', text)
    text = text.strip()
    return text

#clean text helper functions 
def chkPeriod(SentTokList):
    p = re.compile(r'[A-Za-z]+[A-Za-z]+[.]+[A-Za-z]+[A-Za-z]{2,}')
    output= []
    for val in SentTokList: 
        if p.search(val):
            newstr = ' '.join([re.sub('[.]+', ' ', y) for y in val.split()])
        else: 
            newstr = val
        output.append(newstr)        
    return output 

#clean text 
def Txt_PreProcess(x):
    step0 = clean_text(x)
    step11 = sent_tokenize(step0)
    step1 = chkPeriod(step11)
    step2 = [x for x in step1 if max(len(w) for w in x.split())<25] #only consider sentences with words < 15 characters 
    step3 = [y for y in step2 if len(y)>29 and len(y)<550] #only consider sentences within a specific character length 
    step4 = [re.sub('[^A-Za-z|^\$|^\.]+', ' ', y) for y in step3] #remove all special characters except periods and $s 
    step5 = [y.strip() for y in step4 if y] #strip leading and trailing white space and only return if y exists(is not none)
    step6 = [y for y in step5 if not y =='']
    step7 = [re.sub("\.{2,}" , ".",y) for y in step6] #replace multiple periods with a single period 
    step8 = [re.sub(' +',' ',y) for y in step7]
    step9 = ' '.join(step8)
    if len(step9)<10: 
        step9 = 'There is no relevant information in this text'
    return step9


