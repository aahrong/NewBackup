
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 12 11:53:30 2018

@author: caridza
"""
#####################
#Dataset Preperation#
##################### 
#https://www.kaggle.com/baghern/a-deep-dive-into-sklearn-pipelines
#https://scikit-learn.org/stable/auto_examples/model_selection/grid_search_text_feature_extraction.html
# load the dataset
import os
datapath="C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/"
text=[]
labels=[]
filenames = []
for subdir,dirs, files in os.walk(datapath):
    for file in files:
        print(file)
        if file.endswith('.txt'):
             with open(os.path.join(subdir, file), 'r', encoding='utf8') as text_file:
                text_data = text_file.read().replace('\n', '')
                text.append(text_data)
        
                labels.append(' '.join(['Invoice' if 'inv' in file.lower() 
                else 'check' if 'check' in file.lower() 
                else 'qbe' if 'qbe' in file.lower() 
                else 'evidenceOfSale' if 'evidence_of_sale' in file.lower() 
                else 'tax' if 'tax' in file.lower() 
                else 'parkvac' if 'park_vac' in file.lower() 
                else 'aop' if 'AoP' in file.lower() 
                else 'other']))
                filenames.append(file.split('.', 1)[0])
                
#create a dataframe using texts and lables
trainDF = pandas.DataFrame()
trainDF['text'] = ["".join(x) for x in text] #each row is a string  #trainDF['text'] = texts # each row is a list of word tokenized sentences 
trainDF['filename'] = filenames
trainDF['label'] = labels
trainDF['label'] =trainDF['label'].astype('category') #assign label as a categorical vairable 
trainDF['label_cat']= trainDF['label'].cat.codes.astype(int)#convert categorical labels to numeric encoding
trainDF['textlen']= len(trainDF['text'])

#stash all text from all documents of the same type into a unique dic key (will generate tfidf based on this)
data_dic=dict()
for i,val in enumerate(trainDF.label.unique()):
    data = trainDF[trainDF['label']==val]
    #data_dic.update({i:' '.join([x for x in list(data['text'])])})
    data_dic.update({i:' '.join([ab for ab in PreProcData(data['text'],data['label_cat'],data['filename'])[1]]).lower()})

#top words per group
from collections import Counter
split_it = [list(data_dic.values())[i].split() for i in range(len(trainDF.label.unique()))]
counter = [Counter(x) for x in split_it]
most_occur = [list(str(i))+list(counter[i].most_common(10)) for i in range(len(counter))] 

#text preprocessing 
#X: stemmed tokens
#Y: no stemmed
X,x,Y,Z= PreProcData(trainDF['text'],trainDF['label_cat'],trainDF['filename'])

#create vocab look up dataframe 
XX = nltk.word_tokenize(' '.join([doc for doc in X]))
xx = nltk.word_tokenize(' '.join([doc for doc in x]))
vocab_frame = pd.DataFrame({'words': xx}, index = XX)
print('there are ' + str(vocab_frame.shape[0]) + ' items in vocab_frame')
#stemmed vocab used as index and tokenized wordes as the row values , enables easy lookup of original sentence from stemmed output

#define vectorizer parameters
tfidf_vectorizer = TfidfVectorizer(max_df=0.8, max_features=200000,min_df=0.01,use_idf=True,ngram_range=(1,2))
tfidf_matrix = tfidf_vectorizer.fit_transform(X)
print(tfidf_matrix.shape)
#tf-idf vocabulary (list of features used in the tf-idf matrix )
terms = tfidf_vectorizer.get_feature_names()
tfidf_df = pd.DataFrame(tfidf_matrix.toarray(),columns=terms)

#Cosine similarity is measured against the tf-idf matrix and can be used to generate a measure of similarity between each 
#document and the other documents in the corpus (each doc among the docs). Subtracting it from 1 provides cosine distance 
#which I will use for plotting on a euclidean (2-dimensional) plane.
from sklearn.metrics.pairwise import cosine_similarity
dist = 1 - cosine_similarity(tfidf_matrix)

#K-means initializes with a pre-determined number of clusters (I chose 6, one cluster for each doc type). 
#Each observation is assigned to a cluster (cluster assignment) so as to minimize the within cluster sum of squares.
#Next, the mean of the clustered observations is calculated and used as the new cluster centroid. Then, observations 
#are reassigned to clusters and centroids recalculated in an iterative process until the algorithm reaches convergence.
num_clusters = 6
km = KMeans(n_clusters=num_clusters)
km.fit(tfidf_matrix)
clusters = km.labels_.tolist()

doc_data = {  'filename':list(Z),'text': X, 'cluster': clusters,'label': list(Y),'textlen':[len(x) for x in X]}
frame = pd.DataFrame(doc_data, index = [clusters] , columns = ['filename','text', 'cluster','label','textlen'])
frame['cluster'].value_counts()
grouped = frame['label'].groupby(frame['cluster'])
grouped.mean()


#index and sort on each cluster to identify which are the top n words that are nearst to the cluster centroid
print("Top terms per cluster:")
print()
#sort cluster centers by proximity to centroid
order_centroids = km.cluster_centers_.argsort()[:, ::-1] 
centroid_vocabs = []
for i in range(num_clusters):
    print("Cluster %d words:" % i, end='')
    
    centroid_vocab = []
    for ind in order_centroids[i, :3]: #replace 6 with n words per cluster
        centroid_vocab.append(vocab_frame.ix[terms[ind].split(' ')].values.tolist()[0][0])
        print(' %s' % vocab_frame.ix[terms[ind].split(' ')].values.tolist()[0][0].encode('utf-8', 'ignore'), end=',')
    centroid_vocabs.append(','.join([x for x in centroid_vocab]))
    print() #add whitespace
    print() #add whitespace
    
    print("Cluster %d titles:" % i, end='')
    for title in frame.ix[i]['filename'].values.tolist():
        print(' %s,' % title, end='')
    print() #add whitespace
    print() #add whitespace
    
print()
print()


#convert the distance matrix into a 2D array using MDS
from faker import Factory 
fake = Factory.create()
MDS()

# convert two components as we're plotting points in a two-dimensional plane
# "precomputed" because we provide a distance matrix
# we will also specify `random_state` so the plot is reproducible.
#mds = MDS(n_components=3, dissimilarity="precomputed", random_state=1)
mds = MDS(n_components=2, dissimilarity="precomputed", random_state=1)
pos = mds.fit_transform(dist)  # shape (n_components, n_samples)
xs, ys = pos[:, 0], pos[:, 1]

#set up cluster names using a dict of top 3(or whatever u define above) words per cluster
cluster_names = {n:centroid_vocabs[n] for n in range(len(centroid_vocabs))}

#set up cluster colors in dictonary using random colors
cluster_colors = {n:fake.hex_color() for n in range(len(centroid_vocabs))}

#some ipython magic to show the matplotlib plots inline
#%matplotlib inline 

#create data frame that has the result of the MDS plus the cluster numbers and titles
df = pd.DataFrame(dict(x=xs, y=ys, label=clusters, title=list(frame['filename']))) 

#group by cluster
groups = df.groupby('label')


# set up plot
fig, ax = plt.subplots(figsize=(17, 9)) # set size
ax.margins(0.05) # Optional, just adds 5% padding to the autoscaling

#iterate through groups to layer the plot
#note that I use the cluster_name and cluster_color dicts with the 'name' lookup to return the appropriate color/label
for name, group in groups:
    ax.plot(group.x, group.y, marker='o', linestyle='', ms=12, 
            label=cluster_names[name], color=cluster_colors[name], 
            mec='none')
    ax.set_aspect('auto')
    ax.tick_params(\
        axis= 'x',          # changes apply to the x-axis
        which='both',      # both major and minor ticks are affected
        bottom='off',      # ticks along the bottom edge are off
        top='off',         # ticks along the top edge are off
        labelbottom='off')
    ax.tick_params(\
        axis= 'y',         # changes apply to the y-axis
        which='both',      # both major and minor ticks are affected
        left='off',      # ticks along the bottom edge are off
        top='off',         # ticks along the top edge are off
        labelleft='off')
    
ax.legend(numpoints=1)  #show legend with only 1 point

#add label in x,y position with the label as the film title
for i in range(len(df)):
    ax.text(df.ix[i]['x'], df.ix[i]['y'], df.ix[i]['title'], size=8)  
plt.show() #show the plot

#dendrogram 
from scipy.cluster.hierarchy import ward, dendrogram
linkage_matrix = ward(dist) #define the linkage_matrix using ward clustering pre-computed distances

fig, ax = plt.subplots(figsize=(15, 20)) # set size
ax = dendrogram(linkage_matrix, orientation="right", labels=list(Z));

plt.tick_params(\
    axis= 'x',          # changes apply to the x-axis
    which='both',      # both major and minor ticks are affected
    bottom='off',      # ticks along the bottom edge are off
    top='off',         # ticks along the top edge are off
    labelbottom='off')

plt.tight_layout() #show plot with tight layout

#uncomment below to save figure
plt.savefig('ward_clusters.png', dpi=200) #save figure as ward_clusters


#plot of first 3 dimensions in mds
#from mpl_toolkits import mplot3d
#%matplotlib inline
#import numpy as np
#import matplotlib.pyplot as plt
#ax = plt.axes(projection='3d')
#ax.scatter(xs, ys, zs, c=zs, cmap='viridis', linewidth=0.905);











#TSNE
#http://www.scikit-yb.org/en/latest/api/text/tsne.html
from sklearn.manifold import TSNE
from yellowbrick.text import TSNEVisualizer
from sklearn.feature_extraction.text import TfidfVectorizer
X_embedded = TSNE(n_components=2).fit_transform(pos)
X_embedded.shape
tsne = TSNEVisualizer(labels=["documents"])
tsne.fit(tfidf_matrix)
tsne.poof()








#logistic pipeline with preprocessing
Logistic_TFIDF_Classifer(train_x,train_y,valid_x,valid_y)
def Logistic_TFIDF_Classifer(train_x,train_y,valid_x,valid_y):
    '''
    'Inputs'
    'X: pandas series of independent variables we want to transform (here a single series of text)
    'Y: label we are using to trian model on (here a string with label info from pandas df series)
    '''
    model_pipeline = make_pipeline(
             TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,)
            , linear_model.LogisticRegression())
    
    model_pipeline.fit(train_x,train_y) 
    return model_pipeline.score(valid_x,valid_y)




#APPROACH 2: pipelines in aggregate 
####USING A TON OF MODELS FOR CHAMPION / CHALLANGER

import sklearn
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn import svm
from sklearn import tree
from sklearn.pipeline import Pipeline


#test and training data that has been preprocessed
train_x,train_y,valid_x,valid_y= PreProcData(trainDF['text'],trainDF['label'])


# Construct svm pipeline
pipe_log =  Pipeline([ ('tfidf_vectorizer', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,)),('logistic',linear_model.LogisticRegression())])

# Construct knn pipeline
pipe_knn = Pipeline([('tfidf_vec', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,))
 ,('knn', KNeighborsClassifier(n_neighbors=6, metric='euclidean'))])

# Construct DT pipeline
pipe_dt = Pipeline([('tfidf_vec',  TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,))
,('dt', tree.DecisionTreeClassifier(random_state=42))])

# Construct Random Forest pipeline
num_trees = 1000
max_features = 10
pipe_rf = Pipeline([('tfidf_vec', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=400, smooth_idf=True, sublinear_tf=False,lowercase=True,))
,('svm', sklearn.decomposition.TruncatedSVD(n_components=10,random_state=42))
,('rf', RandomForestClassifier(n_estimators=num_trees, criterion='gini',max_depth=20,min_samples_split=20,min_samples_leaf=5,max_features=max_features))])


#create dictonary to store the name of pipelines in dictonary to be used to display results 
pipe_dic = {0: 'K Nearest Neighbours', 1: 'Decision Tree', 2:'Random Forest', 3:'Logistic Regression'}
#list the four pipelines to execute those pipelines iterativelly
pipelines = [pipe_knn, pipe_dt,pipe_rf,pipe_log]

# Fit the pipelines
for pipe in pipelines:
  pipe.fit(train_x, train_y)

# Compare accuracies
for idx, val in enumerate(pipelines):
  print('%s pipeline test accuracy: %.3f' % (pipe_dic[idx], val.score(valid_x, valid_y)))
  
#extract and print infomration on the best model 
best_accuracy = 0
best_classifier = 0
best_pipeline = ''
for idx, val in enumerate(pipelines):
    if val.score(train_x, train_y) > best_accuracy:
        best_accuracy = val.score(valid_x, valid_y)
        best_pipeline = val
        best_classifier = idx
print('%s Classifier has the best accuracy of %.2f' % (pipe_dic[best_classifier],best_accuracy))





#approach 3: single model pippeline e2e
#logistic pipeline with preprocessing
#Logistic_TFIDF_Classifer(trainDF['text'],trainDF['label'])
def Logistic_TFIDF_Classifer(X,Y):
    '''
    'Inputs'
    'X: pandas series of independent variables we want to transform (here a single series of text)
    'Y: label we are using to trian model on (here a string with label info from pandas df series)
    '''
    model_pipeline = make_pipeline(
            pipelinize(remove_punctuation) #remove punctuatoin
            , pipelinize(remove_stop) #remove stopwords
            , pipelinize(stem_words)
            , TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,)
            , linear_model.LogisticRegression()
            ) #stem words 
    
    train_x, valid_x, train_y, valid_y = model_selection.train_test_split(X, Y,shuffle=False, stratify=None,test_size=.25, random_state=10)
    model_pipeline.fit(train_x,train_y) 
    return model_pipeline.score(valid_x,valid_y)

