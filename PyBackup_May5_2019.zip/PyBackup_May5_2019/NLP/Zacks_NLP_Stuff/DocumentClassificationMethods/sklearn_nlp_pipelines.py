# -*- coding: utf-8 -*-
"""
Created on Wed Dec 19 09:11:04 2018

@author: caridza
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Dec 18 12:57:28 2018

@author: caridza
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Nov 12 11:53:30 2018

@author: caridza
"""
#VirtualEnv: docclassify
#VirtualEnv Location: C:\Users\caridza\Downloads\WPy32-3662\ZacksScripts\docclassify

#######################
#######IMPORTS#########
#######################
#install tensorflow: pip3 install --upgrade https://storage.googleapis.com/tensorflow/mac/cpu/tensorflow-1.12.0-py3-none-any.whl
#base modules 
import sys
from itertools import islice #iterating over vectorized objects (countvectorizer, tfidfvectorizer,etc..)
import numpy as np
import pandas as pd

#third party modules
#import required modules for data preprocessing , feature engineering and model training
from sklearn import model_selection, preprocessing, linear_model, naive_bayes, metrics, svm
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn import decomposition, ensemble
from sklearn.pipeline import Pipeline
from sklearn.pipeline import make_pipeline

import pandas, xgboost, numpy, textblob, string
from keras.preprocessing import text, sequence
from keras import layers, models, optimizers

import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
import matplotlib.pyplot as plt
import matplotlib
import seaborn as sns
   
#custom modules 
#sys.path.insert(0,"C:/Users/caridza/Desktop/pythonScripts/")
sys.path.insert(0,"C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/")
from DocClassFuncs.ClassificationFuncs  import read_corp ,topn_tfidf_freq, create_model_architecture ,create_cnn,create_rnn_lstm, create_rnn_gru,create_bidirectional_rnn,train_model, pipelinize, remove_punctuation, remove_stop, stem_words

#punctuation to remove, stopwords to remove, stemming and lemmatizing objects for preprocessing
stemmer = SnowballStemmer('english')
wordnet_lemmatizer = WordNetLemmatizer()
exclude = set(string.punctuation)
stopwords = stopwords.words("english")


def pipelinize(function, active=True):
    def list_comprehend_a_function(list_or_series, active=True):
        if active:
            return [function(i) for i in list_or_series]
        else: # if  it's not active, just pass it right back
            return list_or_series
    return FunctionTransformer(list_comprehend_a_function, validate=False, kw_args={'active':active})

#func to remove punc from string and return string
def remove_punctuation(text,excluded_punct=exclude):
    return ' '.join([word for word in nltk.word_tokenize(text) if word not in excluded_punct])

def remove_stop(text,stopwords=stopwords):
    return ' '.join([word for word in text.split(' ') if word not in stopwords])

def stem_words(text,stemmer = stemmer ):
    return ' '.join([stemmer.stem(word) for word in text.split(' ')])


#####################
#Dataset Preperation#
##################### 
#https://www.kaggle.com/baghern/a-deep-dive-into-sklearn-pipelines
#https://scikit-learn.org/stable/auto_examples/model_selection/grid_search_text_feature_extraction.html
# load the dataset
datapath="C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/corpus"
data =read_corp(datapath)

#define 2 lists: labels=target_series, texts=text to train target with
labels, texts = [], []

#file delimited with new line character
#target is alwasy the first word in each new string
for i, line in enumerate(data.split("\n")):
    #split each entry into a list delimited by a space (Word tokenized)
    content = line.split()
    #target value is the first element in each string (delimited by space)
    labels.append(content[0])
    #text is contained in all remaining elments of the list after the label
    texts.append(content[1:])

#create a dataframe using texts and lables
trainDF = pandas.DataFrame()
trainDF['text'] = [" ".join(x) for x in texts] #each row is a string  #trainDF['text'] = texts # each row is a list of word tokenized sentences 
trainDF['label'] = labels

#APPROACH 1: pipelines by stage (preprocess -> Model)
#using make_pipeline you do not have to specify the name of each process
#Note: we fit the pipeline with x and y , but can only transform the indpendent series, pipelines cannoto handle dependent variables transoformations
#Output: Transformed x and y series split into training and test data
train_x,train_y,valid_x,valid_y= PreProcData(trainDF['text'],trainDF['label'])
def PreProcData(X,Y):
    '''
    'Inputs'
    'X: pandas series of independent variables we want to transform (here a single series of text)
    'Y: label we are using to trian model on (here a string with label info from pandas df series)
    '''
    preprocess_pipeline = make_pipeline(
            pipelinize(remove_punctuation) #remove punctuatoin
            , pipelinize(remove_stop) #remove stopwords
            , pipelinize(stem_words)) #stem words 
    
    train_x, valid_x, train_y, valid_y = model_selection.train_test_split(X, Y,shuffle=False, stratify=None,test_size=.25, random_state=10)
    preprocess_pipeline.fit(train_x,train_y) 
    #return preprocess_pipeline.transform(train_x.append(valid_x)),train_y.append(valid_y)
    return preprocess_pipeline.transform(train_x),train_y,preprocess_pipeline.transform(valid_x),valid_y


#logistic pipeline with preprocessing
Logistic_TFIDF_Classifer(train_x,train_y,valid_x,valid_y)
def Logistic_TFIDF_Classifer(train_x,train_y,valid_x,valid_y):
    '''
    'Inputs'
    'X: pandas series of independent variables we want to transform (here a single series of text)
    'Y: label we are using to trian model on (here a string with label info from pandas df series)
    '''
    model_pipeline = make_pipeline(
             TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,)
            , linear_model.LogisticRegression())
    
    model_pipeline.fit(train_x,train_y) 
    return model_pipeline.score(valid_x,valid_y)




#APPROACH 2: pipelines in aggregate 
####USING A TON OF MODELS FOR CHAMPION / CHALLANGER

import sklearn
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn import svm
from sklearn import tree
from sklearn.pipeline import Pipeline


#test and training data that has been preprocessed
train_x,train_y,valid_x,valid_y= PreProcData(trainDF['text'],trainDF['label'])


# Construct svm pipeline
pipe_log =  Pipeline([ ('tfidf_vectorizer', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,)),('logistic',linear_model.LogisticRegression())])

# Construct knn pipeline
pipe_knn = Pipeline([('tfidf_vec', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,))
 ,('knn', KNeighborsClassifier(n_neighbors=6, metric='euclidean'))])

# Construct DT pipeline
pipe_dt = Pipeline([('tfidf_vec',  TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,))
,('dt', tree.DecisionTreeClassifier(random_state=42))])

# Construct Random Forest pipeline
num_trees = 1000
max_features = 10
pipe_rf = Pipeline([('tfidf_vec', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=400, smooth_idf=True, sublinear_tf=False,lowercase=True,))
,('svm', sklearn.decomposition.TruncatedSVD(n_components=10,random_state=42))
,('rf', RandomForestClassifier(n_estimators=num_trees, criterion='gini',max_depth=20,min_samples_split=20,min_samples_leaf=5,max_features=max_features))])


#create dictonary to store the name of pipelines in dictonary to be used to display results 
pipe_dic = {0: 'K Nearest Neighbours', 1: 'Decision Tree', 2:'Random Forest', 3:'Logistic Regression'}
#list the four pipelines to execute those pipelines iterativelly
pipelines = [pipe_knn, pipe_dt,pipe_rf,pipe_log]

# Fit the pipelines
for pipe in pipelines:
  pipe.fit(train_x, train_y)

# Compare accuracies
for idx, val in enumerate(pipelines):
  print('%s pipeline test accuracy: %.3f' % (pipe_dic[idx], val.score(valid_x, valid_y)))
  
#extract and print infomration on the best model 
best_accuracy = 0
best_classifier = 0
best_pipeline = ''
for idx, val in enumerate(pipelines):
    if val.score(train_x, train_y) > best_accuracy:
        best_accuracy = val.score(valid_x, valid_y)
        best_pipeline = val
        best_classifier = idx
print('%s Classifier has the best accuracy of %.2f' % (pipe_dic[best_classifier],best_accuracy))





#approach 3: single model pippeline e2e
#logistic pipeline with preprocessing
#Logistic_TFIDF_Classifer(trainDF['text'],trainDF['label'])
def Logistic_TFIDF_Classifer(X,Y):
    '''
    'Inputs'
    'X: pandas series of independent variables we want to transform (here a single series of text)
    'Y: label we are using to trian model on (here a string with label info from pandas df series)
    '''
    model_pipeline = make_pipeline(
            pipelinize(remove_punctuation) #remove punctuatoin
            , pipelinize(remove_stop) #remove stopwords
            , pipelinize(stem_words)
            , TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,)
            , linear_model.LogisticRegression()
            ) #stem words 
    
    train_x, valid_x, train_y, valid_y = model_selection.train_test_split(X, Y,shuffle=False, stratify=None,test_size=.25, random_state=10)
    model_pipeline.fit(train_x,train_y) 
    return model_pipeline.score(valid_x,valid_y)

