# -*- coding: utf-8 -*-
"""
Created on Fri Jan 11 15:23:27 2019

@author: caridza
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Jan 11 15:03:42 2019

@author: caridza
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Nov 12 11:53:30 2018

@author: caridza
"""
#VirtualEnv: docclassify
#VirtualEnv Location: C:\Users\caridza\Downloads\WPy32-3662\ZacksScripts\docclassify
#######################
#######IMPORTS#########
#######################
#install tensorflow: pip3 install --upgrade https://storage.googleapis.com/tensorflow/mac/cpu/tensorflow-1.12.0-py3-none-any.whl
#base modules 
import sys
import pickle
import joblib
import pandas as pd
from sklearn import preprocessing
import nltk
from nltk.corpus import stopwords
import re 
from sklearn.pipeline import Pipeline,make_pipeline
from nltk.corpus import stopwords
import string
from nltk.stem.snowball import SnowballStemmer
from sklearn.base import BaseEstimator, TransformerMixin
from utils import TextSelector, NumberSelector,orig_text_clean,load_and_score

stopwords = stopwords.words("english")
exclude = set(string.punctuation)
stemmer = SnowballStemmer('english')

def load_and_score(model_path,data2score,concat_2df,stemmer=None,stopwords=None):
    
    #Final Prediction on entire dataset
    #load model 
    loaded_model = joblib.load(model_path)
    
    #len(newdata.loc[newdata.index.duplicated(keep='first')])
    newdata =orig_text_clean(data2score,target='LegalAction',maplabelvars=['source'],stopwords=stopwords,stemmer=stemmer)# orig_text_clean(data2score)
    
    #preds on new data 
    predictions = loaded_model.predict_proba(newdata)
    preds = pd.DataFrame(data=predictions, columns = ['P_Nolegal','P_legal'])
    preds['LegalAction'] = loaded_model.predict(newdata)
    
    if concat_2df == True:
        #generating a submission file
        results = pd.concat([newdata, preds], axis=1)
        return results 
    else: 
        return preds
    
#preprocess data 
#func to remove punc from string and return string
def remove_punctuation(text,excluded_punct={'+', ':', '[', '^', '"', '|', '{', '@', '=', ')', '%', '#', '`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}):
    return ' '.join([word for word in nltk.word_tokenize(text) if word not in excluded_punct])

#func to remove stop words 
def remove_stop(text,stopwords=['the','is','a','i','are','it']):
    return ' '.join([word for word in text.split(' ') if word.lower() not in stopwords])

#func to stem words 
def stem_words(text,stemmer=None):
    return ' '.join([stemmer.stem(word) for word in text.split(' ')])

#remove non alpha characters from text 
def remove_nonchars(text):
    return ' '.join([re.sub('[^A-Za-z|^\$|^\.]+', ' ', word) for word in text.split(' ') if (word.isalnum() and len(word)>2)])



def orig_text_clean(data,target='LegalAction',maplabelvars=['source'],stopwords=['the','is','a','i','are','it'],stemmer=None):
    trainDF = pd.DataFrame()
    trainDF['text'] = data['origtext'].apply(lambda x: remove_punctuation(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_nonchars(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_stop(x,stopwords=stopwords))
    trainDF['cleantxt'] = trainDF['text'].apply(lambda x: stem_words(x,stemmer=stemmer))
    
    
    trainDF['label'] = data[target]
    trainDF['source'] = data['source']
    trainDF['txt_lngth'] = trainDF['cleantxt'].apply(lambda x: len(x))
    trainDF['txt_words'] = trainDF['cleantxt'].apply(lambda x: len(x.split(' ')))
    trainDF['txt_nonstopwords'] = trainDF['cleantxt'].apply(lambda x: len([t for t in x.split(' ') if t not in stopwords]))
    trainDF['total_commas'] = data['origtext'].apply(lambda x: x.count(','))
    
    le = preprocessing.LabelEncoder() 
    le.fit(trainDF['label'])
    trainDF['label_id'] =le.transform(trainDF['label'])
    le.fit(trainDF['source'])
    trainDF['source_id'] =le.transform(trainDF['source'])
    
    for var in maplabelvars: 
        le.fit(trainDF[var])
        trainDF[var+'_id'] =le.transform(trainDF[var])
        
    trainDF=trainDF.reset_index(drop=True)
    return trainDF 


#transformer to select a column from dataframe to be used for processing 
class TextSelector(BaseEstimator, TransformerMixin):
    """
    Transformer to select a single column from the data frame to perform additional transformations on
    Use on text columns in the data
    """
    def __init__(self, key):
        self.key = key

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return X[self.key]
    
class NumberSelector(BaseEstimator, TransformerMixin):
    """
    Transformer to select a single column from the data frame to perform additional transformations on
    Use on numeric columns in the data
    """
    def __init__(self, key):
        self.key = key

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return X[[self.key]]

#####################
#Dataset Preperation#
##################### 
#https://www.kaggle.com/baghern/a-deep-dive-into-sklearn-pipelines
#https://scikit-learn.org/stable/auto_examples/model_selection/grid_search_text_feature_extraction.html
#http://www.marcosantoni.com/2016/06/19/a-simple-machine-learning-pipeline.html
#cross validation options: https://scikit-learn.org/stable/modules/cross_validation.html
#https://scikit-learn.org/stable/modules/grid_search.html#grid-search

# load the dataset
datapath="C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/NN_ClassificationModelData.pickle"    
model_path ='C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/FinalModel/NN_RF_LegalAction.sav'   
data =pd.read_pickle(datapath)

#Final Model Predictions on entire dataset 
preds = load_and_score(model_path,data,concat_2df=False,stopwords=stopwords,stemmer=stemmer)






