'''Demo for sentiment classifier using Pymagnitude leveraging Keras. Implements a hierarchical attention network architecture.

Paper: http://www.cs.cmu.edu/~./hovy/papers/16HLT-hierarchical-attention-networks.pdf

Usage: 
        TRAINING FROM SCRATCH
        sentiment_classifier_HAN.py mongodb://192.168.16.2:27017 negative_news processed_results \
            /path/to/mag/file /path/to/model/output

        TRAINING FROM CHECKPOINT (seeks '.h5' and '.json' files at 'model_load_path')
        sentiment_classifier_HAN.py mongodb://192.168.0.2:27017 negative_news processed_results \
            /path/to/mag/file /path/to/model/output -model_load_path /path/to/h5/and/json

        TRAINING FROM PICKLED DATA
        sentiment_classifier_HAN.py mongodb://192.168.0.2:27017 negative_news processed_results \
            /path/to/mag/file /path/to/model/output -data_path /path/to/preprocessed/data/pk

        DISPLAY HELP
        sentiment_classifier_HAN.py -h
'''
from math import ceil
import argparse
import time
import os
import pickle

from nltk.tokenize import sent_tokenize, word_tokenize
from sklearn.model_selection import train_test_split
from keras.layers import GaussianNoise, LSTM, Bidirectional, Dropout, Dense, Input, TimeDistributed
from keras.optimizers import Adam
from keras.models import model_from_json
from keras.callbacks import ModelCheckpoint
from keras.regularizers import l2
from keras import initializers as initializers, regularizers, constraints
from keras import backend as K
from keras import optimizers
from keras.models import Model
from pymagnitude import Magnitude, MagnitudeUtils
from pymongo import MongoClient
from pymongo.errors import ServerSelectionTimeoutError
from keras.engine.topology import Layer
import numpy as np

# The maximum number of words the sequence model will consider
MAX_WORDS = 30
# The maximum number of sentences the sequence model will consider
MAX_SENTENCES = 10
# Deviation of noise for Gaussian Noise applied to the embeddings
STD_DEV = 0.01
# The number of hidden units from the LSTM
HIDDEN_UNITS = 100
# The ratio to dropout
DROPOUT_RATIO = 0.8
# The number of examples per train/validation step
BATCH_SIZE = 128
# The number of times to repeat through all of the training data
EPOCHS = 10
# The learning rate for the optimizer
LEARNING_RATE = 0.01
# The number of output classes in the sample data
NUM_OUTPUT_CLASSES = 1
# Lower bound VADER sentiment threshold for neutral
SENTIMENT_NEUTRAL_LB = -0.05
# Upper bound VADER sentiment threshold for neutral
SENTIMENT_NEUTRAL_UB = 0.05
# Percentage of observations included in test sample
TEST_SIZE = 0.15
# MongoDB server timeout in milliseconds
MONGO_TIMEOUT_MS = 1000
# Path at which to store all demo data directory
DEMO_DATA_DIR = "sentiment_classifier_demo/"
# Dense units
DENSE_UNITS = 200

def load_data(conn_str, mongo_db_str, mongo_coll_str):
    '''Loads data from MongoDB and returns a cursor'''
    client = MongoClient(conn_str, serverSelectionTimeoutMS=MONGO_TIMEOUT_MS)

    try:
        client.server_info()
    except ServerSelectionTimeoutError:
        raise Exception("Failed to connect to MongoDB with following connection string: {}".format(conn_str))

    db = client[mongo_db_str]
    coll = db[mongo_coll_str]

    return coll.find({})


def remove_duplicates(seq, indexer=lambda x: x):
    seen = {}
    for item in seq:
        i = indexer(item)
        if i not in seen:
            seen[i] = True
            yield item


def preprocess_data(cursor):
    '''Preprocesses all data associated with a MongoDB cursor until it is exhausted.
        Output data is a list of tuples where each tuple is of the following form:
            (word token list, sentiment class)
        'Word token list' represents the word tokens of a sentence while 
        'sentiment class' represents the VADER sentiment classification for the sentence [-1 = negative, 0 = neutral, 1 = positive ].
    '''
    data = []
    
    for item in remove_duplicates(cursor, lambda x: x['url']):
        sentence_tokens = sent_tokenize(item['content'])
        word_token_lists = [word_tokenize(_sent)[:MAX_WORDS] for _sent in sentence_tokens[:MAX_SENTENCES]]
        fine_flag = 'fine' in ''.join([i[1] for i in item.get('classification_tuple_lists', [])])
        data.append((word_token_lists, fine_flag))

    return data


def build_model(word_vector_length=300):
    '''Builds Keras model'''
    # Words level attention model
    word_input = Input(shape=(MAX_WORDS, word_vector_length), dtype='float32')
    word_sequences = GaussianNoise(STD_DEV)(word_input)
    word_lstm = Bidirectional(LSTM(HIDDEN_UNITS, return_sequences=True, kernel_regularizer=None))(word_sequences)
    word_dense = TimeDistributed(Dense(DENSE_UNITS, kernel_regularizer=None))(word_lstm)
    word_att = AttentionWithContext(name='word_att')(word_dense)
    word_encoder = Model(word_input, word_att)

    # Sentence level attention model
    sent_input = Input(shape=(MAX_SENTENCES, MAX_WORDS, word_vector_length), dtype='float32')
    sent_encoder = TimeDistributed(word_encoder, name='word_encoder')(sent_input)
    sent_lstm = Bidirectional(LSTM(HIDDEN_UNITS, return_sequences=True, kernel_regularizer=None))(sent_encoder)
    sent_dense = TimeDistributed(Dense(DENSE_UNITS, kernel_regularizer=None))(sent_lstm)
    sent_att = Dropout(DROPOUT_RATIO)(AttentionWithContext(name='sent_att')(sent_dense))
    preds = Dense(NUM_OUTPUT_CLASSES, activation='sigmoid')(sent_att)
    model = Model(sent_input, preds)
    model.compile(
        loss='binary_crossentropy',
        optimizer='adam',
        metrics=['accuracy']
    )

    return model


def save_model(model, model_output_name):
    '''Saves Keras model JSON and weights'''
    model_json = model.to_json()
    with open("{}.json".format(model_output_name), "w") as f:
        f.write(model_json)

    model.save_weights("{}.h5".format(model_output_name))


def load_model(model_name):
    '''Loads Keras model JSON and weights; returns Keras model object'''
    # create model from json
    model = build_model()

    # load weights into new model
    model.load_weights("{}.hdf5".format(model_name))

    return model


def sentence_to_vec(wv, token_list, sentence_len):
    sent_vector = wv.query(token_list)
    
    num_to_pad = max(0, sentence_len - len(sent_vector))

    if(num_to_pad):
        sent_vector = np.vstack((sent_vector, np.zeros((num_to_pad, wv.dim))))
        
    return sent_vector

def article_to_vec(wv, article_token_list):
    sent_vectors = np.stack([sentence_to_vec(wv, sent_tokens, MAX_WORDS) for sent_tokens in article_token_list], axis=0)
    
    num_to_pad = max(0, MAX_SENTENCES - len(sent_vectors))
    
    if(num_to_pad):
        sent_vectors = np.vstack((sent_vectors, np.zeros((num_to_pad, MAX_WORDS, wv.dim))))
        
    return sent_vectors

def batch_generator(X_set, y_set, vectors, batch_size):
    while True:
        for ndx in range(0, len(y_set), batch_size):
            x_batch = X_set[ndx: (ndx + batch_size)]
            y_batch = y_set[ndx: (ndx + batch_size)]
            x_batch = np.stack([article_to_vec(vectors, article_tokens) for article_tokens in x_batch])
            y_batch = [int(_bool) for _bool in y_batch]
            yield x_batch, y_batch


def train(model, vectors, model_path, X_train, X_test, y_train, y_test):
    '''Initiates training for Keras model'''
    num_batches_per_epoch_train = int(ceil(len(X_train)/float(BATCH_SIZE)))
    num_batches_per_epoch_test = int(ceil(len(X_test)/float(BATCH_SIZE)))

    # Generates batches of the transformed training data
    train_batch_generator = batch_generator(X_train, y_train, vectors, BATCH_SIZE)

    # Generates batches of the transformed test data
    test_batch_generator = batch_generator(X_test, y_test, vectors, BATCH_SIZE)

    # Create model checkpoint callback
    checkpoint_callback = ModelCheckpoint(model_path + ".hdf5", monitor="val_acc", verbose=1, mode="max")

    # Start training
    model.fit_generator(
        generator=train_batch_generator,
        steps_per_epoch=num_batches_per_epoch_train,
        validation_data=test_batch_generator,
        validation_steps=num_batches_per_epoch_test,
        epochs=EPOCHS,
        callbacks=[checkpoint_callback],
    )


def get_parser():
    '''Builds CLI argument parser for this program'''
    parser = argparse.ArgumentParser(description='Demo Sentiment Classifier')
    parser.add_argument('conn_str', type=str, help='MongoDB connection string')
    parser.add_argument('db_name', type=str, help='MongoDB database name')
    parser.add_argument('coll_name', type=str, help='MongoDB collection name')
    parser.add_argument('magnitude_path', type=str, help='Path to Magnitude file')
    parser.add_argument('model_name', type=str, help='Name to be used for saving model output')
    parser.add_argument('-data_path', type=str, nargs="?", default=None, required=False, help="Path to preprocessed data pickle")
    parser.add_argument('-model_load_path', type=str, nargs="?", default=None, required=False, help="Path to pre-trained model")
    return parser


def main(params):
    os.makedirs(DEMO_DATA_DIR, exist_ok=True)

    vectors = Magnitude(params.magnitude_path)

    if params.data_path is None:
        print("Loading data (conn_str={}, db_name={}, coll_name={}) ..".format(
                params.conn_str, params.db_name, params.coll_name
            )
        )
        tock = time.perf_counter()
        cursor = load_data(params.conn_str, params.db_name, params.coll_name)
        tick = time.perf_counter()
        print("Successfully loaded data. Took {}s ..".format(round(tick - tock, 2)))

        print("Preprocessing data ..")
        tock = time.perf_counter()
        data = preprocess_data(cursor)
        tick = time.perf_counter()
        print("Successfully preprocessed data (records={}). Took {}s ..".format(len(data), round(tick - tock, 2)))

        with open(DEMO_DATA_DIR + params.model_name + "_data.pk", "wb") as f:
            pickle.dump(data, f)
        print("Saved preprocessed data: {}".format(DEMO_DATA_DIR + params.model_name + ".pk"))

        X, y = zip(*data)

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=TEST_SIZE, random_state=101)
    else:
        with open(params.data_path, "rb") as f:
            data = pickle.load(f)

        X_train, X_test, y_train, y_test = data
        print("Loaded preprocessed data from file: {}".format(params.data_path))

    if params.model_load_path is None:
        model = build_model(vectors.dim)
    else:
        model = load_model(params.model_load_path)

    train(model, vectors, DEMO_DATA_DIR + params.model_name, X_train, X_test, y_train, y_test)

    save_model(model, DEMO_DATA_DIR + params.model_name)
    print("Saved model JSON and weights at following path: {}.json/.h5".format(DEMO_DATA_DIR + params.model_name))


def dot_product(x, kernel):
    """
    Wrapper for dot product operation, in order to be compatible with both
    Theano and Tensorflow
    Args:
        x (): input
        kernel (): weights
    Returns:
    """
    if K.backend() == 'tensorflow':
        return K.squeeze(K.dot(x, K.expand_dims(kernel)), axis=-1)
    else:
        return K.dot(x, kernel)


class AttentionWithContext(Layer):
    """
    Attention operation, with a context/query vector, for temporal data.
    Supports Masking.
    Follows the work of Yang et al. [https://www.cs.cmu.edu/~diyiy/docs/naacl16.pdf]
    "Hierarchical Attention Networks for Document Classification"
    by using a context vector to assist the attention
    # Input shape
        3D tensor with shape: `(samples, steps, features)`.
    # Output shape
        2D tensor with shape: `(samples, features)`.
    How to use:
    Just put it on top of an RNN Layer (GRU/LSTM/SimpleRNN) with return_sequences=True.
    The dimensions are inferred based on the output shape of the RNN.
    Note: The layer has been tested with Keras 2.0.6
    Example:
        model.add(LSTM(64, return_sequences=True))
        model.add(AttentionWithContext())
        # next add a Dense layer (for classification/regression) or whatever...
    """

    def __init__(self,
                 W_regularizer=None, u_regularizer=None, b_regularizer=None,
                 W_constraint=None, u_constraint=None, b_constraint=None,
                 bias=True, **kwargs):

        self.supports_masking = True
        self.init = initializers.get('glorot_uniform')

        self.W_regularizer = regularizers.get(W_regularizer)
        self.u_regularizer = regularizers.get(u_regularizer)
        self.b_regularizer = regularizers.get(b_regularizer)

        self.W_constraint = constraints.get(W_constraint)
        self.u_constraint = constraints.get(u_constraint)
        self.b_constraint = constraints.get(b_constraint)

        self.bias = bias
        super(AttentionWithContext, self).__init__(**kwargs)

    def build(self, input_shape):
        assert len(input_shape) == 3

        self.W = self.add_weight((input_shape[-1], input_shape[-1],),
                                 initializer=self.init,
                                 name='{}_W'.format(self.name),
                                 regularizer=self.W_regularizer,
                                 constraint=self.W_constraint)
        if self.bias:
            self.b = self.add_weight((input_shape[-1],),
                                     initializer='zero',
                                     name='{}_b'.format(self.name),
                                     regularizer=self.b_regularizer,
                                     constraint=self.b_constraint)

        self.u = self.add_weight((input_shape[-1],),
                                 initializer=self.init,
                                 name='{}_u'.format(self.name),
                                 regularizer=self.u_regularizer,
                                 constraint=self.u_constraint)

        super(AttentionWithContext, self).build(input_shape)

    def compute_mask(self, input, input_mask=None):
        # do not pass the mask to the next layers
        return None

    def call(self, x, mask=None):
        uit = dot_product(x, self.W)

        if self.bias:
            uit += self.b

        uit = K.tanh(uit)
        ait = dot_product(uit, self.u)

        a = K.exp(ait)

        # apply mask after the exp. will be re-normalized next
        if mask is not None:
            # Cast the mask to floatX to avoid float64 upcasting in theano
            a *= K.cast(mask, K.floatx())

        # in some cases especially in the early stages of training the sum may be almost zero
        # and this results in NaN's. A workaround is to add a very small positive number ε to the sum.
        # a /= K.cast(K.sum(a, axis=1, keepdims=True), K.floatx())
        a /= K.cast(K.sum(a, axis=1, keepdims=True) + K.epsilon(), K.floatx())

        a = K.expand_dims(a)
        weighted_input = x * a
        return K.sum(weighted_input, axis=1)

    def compute_output_shape(self, input_shape):
        return input_shape[0], input_shape[-1]

if __name__ == '__main__':
    parser = get_parser()
    params = parser.parse_args()
    main(params)