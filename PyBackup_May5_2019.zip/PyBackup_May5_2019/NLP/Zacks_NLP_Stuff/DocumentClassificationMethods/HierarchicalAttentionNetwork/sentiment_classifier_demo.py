'''Demo for sentiment classifier using Pymagnitude leveraging Keras.

Usage: 
        TRAINING FROM SCRATCH
        sentiment_classifier_demo.py mongodb://192.168.0.2:27017 negative_news processed_results \
            /path/to/mag/file /path/to/model/output

        TRAINING FROM CHECKPOINT (seeks '.h5' and '.json' files at 'model_load_path')
        sentiment_classifier_demo.py mongodb://192.168.0.2:27017 negative_news processed_results \
            /path/to/mag/file /path/to/model/output -model_load_path /path/to/h5/and/json

        TRAINING FROM PICKLED DATA
        sentiment_classifier_demo.py mongodb://192.168.0.2:27017 negative_news processed_results \
            /path/to/mag/file /path/to/model/output -data_path /path/to/preprocessed/data/pk

        DISPLAY HELP
        sentiment_classifier_demo.py -h

Todo:
	LOAD MODEL FROM .hdf5 (IN ADDITION TO .h5 and .json )

	REMOVE MONGODB INFORMATION FROM REQUIRED PARAMETERS
'''
from math import ceil
import argparse
import time
import os
import pickle

from nltk.tokenize import sent_tokenize
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import GaussianNoise, LSTM, Bidirectional, Dropout, Dense
from keras.optimizers import Adam
from keras.models import model_from_json
from keras.callbacks import ModelCheckpoint
from pymagnitude import Magnitude, MagnitudeUtils
from pymongo import MongoClient
from pymongo.errors import ServerSelectionTimeoutError
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# The maximum number of words the sequence model will consider
MAX_WORDS = 30
# Deviation of noise for Gaussian Noise applied to the embeddings
STD_DEV = 0.01
# The number of hidden units from the LSTM
HIDDEN_UNITS = 100
# The ratio to dropout
DROPOUT_RATIO = 0.8
# The number of examples per train/validation step
BATCH_SIZE = 100
# The number of times to repeat through all of the training data
EPOCHS = 10
# The learning rate for the optimizer
LEARNING_RATE = 0.01
# The number of output classes in the sample data
NUM_OUTPUT_CLASSES = 3
# Lower bound VADER sentiment threshold for neutral
SENTIMENT_NEUTRAL_LB = -0.05
# Upper bound VADER sentiment threshold for neutral
SENTIMENT_NEUTRAL_UB = 0.05
# Percentage of observations included in test sample
TEST_SIZE = 0.25
# MongoDB server timeout in milliseconds
MONGO_TIMEOUT_MS = 1000
# Path at which to store all demo data directory
DEMO_DATA_DIR = "sentiment_classifier_demo/"

def load_data(conn_str, mongo_db_str, mongo_coll_str):
    '''Loads data from MongoDB and returns a cursor'''
    client = MongoClient(conn_str, serverSelectionTimeoutMS=MONGO_TIMEOUT_MS)

    try:
        client.server_info()
    except ServerSelectionTimeoutError:
        raise Exception("Failed to connect to MongoDB with following connection string: {}".format(conn_str))

    db = client[mongo_db_str]
    coll = db[mongo_coll_str]

    return coll.find({})


def preprocess_data(cursor):
    '''Preprocesses all data associated with a MongoDB cursor until it is exhausted.
        Output data is a list of tuples where each tuple is of the following form:
            (word token list, sentiment class)
        'Word token list' represents the word tokens of a sentence while 
        'sentiment class' represents the VADER sentiment classification for the sentence [-1 = negative, 0 = neutral, 1 = positive ].
    '''
    def bin_sentiment(sentiment_score):
        '''Bins continuous sentiment score into discrete buckets'''
        if sentiment_score < SENTIMENT_NEUTRAL_LB:
            return -1
        elif sentiment_score > SENTIMENT_NEUTRAL_UB:
            return 1
        else:
            return 0

    analyzer = SentimentIntensityAnalyzer()
    data = []

    for item in cursor:
        sentence_tokens = sent_tokenize(item['content'])

        sentiment_class_list = [bin_sentiment(analyzer.polarity_scores(sentence)["compound"]) for sentence in sentence_tokens]

        for idx, sentence in enumerate(sentence_tokens):
            data.append((sentence.split(" ")[:MAX_WORDS], sentiment_class_list[idx]))

    return data


def build_model(word_vector_length):
    '''Builds Keras model'''
    model = Sequential()
    model.add(GaussianNoise(STD_DEV, input_shape=(MAX_WORDS, word_vector_length)))
    model.add(Bidirectional(LSTM(HIDDEN_UNITS, activation='tanh'), merge_mode='concat'))
    model.add(Dropout(DROPOUT_RATIO))
    model.add(Dense(NUM_OUTPUT_CLASSES, activation='softmax'))
    model.compile(
        loss='categorical_crossentropy',
        optimizer=Adam(lr=LEARNING_RATE),
        metrics=['categorical_accuracy']
    )
    return model


def save_model(model, model_output_name):
    '''Saves Keras model JSON and weights'''
    model_json = model.to_json()
    with open("{}.json".format(model_output_name), "w") as f:
        f.write(model_json)

    model.save_weights("{}.h5".format(model_output_name))


def load_model(model_name):
    '''Loads Keras model JSON and weights; returns Keras model object'''
    # load model json
    with open('{}.json'.format(model_name), 'r') as f:
        model_json = f.read()

    # create model from json
    model = model_from_json(model_json)

    # load weights into new model
    model.load_weights("{}.h5".format(model_name))

    # compile model
    model.compile(
        loss='categorical_crossentropy',
        optimizer='adam',
        metrics=['categorical_accuracy']
    )

    return model


def train(model, data, vectors, model_path):
    '''Initiates training for Keras model'''
    X, y = zip(*data)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=TEST_SIZE, random_state=101)

    training_batches = MagnitudeUtils.batchify(X_train, y_train, BATCH_SIZE) # Split the training data into batches
    num_batches_per_epoch_train = int(ceil(len(X_train)/float(BATCH_SIZE)))
    test_batches = MagnitudeUtils.batchify(X_test, y_test, BATCH_SIZE)  # Split the test data into batches
    num_batches_per_epoch_test = int(ceil(len(X_test)/float(BATCH_SIZE)))

    # Generates batches of the transformed training data
    train_batch_generator = (
      (
        vectors.query(X_train_batch), # Magnitude will handle converting the 2D array of text into the 3D word vector representations
        MagnitudeUtils.to_categorical(y_train_batch, NUM_OUTPUT_CLASSES) # Magnitude will handle converting the class labels into one-hot encodings
      ) for X_train_batch, y_train_batch in training_batches
    )

    # Generates batches of the transformed test data
    test_batch_generator = (
      (
        vectors.query(X_test_batch), # Magnitude will handle converting the 2D array of text into the 3D word vector representations
        MagnitudeUtils.to_categorical(y_test_batch, NUM_OUTPUT_CLASSES) # Magnitude will handle converting the class labels into one-hot encodings
      ) for X_test_batch, y_test_batch in test_batches
    )

    # Create model checkpoint callback
    checkpoint_callback = ModelCheckpoint(model_path + ".hdf5", monitor="val_acc", verbose=1, mode="max")

    # Start training
    model.fit_generator(
        generator=train_batch_generator,
        steps_per_epoch=num_batches_per_epoch_train,
        validation_data=test_batch_generator,
        validation_steps=num_batches_per_epoch_test,
        epochs=EPOCHS,
        callbacks=[checkpoint_callback],
    )


def get_parser():
    '''Builds CLI argument parser for this program'''
    parser = argparse.ArgumentParser(description='Demo Sentiment Classifier')
    parser.add_argument('conn_str', type=str, help='MongoDB connection string')
    parser.add_argument('db_name', type=str, help='MongoDB database name')
    parser.add_argument('coll_name', type=str, help='MongoDB collection name')
    parser.add_argument('magnitude_path', type=str, help='Path to Magnitude file')
    parser.add_argument('model_name', type=str, help='Name to be used for saving model output')
    parser.add_argument('-data_path', type=str, nargs="?", default=None, required=False, help="Path to preprocessed data pickle")
    parser.add_argument('-model_load_path', type=str, nargs="?", default=None, required=False, help="Path to pre-trained model")
    return parser


def main(params):
    os.makedirs(DEMO_DATA_DIR, exist_ok=True)

    vectors = Magnitude(params.magnitude_path)

    if params.data_path is None:
        print("Loading data (conn_str={}, db_name={}, coll_name={}) ..".format(
                params.conn_str, params.db_name, params.coll_name
            )
        )
        tock = time.perf_counter()
        cursor = load_data(params.conn_str, params.db_name, params.coll_name)
        tick = time.perf_counter()
        print("Successfully loaded data. Took {}s ..".format(round(tick - tock, 2)))

        print("Preprocessing data ..")
        tock = time.perf_counter()
        data = preprocess_data(cursor)
        tick = time.perf_counter()
        print("Successfully preprocessed data (records={}). Took {}s ..".format(len(data), round(tick - tock, 2)))

        with open(DEMO_DATA_DIR + params.model_name + "_data.pk", "wb") as f:
            pickle.dump(data, f)
        print("Saved preprocessed data: {}".format(DEMO_DATA_DIR + params.model_name + ".pk"))
    else:
        with open(params.data_path, "rb") as f:
            data = pickle.load(f)
        print("Loaded preprocessed data from file: {}".format(params.data_path))

    if params.model_load_path is None:
        model = build_model(vectors.dim)
    else:
        model = load_model(params.model_load_path)

    train(model, data, vectors, DEMO_DATA_DIR + params.model_name)

    save_model(model, DEMO_DATA_DIR + params.model_name)
    print("Saved model JSON and weights at following path: {}.json/.h5".format(DEMO_DATA_DIR + params.model_name))


if __name__ == '__main__':
    parser = get_parser()
    params = parser.parse_args()
    main(params)
