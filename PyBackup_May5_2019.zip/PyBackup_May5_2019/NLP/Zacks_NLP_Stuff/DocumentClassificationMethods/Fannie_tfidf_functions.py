####Fannie tfidf_clustering functions 
#VirtualEnv: docclassify
#VirtualEnv Location: C:\Users\caridza\Downloads\WPy32-3662\ZacksScripts\docclassify
#http://brandonrose.org/clustering
#######################
#######IMPORTS#########
#######################
#install tensorflow: pip3 install --upgrade https://storage.googleapis.com/tensorflow/mac/cpu/tensorflow-1.12.0-py3-none-any.whl
#base modules 
import sys
from itertools import islice #iterating over vectorized objects (countvectorizer, tfidfvectorizer,etc..)
import numpy as np
import pandas as pd

#third party modules
#import required modules for data preprocessing , feature engineering and model training
from sklearn import model_selection, preprocessing, linear_model, naive_bayes, metrics, svm
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn import decomposition, ensemble
from sklearn.pipeline import Pipeline
from sklearn.pipeline import make_pipeline

import pandas, xgboost, numpy, textblob, string
from keras.preprocessing import text, sequence
from keras import layers, models, optimizers
from numpy.random import rand

import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
import matplotlib.pyplot as plt
import matplotlib
import seaborn as sns
import re
from sklearn.cluster import KMeans
import os  # for os.path.basename

import matplotlib.pyplot as plt
import matplotlib as mpl
from sklearn.manifold import MDS
import random
import mpu
from sklearn import preprocessing
import pylab as pl
from sklearn import datasets
from sklearn.decomposition import PCA

#custom modules 
#sys.path.insert(0,"C:/Users/caridza/Desktop/pythonScripts/")
sys.path.insert(0,"C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/")
from DocClassFuncs.ClassificationFuncs  import read_corp ,topn_tfidf_freq, create_model_architecture ,create_cnn,create_rnn_lstm, create_rnn_gru,create_bidirectional_rnn,train_model

#punctuation to remove, stopwords to remove, stemming and lemmatizing objects for preprocessing
stemmer = SnowballStemmer('english')
wordnet_lemmatizer = WordNetLemmatizer()
exclude = set(string.punctuation)
stopwords = stopwords.words("english")

#sklearn pipeline function transformer 
from sklearn.preprocessing import FunctionTransformer
def pipelinize(function, active=True):
    def list_comprehend_a_function(list_or_series, active=True):
        if active:
            return [function(i) for i in list_or_series]
        else: # if it's not active, just pass it right back
            return list_or_series
    return FunctionTransformer(list_comprehend_a_function, validate=False, kw_args={'active':active})

#using word tokenizatoin because input documents do not have sentence structure
#func to remove punc from string and return string
def remove_punctuation(text,excluded_punct=exclude):
    return ' '.join([word for word in nltk.word_tokenize(text) if word not in excluded_punct])

def remove_stop(text,stopwords=stopwords):
    return ' '.join([word for word in text.split(' ') if word not in stopwords])

def stem_words(text,stemmer = stemmer ):
    return ' '.join([stemmer.stem(word) for word in text.split(' ')])

def remove_nonchars(text):
    return ' '.join([re.sub(r'\d+',' ',word) for word in text.split(' ') if (word.isalnum() and len(word)>2)])


#Note: we fit the pipeline with x and y , but can only transform the indpendent series, pipelines cannoto handle dependent variables transoformations
#Output: Transformed x and y series split into training and test data
def PreProcData(X,Y,Z=[]):
    '''
    'Inputs'
    'X: pandas series of independent variables we want to transform (here a single series of text)
    'Y: label we are using to trian model on (here a string with label info from pandas df series)
    'Z':descriptive column for each row to pass through 
    '''
    preprocess_pipeline = make_pipeline(
            pipelinize(remove_punctuation) #remove punctuatoin
            , pipelinize(remove_nonchars)
            , pipelinize(remove_stop) #remove stopwords
            , pipelinize(stem_words)
            
            ) #stem words     
    preprocess_pipeline.fit(X,Y) 
    
    preprocess_pipeline_nostem = make_pipeline(
         pipelinize(remove_punctuation) #remove punctuatoin
        , pipelinize(remove_nonchars)
        , pipelinize(remove_stop) #remove stopwords
        
        ) #stem words     
    preprocess_pipeline_nostem.fit(X,Y) 
    
    return preprocess_pipeline.transform(X),preprocess_pipeline_nostem.transform(X),Y,Z,

def display_scores(vectorizer, tfidf_result):
    # http://stackoverflow.com/questions/16078015/
    scores = zip(vectorizer.get_feature_names(),np.asarray(tfidf_result.sum(axis=0)).ravel())
    sorted_scores = sorted(scores, key=lambda x: x[1], reverse=True)
    for item in sorted_scores:
        print("{0:50} Score: {1}".format(item[0], item[1]))
        