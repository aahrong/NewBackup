# -*- coding: utf-8 -*-
"""
Created on Mon Jan 28 07:50:53 2019

@author: caridza
"""
import pandas as pd
import string, pickle, sys
from itertools import islice #iterating over vectorized objects (countvectorizer, tfidfvectorizer,etc..)
#required modules for data preprocessing and modeling
import sklearn
from sklearn import decomposition, ensemble,model_selection, preprocessing, metrics
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer,TfidfTransformer
from sklearn.pipeline import Pipeline,make_pipeline
from sklearn.preprocessing import StandardScaler,MinMaxScaler
from sklearn.model_selection import train_test_split,GridSearchCV
from sklearn.pipeline import FeatureUnion 
from sklearn.neural_network import MLPClassifier
#text parsing
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
from nltk import word_tokenize

#plotting
import numpy as np
import joblib
import re
#pipelien 
from imblearn.over_sampling import SMOTE  # or: import RandomOverSampler
from imblearn.pipeline import Pipeline as imbPipeline
#custom modules 
from negative_news2.consumer.utils.nn_modelutils import TextSelector , NumberSelector
from negative_news2.consumer.utils import replace_words,orig_text_clean,load_and_score,remove_punctuation,remove_stop,stem_words,remove_nonchars,pipelinize,sk_model_stats, encode_categoric

#punctuation to remove, stopwords to remove, stemming and lemmatizing objects for preprocessing
stemmer = SnowballStemmer('english')
wordnet_lemmatizer = WordNetLemmatizer()
exclude = set(string.punctuation)
stopwords = stopwords.words('english')
newStopWords = ['.','?','%','Google','Wells Fargo','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December']
stopwords.extend(newStopWords)
stop_list=set(stopwords)


#TESTING
#load and score test inputs 
model_path = 'C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/FinalModel/NN_MLP_MonetaryFine.sav'
datapath2 = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/postpro_line268_postSentWordtokenized.pickle"
data = pd.read_pickle(datapath2)
joblib.load(model_path)
stop_words=stop_list
target = 'AFGAF'

#TESTING OUTPUT VALUE ASSIGNMENT 
data['new1']=load_and_score(Data = data,model_path=model_path,stop_words=stop_list,stemmer=stemmer,target=target)
#data['new2']=load_and_score(Data = data,model_path=model_path,stop_words=stop_list,stemmer=stemmer,target='fdadfafdfdfa')


def load_and_score(Data=None,model_path=None,stop_words=[],stemmer=None,target=''):
    data = Data.copy()
    #INPUTS
    #data = dataframe of source data with one col reprsenting sent tokenized text 
    #model_path = path to model that is going to ggenerate predictions 
    #stop_words = set of stopwords to be removed from each sentence 
    #stemmer = stemmer class to be utilized for stemming vocabulary 
    
    #get doc_index as col to join results back to
    data.reset_index(inplace=True)
    data.rename(columns={'index': 'DocIndex'}, inplace=True)
    
    #create sent level df 
    SentDF = DocDF2SentDF(DocDF=data,cols = ['DocIndex','date','entity','url','source','title','jobname','sentence_tokenized'])
    
    #clean data 
    newdata = orig_text_clean(SentDF,target='',txtfeild='Sentence',maplabelvars=['source'],stopwords=stop_words,stemmer=stemmer)

    #load pickled model for evaluation on unseen data 
    loaded_model = joblib.load(model_path)
    predictions =  loaded_model.predict(newdata) #loaded_model.predict_proba(newdata)
    preds = pd.DataFrame(data=predictions, columns = ['Pred_'+target])
  
    #create df of preds to join back to original doc level data
    results = pd.concat([newdata, preds], axis=1)
    col = results.filter(like='Pred_').columns.values
 
    results2 = results .groupby(['DocIndex'])[col].sum()
    results2.reset_index(inplace=True)
    
    #merge preds to original df by doc index 
    finaldf = pd.merge(data[['DocIndex']], results2, on='DocIndex', how='left')
    finaldf['Pred_'+target] = finaldf['Pred_'+target].apply(lambda x: 1 if x>0 else x)
    return(finaldf['Pred_'+target].values)


def DocDF2SentDF(DocDF=None,cols = ['date','entity','url','source','title','jobname','sentence_tokenized']):
   
    #subset feilds from source data 
    datatp = DocDF[cols]
    datatp.reset_index(inplace=True,drop=True)
    #data.rename(columns={'index': 'DocIndex'}, inplace=True)
    
    #convert dataframe to sent level 
    rows = []
    datatp.apply(lambda row: [rows.append([row['DocIndex'],row['date'],row['entity'],row['source'],row['title'],row['url'],row['jobname'],sent])
                             for sent in row.sentence_tokenized],axis=1)
    
    SentDF = pd.DataFrame(rows,columns = ['DocIndex','date','entity','source','title','url','jobname','sentence_tokenized'])
    SentDF.reset_index(inplace=True)
    SentDF.rename(columns={'index': 'SentIndex'}, inplace=True)
    SentDF.rename(columns={'sentence_tokenized': 'Sentence'}, inplace=True)
    #NOTE: predictions made at the SentIndex level will be rolled up to DocIndex level 
    del datatp 
    return SentDF


def orig_text_clean(data,target='',txtfeild='origtext',maplabelvars=['source'],stopwords=['the','is','a','i','are','it'],stemmer=None):
    trainDF = data
    
    #clean text 
    trainDF['text'] = data[txtfeild].apply(lambda x: remove_punctuation(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_nonchars(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_stop(x,stopwords=stopwords))
    trainDF['text'] = trainDF['text'].apply(lambda x: stem_words(x,stemmer=stemmer))
    trainDF['Sentence'] = trainDF['text'].apply(lambda x: x.strip())
    trainDF.drop(columns = ['text'],inplace=True)
    
    #document numeric informaiton 
    trainDF['txt_lngth'] = trainDF['Sentence'].apply(lambda x: len(x))
    trainDF['txt_words'] = trainDF['Sentence'].apply(lambda x: len(x.split(' ')))
    trainDF['txt_nonstopwords'] = trainDF['Sentence'].apply(lambda x: len([t for t in x.split(' ') if t not in stopwords]))
    trainDF['total_commas'] = data['Sentence'].apply(lambda x: x.count(','))

    #if no target is defined then we are scoring and do not need to create target
    if len(target)>3:
        trainDF['label'] = data[target]
        le = preprocessing.LabelEncoder() 
        le.fit(trainDF['label'])
        trainDF['label_id'] =le.transform(trainDF['label'])
        trainDF.drop(columns = ['label'],inplace=True)
    
    #for each variable that is categoric, tranform to numeric id for model
    if maplabelvars != []:
        for var in maplabelvars: 
            le = preprocessing.LabelEncoder() 
            le.fit(trainDF[var])
            trainDF[var+'_id'] =le.transform(trainDF[var])
            trainDF.drop(columns = [var],inplace=True)
            
        
    trainDF=trainDF.reset_index(drop=True)
    return trainDF 

#preprocess data 
#func to remove punc from string and return string
def remove_punctuation(text,excluded_punct={'+', ':', '[', '^', '"', '|', '{', '@', '=', ')', '%', '#', '`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}):
    return ' '.join([word for word in nltk.word_tokenize(text) if word not in excluded_punct])

#func to remove stop words 
def remove_stop(text,stopwords=['the','is','a','i','are','it']):
    return ' '.join([word for word in text.split(' ') if word.lower() not in stopwords])

#func to stem words 
def stem_words(text,stemmer=None):
    return ' '.join([stemmer.stem(word) for word in text.split(' ')])

#remove non alpha characters from text 
def remove_nonchars(text):
    return ' '.join([re.sub('[^A-Za-z|^\$|^\.]+', ' ', word) for word in text.split(' ') if (word.isalnum() and len(word)>2)])


#clean text helper functions 
def chkPeriod(SentTokList):
    p = re.compile(r'[A-Za-z]+[A-Za-z]+[.]+[A-Za-z]+[A-Za-z]{2,}')
    output= []
    for val in SentTokList: 
        if p.search(val):
            newstr = ' '.join([re.sub('[.]+', ' ', y) for y in val.split()])
        else: 
            newstr = val
        output.append(newstr)        
    return output 
