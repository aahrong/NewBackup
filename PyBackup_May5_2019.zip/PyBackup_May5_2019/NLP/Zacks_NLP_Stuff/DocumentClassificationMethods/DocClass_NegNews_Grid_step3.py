# -*- coding: utf-8 -*-
"""
Created on Fri Jan 11 15:03:42 2019

@author: caridza
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Nov 12 11:53:30 2018

@author: caridza
"""
#VirtualEnv: docclassify
#VirtualEnv Location: C:\Users\caridza\Downloads\WPy32-3662\ZacksScripts\docclassify
#######################
#######IMPORTS#########
#######################
#install tensorflow: pip3 install --upgrade https://storage.googleapis.com/tensorflow/mac/cpu/tensorflow-1.12.0-py3-none-any.whl
#base modules 
import sys
import pickle
from itertools import islice #iterating over vectorized objects (countvectorizer, tfidfvectorizer,etc..)
import numpy as np
import pandas as pd
from sklearn import model_selection, preprocessing, linear_model, naive_bayes, metrics, svm
from sklearn.model_selection import GridSearchCV
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer,TfidfTransformer
from sklearn.feature_selection import SelectFromModel
from sklearn.svm import LinearSVC
from sklearn import decomposition, ensemble
from sklearn.pipeline import Pipeline
from sklearn.pipeline import make_pipeline,Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.decomposition import TruncatedSVD
import sklearn

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn import tree, svm
from sklearn.metrics import accuracy_score
import xgboost, numpy, textblob, string
from keras.preprocessing import text, sequence
from keras import layers, models, optimizers
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import cross_val_predict
import scikitplot as skplt
import joblib
import re
#custom modules 
#sys.path.insert(0,"C:/Users/caridza/Desktop/pythonScripts/")
sys.path.insert(0,"C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/")
from DocClassFuncs import ClassificationFuncs
from DocClassFuncs.ClassificationFuncs import TextSelector, NumberSelector
from DocClassFuncs.ClassificationFuncs  import orig_text_clean,remove_nonchars,list_comprehend_a_function, pipelinize,PreProcData,remove_punctuation,remove_stop,stem_words, model_eval,remove_nonchars
from sklearn.preprocessing import FunctionTransformer

#punctuation to remove, stopwords to remove, stemming and lemmatizing objects for preprocessing
stemmer = SnowballStemmer('english')
wordnet_lemmatizer = WordNetLemmatizer()
exclude = set(string.punctuation)
stopwords = stopwords.words("english")

#####################
#Dataset Preperation#
##################### 
#https://www.kaggle.com/baghern/a-deep-dive-into-sklearn-pipelines
#https://scikit-learn.org/stable/auto_examples/model_selection/grid_search_text_feature_extraction.html
#http://www.marcosantoni.com/2016/06/19/a-simple-machine-learning-pipeline.html
#cross validation options: https://scikit-learn.org/stable/modules/cross_validation.html
#https://scikit-learn.org/stable/modules/grid_search.html#grid-search

# load the dataset
datapath="C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/NN_ClassificationModelData.pickle"       
data =pd.read_pickle(datapath)

#create a dataframe using texts and lables
trainDF = orig_text_clean(data,target='LegalAction',maplabelvars=['source'])
    
#categorical and numerical columns in dataframe 
target = 'label_id'
features= [c for c in trainDF.columns.values if c  not in ['label','author',target,'source_id']]
numeric_features= [c for c in trainDF.columns.values if c  not in ['label','author','text',target,'source','source_id']]
#numeric_features.append(target)

# convert column "a" of a DataFrame
for col in numeric_features:
    trainDF[col] = pd.to_numeric(trainDF[col])
#numeric_features.remove(target)
                                  
#test train split 
train_x,valid_x,train_y,valid_y= model_selection.train_test_split(trainDF[features],trainDF[target],shuffle=True, stratify=trainDF[target],test_size=.1, random_state=10)
[x.shape for x in [train_x,train_y,valid_x,valid_y]]

#create a selector transformer that simply returns the one column in the dataset by the key value I pass.
text = Pipeline([
                ('selector', TextSelector(key='text')),
                ('removePunc',  pipelinize(remove_punctuation)),
                ('removenonchar', pipelinize(remove_nonchars)),
                ('removestops', pipelinize(remove_stop)),
                ('stemwords', pipelinize(stem_words)),
                ('tfidf',  TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=400,min_df=.01,max_df=.8, smooth_idf=True, sublinear_tf=False,lowercase=True,))
            ])

#create dictonary of pipelines for all numeric features and standardize them 
numfeat_pipe_dic= {val: Pipeline([('selector', NumberSelector(key=val)),('standard', StandardScaler())]) for val in numeric_features}

#create final list of pipelines, starting with text preprocessing, and finishing with the numeric column normalizations(items listed in order of exectuion so we build initial list with text processing and append all numeric processing tasks after)
final_pipeline = [('text',text)]
final_pipeline.extend([(k,v) for k, v in numfeat_pipe_dic.items()])

#to make a pipeline from all of our pipelines, we do the same thing, but now we use a FeatureUnion to join the feature processing pipelines.
from sklearn.pipeline import FeatureUnion 
feats = FeatureUnion(final_pipeline)
feature_processing = Pipeline([('feats', feats)])

#apply feature pipeline and then apply models 
pipe_rf = Pipeline([('features',feats),
                    #('svm', sklearn.decomposition.TruncatedSVD(n_components=100,random_state=42)),
                    #('clf', RandomForestClassifier(n_estimators=1000,oob_score=True
                    #                               ,min_samples_split=20,max_depth=10
                    #                               ,class_weight='balanced_subsample'
                    #                               ,max_features=100,n_jobs=4))
                    # 
                    
                    ('feature_selection', SelectFromModel(LinearSVC(loss='l2',penalty="l1",dual=False),threshold='mean')), 
                    ('clf', LogisticRegression(random_state=42,max_iter=10000))])
                    

#view all attributes that can be tuned
pipe_rf.get_params().keys()
#list of all scoring metrics that can be used
sorted(sklearn.metrics.SCORERS.keys())

#logistic hyper parameters
hyperparameters = [{'feature_selection__max_features':[200],
                    'clf__solver':['newton-cg','saga'],
                    'clf__penalty': ['l2'],
                    'clf__C': [1.0, 0.5, 0.1],               #Inverse of regularization strength; smaller values specify stronger regularization
                    'clf__class_weight':['balanced']         #“balanced” mode uses the values of y to automatically adjust weights inversely proportional to class frequencies in the input data as n_samples / (n_classes * np.bincount(y)).
                    }] 

#create gridsearch object
clf = GridSearchCV(pipe_rf, hyperparameters, cv=3, scoring='balanced_accuracy', refit=True, verbose=5)#,n_jobs=jobs)

# Fit and tune model
clf.fit(train_x, train_y)

#cross validation metrics for all considered models
cv_metrics = pd.DataFrame(clf.cv_results_)

#refitting on entire training data using best settings
#view predictions and probabilities of each class 
clf.refit
preds = clf.predict(valid_x)
probs = clf.predict_proba(valid_x)
np.mean(preds == valid_y)
cf = metrics.confusion_matrix(valid_y, preds)

#save model to file 
import joblib
filename = 'C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/FinalModel/NN_Logistic.sav'
joblib.dump(optimized_clf, filename)

#Final Model Predictions on entire dataset 
load_and_score(model_path,data)






