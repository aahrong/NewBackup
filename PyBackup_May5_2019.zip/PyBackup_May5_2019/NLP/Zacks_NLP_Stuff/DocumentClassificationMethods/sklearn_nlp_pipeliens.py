# -*- coding: utf-8 -*-
"""
Created on Wed Dec 19 09:11:04 2018

@author: caridza
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Dec 18 12:57:28 2018

@author: caridza
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Nov 12 11:53:30 2018

@author: caridza
"""
#VirtualEnv: docclassify
#VirtualEnv Location: C:\Users\caridza\Downloads\WPy32-3662\ZacksScripts\docclassify

#######################
#######IMPORTS#########
#######################
#install tensorflow: pip3 install --upgrade https://storage.googleapis.com/tensorflow/mac/cpu/tensorflow-1.12.0-py3-none-any.whl
#base modules 
import sys
from itertools import islice #iterating over vectorized objects (countvectorizer, tfidfvectorizer,etc..)
import numpy as np
import pandas as pd

#third party modules
#import required modules for data preprocessing , feature engineering and model training
from sklearn import model_selection, preprocessing, linear_model, naive_bayes, metrics, svm
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn import decomposition, ensemble
from sklearn.pipeline import Pipeline
from sklearn.pipeline import make_pipeline

import pandas, xgboost, numpy, textblob, string
from keras.preprocessing import text, sequence
from keras import layers, models, optimizers

import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
import matplotlib.pyplot as plt
import matplotlib
import seaborn as sns
   
#custom modules 
#sys.path.insert(0,"C:/Users/caridza/Desktop/pythonScripts/")
sys.path.insert(0,"C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/")
from DocClassFuncs.ClassificationFuncs  import read_corp ,topn_tfidf_freq, create_model_architecture ,create_cnn,create_rnn_lstm, create_rnn_gru,create_bidirectional_rnn,train_model

#punctuation to remove, stopwords to remove, stemming and lemmatizing objects for preprocessing
stemmer = SnowballStemmer('english')
wordnet_lemmatizer = WordNetLemmatizer()
exclude = set(string.punctuation)
stopwords = stopwords.words("english")

#sklearn pipeline function transformer 
from sklearn.preprocessing import FunctionTransformer
def pipelinize(function, active=True):
    def list_comprehend_a_function(list_or_series, active=True):
        if active:
            return [function(i) for i in list_or_series]
        else: # if it's not active, just pass it right back
            return list_or_series
    return FunctionTransformer(list_comprehend_a_function, validate=False, kw_args={'active':active})

#func to remove punc from string and return string
def remove_punctuation(text,excluded_punct=exclude):
    return ' '.join([word for word in nltk.word_tokenize(text) if word not in excluded_punct])

def remove_stop(text,stopwords=stopwords):
    return ' '.join([word for word in text.split(' ') if word not in stopwords])

def stem_words(text,stemmer = stemmer ):
    return ' '.join([stemmer.stem(word) for word in text.split(' ')])


#####################
#Dataset Preperation#
##################### 
#https://www.kaggle.com/baghern/a-deep-dive-into-sklearn-pipelines
#https://scikit-learn.org/stable/auto_examples/model_selection/grid_search_text_feature_extraction.html
# load the dataset
datapath="C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/corpus"
data =read_corp(datapath)

#define 2 lists: labels=target_series, texts=text to train target with
labels, texts = [], []

#file delimited with new line character
#target is alwasy the first word in each new string
for i, line in enumerate(data.split("\n")):
    #split each entry into a list delimited by a space (Word tokenized)
    content = line.split()
    #target value is the first element in each string (delimited by space)
    labels.append(content[0])
    #text is contained in all remaining elments of the list after the label
    texts.append(content[1:])

#create a dataframe using texts and lables
trainDF = pandas.DataFrame()
trainDF['text'] = [" ".join(x) for x in texts] #each row is a string  #trainDF['text'] = texts # each row is a list of word tokenized sentences 
trainDF['label'] = labels

#pipelines by stage 
#using make_pipeline you do not have to specify the name of each process
#Note: we fit the pipeline with x and y , but can only transform the indpendent series, pipelines cannoto handle dependent variables transoformations
#Output: Transformed x and y series split into training and test data
train_x,train_y,valid_x,valid_y= PreProcData(trainDF['text'],trainDF['label'])
def PreProcData(X,Y):
    '''
    'Inputs'
    'X: pandas series of independent variables we want to transform (here a single series of text)
    'Y: label we are using to trian model on (here a string with label info from pandas df series)
    '''
    preprocess_pipeline = make_pipeline(
            pipelinize(remove_punctuation) #remove punctuatoin
            , pipelinize(remove_stop) #remove stopwords
            , pipelinize(stem_words)) #stem words 
    train_x, valid_x, train_y, valid_y = model_selection.train_test_split(X, Y,shuffle=False, stratify=None,test_size=.25, random_state=10)
    preprocess_pipeline.fit(train_x,train_y) 
    #return preprocess_pipeline.transform(train_x.append(valid_x)),train_y.append(valid_y)
    return preprocess_pipeline.transform(train_x),train_y,preprocess_pipeline.transform(valid_x),valid_y


#logistic pipeline with preprocessing
Logistic_TFIDF_Classifer(train_x,train_y,valid_x,valid_y)
def Logistic_TFIDF_Classifer(train_x,train_y,valid_x,valid_y):
    '''
    'Inputs'
    'X: pandas series of independent variables we want to transform (here a single series of text)
    'Y: label we are using to trian model on (here a string with label info from pandas df series)
    '''
    model_pipeline = make_pipeline(
             TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,)
            , linear_model.LogisticRegression())
    
    model_pipeline.fit(train_x,train_y) 
    return model_pipeline.score(valid_x,valid_y)





####USING A TON OF MODELS FOR CHAMPION / CHALLANGER

import sklearn
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn import svm
from sklearn import tree
from sklearn.pipeline import Pipeline


#test and training data that has been preprocessed
train_x,train_y,valid_x,valid_y= PreProcData(trainDF['text'],trainDF['label'])


# Construct svm pipeline
pipe_log =  Pipeline([ ('tfidf_vectorizer', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,)),('logistic',linear_model.LogisticRegression())])

# Construct knn pipeline
pipe_knn = Pipeline([('tfidf_vec', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,))
 ,('knn', KNeighborsClassifier(n_neighbors=6, metric='euclidean'))])

# Construct DT pipeline
pipe_dt = Pipeline([('tfidf_vec',  TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,))
,('dt', tree.DecisionTreeClassifier(random_state=42))])

# Construct Random Forest pipeline
num_trees = 1000
max_features = 10
pipe_rf = Pipeline([('tfidf_vec', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=400, smooth_idf=True, sublinear_tf=False,lowercase=True,))
,('svm', sklearn.decomposition.TruncatedSVD(n_components=10,random_state=42))
,('rf', RandomForestClassifier(n_estimators=num_trees, criterion='gini',max_depth=20,min_samples_split=20,min_samples_leaf=5,max_features=max_features))])

    
#create dictonary to store the name of pipelines in dictonary to be used to display results 
pipe_dic = {0: 'K Nearest Neighbours', 1: 'Decision Tree', 2:'Random Forest', 3:'Logistic Regression'}
#list the four pipelines to execute those pipelines iterativelly
pipelines = [pipe_knn, pipe_dt,pipe_rf,pipe_log]

# Fit the pipelines
for pipe in pipelines:
  pipe.fit(train_x, train_y)

# Compare accuracies
for idx, val in enumerate(pipelines):
  print('%s pipeline test accuracy: %.3f' % (pipe_dic[idx], val.score(valid_x, valid_y)))
  
#extract and print infomration on the best model 
best_accuracy = 0
best_classifier = 0
best_pipeline = ''
for idx, val in enumerate(pipelines):
    if val.score(train_x, train_y) > best_accuracy:
        best_accuracy = val.score(valid_x, valid_y)
        best_pipeline = val
        best_classifier = idx
print('%s Classifier has the best accuracy of %.2f' % (pipe_dic[best_classifier],best_accuracy))






#logistic pipeline with preprocessing
Logistic_TFIDF_Classifer(trainDF['text'],trainDF['label'])
def Logistic_TFIDF_Classifer(X,Y):
    '''
    'Inputs'
    'X: pandas series of independent variables we want to transform (here a single series of text)
    'Y: label we are using to trian model on (here a string with label info from pandas df series)
    '''
    model_pipeline = make_pipeline(
            pipelinize(remove_punctuation) #remove punctuatoin
            , pipelinize(remove_stop) #remove stopwords
            , pipelinize(stem_words)
            , TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000, smooth_idf=True, sublinear_tf=False,lowercase=True,)
            , linear_model.LogisticRegression()
            ) #stem words 
    
    train_x, valid_x, train_y, valid_y = model_selection.train_test_split(X, Y,shuffle=False, stratify=None,test_size=.25, random_state=10)
    model_pipeline.fit(train_x,train_y) 
    return model_pipeline.score(valid_x,valid_y)














preprocess_pipeline = Pipeline([
        ('remove_punctuation', pipelinize(remove_punctuation))
        , ('remove_stop', pipelinize(remove_stop))
        , ('stem_words', pipelinize(stem_words))
     
        , ('tfidf_vectorizer', TfidfVectorizer(analyzer='word'
                                               , token_pattern=r'\w{1,}'
                                               , max_features=5000
                                               , smooth_idf=True
                                               , sublinear_tf=False
                                               #, stop_words='english'
                                               ,lowercase=True,))
        ,('logistic',linear_model.LogisticRegression())
        

    ])


preprocess_pipeline.fit(train_x, train_y)
score = preprocess_pipeline.score(valid_x , valid_y)
print('Logistic Regression pipeline test accuracy: %.3f' % score)




#describe / view dataframe 
trainDF.info()
trainDF.describe()
trainDF.head()
trainDF.groupby('label').describe()
plotdf = trainDF.copy()
plotdf['txt_len'] = plotdf['text'].apply(len)

%matplotlib inline
plotdf['txt_len'].plot(bins=50,kind = 'hist')
plotdf.hist(column='txt_len',by='label',bins=50, figsize=(10,4))
sns.pairplot(plotdf, hue='label', size=3)
######################
##Data partioning#####
##& Target Encoding###
######################
# split the dataset into training and validation datasets 
#random_state=10 used to proivde constant seed to splitting algo to ensure reproducability 
#help(model_selection.train_test_split)
train_x, valid_x, train_y, valid_y = model_selection.train_test_split(trainDF['text'], trainDF['label'],shuffle=False, stratify=None,test_size=.25, random_state=10)



#label and encode target variable so it can be used in ML models 
#encoder takes the target pandas sereies of labels and converts them to numeric indecies for modeling 
encoder = preprocessing.LabelEncoder()
train_y  = encoder.fit_transform(train_y)
valid_y = encoder.fit_transform(valid_y)

#######################
##Feature Engineering##
#######################
#1. Count Vectors as features
#here raw text data will be transformed into feature vectors and new features will be created using the existing dataset
#features will be derived from: count vectors, tf-idf vectors(word level, n-gram levle, character level), word embeddings, text/nlp features , topic models 

count_vect = CountVectorizer(analyzer='word'
                             , token_pattern=r'\w{1,}'
                             ,encoding='utf-8'
                             , strip_accents=None
                             , decode_error='strict'
                             , preprocessor=None
                             , stop_words='english'
                             , lowercase=True
                             , max_df=.5
                             , min_df=.01
                             , max_features=10000 
                             , binary=False
                             , ngram_range=(1,1)
                             )

count_vect.fit_transform(trainDF['text'])
count_vect._validate_vocabulary()
print('feature names','/n',count_vect.get_feature_names())

# transform the training and validation data using count vectorizer object
#Note: Must convert list of toeknized words back to strings to enable word tokenization 
xtrain_count =  count_vect.transform(train_x.apply(lambda x: " ".join(x) ))
xvalid_count =  count_vect.transform(valid_x.apply(lambda x: " ".join(x) ))

#
#2.TF-idf Vectors as features 
#
#TF-IDF score represents the relative importance of a term in the document and the entire corpus. 
##  TF(t) = (Number of times term t appears in a document) / (Total number of terms in the document)
##  IDF(t) = log_e(Total number of documents / Number of documents with term t in it)
#TF-IDF Vectors can be generated at different levels of input tokens (words, characters, n-grams)
##  a. Word Level TF-IDF : Matrix representing tf-idf scores of every term in different documents
##  b. N-gram Level TF-IDF : N-grams are the combination of N terms together. This Matrix representing tf-idf scores of N-grams
##  c. Character Level TF-IDF : Matrix representing tf-idf scores of character level n-grams in the corpus

#building tfidf with pipelines: https://buhrmann.github.io/sklearn-pipelines.html
#evaluating tfidf: https://buhrmann.github.io/tfidf-analysis.html

# word level tf-idf
tfidf_vect = TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=5000,smooth_idf=True, sublinear_tf=False, stop_words='english',lowercase=True,)
tfidf_vect.fit(trainDF['text'])
xtrain_tfidf =  tfidf_vect.transform(train_x)
xvalid_tfidf =  tfidf_vect.transform(valid_x)
print('TFIDF Descriptive Information')
print('Top 20 items in vocab {}'.format(list(islice(tfidf_vect.vocabulary_.items(), 20)))) #extract elements from sequence using isslice
print('Total unique tokens in vocab: {}'.format(len(tfidf_vect.vocabulary_)))
print('sparse matrix shape:', xtrain_tfidf.shape)
print('nonzero count:', xtrain_tfidf.nnz)
print('sparsity: %.2f%%' % (100.0 * xtrain_tfidf.nnz / (xtrain_tfidf.shape[0] * xtrain_tfidf.shape[1])))
print('top n terms from tfidf','\n',topn_tfidf_freq(tfidf_vect, xtrain_tfidf)[0])
print('top n weights from top n terms from tfidf','\n',topn_tfidf_freq(tfidf_vect, xtrain_tfidf)[1])

# ngram level tf-idf 
tfidf_vect_ngram = TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', ngram_range=(2,3), max_features=5000, stop_words='english',lowercase=True)
tfidf_vect_ngram.fit(trainDF['text'])
xtrain_tfidf_ngram =  tfidf_vect_ngram.transform(train_x)
xvalid_tfidf_ngram =  tfidf_vect_ngram.transform(valid_x)
print('TFIDF Descriptive Information')
print('Top 20 items in vocab {}'.format(list(islice(tfidf_vect_ngram.vocabulary_.items(), 20)))) #extract elements from sequence using isslice
print('Total unique tokens in vocab: {}'.format(len(tfidf_vect_ngram.vocabulary_)))
print('sparse matrix shape:', xtrain_tfidf_ngram.shape)
print('nonzero count:', xtrain_tfidf_ngram.nnz)
print('sparsity: %.2f%%' % (100.0 * xtrain_tfidf_ngram.nnz / (xtrain_tfidf_ngram.shape[0] * xtrain_tfidf_ngram.shape[1])))
print('top n weights from top n terms from tfidf','\n',topn_tfidf_freq(tfidf_vect_ngram, xtrain_tfidf_ngram)[1])


#
#1.Naives base model 
#
#Naive Bayes is a classification technique based on Bayes’ Theorem with an assumption of independence among predictors.
# A Naive Bayes classifier assumes that the presence of a particular feature in a class is unrelated to the presence of any other feature 
# Naive Bayes on Word Level TF IDF Vectors
accuracy = train_model(naive_bayes.MultinomialNB(), xtrain_tfidf, train_y, xvalid_tfidf,valid_y)
print("NB, WordLevel TF-IDF: ", accuracy)

#
#2.logistic
#
# Linear Classifier on Word Level TF IDF Vectors
accuracy = train_model(linear_model.LogisticRegression(), xtrain_tfidf, train_y, xvalid_tfidf,valid_y)
print("LR, WordLevel TF-IDF: ", accuracy)

##pipeline implementation (TBD)
pipeline = Pipeline([
        ('process' , PreProcessClass()), #step 1:preprocess data 
        , ('navs',naive_bayes.MultinomialNB())
        , ('logistic',lienar_model.LogisticRegression())
        , ('ensemble',custom_emsemble())
        ,('validate',custom_validation())
        , ('tune', custom_tuning())
        ,('champion',champion_mod())
        ,('visualize',custom_vis())
        ])
    
###############################
####NOTE: HYPERPARAMER TUNING REQUIRED TO GET OPTIMAL RESULTS FOR BELOW ML BASED MODELING APPROACHES
####NOTE: Random forest is a good solution for this problem. we have a lot of different levels in our 
    ###   target with few observations to train for each, RF does good here if hyper parameters are tunned correctly 
##############################
#3.Randomforest
#
accuracy = train_model(xgboost.XGBClassifier(), xtrain_tfidf.tocsc(), train_y, xvalid_tfidf.tocsc(),valid_y)
print("Xgb, WordLevel TF-IDF: ", accuracy)


#NN
classifier = create_model_architecture(xtrain_tfidf_ngram.shape[1])
accuracy = train_model(classifier, xtrain_tfidf, train_y, xvalid_tfidf, valid_y,is_neural_net=True)
print("NN, Ngram Level TF IDF Vectors",  accuracy)














#import inspect 
#print(inspect.getargspec(model_selection.train_test_split))
#print(inspect.getfullargspec(model_selection.train_test_split))