# -*- coding: utf-8 -*-
"""
Created on Mon Nov 12 11:53:30 2018

@author: caridza
"""
#VirtualEnv: docclassify
#VirtualEnv Location: C:\Users\caridza\Downloads\WPy32-3662\ZacksScripts\docclassify
#######################
#######IMPORTS#########
#######################
#install tensorflow: pip3 install --upgrade https://storage.googleapis.com/tensorflow/mac/cpu/tensorflow-1.12.0-py3-none-any.whl
#base modules 
import pandas, xgboost, numpy, textblob, string, pickle, sys
from itertools import islice #iterating over vectorized objects (countvectorizer, tfidfvectorizer,etc..)
#required modules for data preprocessing and modeling
import sklearn
from sklearn import decomposition, ensemble, tree, svm,model_selection, preprocessing, linear_model, naive_bayes, metrics, svm
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer,TfidfTransformer
from sklearn.pipeline import Pipeline,make_pipeline
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler,MinMaxScaler
from sklearn.model_selection import train_test_split,GridSearchCV,cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import GradientBoostingClassifier,RandomForestClassifier,AdaBoostClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC,LinearSVC
#text parsing
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
#plotting
import matplotlib.pyplot as plt
import matplotlib
import seaborn as sns
#custom modules 
sys.path.insert(0,"C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/")
from DocClassFuncs.ClassificationFuncs  import read_corp ,topn_tfidf_freq, create_model_architecture ,create_cnn,create_rnn_lstm, create_rnn_gru,create_bidirectional_rnn,train_model, pipelinize, remove_punctuation, remove_stop, stem_words,PreProcData,remove_punctuation,remove_stop,stem_words,Logistic_TFIDF_Classifer,KNN_TFIDF_Classifer,DT_TFIDF_Classifer,RF_TFIDF_Classifer,generic_pipeline, model_eval

#punctuation to remove, stopwords to remove, stemming and lemmatizing objects for preprocessing
stemmer = SnowballStemmer('english')
wordnet_lemmatizer = WordNetLemmatizer()
exclude = set(string.punctuation)
stopwords = stopwords.words("english")

#####################
#Dataset Preperation#
##################### 
#https://www.kaggle.com/baghern/a-deep-dive-into-sklearn-pipelines
#https://scikit-learn.org/stable/auto_examples/model_selection/grid_search_text_feature_extraction.html
# load the dataset
datapath="C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/NN_ClassificationModelData.pickle"       
data =pd.read_pickle(datapath)

#create a dataframe using texts and lables
trainDF = pandas.DataFrame()
trainDF['text'] = data['origtext']
trainDF['label'] = data['LegalAction']

#transform categorical target into numeric index 
le = preprocessing.LabelEncoder() 
le.fit(trainDF['label'])
trainDF['label_id'] =le.transform(trainDF['label'])
label_id_df = trainDF[['label', 'label_id']].drop_duplicates().sort_values('label_id')
label_to_id = dict(label_id_df.values)
id_to_label = dict(label_id_df[['label_id', 'label']].values)
                                      
#preprocessing pipeline
train_x,train_y,valid_x,valid_y= PreProcData(trainDF['text'],trainDF['label'],test_size=.1)
print(train_y.value_counts(normalize=True),'\n',valid_y.value_counts(normalize=True))

#generate model pipeline
pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(stop_words=stopwords)),
    ('feature_selection', SelectFromModel(LinearSVC(loss='l2',penalty="l1",dual=False))), 
    ('clf', RandomForestClassifier(n_estimators=20)),
])

#hyper parameters to execute grid search on 
parameters = {
    'tfidf__max_df': ( 0.5, 0.75,1),
    'tfidf__ngram_range': [(1, 1), (1, 2)],
    'clf__max_depth': [5,10,15],
    'clf__min_samples_split': [10,15],
    'clf__max_features': [3, 10],
    'clf__bootstrap': [True,False],
    'clf__criterion':["gini","entropy"],

    }

grid_search_tune = GridSearchCV(pipeline, parameters, cv=2, n_jobs=4, verbose=3)
grid_search_tune.fit(train_x, train_y)
report(grid_search.cv_results_)

#############################################################################################
#GRID SEARCH ACROSS MULTIPLE MODELS 
#https://towardsdatascience.com/multi-class-text-classification-with-scikit-learn-12f1e60e0a9f
#https://www.kdnuggets.com/2018/01/managing-machine-learning-workflows-scikit-learn-pipelines-part-3.html


#create tf-idf for entire dataframe
tfidf = TfidfVectorizer(sublinear_tf=True, min_df=5, norm='l2', encoding='latin-1', ngram_range=(1, 2), stop_words='english')
features = tfidf.fit_transform(trainDF.text).toarray()
labels = trainDF.label_id
features.shape

#identify terms most corrolated with each target level 
from sklearn.feature_selection import chi2
import numpy as np
N = 4
for label, label_id in sorted(label_to_id.items()):
    print(label)
    features_chi2 = chi2(features, labels == label_id)
    indices = np.argsort(features_chi2[0])
    feature_names = np.array(tfidf.get_feature_names())[indices]
    unigrams = [v for v in feature_names if len(v.split(' ')) == 1]
    bigrams = [v for v in feature_names if len(v.split(' ')) == 2]
    print("# '{}':".format(label))
    print("  . Most correlated unigrams:\n. {}".format('\n. '.join(unigrams[-N:])))
    print("  . Most correlated bigrams:\n. {}".format('\n. '.join(bigrams[-N:])))
  
#build training tfidf representaiton for modeling 
count_vect = CountVectorizer()
X_train_counts = count_vect.fit_transform(train_x)
tfidf_transformer = TfidfTransformer()
X_train_tfidf = tfidf_transformer.fit_transform(X_train_counts)

#models to evaluate 
models = [
    RandomForestClassifier(n_estimators=200, max_depth=3, random_state=0),
    LinearSVC(),
    MultinomialNB(),
    LogisticRegression(random_state=0),
]

#cross validation metrics setup 
CV = 5
cv_df = pd.DataFrame(index=range(CV * len(models)))
entries = []
for model in models:
  model_name = model.__class__.__name__
  accuracies = cross_val_score(model, features, labels, scoring='balanced_accuracy', cv=CV)
  for fold_idx, accuracy in enumerate(accuracies):
    entries.append((model_name, fold_idx, accuracy))
cv_df = pd.DataFrame(entries, columns=['model_name', 'fold_idx', 'accuracy'])

#plot cv 
import seaborn as sns
sns.boxplot(x='model_name', y='accuracy', data=cv_df)
sns.stripplot(x='model_name', y='accuracy', data=cv_df, 
              size=8, jitter=True, edgecolor="gray", linewidth=2)
plt.show()

cv_df.groupby('model_name').accuracy.mean()



# Utility function to report best scores
def report(results, n_top=3):
    for i in range(1, n_top + 1):
        candidates = np.flatnonzero(results['rank_test_score'] == i)
        for candidate in candidates:
            print("Model with rank: {0}".format(i))
            print("Mean validation score: {0:.3f} (std: {1:.3f})".format(
                  results['mean_test_score'][candidate],
                  results['std_test_score'][candidate]))
            print("Parameters: {0}".format(results['params'][candidate]))
            print("")






















#logistic pipeline with preprocessed data(score new data:log_pipe.score(valid_x,valid_y))
pipe_log = Pipeline([('tfidf_vec', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=4000, smooth_idf=True, sublinear_tf=False,lowercase=True,)),('log',  linear_model.LogisticRegression())])
pipe_log.steps #view all steps in above pipeline 
vars(pipe_log.named_steps['log'])
model_perf_dict = model_eval(pipe_log, train_x,train_y,valid_x,valid_y)

  

#knn pipeline 
pipe_knn = KNN_TFIDF_Classifer(train_x,train_y,valid_x,valid_y)
knn_perf_dict = model_eval(pipe_knn, train_x,train_y,valid_x,valid_y)

  
#dt pipeline 
#pipe_dt = DT_TFIDF_Classifer(train_x,train_y,valid_x,valid_y)
pipe_dt = generic_pipeline(train_x,train_y,valid_x,valid_y 
                 ,TfidfVectorizer
                 , tree.DecisionTreeClassifier
                 ,{'analyzer':'word', 'token_pattern':r'\w{1,}', 'max_features':5000, 'smooth_idf':True, 'sublinear_tf':False,'lowercase':True}
                 ,{'random_state':42})
dt_perf_dict = model_eval(pipe_dt, train_x,train_y,valid_x,valid_y)

#rf pipeline 
pipe_rf = generic_pipeline(train_x,train_y,valid_x,valid_y 
                 ,TfidfVectorizer
                 ,RandomForestClassifier
                 ,{'analyzer':'word', 'token_pattern':r'\w{1,}', 'max_features':5000, 'smooth_idf':True, 'sublinear_tf':False,'lowercase':True}
                 #,{'n_estimators':100, 'criterion':'gini','max_depth':20,'min_samples_split':20,'min_samples_leaf':5,'max_features':10})
                 ,{'n_estimators':100, 'criterion':'gini'})
rf_perf_dict = model_eval(pipe_rf, train_x,train_y,valid_x,valid_y)

#mlp pipeline 
pipe_mlp = generic_pipeline(train_x,train_y,valid_x,valid_y 
                 ,TfidfVectorizer
                 ,MLPClassifier
                 ,{'analyzer':'word', 'token_pattern':r'\w{1,}', 'max_features':5000, 'smooth_idf':True, 'sublinear_tf':False,'lowercase':True}
                 ,{'hidden_layer_sizes':(10,), 'activation':'relu','solver':'adam','learning_rate':'constant','shuffle':True})
mlp_perf_dict = model_eval(pipe_mlp, train_x,train_y,valid_x,valid_y)

#evalute models 
#create dictonary to store the name of pipelines in dictonary to be used to display results 
pipe_dic = {0: 'logistic', 1: 'knn', 2:'DT', 3:'RF',4:'mlp'}

#list the four pipelines to execute those pipelines iterativelly
pipelines = [pipe_log,pipe_knn, pipe_dt,pipe_rf,pipe_mlp]

# Fit the pipelines
for pipe in pipelines:
  pipe.fit(train_x, train_y)

# Compare accuracies
for idx, val in enumerate(pipelines):
  print('%s pipeline test accuracy: %.3f' % (pipe_dic[idx], val.score(valid_x, valid_y)))
  
#extract and print infomration on the best model 
best_accuracy = 0
best_classifier = 0
best_pipeline = ''
for idx, val in enumerate(pipelines):
    if val.score(train_x, train_y) > best_accuracy:
        best_accuracy = val.score(valid_x, valid_y)
        best_pipeline = val
        best_classifier = idx
print('%s Classifier has the best accuracy of %.2f' % (pipe_dic[best_classifier],best_accuracy))

#######SAVING MODEL AND LOADING MODEL FOR LATER USE#######
#NOTE: Generate requirements.txt when exporting model so you can replicate the requirments needed to run the saved model 
#save best model to pickle for use on future data 
filename = 'nn_finalmodel.sav'
pickle.dump(pip_log, open(filename,'wb'))

#load pickled model for evaluation on unseen data 
loaded_model = pickle.load(open(filename,'rb'))
OOS_predictions = loaded_model.score(valid_x,valid_y)
print(OOS_predictions)

#option 2:save model using joblib(useful when algo requires a lot of parameters or store the entire dataset)
#save model 
joblib.dump(pip_log, filename)
#load model 
loaded_model = joblib.load(filename)
OOS_predictions = loaded_model.score(valid_x,valid_y)
print(OOS_predictions)

