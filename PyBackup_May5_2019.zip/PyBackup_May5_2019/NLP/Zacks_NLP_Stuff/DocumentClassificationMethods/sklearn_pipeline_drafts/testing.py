# -*- coding: utf-8 -*-
"""
Created on Tue Jan 22 13:33:37 2019

@author: caridza
"""

#how to use super()
class ParentOne:
    def __init__(self):
        self.val = 5
        print('Called constructor of ParentOne')
    
    def test(self):
        print('Called test from ParentOne')
        
class Child(ParentOne):
    def __init__(self):
        super().__init__()
        print('Called constructor of Child')
        
    def test(self):
        super().test()
        print('Called test from Child')


#gs_mlp.estimator.named_steps['clf']
key_metrics = ['mean_train_score','mean_test_score','std_train_score','std_test_score']

for idx, gs in enumerate(grids):
    
    for metric in key_metrics: 
        print(grid_dict[idx],gs.cv_results_[metric])
        
    print(gs.cv_results_)
    preds = final_rf.predict(train_x)
    print(cf = metrics.confusion_matrix(train_y, preds))
    
dir(gs_mlp.estimator._final_estimator)


#http://zacstewart.com/2014/08/05/pipelines-of-featureunions-of-pipelines.html
#https://zablo.net/blog/post/pandas-dataframe-in-scikit-learn-feature-union
datapath = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/SentDF.pickle"
target = 'MonetaryFine'
inputtxt = 'Sentence'


#dic of results 
res = {'1': [False] * 119647 ,'2':[True] * 119647}

#aggregate dic of lists 
outvals = [pd.Series(res[key]) for key in res.keys()]

#output series 
outSeries = pd.Series([element for list_ in outvals for element in list_])
outSeries.value_counts()

# load the dataset
data = pd.read_pickle(datapath)
data
data.assign(new3= outSeries.values)


#create ordered dict from dictonary 
from collections import OrderedDict
dic= {'1': [False] * 119647 ,'2':[True] * 119647}
order_of_keys = [str(i) for i in range(1,3)] #order in which you want your keys to be ordered 
list_of_tuples = [(key, dic[key]) for key in order_of_keys] #create an ordered list of tuples from order_of_keys mapping
your_dict = OrderedDict(list_of_tuples)#create ordred dict



#APPLY MULTI - CRITERAS TO GENERATE NEW COLUMN 
#using lambda to look around rows above and below 
df = trainDF
CM_conditions = [ ((testdf.Managment == True)|(testdf.Managment.shift(1)== True)|(testdf.Managment.shift(2)== True)|(testdf.Managment.shift(-1)== True)|(testdf.Managment.shift(-2)== True)) & ((testdf.Change ==True) |(testdf.Change.shift(1)==True) |(testdf.Change.shift(-1)==True))
                ,(testdf.Managment == True) & (testdf.Change == True)
                ,(testdf.Managment == False) & (testdf.Change == False)]
CM_choices = [True,True,False]
2
TS_conditions = [(testdf.Trade == True) & (testdf.Suspension == True)
                ,(testdf.Trade == False) & (testdf.Suspension == False)
                ,(testdf.Trade != False) & (testdf.Suspension == False)
                ,((testdf.Trade == True)|(testdf.Trade.shift(1)== True)|(testdf.Trade.shift(2)== True)|(testdf.Trade.shift(-1)== True)|(testdf.Trade.shift(-2)== True)) & ((testdf.Suspension ==True) |(testdf.Suspension.shift(1)==True) |(testdf.Suspension.shift(-1)==True))                ]
TS_choices = [True,False,False,True]

SD_conditions = [(testdf.Statutary == True) & (testdf.Disqualification == True)
                ,(testdf.Statutary == False) & (testdf.Disqualification == False)
                ,(testdf.Statutary != False) & (testdf.Disqualification == False)
                ,((testdf.Statutary == True)|(testdf.Statutary.shift(1)== True)|(testdf.Statutary.shift(2)== True)|(testdf.Statutary.shift(-1)== True)|(testdf.Statutary.shift(-2)== True)) & ((testdf.Disqualification ==True) |(testdf.Disqualification.shift(1)==True) |(testdf.Disqualification.shift(-1)==True))                ]
SD_choices = [True,False,False,True]


#value associated wiht each condition 
TS_choices = [True,False,False,True]

df['ChangeManagment'] = np.select(CM_conditions,CM_choices,default=False)
df['TradeSuspension'] = np.select(TS_conditions,TS_choices,default=False)
df['StatutoryDisqual'] = np.select(SD_conditions,SD_choices,default=False)

df.ChangeManagment.value_counts()
df.TradeSuspension.value_counts()
df.StatutoryDisqual.value_counts()
####
###
####
def replace_words(text,wordList):
    #input:string 
    #output:string with words in wordList replaced
    for word in wordList:
        if word in text:
            text=text.replace(word,' ')
    
    return text

text = 'Wells Fargo is in big Trouble with Bank of America on Monday'
wordlist = ['Wells Fargo','Bank of America','Monday']
replace_words(text,wordlist)

   
 def remove_stop(text,stopwords=['the','is','a','i','are','it']):
    return ' '.join([word for word in text.split(' ') if word.lower() not in stopwords])
      



sk_model_stats(pipe_fit,data_dic['training']['x'],data_dic['training']['y'],data_type='train')
def sk_model_stats(pipe_dict,x,y,data_type='train'):
cm_stats = []
pipe_dict = pipe_fit
x = data_dic['training']['x']
y = data_dic['training']['y']
data_type='train'

for key,value in pipe_dict.items():
    preds = value.predict(x)
    prob_preds = value.predict_proba(x)
    print('Model Validation Charts {}:'.format(key))
    #plotmetrics(y,prob_preds,preds)

    cm = metrics.confusion_matrix(y,preds).flatten()
    df=pd.DataFrame(data={'model':key
                          ,'data':data_type
                          ,'logloss':metrics.log_loss(y, prob_preds)
                          ,'accuracy_score':metrics.accuracy_score(y,preds)
                          ,'roc_auc':metrics.roc_auc_score(y,preds,average='macro')
                          ,'recall':metrics.recall_score(y,preds)
                          ,'precision':metrics.precision_score(y,preds)
                          #,'precision_f1_bal':mean(metrics.precision_recall_fscore_support(y,preds,average='macro'))
                          #,'coverage_error':metrics.coverage_error(y,preds)
                          ,'f1_score':metrics.f1_score(y,preds)
                          ,'fbeta_score': metrics.fbeta_score(y,preds,beta=.75)
                          ,'mae': metrics.mean_absolute_error(y,preds)
                          ,'mse': metrics.mean_squared_error(y,preds)
                          ,'median_absolute_error': metrics.median_absolute_error(y,preds)
                          ,'TrueNeg':[cm[0]]
                          ,'FalseNeg':[cm[1]]
                          ,'FalsePos':[cm[2]]
                          ,'TruePos':[cm[3]]
                          })
    cm_stats.append(df)
appended_data = pd.concat(cm_stats, axis=0)   
out = appended_data.sort_values(by=['f1_score'],ascending=False) 



#for a list of tokenized sentences 
def orig_text_clean_inline(Sent, stopwords=['the','is','a','i','are','it'],stemmer=None):    
    startval = Sent 
    step1 = [remove_punctuation(x) for x in startval]
    step2 = [remove_nonchars(x) for x in step1]
    step3 = [remove_stop(x,stopwords=stopwords) for x in step2]
    step4 = [stem_words(x,stemmer=stemmer) for x in step3] 
    return step4
