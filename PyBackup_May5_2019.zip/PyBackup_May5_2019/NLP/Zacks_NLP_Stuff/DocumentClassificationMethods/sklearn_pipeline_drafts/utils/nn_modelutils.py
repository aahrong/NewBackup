# -*- coding: utf-8 -*-
"""
Created on Wed Jan 16 09:01:40 2019

@author: caridza
"""
import sys
import pickle
import joblib
import pandas as pd
from sklearn import preprocessing
import nltk
from nltk.corpus import stopwords
import re 
from sklearn.pipeline import Pipeline,make_pipeline
from nltk.corpus import stopwords
import string
from nltk.stem.snowball import SnowballStemmer
from sklearn.base import BaseEstimator, TransformerMixin
#from negative_news2.consumer.utils import load_and_score

#stemmer = SnowballStemmer('english')
#stopwords = stopwords.words("english")

#################################################################
###############FUNCTIONS THAT MUST BE USED WHEN RUN##############
#################################################################
#load model and score new data through the pipeline defined in the finalmodel 
def load_and_score(model_path,data2score,concat_2df,stemmer=None,stopwords=None):
    
    #Final Prediction on entire dataset
    #load model 
    loaded_model = joblib.load(model_path)
    
    #len(newdata.loc[newdata.index.duplicated(keep='first')])
    newdata =orig_text_clean(data2score,target='LegalAction',maplabelvars=['source'],stopwords=stopwords,stemmer=stemmer)# orig_text_clean(data2score)
    
    #preds on new data 
    predictions = loaded_model.predict_proba(newdata)
    preds = pd.DataFrame(data=predictions, columns = ['P_Nolegal','P_legal'])
    preds['LegalAction'] = loaded_model.predict(newdata)
    
    if concat_2df == True:
        #generating a submission file
        results = pd.concat([newdata, preds], axis=1)
        return results 
    else: 
        return preds
    
#preprocess data 
#func to remove punc from string and return string
def remove_punctuation(text,excluded_punct={'+', ':', '[', '^', '"', '|', '{', '@', '=', ')', '%', '#', '`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}):
    return ' '.join([word for word in nltk.word_tokenize(text) if word not in excluded_punct])

#func to remove stop words 
def remove_stop(text,stopwords=['the','is','a','i','are','it']):
    return ' '.join([word for word in text.split(' ') if word.lower() not in stopwords])

#func to stem words 
def stem_words(text,stemmer=None):
    return ' '.join([stemmer.stem(word) for word in text.split(' ')])

#remove non alpha characters from text 
def remove_nonchars(text):
    return ' '.join([re.sub('[^A-Za-z|^\$|^\.]+', ' ', word) for word in text.split(' ') if (word.isalnum() and len(word)>2)])



def orig_text_clean(data,target='LegalAction',maplabelvars=['source'],stopwords=['the','is','a','i','are','it'],stemmer=None):
    trainDF = pd.DataFrame()
    trainDF['text'] = data['origtext'].apply(lambda x: remove_punctuation(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_nonchars(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_stop(x,stopwords=stopwords))
    trainDF['cleantxt'] = trainDF['text'].apply(lambda x: stem_words(x,stemmer=stemmer))
    
    
    trainDF['label'] = data[target]
    trainDF['source'] = data['source']
    trainDF['txt_lngth'] = trainDF['cleantxt'].apply(lambda x: len(x))
    trainDF['txt_words'] = trainDF['cleantxt'].apply(lambda x: len(x.split(' ')))
    trainDF['txt_nonstopwords'] = trainDF['cleantxt'].apply(lambda x: len([t for t in x.split(' ') if t not in stopwords]))
    trainDF['total_commas'] = data['origtext'].apply(lambda x: x.count(','))
    
    le = preprocessing.LabelEncoder() 
    le.fit(trainDF['label'])
    trainDF['label_id'] =le.transform(trainDF['label'])
    le.fit(trainDF['source'])
    trainDF['source_id'] =le.transform(trainDF['source'])
    
    for var in maplabelvars: 
        le.fit(trainDF[var])
        trainDF[var+'_id'] =le.transform(trainDF[var])
        
    trainDF=trainDF.reset_index(drop=True)
    return trainDF 


#transformer to select a column from dataframe to be used for processing 
class TextSelector(BaseEstimator, TransformerMixin):
    """
    Transformer to select a single column from the data frame to perform additional transformations on
    Use on text columns in the data
    """
    def __init__(self, key):
        self.key = key

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return X[self.key]
    
    def get_feature_names(self):
        return self.key
    
class NumberSelector(BaseEstimator, TransformerMixin):
    """
    Transformer to select a single column from the data frame to perform additional transformations on
    Use on numeric columns in the data
    """
    def __init__(self, key):
        self.key = key

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return X[[self.key]]
    
    def get_feature_names(self):
        return self.key
