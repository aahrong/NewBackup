# -*- coding: utf-8 -*-
#VirtualEnv: docclassify
#VirtualEnv Location: C:\Users\caridza\Downloads\WPy32-3662\ZacksScripts\docclassify
#######################
#######IMPORTS#########
#######################
#install tensorflow: pip3 install --upgrade https://storage.googleapis.com/tensorflow/mac/cpu/tensorflow-1.12.0-py3-none-any.whl
#base modules 
import pandas as pd
import xgboost, numpy, textblob, string, pickle, sys
from itertools import islice #iterating over vectorized objects (countvectorizer, tfidfvectorizer,etc..)
#required modules for data preprocessing and modeling
import sklearn
from sklearn import decomposition, ensemble, tree, svm,model_selection, preprocessing, linear_model, naive_bayes, metrics, svm
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer,TfidfTransformer
from sklearn.pipeline import Pipeline,make_pipeline
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler,MinMaxScaler
from sklearn.model_selection import train_test_split,GridSearchCV,cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import GradientBoostingClassifier,RandomForestClassifier,AdaBoostClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC,LinearSVC
from sklearn.feature_selection import RFECV
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import SelectFromModel
from sklearn.pipeline import FeatureUnion 
from sklearn.model_selection import StratifiedKFold
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.gaussian_process.kernels import RBF
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis

#text parsing
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
#plotting
import matplotlib.pyplot as plt
import matplotlib
import seaborn as sns
from collections import Counter
import numpy as np
import mpu
import scikitplot as skplt
import joblib
import re

#custom modules 
import negative_news2
from negative_news2 import consumer
from negative_news2.consumer import utils
from negative_news2.consumer.utils  import TextSelector, NumberSelector,orig_text_clean,load_and_score,remove_punctuation,remove_stop,stem_words,remove_nonchars,pipelinize,sk_model_stats

#required for corrolation 
import scipy
import statistics
from scipy.stats.stats import pearsonr   

#sys.path.insert(0,"C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/")
#import DocClassFuncs
#from DocClassFuncs import ClassificationFuncs
#from DocClassFuncs.ClassificationFuncs import TextSelector, NumberSelector
#from DocClassFuncs.ClassificationFuncs  import sk_model_stats,orig_text_clean, pipelinize, remove_punctuation, remove_stop, stem_words,PreProcData, model_eval

#punctuation to remove, stopwords to remove, stemming and lemmatizing objects for preprocessing
stemmer = SnowballStemmer('english')
wordnet_lemmatizer = WordNetLemmatizer()
exclude = set(string.punctuation)
stopwords = stopwords.words("english")


#####################
#Dataset Preperation#
##################### 
#https://www.kaggle.com/baghern/a-deep-dive-into-sklearn-pipelines
#https://scikit-learn.org/stable/auto_examples/model_selection/grid_search_text_feature_extraction.html
#https://scikit-learn.org/stable/auto_examples/text/plot_document_classification_20newsgroups.html#sphx-glr-auto-examples-text-plot-document-classification-20newsgroups-py
#http://zacstewart.com/2014/08/05/pipelines-of-featureunions-of-pipelines.html
#https://zablo.net/blog/post/pandas-dataframe-in-scikit-learn-feature-union

# load the dataset
data = pd.read_pickle("C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/NN_ClassificationModelData2.pickle")

#create a dataframe using texts and lables and conduct preprocessing
#saving objects with label informaiton for visualizations and filtering
trainDF = orig_text_clean(data,target='LegalAction',maplabelvars=['source'],stopwords=stopwords,stemmer=stemmer)
#trainDF['topwords']=trainDF['text'].apply(lambda x: Counter(x.split()).most_common(10))
#trainDF['cleantxt'] = PreProcData(trainDF['text'],trainDF['label'],test_size=0)[0]
#label_id_df = trainDF[['label', 'label_id']].drop_duplicates().sort_values('label_id')
#label_to_id = dict(label_id_df.values)
#id_to_label = dict(label_id_df[['label_id', 'label']].values)

#categorical and numerical columns in dataframe 
target = 'label_id'
features= [c for c in trainDF.columns.values if c  not in ['label','author',target,'source_id','label_id','text','topwords']]
numeric_features= [c for c in trainDF.columns.values if c  not in ['label','author','text',target,'source','source_id','topwords','label_id','cleantxt']]

#create dictonary of unique vocab for each level of the target
unique_vocab={diflab:np.setdiff1d(
        list(trainDF[trainDF['label']==diflab]['cleantxt'].str.split(' ', expand=True).stack().unique())
        , mpu.datastructures.flatten([list(trainDF[trainDF['label']==label]['cleantxt'].str.split(' ', expand=True).stack().unique()) 
                                for label in list(trainDF['label'].unique()) if label !=diflab])
                    ) for diflab in list(trainDF['label'].unique())
        }

#count of unique words per topic                
length_dict = {key: len(value) for key, value in unique_vocab.items()}

#define text transformations to generate
text_feats = {'tfidf_pipe':{'analyzer':'word','ngram_range':(1,1)}
              #,'cooccur_pipe':{'analyzer':'word','ngram_range':(2,2)}
              #,'chargrams_pipe':{'analyzer':'char_wb','ngram_range':(1,3)}
              }

#apply text_feats transformations iterativly into tfidf tranformation pipeline
catfeat_pipe_dic = {key : Pipeline([('selector', TextSelector(key='cleantxt')),
                            ('tfidf',  TfidfVectorizer(analyzer=val['analyzer'], ngram_range=val['ngram_range'], max_features=400,min_df=.01
                                                       ,max_df=.8, smooth_idf=True, norm='l2',sublinear_tf=True,lowercase=True,))
                            ]) for key,val in text_feats.items()
                    }   

#create pipe for each numerical features generated by orig_text_clean 
numfeat_pipe_dic= {val: Pipeline([('selector', NumberSelector(key=val)),('standard', StandardScaler())]) for val in numeric_features}

#create final list of pipelines, starting with text preprocessing, and finishing with the numeric column normalizations(items listed in order of exectuion so we build initial list with text processing and append all numeric processing tasks after)
final_pipeline = [(k,v) for k, v in catfeat_pipe_dic.items()]
final_pipeline.extend([(k,v) for k, v in numfeat_pipe_dic.items()])

#make a pipeline from all of our pipelines, we dao the same thing, but now we use a FeatureUnion to join the feature processing pipelines.
feats = FeatureUnion(final_pipeline)
feats_fit = feats.fit_transform(trainDF)

#extract feature names from each pipeline to map to output df used for prelim statistical analysis  
#note: i am only concertned with tfidf feature names as that is the only transformation in the pipeline, if others were used, we would need to iterate through those steps and pull feature names out as well
catfeat_names = catfeat_pipe_dic['tfidf_pipe'].named_steps['tfidf'].get_feature_names()
numfeat_names =[numfeat_pipe_dic[key].named_steps['selector'].get_feature_names() for key in numfeat_pipe_dic.keys()]
feat_names = catfeat_names +numfeat_names

#creat df to conduct preliminary analysis on 
feat_df=pd.DataFrame(feats_fit.todense())
feat_df.columns = feat_names
feat_df['NN_Target']= trainDF['label_id']
feat_df['news_source']= trainDF['source']

#######################################
##PRELIMINARY DESCRIPTIVE STATISTICS###
####USING FINAL TRANFORMATION DATASET##
#######################################
import pandas as pd
import researchpy as rp
import seaborn as sns
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import operator 
import math 
#num vs cat cols
Numcols=list(feat_df.select_dtypes(include=[np.number]).columns.values)
nontxt_numcol = [ 'txt_lngth', 'txt_words','txt_nonstopwords','total_commas']
numcols= list(set(Numcols)-set(nontxt_numcol))
catcols = feat_df.columns.difference(list(feat_df.select_dtypes(include=[np.number]).columns.values))

#numeric and cat col stats
NumCol_stats = rp.summary_cont(feat_df[numcols])
NumCol_stats['kurtosis']= feat_df[numcols].kurtosis().values
NumCol_stats['skew']=feat_df[numcols].skew().values
CatCol_stats = rp.summary_cat(feat_df[catcols])


#melt df for easy processing 
melt_df = pd.melt(feat_df[numcols], id_vars = 'NN_Target',var_name='features',value_name='value')
melt_df.value.astype(float)

#violen plots #MUST FIGURE OUT BEST NORMALIZATION TECHNIQUE TO VIEW DATA 
#violen_df =melt_df
#min_val=min(violen_df ['value'])
#max_val=max(violen_df ['value'])
#violen_df ['value']=violen_df ['value'].apply(lambda x: (x-min_val)/(max_val-min_val))#.apply(lambda x: math.log(abs(x)) if abs(x)>0 else 0)
#violen_df ['value']=violen_df ['value'].apply(lambda x: x if x < .1 else .1)

#violen plots
#for i in range(0,len(numcols),10):
#    plt.figure(figsize=(10,10))
#    sns.violinplot(x="features",y="value",hue="NN_Target",data=violen_df.loc[violen_df['features'].isin(numcols[i:i+10])],split=True,inner='quart')
#    plt.xticks(rotation=90)
#    plt.show()
    
#plot target distribution
#plot count of target and only cat vairable in dataset
#_, axes = plt.subplots(nrows=1, ncols=2, figsize=(12, 4))
#a= sns.countplot(x='NN_Target', data=feat_df, ax=axes[0]);
#b=sns.countplot(x='news_source', data=feat_df, ax=axes[1]);b.set_xticklabels(b.get_xticklabels(),rotation=90)

#plot count of target and only cat vairable in dataset
#df_plot = feat_df.groupby(['news_source', 'NN_Target']).size().reset_index().pivot(columns='news_source', index='NN_Target', values=0)
#df_plot = df_plot.reindex(columns=['NN_Target'])
#df_plot.plot(x=df_plot.index, kind='bar', stacked=True)


#swarm plot 
#import time
#for i in range(0,len(numcols),10):
#    plt.figure(figsize=(10,10))
#    tic = time.time()
#    sns.swarmplot(x="features", y="value", hue="NN_Target", data=violen_df.loc[melt_df['features'].isin(numcols[i:i+10])])
#    plt.xticks(rotation=90)

#evaluate and impute missing data 
#NOT NEEDED HERE 

###########################################
#corrolation between all numeric variables# 
###########################################
#using mask to only return lower diagnal corrolation(note: lowever and upper traingles in matrix provide the same information)
corr_df = feat_df[numcols].corr(min_periods=3)#feat_df[numcols].rename_axis(None).rename_axis(None, axis=1)
mask = np.triu(np.ones_like(corr_df, dtype=np.bool), k=-1)
unique_corr_df = corr_df.where(mask) #upper triangle of corr matrix 
cor_df = unique_corr_df.unstack().reset_index();cor_df.columns = ['var1','var2','corr'];cor_df.dropna(inplace=True) #converting matrix to long format 
cor_subset = cor_df[(cor_df['corr']>.5)&(cor_df['corr']<.9)] #filtering vairable corrolations out based on relationship magnitude
#cor_sub_mat = cor_subset.pivot('var1','var2','corr').fillna(0)
topCorVars = list(set(list(cor_subset.var1.unique())+list(cor_subset.var2.unique())))
topCor_DF = feat_df[topCorVars]
topCor_df = topCor_DF.corr()
mask = np.tril(np.ones_like(topCor_df, dtype=np.bool), k=-1)
topCorr_df = topCor_df.where(mask).fillna(0)

#correlation map of top corrolations 
f,ax = plt.subplots(figsize=(20, 20))
sns.heatmap(topCorr_df, annot=False, linewidths=.5, fmt= '.01f',ax=ax,robust=True,cbar=True)
#sns.heatmap(topCorr_df, annot=False,ax=ax,robust=True,cbar=True)

#cluster mapping of corrolations 
sns.clustermap(topCor_df.fillna(0),row_cluster=True,col_cluster=True,linewidths=.01,fmt='.01f',figsize=(20,20)
               ,mask= np.triu(np.ones_like(topCor_df, dtype=np.bool), k=0))

#corrolation with pearson p-vals
#Note: we zip all unique combinations of elements identified from the lower triangle of the corroaltion matrix above 
cormap=zip(cor_df['var1'],cor_df['var2'])
cors=[]
for var1, var2 in cormap: 
    cor = scipy.stats.pearsonr(feat_df[var1], feat_df[var2])
    cors.append((var1,var2,cor[0],cor[1]))

#subset list of 2way corrolations to only include those with sig p-vals and mild or above corrolation 
corsWpval =pd.DataFrame(cors,columns=['var1','var2','cor','pval'])
sigcordf = corsWpval[(corsWpval['pval']<.05) & (corsWpval['cor']>.4)& (corsWpval['cor']<.9)]
sigcorvars = list(set(list(set(sigcordf['var1'])) + list(set(sigcordf['var2']))))

#identifying potential variables driving multicolinarity
vars2rm = []
vars2kp = []
multicolinarity_thresh = .8

#create generator object from list to loop thorugh 
lst_iter_generator = (item for item in list(set(corsWpval['var1'])))

for i in range(0,corsWpval.shape[0]):
    if (corsWpval['var1'][i]!='NN_Target') & (corsWpval['cor'][i]>multicolinarity_thresh):
        if corsWpval['var1'][i]!=corsWpval['var2'][i]:    
            
            #identify which of the two is most corrolated with target and least corrolated with all other variables 
            TargCors={corsWpval['var1'][i]:pearsonr(feat_df['NN_Target'],feat_df[corsWpval['var1'][i]])[0]
            ,corsWpval['var2'][i]:pearsonr(feat_df['NN_Target'],feat_df[corsWpval['var2'][i]])[0]}
            
            #identify which variables have the lowest average corrolation with all other variables 
            minOtherCor = {corsWpval['var1'][i]:statistics.mean(corsWpval[corsWpval['var1']==corsWpval['var1'][i]]['cor'])
            ,corsWpval['var2'][i]:statistics.mean(corsWpval[corsWpval['var2']==corsWpval['var2'][i]]['cor'])}           
            
            #var with max corrolation with target and min corrolation with all other variables
            maxTargCor = max(TargCors.items(), key=operator.itemgetter(1))[0]
            minCorAll= min(minOtherCor.items(), key=operator.itemgetter(1))[0]
            
            #if the same variable satisfies both of the above conditions we keep that variable and remove the other 
            if maxTargCor == minCorAll==corsWpval['var1'][i]:
                vars2rm.append(corsWpval['var2'][i])
                vars2kp.append(corsWpval['var1'][i])
                print('Variable {} will be retained and {} will be disgarded'.format(corsWpval['var1'][i],corsWpval['var2'][i]))
            
            if maxTargCor == minCorAll==corsWpval['var2'][i]:
                vars2rm.append(corsWpval['var1'][i])    
                vars2kp.append(corsWpval['var2'][i])
                print('Variable {} will be retained and {} will be disgarded'.format(corsWpval['var2'][i],corsWpval['var1'][i]))
            
            #if there are conflicting variables associated with each condition we keep the variable with the least amount of multicollinarity with the other co-variants
            if maxTargCor != minCorAll:
                #vars2rm.append(maxTargCor)    
                #vars2kp.append(minCorAll)
                print('Min Avg Cor {} will be retained'.format(minCorAll))


#plot dists with facet grid
distData_long = feat_df.melt(['NN_Target'],var_name='cols',value_name='vals')
cols = list(distData_long.cols.unique())
subset=distData_long.loc[distData_long['cols'].isin([ 'write','year', 'york', 'txt_lngth', 'txt_words', 'txt_nonstopwords', 'total_commas'])]
#g = sns.FacetGrid(subset, col='cols', hue="NN_Target", palette="Set1")
#g = (g.map(sns.kdeplot, "vals"))
for name in list(feat_df[numcols]):
    plt.figure()
    sns.kdeplot(feat_df[(feat_df['NN_Target']==0) & (feat_df[name]!=0) ][name],shade=True,color='b')
    sns.kdeplot(feat_df[(feat_df['NN_Target']==1) & (feat_df[name]!=0) ][name],shade=True,color='r')


_, axes = plt.subplots(1, 2, sharey=True, figsize=(6, 4))
sns.boxplot(data=feat_df['txt_words'], ax=axes[0]);
sns.boxplot(data=feat_df['year'], ax=axes[1]);

for var1, var2 in cormap: 
    plt.figure()
#    sns.jointplot(x=var1, y=var2, data=feat_df,kind="reg")
    sns.lmplot( x=var1, y=var2, data=feat_df, fit_reg=True, hue='NN_Target', legend=False)
    
# library & dataset
import seaborn as sns
df = feat_df
 
# Use the 'hue' argument to provide a factor variable
sns.lmplot( x=var1, y=var2, data=feat_df, fit_reg=True, hue='NN_Target', legend=False)
 
# Move the legend to an empty part of the plot
plt.legend(loc='lower right')
 
#sns.plt.show()


###################################
######FEATURE + MODEL SELECTION####
###################################
###
#feature selection with Random Forestr
### 
#feature selection visualzation 
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold
from yellowbrick.features import RFECV
oz = RFECV(RandomForestClassifier(), cv=cv, scoring='f1_weighted')
oz.fit(, y)
oz.poof()


#modelpipes(note nayesbayes supports online training , train_partial_model)
#note:only using these baseline models as indicators into which models we should conduct more in depth hyperparameter turning via grid and randomgrid searh architectures. We will not dive into Deep NN's
model_dic = {'pipe_log':[('features',feats),('feature_selection', SelectFromModel(ExtraTreesClassifier(n_estimators=1000,n_jobs=6))),('clf', LogisticRegression(random_state=42,max_iter=10000))],
             'pipe_knn':[('features',feats),('feature_selection', SelectFromModel(ExtraTreesClassifier(n_estimators=1000,n_jobs=6))),('clf', KNeighborsClassifier(n_neighbors=5,algorithm='auto'))],
             #'pipe_nbayes':[('features',feats),('feature_selection', SelectFromModel(ExtraTreesClassifier(n_estimators=1000,n_jobs=6), threshold=-np.inf,max_features=100)),('clf', GaussianNB(priors=None, var_smoothing=1e-09))],
             #'pipe_Gaussian':[('features',feats),('to_dense', DenseTransformer()),('feature_selection', SelectFromModel(ExtraTreesClassifier(n_estimators=1000,n_jobs=6))),('clf',GaussianProcessClassifier(1.0 * RBF(1.0)))],
             'pipe_dt':[('features',feats),('feature_selection', SelectFromModel(ExtraTreesClassifier(n_estimators=1000,n_jobs=6))),('clf', DecisionTreeClassifier(max_depth=5))],
             'pipe_rf':[('features',feats),('clf', RandomForestClassifier(n_estimators=500,oob_score=True,max_depth=10,n_jobs=6))],
             'pipe_svm':[('features',feats),('feature_selection', SelectFromModel(ExtraTreesClassifier(n_estimators=1000,n_jobs=6))),('clf', svm.SVC(random_state=42,probability =True,max_iter=300,tol=.0001))],
             'pipe_mlp':[('features',feats),('clf', MLPClassifier(solver='adam',tol=.0001,max_iter=500,learning_rate='adaptive',alpha=.01))],
             'pipe_Adaboost':[('features',feats),('feature_selection', SelectFromModel(ExtraTreesClassifier(n_estimators=1000,n_jobs=6))),('clf',AdaBoostClassifier())],
             'pipe_Par':[('features',feats), ModelTransformer(PassiveAggressiveRegressor())],
             'pipe_En':[('features',feats), ModelTransformer(ElasticNet())],
        
             }

#pipeline dic(key=Model name , value = model pipeline)
pipe_dic = {key:Pipeline([process for process in value]) for key,value in model_dic.items()}

#split data and create dictonary 
train_x,valid_x,train_y,valid_y= model_selection.train_test_split(trainDF[features],trainDF['label_id'],shuffle=True, stratify=trainDF['label_id'],test_size=.2, random_state=10)
data_dic={'training':{'x':train_x,'y':train_y},'validation':{'x':valid_x,'y':valid_y}}

#fit each model pipelinedef 
pipe_fit = {key:value.fit(data_dic['training']['x'],data_dic['training']['y']) for key,value in pipe_dic.items()}

#train and valid validation / metric df (takes in a dictonary of pipes)
train_metrics = sk_model_stats(pipe_fit,data_dic['training']['x'],data_dic['training']['y'],data_type='train')
valid_metrics = sk_model_stats(pipe_fit,data_dic['validation']['x'],data_dic['validation']['y'],data_type='valid')
model_metrics=train_metrics.append(valid_metrics)
model_mean_stats=model_matrics.groupby('model').describe()
model_rank=model_mean_stats.sort_values(by=['f1_score'], ascending=['False']).head(3)

#results_dic={key:model_eval(value,train_x,train_y,valid_x,valid_y) for key,value in pipe_dic.items()}
#score_fit={key:value.predict(train_x) for key,value in pipe_fit.items()}
#results_dic= {key:{'report':metrics.classification_report(train_y,value),'confusionmtrix':metrics.confusion_matrix(train_y,value)}for key,value in score_fit.items()}

####
####NOW THAT WE HAVE A VIEW OF THE TOP PERFORMING MODELS, EVALUTE THE GRID SEARACH OVER THESE TOPn Models
####
#apply feature pipeline and then apply models 
pipe_rf = Pipeline([('features',feats),
                    ('clf', RandomForestClassifier(n_estimators=500,oob_score=True,max_depth=10,n_jobs=6))])
                  
#logistic hyper parameters
hyperparameters = [{
                    'clf__min_samples_split':[5,10,20],
                    'clf__min_samples_leaf':[1,5,10],
                    'clf__max_features':[100,200,300],
                    }] 


clf = GridSearchCV(pipe_rf, hyperparameters, cv=3, scoring='balanced_accuracy', refit=True, verbose=5)#,n_jobs=jobs)
#clfr = RandomizedSearchCV(pipe_rf, hyperparameters, cv=5, n_iter =20,scoring='balanced_accuracy',n_jobs=3)
  
# Fit and tune model
clf.fit(train_x, train_y)
optimized_parms = clf.best_params_
optimized_clf= clf.best_estimator_
optimized_coef = clf.coef_
#cross validation metrics for all considered models
cv_metrics = pd.DataFrame(clf.cv_results_)

#view parameters that resulted in best model 
final_rf= Pipeline([('features',feats),
                    ('clf', RandomForestClassifier(n_estimators=500,oob_score=True,max_depth=10
                                                   ,n_jobs=6,max_features=100,min_samples_leaf=1,min_samples_split=5))
                    ])

#refitting on entire training data using best settings
#view predictions and probabilities of each class 
final_rf.fit(data_dic['validation']['x'],data_dic['validation']['y'])
preds = final_rf.predict(data_dic['training']['x'])
probs = final_rf.predict_proba(data_dic['training']['x'])
print('mean accuracy:{}'.format(np.mean(preds == data_dic['training']['y'])))
cf = metrics.confusion_matrix(data_dic['training']['y'],preds)

#save model to file 
import joblib
filename = 'C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/FinalModel/NN_RF_LegalAction.sav'
joblib.dump(final_rf, filename)









































# Fit the grid search objects
print('Performing model optimizations.d..')
best_acc = 0.0
best_clf = 0
best_gs = ''
for key, value in model_dic.items():
	print('\nEstimator: %s' % model_dic[key])		
	value.fit(train_x, train_y)
	# Best params
	print('Best params: %s' % gs.best_params_)
	# Best training data accuracy
	print('Best training accuracy: %.3f' % gs.best_score_)
	# Predict on test data with best params
	y_pred = gs.predict(valid_x)
	# Test data accuracy of model with best params
	print('Test set accuracy score for best params: %.3f ' % accuracy_score(valid_y, y_pred))
	# Track best (highest test accuracy) model
	if accuracy_score(valid_y, y_pred) > best_acc:
		best_acc = accuracy_score(valid_y, y_pred)
		best_gs = gs
		best_clf = idx
print('\nClassifier with best test set accuracy: %s' % grid_dict[best_clf])



#apply feature pipeline and then apply models 
pipe_rf = Pipeline([('features',feats),
                    #('svm', sklearn.decomposition.TruncatedSVD(n_components=100,random_state=42)),
                    #('clf', RandomForestClassifier(n_estimators=1000,oob_score=True
                    #                               ,min_samples_split=20,max_depth=10
                    #                               ,class_weight='balanced_subsample'
                    #                               ,max_features=100,n_jobs=4))
                    # 
                    
                    ('feature_selection', SelectFromModel(ExtraTreesClassifier(n_estimators=400,n_jobs=6))),
                   #('feature_selection', RFECV(RandomForestClassifier(),cv = StratifiedKFold(5),scoring='f1_weighted')),
                    #('feature_selection', SelectFromModel(LinearSVC(loss='l2',penalty="l1",dual=False),threshold='mean')), 
                    ('clf', LogisticRegression(random_state=42,max_iter=10000))])

#view all attributes that can be tuned andlist of all scoring metrics that can be used
pipe_rf.get_params().keys()
sorted(sklearn.metrics.SCORERS.keys())

#logistic hyper parameters
hyperparameters = [{'feature_selection__max_features':[100,200],
                    'clf__solver':['newton-cg','saga'],
                    'clf__penalty': ['l2'],
                    'clf__C': [1.0, 0.5, 0.1],               #Inverse of regularization strength; smaller values specify stronger regularization
                    'clf__class_weight':['balanced']         #“balanced” mode uses the values of y to automatically adjust weights inversely proportional to class frequencies in the input data as n_samples / (n_classes * np.bincount(y)).
                    }] 


clf = GridSearchCV(pipe_rf, hyperparameters, cv=3, scoring='balanced_accuracy', refit=True, verbose=5)#,n_jobs=jobs)
#clfr = RandomizedSearchCV(pipe_rf, hyperparameters, cv=5, n_iter =20,scoring='balanced_accuracy',n_jobs=3)
  
#split data 
train_x,valid_x,train_y,valid_y= model_selection.train_test_split(trainDF[features],trainDF[target],shuffle=True, stratify=trainDF[target],test_size=.2, random_state=10)

#train model with no gridsearch
pipe_rf.fit(train_x, train_y)

#train model with gridsearch 
clf.fit(train_x,train_y)
best_model=clf.best_estimator_

#train preds
train_preds= get_preds(best_model,train_x,train_y,return_preds=True)
train_stats =get_preds(best_model,train_x,train_y,return_preds=False)
print(metrics.classification_report(train_y,train_preds))


train_preds = pipe_rf.predict(train_x)
train_pred_probs = pipe_rf.predict_proba(train_x)
plotmetrics(train_y,train_pred_probs,train_preds)
print('Avg Accuracy:',np.mean(train_preds == valid_y),'\n'
,'min Accuracy:',np.min(train_preds == valid_y),'\n'
,'max Accuracy:',np.max(train_preds == valid_y),'\n'
,'std Accuracy:',np.std(train_preds == valid_y))



#valid preds
def get_preds(model_pipe,x,y,return_preds=True):
    preds = model_pipe.predict(x)
    pred_probs = model_pipe.predict_proba(x)
    
    #accuracy_dic
    accuracy_stats={'avg_Accuracy':np.mean(preds == y)
    ,'min_Accuracy':np.min(preds == y)
    ,'max_Accuracy':np.max(preds == y)
    ,'std_Accuracy':np.std(preds == y)
    }
    
    print((k,v) for k,v in accuracy_stats.items())
    if return_preds==True:
        return preds
    else: 
        plotmetrics(y,pred_probs,preds)
        return accuracy_stats


            
print('Avg Accuracy:',np.mean(preds == valid_y),'\n',
,'std Accuracy:',np.std(preds == valid_y))


cf = metrics.confusion_matrix(valid_y, valid_preds)
filename = 'C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/FinalModel/NN_Logistic.sav'
joblib.dump(pipe_rf, filename)
    

#test 
pipe_rf.get_params

len(pipe_rf.named_steps['clf'].coef_[0])
dir(pipe_rf.named_steps['clf'].get_params)
print(pipe_rf.summary())















#create tf-idf for entire dataframe
tfidf = TfidfVectorizer(sublinear_tf=True, min_df=.05,max_df=.8, norm='l2',ngram_range=(1, 2), stop_words='english')
features = tfidf.fit_transform(trainDF.text).toarray()
labels = trainDF.label_id

#identify terms most corrolated with each target level 
from sklearn.feature_selection import chi2
import numpy as np

N = 10
for label, label_id in sorted(label_to_id.items()):
    print(label)
    features_chi2 = chi2(features, labels == label_id)
    indices = np.argsort(features_chi2[label_id])
    chi2vals =np.array(features_chi2[label_id])[indices]
    feature_names = np.array(tfidf.get_feature_names())[indices]
    
    if ('chi2df' not in locals() and 'chi2df' not in globals()):
        chi2df = pd.DataFrame(list(zip(indices,feature_names,chi2vals)))
        chi2df['label_id']=label_id
    else: 
        df = pd.DataFrame(list(zip(indices,feature_names,chi2vals)))
        chi2df.append(df)


#build training tfidf representaiton for modeling 
count_vect = CountVectorizer()
X_train_counts = count_vect.fit_transform(train_x)
tfidf_transformer = TfidfTransformer()
X_train_tfidf = tfidf_transformer.fit_transform(X_train_counts)

#models to evaluate 
models = [
    RandomForestClassifier(n_estimators=200, max_depth=3, random_state=0),
    LinearSVC(),
    MultinomialNB(),
    LogisticRegression(random_state=0),
]

#cross validation metrics setup 
CV = 5
cv_df = pd.DataFrame(index=range(CV * len(models)))
entries = []
for model in models:
  model_name = model.__class__.__name__
  accuracies = cross_val_score(model, features, labels, scoring='balanced_accuracy', cv=CV)
  for fold_idx, accuracy in enumerate(accuracies):
    entries.append((model_name, fold_idx, accuracy))
cv_df = pd.DataFrame(entries, columns=['model_name', 'fold_idx', 'accuracy'])

#plot cv 
import seaborn as sns
sns.boxplot(x='model_name', y='accuracy', data=cv_df)
sns.stripplot(x='model_name', y='accuracy', data=cv_df, 
              size=8, jitter=True, edgecolor="gray", linewidth=2)
plt.show()

cv_df.groupby('model_name').accuracy.mean()



# Utility function to report best scores
def report(results, n_top=3):
    for i in range(1, n_top + 1):
        candidates = np.flatnonzero(results['rank_test_score'] == i)
        for candidate in candidates:
            print("Model with rank: {0}".format(i))
            print("Mean validation score: {0:.3f} (std: {1:.3f})".format(
                  results['mean_test_score'][candidate],
                  results['std_test_score'][candidate]))
            print("Parameters: {0}".format(results['params'][candidate]))
            print("")






















#logistic pipeline with preprocessed data(score new data:log_pipe.score(valid_x,valid_y))
pipe_log = Pipeline([('tfidf_vec', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=4000, smooth_idf=True, sublinear_tf=False,lowercase=True,)),('log',  linear_model.LogisticRegression())])
pipe_log.steps #view all steps in above pipeline 
vars(pipe_log.named_steps['log'])
model_perf_dict = model_eval(pipe_log, train_x,train_y,valid_x,valid_y)

  

#knn pipeline 
pipe_knn = KNN_TFIDF_Classifer(train_x,train_y,valid_x,valid_y)
knn_perf_dict = model_eval(pipe_knn, train_x,train_y,valid_x,valid_y)

  
#dt pipeline 
#pipe_dt = DT_TFIDF_Classifer(train_x,train_y,valid_x,valid_y)
pipe_dt = generic_pipeline(train_x,train_y,valid_x,valid_y 
                 ,TfidfVectorizer
                 , tree.DecisionTreeClassifier
                 ,{'analyzer':'word', 'token_pattern':r'\w{1,}', 'max_features':5000, 'smooth_idf':True, 'sublinear_tf':False,'lowercase':True}
                 ,{'random_state':42})
dt_perf_dict = model_eval(pipe_dt, train_x,train_y,valid_x,valid_y)

#rf pipeline 
pipe_rf = generic_pipeline(train_x,train_y,valid_x,valid_y 
                 ,TfidfVectorizer
                 ,RandomForestClassifier
                 ,{'analyzer':'word', 'token_pattern':r'\w{1,}', 'max_features':5000, 'smooth_idf':True, 'sublinear_tf':False,'lowercase':True}
                 #,{'n_estimators':100, 'criterion':'gini','max_depth':20,'min_samples_split':20,'min_samples_leaf':5,'max_features':10})
                 ,{'n_estimators':100, 'criterion':'gini'})
rf_perf_dict = model_eval(pipe_rf, train_x,train_y,valid_x,valid_y)

#mlp pipeline 
pipe_mlp = generic_pipeline(train_x,train_y,valid_x,valid_y 
                 ,TfidfVectorizer
                 ,MLPClassifier
                 ,{'analyzer':'word', 'token_pattern':r'\w{1,}', 'max_features':5000, 'smooth_idf':True, 'sublinear_tf':False,'lowercase':True}
                 ,{'hidden_layer_sizes':(10,), 'activation':'relu','solver':'adam','learning_rate':'constant','shuffle':True})
mlp_perf_dict = model_eval(pipe_mlp, train_x,train_y,valid_x,valid_y)

#evalute models 
#create dictonary to store the name of pipelines in dictonary to be used to display results 
pipe_dic = {0: 'logistic', 1: 'knn', 2:'DT', 3:'RF',4:'mlp'}

#list the four pipelines to execute those pipelines iterativelly
pipelines = [pipe_log,pipe_knn, pipe_dt,pipe_rf,pipe_mlp]

# Fit the pipelines
for pipe in pipelines:
  pipe.fit(train_x, train_y)

# Compare accuracies
for idx, val in enumerate(pipelines):
  print('%s pipeline test accuracy: %.3f' % (pipe_dic[idx], val.score(valid_x, valid_y)))
  
#extract and print infomration on the best model 
best_accuracy = 0
best_classifier = 0
best_pipeline = ''
for idx, val in enumerate(pipelines):
    if val.score(train_x, train_y) > best_accuracy:
        best_accuracy = val.score(valid_x, valid_y)
        best_pipeline = val
        best_classifier = idx
print('%s Classifier has the best accuracy of %.2f' % (pipe_dic[best_classifier],best_accuracy))

#######SAVING MODEL AND LOADING MODEL FOR LATER USE#######
#NOTE: Generate requirements.txt when exporting model so you can replicate the requirments needed to run the saved model 
#save best model to pickle for use on future data 
filename = 'nn_finalmodel.sav'
pickle.dump(pip_log, open(filename,'wb'))

#load pickled model for evaluation on unseen data 
loaded_model = pickle.load(open(filename,'rb'))
OOS_predictions = loaded_model.score(valid_x,valid_y)
print(OOS_predictions)

#option 2:save model using joblib(useful when algo requires a lot of parameters or store the entire dataset)
#save model 
joblib.dump(pip_log, filename)
#load model 
loaded_model = joblib.load(filename)
OOS_predictions = loaded_model.score(valid_x,valid_y)
print(OOS_predictions)

