# -*- coding: utf-8 -*-
"""
Created on Mon Jan 21 15:56:59 2019

@author: caridza
"""
# -*- coding: utf-8 -*-
#VirtualEnv: docclassify
#VirtualEnv Location: C:\Users\caridza\Downloads\WPy32-3662\ZacksScripts\docclassify
#######################
#######IMPORTS#########
#######################
#install tensorflow: pip3 install --upgrade https://storage.googleapis.com/tensorflow/mac/cpu/tensorflow-1.12.0-py3-none-any.whl
#base modules 
import pandas as pd
import xgboost, numpy, textblob, string, pickle, sys
from itertools import islice #iterating over vectorized objects (countvectorizer, tfidfvectorizer,etc..)
#required modules for data preprocessing and modeling
import sklearn
from sklearn import decomposition, ensemble, tree, svm,model_selection, preprocessing, linear_model, naive_bayes, metrics, svm
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer,TfidfTransformer
from sklearn.pipeline import Pipeline,make_pipeline
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler,MinMaxScaler
from sklearn.model_selection import train_test_split,GridSearchCV,cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import GradientBoostingClassifier,RandomForestClassifier,AdaBoostClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC,LinearSVC
from sklearn.feature_selection import RFECV
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import SelectFromModel
from sklearn.pipeline import FeatureUnion 
from sklearn.model_selection import StratifiedKFold
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.gaussian_process.kernels import RBF
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis

#text parsing
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
#plotting
import matplotlib.pyplot as plt
import matplotlib
import seaborn as sns
from collections import Counter
import numpy as np
import mpu
import scikitplot as skplt
import joblib
import re
#custom modules 
import negative_news2
from negative_news2 import consumer
from negative_news2.consumer import utils
from negative_news2.consumer.utils  import TextSelector,replace_words, NumberSelector,orig_text_clean,load_and_score,remove_punctuation,remove_stop,stem_words,remove_nonchars,pipelinize,sk_model_stats, encode_categoric
#required for corrolation 
import scipy
import statistics
from scipy.stats.stats import pearsonr   
from imblearn.over_sampling import SMOTE

#punctuation to remove, stopwords to remove, stemming and lemmatizing objects for preprocessing
stemmer = SnowballStemmer('english')
wordnet_lemmatizer = WordNetLemmatizer()
exclude = set(string.punctuation)
stopwords = stopwords.words('english')
newStopWords = ['.','?','%']
stopwords.extend(newStopWords)
stopwords=set(stopwords)
NonStopWords2Remove = ['Google','Wells Fargo','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December']

#####################
#Dataset Preperation#
##################### 
#https://www.kaggle.com/baghern/a-deep-dive-into-sklearn-pipelines
#https://scikit-learn.org/stable/auto_examples/model_selection/grid_search_text_feature_extraction.html
#https://scikit-learn.org/stable/auto_examples/text/plot_document_classification_20newsgroups.html#sphx-glr-auto-examples-text-plot-document-classification-20newsgroups-py
#http://zacstewart.com/2014/08/05/pipelines-of-featureunions-of-pipelines.html
#https://zablo.net/blog/post/pandas-dataframe-in-scikit-learn-feature-union
datapath = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/SentDF.pickle"
target = 'MandA'
mapvars = ['source','Change','Managment']
inputtxt = 'Sentence'

# load the dataset
data = pd.read_pickle(datapath)
data.info()

#convert anything that was a list to a string 
for col in list(data):
    data[col]=data[col].apply(lambda x: ' '.join(map(str, x)).strip() if isinstance(x,list) else x)

#check values in each column binary 
{key: len(list(data[key].unique())) for key in list(data) } #unique values per col
{key: {'True':data[key].value_counts()[1],'False':data[key].value_counts()[0]} for key in list(data) if data[key].dtypes=='bool'} #unique breakout of booleans
{key: list(data[key].unique()) for key in list(data) if len(list(data[key].unique()))<50} #cat columns that can be converted to numeric labels

#check for missing data 
data.isnull().sum()
 
#convert cat to numeric levels (input:df, output: df with new col)
#for val in list(data):
#    if len(list(data[val].unique()))<50 and target not in val:
#        print(val,' has been converted to int')
 #       data = encode_categoric(data,val)

#being data processing for modeling 
#data[inputtxt] = data[inputtxt].apply(lambda x: replace_words(x,NonStopWords2Remove))#remove Proper Nouns and uninteresting non stop words from sentences 
trainDF = orig_text_clean(data,target=target , txtfeild='Sentence' , maplabelvars=mapvars,stopwords=stopwords,stemmer=stemmer)#remove stopwords, stem, and clean sentences 
list(trainDF);trainDF.info();trainDF.describe()

#ONLY BUILD THESE OUT FOR NEW MODELS WITH MULTIPLE CONDITIONS (note: you will NOT be able to use text_preprocesing)
if 'Managment_id' in list(trainDF):
    #create critera for each compound column(_conditions) and value associated with each (_choices)
    #Note: We look around at the sentences before and after the current row to determine if condition is met
    #NEED to make sure the sentences around the row are tid to the same entity and url 
    CM_conditions = [ ((trainDF.Managment_id == True)|(trainDF.Managment_id.shift(1)== True)|(trainDF.Managment_id.shift(2)== True)|(trainDF.Managment_id.shift(-1)== True)|(trainDF.Managment_id.shift(-2)== True)) & ((trainDF.Change_id ==True) |(trainDF.Change_id.shift(1)==True) |(trainDF.Change_id.shift(-1)==True))
                    ,(trainDF.Managment_id == True) & (trainDF.Change_id == True)
                    ,(trainDF.Managment_id == False) & (trainDF.Change_id == False)]
    CM_choices = [1,1,0]
    trainDF['ChangeManagment'] = np.select(CM_conditions,CM_choices,default=0)
if 'Suspension_id' in list(trainDF):
    TS_conditions = [(trainDF.Trade == True) & (trainDF.Suspension == True)
                    ,(trainDF.Trade == False) & (trainDF.Suspension == False)
                    ,(trainDF.Trade != False) & (trainDF.Suspension == False)
                    ,((trainDF.Trade == True)|(trainDF.Trade.shift(1)== True)|(trainDF.Trade.shift(2)== True)|(trainDF.Trade.shift(-1)== True)|(trainDF.Trade.shift(-2)== True)) & ((trainDF.Suspension ==True) |(trainDF.Suspension.shift(1)==True) |(trainDF.Suspension.shift(-1)==True))                ]
    TS_choices = [1,0,0,1]
    trainDF['TradeSuspension'] = np.select(TS_conditions,TS_choices,default=0)
if 'Disqualification_id' in list(trainDF):
    SD_conditions = [(trainDF.Statutary == True) & (trainDF.Disqualification == True)
                    ,(trainDF.Statutary == False) & (trainDF.Disqualification == False)
                    ,(trainDF.Statutary != False) & (trainDF.Disqualification == False)
                    ,((trainDF.Statutary == True)|(trainDF.Statutary.shift(1)== True)|(trainDF.Statutary.shift(2)== True)|(trainDF.Statutary.shift(-1)== True)|(trainDF.Statutary.shift(-2)== True)) & ((trainDF.Disqualification ==True) |(trainDF.Disqualification.shift(1)==True) |(trainDF.Disqualification.shift(-1)==True))                ]
    SD_choices = [1,0,0,1]
    trainDF['StatutoryDisqual'] = np.select(SD_conditions,SD_choices,default=0)


#categorical and numerical columns in dataframe 
vars2rmv = ['ChangeManagment','TradeSuspension','StatutoryDisqual','entity','date','source','title','url',target,'label','label_id','text','Change_id','Managment_id']
catvars  = list(trainDF.filter(like='_id').columns.values);catvars.append(inputtxt)
numvars = list(trainDF.filter(like='txt_').columns.values)

if 'Change' in mapvars:
    trainDF.drop(columns = ['label_id'],inplace=True)
    trainDF.rename(columns={'ChangeManagment': 'label_id'}, inplace=True)

features= [c for c in catvars if c  not in vars2rmv]
numeric_features= [c for c in numvars if c not in vars2rmv]
features.extend(numeric_features)

#create dictonary of unique vocab for each level of the target
unique_vocab={diflab:np.setdiff1d(
        list(trainDF[trainDF['label_id']==diflab][inputtxt].str.split(' ', expand=True).stack().unique())
        , mpu.datastructures.flatten([list(trainDF[trainDF['label_id']==label][inputtxt].str.split(' ', expand=True).stack().unique()) 
                                for label in list(trainDF['label_id'].unique()) if label !=diflab])
                    ) for diflab in list(trainDF['label_id'].unique())
        }

#count of unique words per topic                
length_dict = {key: len(value) for key, value in unique_vocab.items()}

#identify alll rows with strings of interrst 
print('Total Unique Sentences: {}'.format(len(trainDF[inputtxt].unique())),'\n'
, 'Total Sentences with Fine or Penalty {}'.format(len(trainDF[(trainDF[inputtxt].str.contains("fine")|trainDF[inputtxt].str.contains("penalt"))][inputtxt].unique())),'\n'
, 'Total Sentences flagged via relationship with embedding {}'.format(trainDF['label_id'].value_counts()[1]))


#####SKLEARN PIPELINE DEVELOPMENT
#define text transformations to generate
text_feats = {'tfidf_pipe':{'analyzer':'word','ngram_range':(1,1)}
              #,'cooccur_pipe':{'analyzer':'word','ngram_range':(2,2)}
              #,'chargrams_pipe':{'analyzer':'char_wb','ngram_range':(1,3)}
              }

#apply text_feats transformations iterativly into tfidf tranformation pipeline
catfeat_pipe_dic = {key : Pipeline([('selector', TextSelector(key=inputtxt)),
                            ('tfidf',  TfidfVectorizer(analyzer=val['analyzer'], ngram_range=val['ngram_range'], 
                                             max_features=400,min_df=2,stop_words='english',max_df=.4
                                             , smooth_idf=True, norm='l2',sublinear_tf=True,lowercase=True,))
                            ]) for key,val in text_feats.items()
                    }   

#create pipe for each numerical features generated by orig_text_clean 
numfeat_pipe_dic= {val: Pipeline([('selector', NumberSelector(key=val)),('standard', StandardScaler(with_std=True,with_mean=True))]) for val in numeric_features}

#create final list of pipelines, starting with text preprocessing, and finishing with the numeric column normalizations(items listed in order of exectuion so we build initial list with text processing and append all numeric processing tasks after)
final_pipeline = [(k,v) for k, v in catfeat_pipe_dic.items()]
final_pipeline.extend([(k,v) for k, v in numfeat_pipe_dic.items()])

#make a pipeline from all of our pipelines, we dao the same thing, but now we use a FeatureUnion to join the feature processing pipelines.
feats = FeatureUnion(final_pipeline)
feats_fit = feats.fit_transform(trainDF)

#extract feature names from each pipeline to map to output df used for prelim statistical analysis  
#note: i am only concertned with tfidf feature names as that is the only transformation in the pipeline, if others were used, we would need to iterate through those steps and pull feature names out as well
catfeat_names = catfeat_pipe_dic['tfidf_pipe'].named_steps['tfidf'].get_feature_names()
numfeat_names =[numfeat_pipe_dic[key].named_steps['selector'].get_feature_names() for key in numfeat_pipe_dic.keys()]
feat_names = catfeat_names +numfeat_names

#creat df to conduct preliminary analysis on 
feat_df=pd.DataFrame(feats_fit.todense())
feat_df.columns = feat_names

#add additional metrics to DataFrame
feat_df['NN_Target']= trainDF['label_id']
feat_df['news_source']= trainDF['source_id']

#######################################
##PRELIMINARY DESCRIPTIVE STATISTICS###
####USING FINAL TRANFORMATION DATASET##
#######################################
import pandas as pd
import researchpy as rp
import seaborn as sns
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import operator 
import math 
#num vs cat cols
Numcols=list(feat_df.select_dtypes(include=[np.number]).columns.values)
#nontxt_numcol = [ 'txt_length', 'txt_words','txt_nonstopwords','txt_total_commas']
numcols= Numcols#list(set(Numcols)-set(nontxt_numcol))
catcols = feat_df.columns.difference(list(feat_df.select_dtypes(include=[np.number]).columns.values))

#numeric and cat col stats
NumCol_stats = rp.summary_cont(feat_df[numcols])
NumCol_stats['kurtosis']= feat_df[numcols].kurtosis().values
NumCol_stats['skew']=feat_df[numcols].skew().values
CatCol_stats = rp.summary_cat(feat_df[catcols])

#plot target distribution
#plot count of target and only cat vairable in dataset
_, axes = plt.subplots(nrows=1, ncols=2, figsize=(12, 4))
a= sns.countplot(x='NN_Target', data=feat_df, ax=axes[0]);
b=sns.countplot(x='news_source', data=feat_df, ax=axes[1]);b.set_xticklabels(b.get_xticklabels(),rotation=90)

###########################################
#corrolation between all numeric variables# 
###########################################
#using mask to only return lower diagnal corrolation(note: lowever and upper traingles in matrix provide the same information)
corr_df = feat_df[numcols].corr(min_periods=2)#feat_df[numcols].rename_axis(None).rename_axis(None, axis=1)
mask = np.triu(np.ones_like(corr_df, dtype=np.bool), k=-1)
unique_corr_df = corr_df.where(mask) #upper triangle of corr matrix 
cor_df = unique_corr_df.unstack().reset_index();cor_df.columns = ['var1','var2','corr'];cor_df.dropna(inplace=True) #converting matrix to long format 
cor_subset = cor_df[(abs(cor_df['corr'])>.2)&(abs(cor_df['corr'])<.9)] #filtering vairable corrolations out based on relationship magnitude
topCorVars = list(set(list(cor_subset.var1.unique())+list(cor_subset.var2.unique())))
topCor_DF = feat_df[topCorVars]
topCor_df = topCor_DF.corr()
mask = np.tril(np.ones_like(topCor_df, dtype=np.bool), k=-1)
topCorr_df = topCor_df.where(mask).fillna(0)

#correlation map of top corrolations 
f,ax = plt.subplots(figsize=(20, 20))
sns.heatmap(topCorr_df, annot=False, linewidths=.5, fmt= '.01f',ax=ax,robust=True,cbar=True)
#sns.heatmap(topCorr_df, annot=False,ax=ax,robust=True,cbar=True)

#cluster mapping of corrolations 
#sns.clustermap(cor_df.fillna(0),row_cluster=True,col_cluster=True,linewidths=.01,fmt='.01f',figsize=(20,20))
sns.clustermap(topCor_df.fillna(0),row_cluster=True,col_cluster=True,linewidths=.01,fmt='.01f',figsize=(20,20)
               ,mask= np.triu(np.ones_like(topCor_df, dtype=np.bool), k=0))

#corrolation with pearson p-vals
#Note: we zip all unique combinations of elements identified from the lower triangle of the corroaltion matrix above 
cormap=zip(cor_df['var1'],cor_df['var2'])
cors=[]
for var1, var2 in cormap: 
    cor = scipy.stats.pearsonr(feat_df[var1], feat_df[var2])
    cors.append((var1,var2,cor[0],cor[1]))

#subset list of 2way corrolations to only include those with sig p-vals and mild or above corrolation 
corsWpval =pd.DataFrame(cors,columns=['var1','var2','cor','pval']);corsWpval.sort_values(by = ['cor'],ascending=False,inplace=True)
targcordf = corsWpval[corsWpval['var1']=='NN_Target']
sigcordf = corsWpval[(corsWpval['pval']<.05) & (corsWpval['cor']>.2)& (corsWpval['cor']<.99)]
sigcorvars = list(set(list(set(sigcordf['var1'])) + list(set(sigcordf['var2']))))
sigcorvars.remove('NN_Target')


###################################
######FEATURE + MODEL SELECTION####
###################################

#modelpipes(note nayesbayes supports online training , train_partial_model)
#note:only using these baseline models as indicators into which models we should conduct more in depth hyperparameter turning via grid and randomgrid searh architectures. We will not dive into Deep NN's
model_dic = {'pipe_log':[('features',feats),('feature_selection', SelectFromModel(ExtraTreesClassifier(n_estimators=1000,n_jobs=6))),('clf', LogisticRegression(random_state=42,max_iter=10000))],
             'pipe_knn':[('features',feats),('feature_selection', SelectFromModel(ExtraTreesClassifier(n_estimators=1000,n_jobs=6))),('clf', KNeighborsClassifier(n_neighbors=5,algorithm='auto'))],
             'pipe_dt':[('features',feats),('feature_selection', SelectFromModel(ExtraTreesClassifier(n_estimators=1000,n_jobs=6))),('clf', DecisionTreeClassifier(max_depth=5))],
             'pipe_rf':[('features',feats),('clf', RandomForestClassifier(n_estimators=500,oob_score=True,max_depth=10,n_jobs=6))],
             'pipe_svm':[('features',feats),('feature_selection', SelectFromModel(ExtraTreesClassifier(n_estimators=1000,n_jobs=6))),('clf', svm.SVC(random_state=42,probability =True,max_iter=300,tol=.0001))],
             'pipe_mlp':[('features',feats),('clf', MLPClassifier(solver='adam',tol=.0001,max_iter=500,learning_rate='adaptive',alpha=.01))],
             'pipe_Adaboost':[('features',feats),('feature_selection', SelectFromModel(ExtraTreesClassifier(n_estimators=1000,n_jobs=6))),('clf',AdaBoostClassifier())],

             }

#pipeline dic(key=Model name , value = model pipeline)
pipe_dic = {key:Pipeline([process for process in value]) for key,value in model_dic.items()}

#split data and create dictonary 
#use smote to oversample unbalanced target
train_x,valid_x,train_y,valid_y= model_selection.train_test_split(trainDF[features],trainDF['label_id'],shuffle=True, stratify=trainDF['label_id'],test_size=.2, random_state=10)
data_dic={'training':{'x':train_x,'y':train_y},'validation':{'x':valid_x,'y':valid_y}}

#fit each model pipelinedef 
pipe_fit = {key:value.fit(data_dic['training']['x'],data_dic['training']['y']) for key,value in pipe_dic.items()}

#train and valid validation / metric df (takes in a dictonary of pipes)
train_metrics = sk_model_stats(pipe_fit,data_dic['training']['x'],data_dic['training']['y'],data_type='train')
valid_metrics = sk_model_stats(pipe_fit,data_dic['validation']['x'],data_dic['validation']['y'],data_type='valid')
model_metrics=train_metrics.append(valid_metrics)
model_mean_stats=model_metrics.groupby('model').describe()
model_rank=model_mean_stats.sort_values(by=[('fbeta_score','mean')], ascending=['False']).head(10)
model_rank[[('fbeta_score', 'mean'),('roc_auc', 'mean'),('median_absolute_error', 'mean'), ('TrueNeg', 'mean'), ('TruePos', 'mean')]]
#results_dic={key:model_eval(value,train_x,train_y,valid_x,valid_y) for key,value in pipe_dic.items()}
#score_fit={key:value.predict(train_x) for key,value in pipe_fit.items()}
#results_dic= {key:{'report':metrics.classification_report(train_y,value),'confusionmtrix':metrics.confusion_matrix(train_y,value)}for key,value in score_fit.items()}


####
####NOW THAT WE HAVE A VIEW OF THE TOP PERFORMING MODELS, EVALUTE THE GRID SEARACH OVER THESE TOPn Models
####
#define models you want to explore further through hyperparameter tuning
#feature selection takes forevvver.....so i comment it out, i will be using MLP anyway
from imblearn.over_sampling import SMOTE  # or: import RandomOverSampler
from imblearn.pipeline import Pipeline as imbPipeline

pipe_dt = imbPipeline([('features',feats),
                       ('oversample',SMOTE(random_state=444)),
                    #('feature_selection',SelectFromModel(ExtraTreesClassifier(n_estimators=200))),
                    ('clf', DecisionTreeClassifier(max_depth=5))])

pipe_mlp = imbPipeline([('features',feats),
                 ('oversample',SMOTE(random_state=444)),
                 ('clf', MLPClassifier(solver='adam',tol=.0001,max_iter=500,learning_rate='adaptive',shuffle=True,alpha=.0001,activation='relu'))])

#save and print coefficents that can be used in grid search for each model 
pipes = [pipe_dt,pipe_mlp]
for pipe in pipes:
    print(vars(pipe.named_steps['clf']))
    
# hyper parameters
grid_params_dt = [{
                    'clf__splitter':['best','random'],
                     'clf__max_depth':[10,15,20],
                     'clf__min_samples_split':[5,20,50],
                     'clf__max_features':[50,100,200],
                     'clf__min_impurity_decrease':[0,.00001,.01]
                    }] 
    
grid_params_mlp= [{#'clf__activation': ['logistic', 'relu'], 
                   'clf__beta_1':[.99,.9,.5,.1],
                   'clf__beta_2':[.99,.9,.5,.1]                   
                   }]
    
#dictonary of models and grid search parameters 
import os
os.chdir('C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/')
from GridModelSelection import EstimatorSelectionHelpers 
GridSearchModelDic = {'dt':pipe_dt,'mlp':pipe_mlp}
GridSearchParamDic = {'dt':grid_params_dt,'mlp':grid_params_mlp}

#execute grid search using wrappers
#multiple model wrapper
#helper1 = EstimatorSelectionHelpers.EstimatorSelectionHelper(GridSearchModelDic, GridSearchParamDic)
#helper1.fit(train_x, train_y, scoring='balanced_accuracy', n_jobs=4)
#cv_df=helper1.score_summary(sort_by='max_score')
#cv_df[['estimator','min_score','mean_score','max_score','std_score',]]
jobs=6
gs_dt = GridSearchCV(estimator=pipe_dt,
			param_grid=grid_params_dt,
			scoring='balanced_accuracy',
			cv=2, 
			n_jobs=jobs)

gs_mlp = GridSearchCV(estimator=pipe_mlp,
			param_grid=grid_params_mlp,
			scoring='balanced_accuracy',
			cv=5, 
			n_jobs=jobs)

#create list of all grids 
grids = [gs_dt, gs_mlp]

# Dictionary of pipelines and classifier types for ease of reference
grid_dict = {0: 'Decision Tree',1: 'Multi-Layer-Perceptrion'}

#create dictonary of models and gs objects to loop through 
gridmod_dict = {'DT':gs_dt,'MLP':gs_mlp}

#fit grid for each model 
mod_obs ={}
for key,value in gridmod_dict.items():
    mod_obs.update({key:value.fit(train_x,train_y)})   

#store results in object 
res_obs ={}
for key,value in gridmod_dict.items():
   res_obs.update({key:value.cv_results_})   

#extract model stats 
train=sk_model_stats(gridmod_dict,train_x,train_y*1,data_type='train')
valid=sk_model_stats(gridmod_dict,valid_x,valid_y*1,data_type='valid')
stats = train.append(valid).T;stats.columns = [x+"_"+y for x,y in zip(stats.iloc[[0],:].values[0],stats.iloc[[1],:].values[0])]

# Fit the grid search objects
print('Performing model optimizations...')
best_acc = 0.0
best_clf = 0
best_gs = ''
for idx, gs in enumerate(grids):
	print('\nEstimator: %s' % grid_dict[idx])	
	# Fit grid search	
	#gs.fit(train_x, train_y)
	# Best params
	print('Best params: %s' % gs.best_params_)
	# Best training data accuracy
	print('Best training accuracy: %.3f' % gs.best_score_)
	# Predict on test data with best params
	y_pred = gs.predict(valid_x)
	# Test data accuracy of model with best params
	print('Test set accuracy score for best params: %.3f ' % metrics.accuracy_score(valid_y, y_pred))
	# Track best (highest test accuracy) model
	if metrics.accuracy_score(valid_y, y_pred) > best_acc:
		best_acc = metrics.accuracy_score(valid_y, y_pred)
		best_gs = gs
		best_clf = idx
print('\nClassifier with best test set accuracy: %s' % grid_dict[best_clf])


gs_mlp.best_estimator_.named_steps['clf']



# Save best grid search pipeline to file
dump_file = 'best_gs_pipeline.pkl'
joblib.dump(best_gs, dump_file, compress=1)
print('\nSaved %s grid search pipeline to file: %s' % (grid_dict[best_clf], dump_file))


    
#best dt params 
#DecisionTreeClassifier(class_weight=None, criterion='gini', max_depth=5,
#        max_features=None, max_leaf_nodes=None,
#        min_impurity_decrease=0.0, min_impurity_split=None,
#        min_samples_leaf=1, min_samples_split=2,
#        min_weight_fraction_leaf=0.0, presort=False, random_state=None,
#        splitter='best')

#mlp best features 
############################################
###BUILD FINAL MODEL BASED ON ABOVE RESULTS#
############################################

#view parameters that resulted in best model 
final_rf= Pipeline([('features',feats),
                    ('clf', RandomForestClassifier(n_estimators=500,oob_score=True,max_depth=10
                                                   ,n_jobs=6,max_features=100,min_samples_leaf=1,min_samples_split=5))
                    ])

#refitting on entire training data using best settings
#view predictions and probabilities of each class 
final_rf.fit(data_dic['validation']['x'],data_dic['validation']['y'])
preds = final_rf.predict(data_dic['training']['x'])
probs = final_rf.predict_proba(data_dic['training']['x'])
print('mean accuracy:{}'.format(np.mean(preds == data_dic['training']['y'])))
cf = metrics.confusion_matrix(data_dic['training']['y'],preds)

#save model to file 
import joblib
filename = 'C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/FinalModel/NN_RF_LegalAction.sav'
joblib.dump(final_rf, filename)


















#######SAVING MODEL AND LOADING MODEL FOR LATER USE#######
#NOTE: Generate requirements.txt when exporting model so you can replicate the requirments needed to run the saved model 
#save best model to pickle for use on future data 
filename = 'nn_finalmodel.sav'
pickle.dump(pip_log, open(filename,'wb'))

#load pickled model for evaluation on unseen data 
loaded_model = pickle.load(open(filename,'rb'))
OOS_predictions = loaded_model.score(valid_x,valid_y)
print(OOS_predictions)

#option 2:save model using joblib(useful when algo requires a lot of parameters or store the entire dataset)
#save model 
joblib.dump(pip_log, filename)
#load model 
loaded_model = joblib.load(filename)
OOS_predictions = loaded_model.score(valid_x,valid_y)
print(OOS_predictions)

