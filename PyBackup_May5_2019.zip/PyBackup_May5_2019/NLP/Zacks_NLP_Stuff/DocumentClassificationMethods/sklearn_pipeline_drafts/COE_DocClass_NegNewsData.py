# -*- coding: utf-8 -*-
"""
Created on Mon Nov 12 11:53:30 2018

@author: caridza
"""
#VirtualEnv: docclassify
#VirtualEnv Location: C:\Users\caridza\Downloads\WPy32-3662\ZacksScripts\docclassify

#######################
#######IMPORTS#########
#######################
#install tensorflow: pip3 install --upgrade https://storage.googleapis.com/tensorflow/mac/cpu/tensorflow-1.12.0-py3-none-any.whl
#base modules 
import sys
import pickle
from itertools import islice #iterating over vectorized objects (countvectorizer, tfidfvectorizer,etc..)
import numpy as np
import pandas as pd

#third party modules
#import required modules for data preprocessing , feature engineering and model training
from sklearn import model_selection, preprocessing, linear_model, naive_bayes, metrics, svm
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer,TfidfTransformer
from sklearn import decomposition, ensemble
from sklearn.pipeline import Pipeline
from sklearn.pipeline import make_pipeline

import sklearn
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn import tree
from sklearn import svm
from sklearn import tree
from sklearn.pipeline import Pipeline

import pandas, xgboost, numpy, textblob, string
from keras.preprocessing import text, sequence
from keras import layers, models, optimizers

import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
import matplotlib.pyplot as plt
import matplotlib
import seaborn as sns
   
#custom modules 
#sys.path.insert(0,"C:/Users/caridza/Desktop/pythonScripts/")
sys.path.insert(0,"C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/")
from DocClassFuncs.ClassificationFuncs  import read_corp ,topn_tfidf_freq, create_model_architecture ,create_cnn,create_rnn_lstm, create_rnn_gru,create_bidirectional_rnn,train_model, pipelinize, remove_punctuation, remove_stop, stem_words,PreProcData,remove_punctuation,remove_stop,stem_words,Logistic_TFIDF_Classifer,KNN_TFIDF_Classifer,DT_TFIDF_Classifer,RF_TFIDF_Classifer,generic_pipeline, model_eval

#punctuation to remove, stopwords to remove, stemming and lemmatizing objects for preprocessing
stemmer = SnowballStemmer('english')
wordnet_lemmatizer = WordNetLemmatizer()
exclude = set(string.punctuation)
stopwords = stopwords.words("english")

#####################
#Dataset Preperation#
##################### 
#https://www.kaggle.com/baghern/a-deep-dive-into-sklearn-pipelines
#https://scikit-learn.org/stable/auto_examples/model_selection/grid_search_text_feature_extraction.html
# load the dataset
datapath="C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/NN_ClassificationModelData.pickle"       
data =pd.read_pickle(datapath)

#create a dataframe using texts and lables
trainDF = pandas.DataFrame()
trainDF['text'] = data['origtext']
trainDF['label'] = data['LegalAction']

#transform categorical target into numeric index 
le = preprocessing.LabelEncoder() 
le.fit(trainDF['label'])
trainDF['label'] =le.transform(trainDF['label'])

#GENERATE MODEL PIPELINES 
#NOTE: MULTIPLE APPROACHES SHOWN BELOW FOR GENERATING PIPELINES FOR REFRENCE 
#using make_pipeline you do not have to specify the name of each process
#Note: we fit the pipeline with x and y , but can only transform the indpendent series, pipelines cannoto handle dependent variables transoformations
#Output: Transformed x and y series split into training and test data
train_x,train_y,valid_x,valid_y= PreProcData(trainDF['text'],trainDF['label'])
print(train_y.value_counts(normalize=True))
print(valid_y.value_counts(normalize=True))

#logistic pipeline with preprocessed data(score new data:log_pipe.score(valid_x,valid_y))
pipe_log = Pipeline([('tfidf_vec', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=4000, smooth_idf=True, sublinear_tf=False,lowercase=True,)),('log',  linear_model.LogisticRegression())])
pipe_log.steps #view all steps in above pipeline 
vars(pipe_log.named_steps['log'])
model_perf_dict = model_eval(pipe_log, train_x,train_y,valid_x,valid_y)

  

#knn pipeline 
pipe_knn = KNN_TFIDF_Classifer(train_x,train_y,valid_x,valid_y)
knn_perf_dict = model_eval(pipe_knn, train_x,train_y,valid_x,valid_y)

  
#dt pipeline 
#pipe_dt = DT_TFIDF_Classifer(train_x,train_y,valid_x,valid_y)
pipe_dt = generic_pipeline(train_x,train_y,valid_x,valid_y 
                 ,TfidfVectorizer
                 , tree.DecisionTreeClassifier
                 ,{'analyzer':'word', 'token_pattern':r'\w{1,}', 'max_features':5000, 'smooth_idf':True, 'sublinear_tf':False,'lowercase':True}
                 ,{'random_state':42})
dt_perf_dict = model_eval(pipe_dt, train_x,train_y,valid_x,valid_y)

#rf pipeline 
pipe_rf = generic_pipeline(train_x,train_y,valid_x,valid_y 
                 ,TfidfVectorizer
                 ,RandomForestClassifier
                 ,{'analyzer':'word', 'token_pattern':r'\w{1,}', 'max_features':5000, 'smooth_idf':True, 'sublinear_tf':False,'lowercase':True}
                 #,{'n_estimators':100, 'criterion':'gini','max_depth':20,'min_samples_split':20,'min_samples_leaf':5,'max_features':10})
                 ,{'n_estimators':100, 'criterion':'gini'})
rf_perf_dict = model_eval(pipe_rf, train_x,train_y,valid_x,valid_y)

#mlp pipeline 
pipe_mlp = generic_pipeline(train_x,train_y,valid_x,valid_y 
                 ,TfidfVectorizer
                 ,MLPClassifier
                 ,{'analyzer':'word', 'token_pattern':r'\w{1,}', 'max_features':5000, 'smooth_idf':True, 'sublinear_tf':False,'lowercase':True}
                 ,{'hidden_layer_sizes':(10,), 'activation':'relu','solver':'adam','learning_rate':'constant','shuffle':True})
mlp_perf_dict = model_eval(pipe_mlp, train_x,train_y,valid_x,valid_y)

#evalute models 
#create dictonary to store the name of pipelines in dictonary to be used to display results 
pipe_dic = {0: 'logistic', 1: 'knn', 2:'DT', 3:'RF',4:'mlp'}

#list the four pipelines to execute those pipelines iterativelly
pipelines = [pipe_log,pipe_knn, pipe_dt,pipe_rf,pipe_mlp]

# Fit the pipelines
for pipe in pipelines:
  pipe.fit(train_x, train_y)

# Compare accuracies
for idx, val in enumerate(pipelines):
  print('%s pipeline test accuracy: %.3f' % (pipe_dic[idx], val.score(valid_x, valid_y)))
  
#extract and print infomration on the best model 
best_accuracy = 0
best_classifier = 0
best_pipeline = ''
for idx, val in enumerate(pipelines):
    if val.score(train_x, train_y) > best_accuracy:
        best_accuracy = val.score(valid_x, valid_y)
        best_pipeline = val
        best_classifier = idx
print('%s Classifier has the best accuracy of %.2f' % (pipe_dic[best_classifier],best_accuracy))

#######SAVING MODEL AND LOADING MODEL FOR LATER USE#######
#NOTE: Generate requirements.txt when exporting model so you can replicate the requirments needed to run the saved model 
#save best model to pickle for use on future data 
filename = 'nn_finalmodel.sav'
pickle.dump(pip_log, open(filename,'wb'))

#load pickled model for evaluation on unseen data 
loaded_model = pickle.load(open(filename,'rb'))
OOS_predictions = loaded_model.score(valid_x,valid_y)
print(OOS_predictions)

#option 2:save model using joblib(useful when algo requires a lot of parameters or store the entire dataset)
#save model 
joblib.dump(pip_log, filename)
#load model 
loaded_model = joblib.load(filename)
OOS_predictions = loaded_model.score(valid_x,valid_y)
print(OOS_predictions)

