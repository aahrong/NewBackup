# -*- coding: utf-8 -*-
"""
Created on Mon Nov 12 11:53:30 2018

@author: caridza
"""
#VirtualEnv: docclassify
#VirtualEnv Location: C:\Users\caridza\Downloads\WPy32-3662\ZacksScripts\docclassify
#######################
#######IMPORTS#########
#######################
#install tensorflow: pip3 install --upgrade https://storage.googleapis.com/tensorflow/mac/cpu/tensorflow-1.12.0-py3-none-any.whl
#base modules 
import sys
import pickle
from itertools import islice #iterating over vectorized objects (countvectorizer, tfidfvectorizer,etc..)
import numpy as np
import pandas as pd
from sklearn import model_selection, preprocessing, linear_model, naive_bayes, metrics, svm
from sklearn.model_selection import GridSearchCV
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer,TfidfTransformer
from sklearn.feature_selection import SelectFromModel
from sklearn.svm import LinearSVC
from sklearn import decomposition, ensemble
from sklearn.pipeline import Pipeline
from sklearn.pipeline import make_pipeline,Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.decomposition import TruncatedSVD
import sklearn
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn import tree, svm
from sklearn.metrics import accuracy_score
import pandas, xgboost, numpy, textblob, string
from keras.preprocessing import text, sequence
from keras import layers, models, optimizers
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
import matplotlib.pyplot as plt
import matplotlib
import seaborn as sns
from sklearn.model_selection import cross_val_predict
import scikitplot as skplt
import matplotlib.pyplot as plt
import joblib
import re
#custom modules 
#sys.path.insert(0,"C:/Users/caridza/Desktop/pythonScripts/")
sys.path.insert(0,"C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/")
from DocClassFuncs import ClassificationFuncs
from DocClassFuncs.ClassificationFuncs import TextSelector, NumberSelector
from DocClassFuncs.ClassificationFuncs  import orig_text_clean,remove_nonchars,list_comprehend_a_function, pipelinize,PreProcData,remove_punctuation,remove_stop,stem_words, model_eval,remove_nonchars
from sklearn.preprocessing import FunctionTransformer

#punctuation to remove, stopwords to remove, stemming and lemmatizing objects for preprocessing
stemmer = SnowballStemmer('english')
wordnet_lemmatizer = WordNetLemmatizer()
exclude = set(string.punctuation)
stopwords = stopwords.words("english")

#####################
#Dataset Preperation#
##################### 
#https://www.kaggle.com/baghern/a-deep-dive-into-sklearn-pipelines
#https://scikit-learn.org/stable/auto_examples/model_selection/grid_search_text_feature_extraction.html
#http://www.marcosantoni.com/2016/06/19/a-simple-machine-learning-pipeline.html
#cross validation options: https://scikit-learn.org/stable/modules/cross_validation.html
#https://scikit-learn.org/stable/modules/grid_search.html#grid-search

# load the dataset
datapath="C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/NN_ClassificationModelData.pickle"       
data =pd.read_pickle(datapath)

#create a dataframe using texts and lables
trainDF = orig_text_clean(data,target='LegalAction',maplabelvars=['source'])
    
#categorical and numerical columns in dataframe 
target = 'label_id'
features= [c for c in trainDF.columns.values if c  not in ['label','author',target,'source_id']]
numeric_features= [c for c in trainDF.columns.values if c  not in ['label','author','text',target,'source','source_id']]
#numeric_features.append(target)

# convert column "a" of a DataFrame
for col in numeric_features:
    trainDF[col] = pd.to_numeric(trainDF[col])
#numeric_features.remove(target)
                                  
#test train split 
train_x,valid_x,train_y,valid_y= model_selection.train_test_split(trainDF[features],trainDF[target],shuffle=True, stratify=trainDF[target],test_size=.1, random_state=10)
[x.shape for x in [train_x,train_y,valid_x,valid_y]]

#create a selector transformer that simply returns the one column in the dataset by the key value I pass.
text = Pipeline([
                ('selector', TextSelector(key='text')),
                ('removePunc',  pipelinize(remove_punctuation)),
                ('removenonchar', pipelinize(remove_nonchars)),
                ('removestops', pipelinize(remove_stop)),
                ('stemwords', pipelinize(stem_words)),
                ('tfidf',  TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=400,min_df=.01,max_df=.8, smooth_idf=True, sublinear_tf=False,lowercase=True,))
            ])

#create dictonary of pipelines for all numeric features and standardize them 
numfeat_pipe_dic= {val: Pipeline([('selector', NumberSelector(key=val)),('standard', StandardScaler())]) for val in numeric_features}

#create final list of pipelines, starting with text preprocessing, and finishing with the numeric column normalizations(items listed in order of exectuion so we build initial list with text processing and append all numeric processing tasks after)
final_pipeline = [('text',text)]
final_pipeline.extend([(k,v) for k, v in numfeat_pipe_dic.items()])

#to make a pipeline from all of our pipelines, we do the same thing, but now we use a FeatureUnion to join the feature processing pipelines.
from sklearn.pipeline import FeatureUnion 
feats = FeatureUnion(final_pipeline)
feature_processing = Pipeline([('feats', feats)])
#feature_processing.fit_transform(train_x)

#apply feature pipeline and then apply models 
pipe_rf = Pipeline([('features',feats),
                    #('svm', sklearn.decomposition.TruncatedSVD(n_components=100,random_state=42)),
                    #('clf', RandomForestClassifier(n_estimators=1000,oob_score=True
                    #                               ,min_samples_split=20,max_depth=10
                    #                               ,class_weight='balanced_subsample'
                    #                               ,max_features=100,n_jobs=4))
                    # 
                    
                    ('feature_selection', SelectFromModel(LinearSVC(loss='l2',penalty="l1",dual=False),threshold='mean')), 
                    ('clf', LogisticRegression(random_state=42,max_iter=10000))])
                    
##train basic model with no gridsearch
##https://scikit-plot.readthedocs.io/en/stable/metrics.html
#pipe_rf.fit(train_x, train_y)
#preds = pipe_rf.predict(valid_x)
#pred_probs = pipe_rf.predict_proba(valid_x)
#plotmetrics(valid_y,pred_probs,preds)
##plot confusion matrix 
#np.mean(preds == valid_y)
#cf = metrics.confusion_matrix(valid_y, preds)
#filename = 'C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/FinalModel/NN_Logistic.sav'
#joblib.dump(pipe_rf, filename)
    
#view all attributes that can be tuned
pipe_rf.get_params().keys()
#list of all scoring metrics that can be used
sorted(sklearn.metrics.SCORERS.keys())

#define hyperparameters from pipeline to run gridsearch on rf
#hyperparameters =  [{'clf__criterion': ['gini'], #function to measure the quality of a split (tree level metric)
#		#features__text__tfidf__max_df': [0.9, 0.95],
#        'clf__max_depth': [10,20],
#		'clf__min_samples_split': [.05,.1],
#        'clf__min_samples_leaf':[.1], #The minimum number of samples required to be at a leaf node. A split point at any depth will only be considered if it leaves at least min_samples_leaf training samples in each of the left and right branches
#        'clf__max_features':[.2,.7], #number of features to consider when looking for the best split (If “auto”, then max_features=sqrt(n_features))
#        'clf__class_weight':['balanced_subsample']
#        }]

#logistic hyper parameters
hyperparameters = [{'feature_selection__max_features':[200],
                    'clf__solver':['newton-cg','saga'],
                    'clf__penalty': ['l2'],
                    'clf__C': [1.0, 0.5, 0.1],               #Inverse of regularization strength; smaller values specify stronger regularization
                    'clf__class_weight':['balanced']         #“balanced” mode uses the values of y to automatically adjust weights inversely proportional to class frequencies in the input data as n_samples / (n_classes * np.bincount(y)).
                    }] 

jobs=4
clf = GridSearchCV(pipe_rf, hyperparameters, cv=3, scoring='balanced_accuracy', refit=True, verbose=5)#,n_jobs=jobs)
#clfr = RandomizedSearchCV(pipe_rf, hyperparameters, cv=5, n_iter =20,scoring='balanced_accuracy',n_jobs=3)
  
# Fit and tune model
clf.fit(train_x, train_y)

#view parameters that resulted in best model 
optimized_parms = clf.best_params_
optimized_clf= clf.best_estimator_

#cross validation metrics for all considered models
cv_metrics = pd.DataFrame(clf.cv_results_)
report(cv_metrics)

#refitting on entire training data using best settings
#view predictions and probabilities of each class 
clf.refit
preds = clf.predict(valid_x)
probs = clf.predict_proba(valid_x)
np.mean(preds == valid_y)
cf = metrics.confusion_matrix(valid_y, preds)

#save model to file 
import joblib
filename = 'C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/FinalModel/NN_Logistic.sav'
joblib.dump(optimized_clf, filename)



#Final Prediction on entire dataset
#load model 
loaded_model = joblib.load(filename)

#len(newdata.loc[newdata.index.duplicated(keep='first')])
newdata = orig_text_clean(data)

#preds on new data 
predictions = loaded_model.predict_proba(newdata)
preds = pd.DataFrame(data=predictions, columns = loaded_model.classes_)

#generating a submission file
results = pd.concat([newdata, preds], axis=1)


dir(loaded_model)






















#define grid search critera 
grid_params_rf = [{'clf__criterion': ['gini', 'entropy'], #function to measure the quality of a split (tree level metric)
		'clf__min_samples_leaf': [10,20],
		'clf__max_depth': [10,20],
		'clf__min_samples_split': [10,20],
        'clf__min_samples_leaf':[20,100], #The minimum number of samples required to be at a leaf node. A split point at any depth will only be considered if it leaves at least min_samples_leaf training samples in each of the left and right branches
        'clf__max_features':[50,100], #number of features to consider when looking for the best split (If “auto”, then max_features=sqrt(n_features))
        #'clf__class_weight':['balanced_subsample']
        }]



#run grid search 
from GridModelSelection import EstimatorSelectionHelpers 
from GridModelSelection import EstimatorSelectionHelpers 
GridSearchModelDic = {'rf':pipe_rf}
GridSearchParamDic = {'rf':grid_params_rf}

helper1 = EstimatorSelectionHelpers.EstimatorSelectionHelper(GridSearchModelDic, GridSearchParamDic)
helper1.fit(train_x, train_y, scoring='balanced_accuracy', n_jobs=5)
helper1.score_summary(sort_by='max_score')

    
    
    
    


#create pipelines for each type of classifer you want to run grid search on
#next steps: create dictonarys with pipelines with key indicating the model, and value being the pipeline 
#feature selection: https://scikit-learn.org/stable/modules/feature_selection.html
pipe_rf = Pipeline([('tfidf_vec', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=400, smooth_idf=True, sublinear_tf=False,lowercase=True,)),
                    ('svm', sklearn.decomposition.TruncatedSVD(n_components=100,random_state=42)),
                    ('clf', RandomForestClassifier(n_estimators=500,oob_score=True))])

pipe_lr= Pipeline([('tfidf_vec', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=400, smooth_idf=True, sublinear_tf=False,lowercase=True,)),
                   ('feature_selection', SelectFromModel(LinearSVC(penalty="l1"))), 
                   ('clf', LogisticRegression(random_state=42))])

pipe_lr_pca = Pipeline([('tfidf_vec', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=400, smooth_idf=True, sublinear_tf=False,lowercase=True,)),
                        ('pca', TruncatedSVD(n_components=100)),
                        ('clf', LogisticRegression(random_state=42))])

pipe_svm = Pipeline([('tfidf_vec', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=400, smooth_idf=True, sublinear_tf=False,lowercase=True,)),
                     ('clf', MLPClassifier(solver='adam'))])

pipe_mlp = Pipeline([('tfidf_vec', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=400, smooth_idf=True, sublinear_tf=False,lowercase=True,)),
                     ('clf', svm.SVC(random_state=42))])

#save and print coefficents that can be used in grid search for each model 
pipes = [pipe_rf,pipe_lr,pipe_lr_pca,pipe_svm,pipe_mlp]
for pipe in pipes:
    print(vars(pipe.named_steps['clf']))
    

# Set grid search params
grid_params_lr = [{'clf__penalty': ['l1', 'l2'],
		'clf__C': [1.0, 0.5, 0.1],                 #Inverse of regularization strength; smaller values specify stronger regularization
		'clf__solver': ['liblinear'],     #‘newton-cg’, ‘lbfgs’ and ‘sag’ only handle L2 penalty, whereas ‘liblinear’ and ‘saga’ handle L1 penalty.
        'clf__class_weight':['balanced']           #“balanced” mode uses the values of y to automatically adjust weights inversely proportional to class frequencies in the input data as n_samples / (n_classes * np.bincount(y)).
        }] 

grid_params_rf = [{'clf__criterion': ['gini', 'entropy'], #function to measure the quality of a split (tree level metric)
		'clf__min_samples_leaf': [10,20],
		'clf__max_depth': [10,20],
		'clf__min_samples_split': [10,20],
        'clf__min_samples_leaf':[20,100], #The minimum number of samples required to be at a leaf node. A split point at any depth will only be considered if it leaves at least min_samples_leaf training samples in each of the left and right branches
        'clf__max_features':[50,100], #number of features to consider when looking for the best split (If “auto”, then max_features=sqrt(n_features))
        'clf__class_weight':['balanced','balanced_subsample']
        }]
    
grid_params_svm = [{'clf__kernel': ['linear', 'rbf'], 
		'clf__C': [2,10,20]
        }]

grid_params_mlp= [{'clf__activation': ['logistic', 'relu'], 
                   'clf__alpha': [1.0, 0.5, 0.1]
                   }]


#dictonary of models and grid search parameters 
from GridModelSelection import EstimatorSelectionHelpers
from GridModelSelection.EstimatorSelectionHelpers import EstimatorSelectionHelper

GridSearchModelDic = {'lr':pipe_lr,'rf':pipe_rf,'lr_pca':pipe_lr_pca,'svm':pipe_svm,'mlp':pipe_mlp}
GridSearchParamDic = {'lr':grid_params_lr,'rf':grid_params_rf,'lr_pca':grid_params_lr,'svm':grid_params_svm,'mlp':grid_params_mlp}

#execute grid search using wrappers
#single model wrapper
#grid_search_wrapper(train_x,train_y,valid_x,valid_y,pipe_lr,param_grid = grid_params_lr,scorers='balanced_accuracy',refit_score='precision_score')
#multiple model wrapper
helper1 = EstimatorSelectionHelper(GridSearchModelDic, GridSearchParamDic)
helper1.fit(train_x, train_y, scoring='balanced_accuracy', n_jobs=5)
helper1.score_summary(sort_by='max_score')













#pass parameters to iterate over to gribserach object 
jobs=4
gs_rf = GridSearchCV(estimator=pipe_rf,
			param_grid=grid_params_rf,
			scoring='balanced_accuracy',
			cv=5, 
			n_jobs=jobs)

gs_mlp = GridSearchCV(estimator=pipe_mlp,
			param_grid=grid_params_mlp,
			scoring='balanced_accuracy',
			cv=5, 
			n_jobs=jobs)
gs_lr = GridSearchCV(estimator=pipe_lr,
			param_grid=grid_params_lr,
			scoring='balanced_accuracy',
			cv=5, 
			n_jobs=jobs)    
gs_svm = GridSearchCV(estimator=pipe_svm,
			param_grid=grid_params_svm,
			scoring='balanced_accuracy',
			cv=5, 
			n_jobs=jobs) 

#create list of all grids 
grids = [gs_lr, gs_rf, gs_svm, gs_mlp]

# Dictionary of pipelines and classifier types for ease of reference
grid_dict = {0: 'Logistic Regression',1: 'Random Forest',2: 'Support Vector Machine', 3: 'MLP'}

# Fit the grid search objects
print('Performing model optimizations...')
best_acc = 0.0
best_clf = 0
best_gs = ''
for idx, gs in enumerate(grids):
	print('\nEstimator: %s' % grid_dict[idx])	
	# Fit grid search	
	gs.fit(train_x, train_y)
	# Best params
	print('Best params: %s' % gs.best_params_)
	# Best training data accuracy
	print('Best training accuracy: %.3f' % gs.best_score_)
	# Predict on test data with best params
	y_pred = gs.predict(valid_x)
	# Test data accuracy of model with best params
	print('Test set accuracy score for best params: %.3f ' % accuracy_score(valid_y, y_pred))
	# Track best (highest test accuracy) model
	if accuracy_score(valid_y, y_pred) > best_acc:
		best_acc = accuracy_score(valid_y, y_pred)
		best_gs = gs
		best_clf = idx
print('\nClassifier with best test set accuracy: %s' % grid_dict[best_clf])

# Save best grid search pipeline to file
dump_file = 'best_gs_pipeline.pkl'
joblib.dump(best_gs, dump_file, compress=1)
print('\nSaved %s grid search pipeline to file: %s' % (grid_dict[best_clf], dump_file))













































#Grid Search critera for each model 


pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(stop_words=stopwords)),
    ('clf', RandomForestClassifier(n_estimators=20)),
])

parameters = {
    'tfidf__max_df': ( 0.5, 0.75,1),
    'tfidf__ngram_range': [(1, 1), (1, 2)],
    'clf__max_depth': [5,10,15],
    'clf__min_samples_split': [10,15],
    'clf__max_features': [3, 10],
    'clf__bootstrap': [True,False],
    'clf__criterion':["gini","entropy"],

    }

grid_search_tune = GridSearchCV(pipeline, parameters, cv=2, n_jobs=4, verbose=3)
grid_search_tune.fit(train_x, train_y)
report(grid_search.cv_results_)

#############################################################################################
#GRID SEARCH ACROSS MULTIPLE MODELS 
#https://towardsdatascience.com/multi-class-text-classification-with-scikit-learn-12f1e60e0a9f
#https://www.kdnuggets.com/2018/01/managing-machine-learning-workflows-scikit-learn-pipelines-part-3.html
#https://spandan-madan.github.io/DeepLearningProject/docs/Deep_Learning_Project-Pytorch.html
#https://www.kaggle.com/kashnitsky/topic-2-visual-data-analysis-in-python

from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import LinearSVC
from sklearn.model_selection import cross_val_score

#create tf-idf for entire dataframe
tfidf = TfidfVectorizer(sublinear_tf=True, min_df=5, norm='l2', encoding='latin-1', ngram_range=(1, 2), stop_words='english')
features = tfidf.fit_transform(trainDF.text).toarray()
labels = trainDF.label_id
features.shape

#identify terms most corrolated with each target level 
from sklearn.feature_selection import chi2
import numpy as np
N = 4
for label, label_id in sorted(label_to_id.items()):
    print(label)
  features_chi2 = chi2(features, labels == label_id)
  indices = np.argsort(features_chi2[0])
  feature_names = np.array(tfidf.get_feature_names())[indices]
  unigrams = [v for v in feature_names if len(v.split(' ')) == 1]
  bigrams = [v for v in feature_names if len(v.split(' ')) == 2]
  print("# '{}':".format(label))
  print("  . Most correlated unigrams:\n. {}".format('\n. '.join(unigrams[-N:])))
  print("  . Most correlated bigrams:\n. {}".format('\n. '.join(bigrams[-N:])))
  
#build training tfidf representaiton for modeling 
count_vect = CountVectorizer()
X_train_counts = count_vect.fit_transform(train_x)
tfidf_transformer = TfidfTransformer()
X_train_tfidf = tfidf_transformer.fit_transform(X_train_counts)

#models to evaluate 
models = [
    RandomForestClassifier(n_estimators=200, max_depth=3, random_state=0),
    LinearSVC(),
    MultinomialNB(),
    LogisticRegression(random_state=0),
]

#cross validation metrics setup 
CV = 5
cv_df = pd.DataFrame(index=range(CV * len(models)))
entries = []
for model in models:
  model_name = model.__class__.__name__
  accuracies = cross_val_score(model, features, labels, scoring='accuracy', cv=CV)
  for fold_idx, accuracy in enumerate(accuracies):
    entries.append((model_name, fold_idx, accuracy))
cv_df = pd.DataFrame(entries, columns=['model_name', 'fold_idx', 'accuracy'])

#plot cv 
import seaborn as sns
sns.boxplot(x='model_name', y='accuracy', data=cv_df)
sns.stripplot(x='model_name', y='accuracy', data=cv_df, 
              size=8, jitter=True, edgecolor="gray", linewidth=2)
plt.show()

cv_df.groupby('model_name').accuracy.mean()



# Utility function to report best scores
def report(results, n_top=3):
    for i in range(1, n_top + 1):
        candidates = np.flatnonzero(results['rank_test_score'] == i)
        for candidate in candidates:
            print("Model with rank: {0}".format(i))
            print("Mean validation score: {0:.3f} (std: {1:.3f})".format(
                  results['mean_test_score'][candidate],
                  results['std_test_score'][candidate]))
            print("Parameters: {0}".format(results['params'][candidate]))
            print("")






















#logistic pipeline with preprocessed data(score new data:log_pipe.score(valid_x,valid_y))
pipe_log = Pipeline([('tfidf_vec', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=4000, smooth_idf=True, sublinear_tf=False,lowercase=True,)),('log',  linear_model.LogisticRegression())])
pipe_log.steps #view all steps in above pipeline 
vars(pipe_log.named_steps['log'])
model_perf_dict = model_eval(pipe_log, train_x,train_y,valid_x,valid_y)

  

#knn pipeline 
pipe_knn = KNN_TFIDF_Classifer(train_x,train_y,valid_x,valid_y)
knn_perf_dict = model_eval(pipe_knn, train_x,train_y,valid_x,valid_y)

  
#dt pipeline 
#pipe_dt = DT_TFIDF_Classifer(train_x,train_y,valid_x,valid_y)
pipe_dt = generic_pipeline(train_x,train_y,valid_x,valid_y 
                 ,TfidfVectorizer
                 , tree.DecisionTreeClassifier
                 ,{'analyzer':'word', 'token_pattern':r'\w{1,}', 'max_features':5000, 'smooth_idf':True, 'sublinear_tf':False,'lowercase':True}
                 ,{'random_state':42})
dt_perf_dict = model_eval(pipe_dt, train_x,train_y,valid_x,valid_y)

#rf pipeline 
pipe_rf = generic_pipeline(train_x,train_y,valid_x,valid_y 
                 ,TfidfVectorizer
                 ,RandomForestClassifier
                 ,{'analyzer':'word', 'token_pattern':r'\w{1,}', 'max_features':5000, 'smooth_idf':True, 'sublinear_tf':False,'lowercase':True}
                 #,{'n_estimators':100, 'criterion':'gini','max_depth':20,'min_samples_split':20,'min_samples_leaf':5,'max_features':10})
                 ,{'n_estimators':100, 'criterion':'gini'})
rf_perf_dict = model_eval(pipe_rf, train_x,train_y,valid_x,valid_y)

#mlp pipeline 
pipe_mlp = generic_pipeline(train_x,train_y,valid_x,valid_y 
                 ,TfidfVectorizer
                 ,MLPClassifier
                 ,{'analyzer':'word', 'token_pattern':r'\w{1,}', 'max_features':5000, 'smooth_idf':True, 'sublinear_tf':False,'lowercase':True}
                 ,{'hidden_layer_sizes':(10,), 'activation':'relu','solver':'adam','learning_rate':'constant','shuffle':True})
mlp_perf_dict = model_eval(pipe_mlp, train_x,train_y,valid_x,valid_y)

#evalute models 
#create dictonary to store the name of pipelines in dictonary to be used to display results 
pipe_dic = {0: 'logistic', 1: 'knn', 2:'DT', 3:'RF',4:'mlp'}

#list the four pipelines to execute those pipelines iterativelly
pipelines = [pipe_log,pipe_knn, pipe_dt,pipe_rf,pipe_mlp]

# Fit the pipelines
for pipe in pipelines:
  pipe.fit(train_x, train_y)

# Compare accuracies
for idx, val in enumerate(pipelines):
  print('%s pipeline test accuracy: %.3f' % (pipe_dic[idx], val.score(valid_x, valid_y)))
  
#extract and print infomration on the best model 
best_accuracy = 0
best_classifier = 0
best_pipeline = ''
for idx, val in enumerate(pipelines):
    if val.score(train_x, train_y) > best_accuracy:
        best_accuracy = val.score(valid_x, valid_y)
        best_pipeline = val
        best_classifier = idx
print('%s Classifier has the best accuracy of %.2f' % (pipe_dic[best_classifier],best_accuracy))

#######SAVING MODEL AND LOADING MODEL FOR LATER USE#######
#NOTE: Generate requirements.txt when exporting model so you can replicate the requirments needed to run the saved model 
#save best model to pickle for use on future data 
filename = 'nn_finalmodel.sav'
pickle.dump(pip_log, open(filename,'wb'))

#load pickled model for evaluation on unseen data 
loaded_model = pickle.load(open(filename,'rb'))
OOS_predictions = loaded_model.score(valid_x,valid_y)
print(OOS_predictions)

#option 2:save model using joblib(useful when algo requires a lot of parameters or store the entire dataset)
#save model 
joblib.dump(pip_log, filename)
#load model 
loaded_model = joblib.load(filename)
OOS_predictions = loaded_model.score(valid_x,valid_y)
print(OOS_predictions)

