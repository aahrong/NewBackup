# -*- coding: utf-8 -*-
"""
Created on Tue Jan 15 18:30:56 2019

@author: caridza
"""
import sys
import pandas as pd 
from sklearn.model_selection import train_test_split
from sklearn_pandas import DataFrameMapper, cross_val_score
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler

import nltk
import numpy as np
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
from collections import Counter

#custom modules 
sys.path.insert(0,"C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/")
import DocClassFuncs
from DocClassFuncs import ClassificationFuncs
from DocClassFuncs.ClassificationFuncs import TextSelector, NumberSelector,DenseTransformer,orig_text_clean


#punctuation to remove, stopwords to remove, stemming and lemmatizing objects for preprocessing
stemmer = SnowballStemmer('english')
wordnet_lemmatizer = WordNetLemmatizer()
exclude = set(string.punctuation)
stopwords = stopwords.words("english")


# load the dataset
data = pd.read_pickle("C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/NN_ClassificationModelData.pickle")

#create a dataframe using texts and lables and conduct preprocessing
trainDF = orig_text_clean(data,target='LegalAction',maplabelvars=['source'],stopwords=stopwords,stemmer=stemmer)

#dataframe mapper appraoch (not going to use)
mapper = DataFrameMapper([
     ('cleantxt',  TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=400,min_df=.01,max_df=.8, smooth_idf=True, sublinear_tf=False,lowercase=True,)),
     #('title',  TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=400,min_df=.01,max_df=.8, smooth_idf=True, sublinear_tf=False,lowercase=True,)),
     #('summary',  TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=400,min_df=.01,max_df=.8, smooth_idf=True, sublinear_tf=False,lowercase=True,)),
     ('source_id', None ),
     #('txt_lngth',StandardScaler()),
     #('txt_words',StandardScaler()),
     #('txt_nonstopwords',StandardScaler()),
     #('total_commas',StandardScaler()),

     ])
 








      