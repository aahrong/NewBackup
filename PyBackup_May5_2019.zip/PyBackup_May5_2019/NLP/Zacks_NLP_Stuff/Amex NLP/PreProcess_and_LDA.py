# -*- coding: utf-8 -*-
"""
Created on Fri Jun 23 16:34:10 2017

@author: queenmi
"""

import spacy
import codecs
import pandas as pd
import os
from gensim.models import Phrases
from gensim.models.word2vec import LineSentence
from gensim.corpora import Dictionary, MmCorpus
from gensim.models.ldamulticore import LdaMulticore
import warnings
import pyLDAvis
import pyLDAvis.gensim

# Change working directory
os.chdir("C:/Users/queenmi/Documents/Personal/Kaggle/Spooky_Authors")

# Load SpaCy's english model
nlp = spacy.load('en')

# Read in the dialogues
location = "train.csv"
reader = pd.read_csv(location)

# Create a dictionary with id as key
text_dict = reader.set_index("id").to_dict()["text"]

# Loop through dict to create a single text file containing all lines of dialogue, 
# where each line represents a single utterance.
text_filepath = "text_all.txt"

with codecs.open(text_filepath, 'w', encoding='utf_8') as txt_file:
    for key, value in text_dict.items():
        txt_file.write(text_dict[key].replace('\n', '\\n') + '\n')

# Define helper functions for pre-processing. These use spaCy.
def punct_space(token):
    """
    helper function to eliminate tokens
    that are pure punctuation or whitespace
    """
    
    return token.is_punct or token.is_space

def line_utterance(filename):
    """
    generator function to read in documents from the file
    and un-escape the original line breaks in the text
    """
    
    with codecs.open(filename, encoding='utf_8') as f:
        for document in f:
            yield document.replace('\\n', '\n')
            
def lemmatized_sentence_corpus(filename):
    """
    generator function to use spaCy to parse utterances,
    lemmatize the text, and yield sentences
    """
    
    for parsed_review in nlp.pipe(line_utterance(filename),
                                  batch_size=1000, n_threads=2):
        
        for sent in parsed_review.sents:
            yield u' '.join([token.lemma_ for token in sent
                             if not punct_space(token) and not token.is_stop])

# Specify a new text file to store the normalized and parsed sentences. 
unigram_sentences_filepath = 'unigram_sentences_all.txt'
    
# Loop through our original text file and call our helper functions to process text.
with codecs.open(unigram_sentences_filepath, 'w', encoding='utf_8') as f:
        for sentence in lemmatized_sentence_corpus(text_filepath):
            f.write(sentence + '\n')

# Use GenSim's LineSentence function to create one sentence to one line format for modeling
unigram_sentences = LineSentence(unigram_sentences_filepath)

# Build a phrase extraction model to capture bi-grams and tri-grams
# Specify spot to store bi-gram model
bigram_model_filepath = 'bigram_model_all'

bigram_model = Phrases(unigram_sentences)

bigram_model.save(bigram_model_filepath)

#Apply the bi-gram model on the corpus
# Specify location for storing corpus with bi-grams
bigram_sentences_filepath = 'bigram_sentences_all.txt'

# Loop through sentences and apply bi_gram
with codecs.open(bigram_sentences_filepath, 'w', encoding='utf_8') as f:        
        for unigram_sentence in unigram_sentences:            
            bigram_sentence = u' '.join(bigram_model[unigram_sentence])            
            f.write(bigram_sentence + '\n')

#Create one line to one sentence format for modeling
bigram_sentences = LineSentence(bigram_sentences_filepath)

#Specify location for storing tri-gram model
trigram_model_filepath ='trigram_model_all'

# We will now apply a second order phrase model to get tri-grams
trigram_model = Phrases(bigram_sentences)

trigram_model.save(trigram_model_filepath)
    
# load the finished model from disk
trigram_model = Phrases.load(trigram_model_filepath)

# Specify location to store corpus with tri-grams
trigram_sentences_filepath = 'trigram_sentences_all.txt'

# loop through bi-gram sentences and apply tri-grams
with codecs.open(trigram_sentences_filepath, 'w', encoding='utf_8') as f:
    for bigram_sentence in bigram_sentences:
        trigram_sentence = u' '.join(trigram_model[bigram_sentence])
        f.write(trigram_sentence + '\n')

# Format tri-grams for modeling
trigram_sentences = LineSentence(trigram_sentences_filepath)

# Loop through our original text file and call our helper functions to process text.
with codecs.open(unigram_sentences_filepath, 'w', encoding='utf_8') as f:
        for sentence in lemmatized_sentence_corpus(text_filepath):
            f.write(sentence + '\n')

# Now that we have a pre-processed corpus with bi-grams and tri-grams, let's do some 
# experimentation with LDA

trigram_dictionary_filepath = 'trigram_dict_all.dict'

# learn a dictionary by iterating over all of the reviews. This is needed
# to create he bag of words representation
trigram_dictionary = Dictionary(trigram_sentences)

# filter tokens that are very rare or too common from
# the dictionary (filter_extremes) and reassign integer ids (compactify)
trigram_dictionary.filter_extremes(no_below=5, no_above=0.5)
trigram_dictionary.compactify()

trigram_dictionary.save(trigram_dictionary_filepath)

# load the finished dictionary from disk
trigram_dictionary = Dictionary.load(trigram_dictionary_filepath)

# Specify location to store bag of words representations
trigram_bow_filepath = 'trigram_bow_corpus_all.mm'

# Define function to create bag of words
def trigram_bow_generator(filepath):
    for utterance in LineSentence(filepath):
        yield trigram_dictionary.doc2bow(utterance)

#Apply the BoW function to the tri-grams corpus
MmCorpus.serialize(trigram_bow_filepath,
                   trigram_bow_generator(trigram_sentences_filepath))
    
# load the finished bag-of-words corpus from disk
trigram_bow_corpus = MmCorpus(trigram_bow_filepath)

# Specify path to store LDA model
lda_model_filepath = 'lda_model_all'

with warnings.catch_warnings():
    warnings.simplefilter('ignore')
        
    # workers sets the parallelism and should be
    # set to your number of physical cores minus one
    lda = LdaMulticore(trigram_bow_corpus,
                       num_topics=10,
                       id2word=trigram_dictionary,
                       workers=1)
    
    lda.save(lda_model_filepath)
    
# load the finished LDA model from disk
lda = LdaMulticore.load(lda_model_filepath)

# Specify location for storing data prepped for visualization
LDAvis_data_filepath = 'ldavis_prepared'

LDAvis_prepared = pyLDAvis.gensim.prepare(lda, trigram_bow_corpus,
                                              trigram_dictionary)

pyLDAvis.save_html(LDAvis_prepared, "lda_vis.html")

# Explore topic-term distributions
# Create function that takes user supplied topic number and returns top terms
def explore_topic(topic_number, topn=25):
    """
    accept a user-supplied topic number and
    print out a formatted list of the top terms
    """       
    print(u'{:20} {}'.format(u'term', u'frequency') + u'\n')
    
    for term, frequency in lda.show_topic(topic_number, topn=25):
        print(u'{:20} {:.3f}'.format(term, round(frequency, 3)))

# Explore topics with our function 
explore_topic(1)
