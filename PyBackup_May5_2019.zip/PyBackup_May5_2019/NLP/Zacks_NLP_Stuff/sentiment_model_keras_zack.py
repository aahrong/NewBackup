# -*- coding: utf-8 -*-
"""
Created on Tue Apr 16 15:21:16 2019

@author: caridza
"""

#!/usr/bin/env python
# coding: utf-8


"""
Created on Wed Jan 30 08:19:40 2019
https://www.kaggle.com/takuok/bidirectional-lstm-and-attention-lb-0-043
@author: caridza
"""
#for hpyer parameter tuning
import comet_ml 
from comet_ml import experiment
import argparse
import os 
import sys
import pandas as pd 
import pymagnitude
import re
import string 
import numpy as np
import nltk
from sklearn import preprocessing , model_selection, metrics
from sklearn.model_selection import StratifiedShuffleSplit
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk import regexp_tokenize
from nltk.tokenize import word_tokenize , sent_tokenize

#MUST IMPORT ALL FROM EITHER KERAS or Tensorflow.python.keras. YOU CANNOT MIX
import keras 
import keras_self_attention
from keras.preprocessing.text import Tokenizer 
from keras.preprocessing.sequence import pad_sequences 
from keras.preprocessing.text import Tokenizer 
from keras.preprocessing.sequence import pad_sequences 
from keras.callbacks import ModelCheckpoint, EarlyStopping
from keras_self_attention import SeqSelfAttention 
from keras.callbacks import Callback

import gensim
from imblearn.over_sampling import SMOTE  # or: import RandomOverSampler
from imblearn.pipeline import Pipeline as imbPipeline
from matplotlib import pyplot
import matplotlib.pyplot as plt

#DEFINING CUSTOM METRICS TO USE WITH KERAS 
import numpy as np
from sklearn.metrics import confusion_matrix, f1_score, precision_score, recall_score

def bin_sentiment(sentiment_score,SENTIMENT_NEUTRAL_LB=-.05,SENTIMENT_NEUTRAL_UB=.05):
    '''Bins continuous sentiment score into discrete buckets'''
    if sentiment_score < SENTIMENT_NEUTRAL_LB:
        return -1
    elif sentiment_score > SENTIMENT_NEUTRAL_UB:
        return 1
    else:
        return 0
    
#stopwords, stemmer
DATAPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/NewData/NEW_SENTLEVEL_CLASSIFICATIONS_DF.pickle"
OUTPUTPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/"

stemmer = SnowballStemmer('english')
exclude = set(string.punctuation)
stopwords = stopwords.words('english')
newStopWords = ['.','?','%','Google','Wells Fargo','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December']
stopwords.extend(newStopWords)
stop_list=set(stopwords)
wv=pymagnitude.Magnitude('C://Users//caridza//Downloads//crawl-300d-2M.magnitude')

#inputs requiring path specification
max_features = 100000000 #maximum number of words to consider in analysis 
EMBEDDING_DIM = 300 #NOTE: becuase we use pymag this must be set to 300 
stop_list = stop_list
stemmer = stemmer
target = 'Sentiment_Bin'

#SPECIFY KERAS CALLBACKS 
filepath = "best_bilstm.hdf5"
monitor = 'val_acc'
min_max_metric = 'max'

#MODEL FIT CONSTANTS 
batch_size = 200 
epochs=50



#FUNCTION TO CLEAN ORIGINAL TEXT FOR MODEL INPUT
def orig_text_clean(data,target='LegalAction',txtfeild='origtext',maplabelvars=['source']
                    ,stopwords=['the','is','a','i','are','it'],stemmer=None,score_new=False):
    trainDF = pd.DataFrame()
    trainDF['text'] = data[txtfeild].apply(lambda x: remove_punctuation(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_nonchars(x))
    if stemmer==None:
        trainDF[txtfeild] = trainDF['text'].apply(lambda x: remove_stop(x,stopwords=stopwords))
    else:
        trainDF['text'] = trainDF['text'].apply(lambda x: remove_stop(x,stopwords=stopwords))
        trainDF[txtfeild] = trainDF['text'].apply(lambda x: stem_words(x,stemmer=stemmer))
    
    if score_new==False:
        trainDF['label'] = data[target]
        le = preprocessing.LabelEncoder() 
        le.fit(trainDF['label'])
        trainDF['label_id'] =le.transform(trainDF['label'])
            
    trainDF=trainDF.reset_index(drop=True)
    return trainDF 

#preprocess data 
#func to remove punc from string and return string
def remove_punctuation(text,excluded_punct={'+', ':', '[', '^', '"', '|', '{', '@', '=', ')', '%', '#', '`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}):
    return ' '.join([word for word in nltk.word_tokenize(text) if word not in excluded_punct])

#func to remove stop words 
def remove_stop(text,stopwords=['the','is','a','i','are','it']):
    return ' '.join([word for word in text.split(' ') if word.lower() not in stopwords])

#func to stem words 
def stem_words(text,stemmer=None):
    return ' '.join([stemmer.stem(word) for word in text.split(' ')])

#remove non alpha characters from text 
def remove_nonchars(text):
    return ' '.join([re.sub('[^A-Za-z|^\$|^\.]+', ' ', word) for word in text.split(' ') if (word.isalnum() and len(word)>2)])


#####MODEL DATA PREPROCESSING FUNCTION 
def make_df(datapath , max_features,EMBEDDING_DIM,stop_list,stemmer,target,txtfeild,rebalance_data=False,test_size=.2):
    '''
    Inputs: 
    ##### datapath = path to dataframe of sentences and label ids 
    ##### max_features = total number of features from text to consider when buildling embedding layer
    ##### EMBEDDING_DIM = total number of dimensions from embedding we want to use in embedding layer (Note: if using pymag you must use 300)
    ##### stop_lsit = list of stopwords to use for preprocessing 
    ##### stemmer = stemming class to use to stem words in sentences 
    ##### target = name of the target feild you are trying to predict in the dataset 
    PROCESS STEPS: 
    ##### 1. toeknize text
    ##### 2. Convert text to sequences
    ##### 3. Pad Sequences 
    ##### 4. Split into Test and Train
    ##### 5. Return X_train , X_Test, Y, WordIndex 
    '''
    #load data
    if isinstance(datapath,object): 
        data = datapath 
    else:
        data = pd.read_pickle(datapath)
    
    #clean original sentence level text
    trainDF = orig_text_clean(data,target=target , txtfeild=txtfeild,stopwords=stop_list,stemmer=None,score_new=False) 
    
    #specify X and Y (these standard columns are created in orig_text_clean)
    X = trainDF[txtfeild]
    Y = trainDF['label_id']
    
    #generate list of unique words based on total words specified to consider
    sentences = []
    lines = X.values.tolist()
    lines = [word_tokenize(sent) for sent in lines]
    model=gensim.models.Word2Vec(sentences=lines, size=EMBEDDING_DIM,window=5,workers=4,min_count=1)
    words = list(model.wv.vocab)
    
    #model process 
    #fit tokenizer to words and turn to sequences 
    tokenizer_obj = Tokenizer()
    tokenizer_obj.fit_on_texts(X)
    sequences = tokenizer_obj.texts_to_sequences(X)
    
    #define max length for padding and total vocab size
    max_length = max([len(s.split()) for s in X]) 
    vocab_size = len(tokenizer_obj.word_index)+1
    
    #pad sequences 
    word_index = tokenizer_obj.word_index
    review_pad = pad_sequences(sequences,maxlen=max_length)
    label = Y.values
    
    #split data 
    x_train,x_test,y_train,y_test = model_selection.train_test_split(review_pad, label,shuffle=True, stratify=Y,test_size=test_size, random_state=10)
    
    if rebalance_data == True:
        sm = SMOTE(random_state=2)
        x_train, y_train = sm.fit_sample(x_train, y_train)

    return x_train, y_train, x_test, y_test, word_index, max_length , words

#EMBEDDING GENERATION FUNCTIONS:FUNCTIONS TO GENERATE EMBEDDINGS FROM PRETRAINED EMBEDDINGS FOR EMBEDDINGS LAYER IN NN 
#pymagnitude vectors 
def make_embeddings_pymag(wv, max_features,words, word_index, embed_size, nb_words):
    #embeddings using pymagnitude 
    embeddings_index = {}
    for w in words:
        word =w
        coefs = wv.query(word) #np.asarray(values[1:])
        embeddings_index[word]=coefs

    embedding_matrix = np.zeros((nb_words, embed_size))
    for word, i in word_index.items():
        if i >= max_features:
            continue
        embedding_vector = embeddings_index.get(word)
        if embedding_vector is not None:
            embedding_matrix[i] = embedding_vector
    return embedding_matrix


def load_data(datapath = DATAPATH):
    #generate unbalanced holdout and balanecd training data for model training
    Data = pd.read_pickle(datapath).head(10000)
    Data['Sentiment_Bin'] = Data['sentence_sentiment'].apply(lambda x: bin_sentiment(x))
    return Data


def get_embedding_vectors(max_features=None,word_index=None,wv=None,words=None,EMBEDDING_DIM=None):
    #GENERATE EMBEDDING MATRIX FOR EMBEDDING LAYER IN MODEL(using pymagnitude converted vectors)
    nb_words = min(max_features, len(word_index)+1) #total features to consider, min of the max feats vs total feats 
    embedding_vector =  make_embeddings_pymag(wv, max_features,words, word_index, EMBEDDING_DIM, nb_words)
    return embedding_vector,nb_words


#BEGIN MODEL LAYER DEFFINITIONS 
#Initialize Sequential Model class  
def create_model(nb_words=None,EMBEDDING_DIM=None,embedding_vector=None,maxlen=None):
    model=keras.models.Sequential()
    
    #add embedding layer
    model.add(keras.layers.Embedding(input_dim = nb_words #max_features
                                     , output_dim= EMBEDDING_DIM #embedding size 
                                     , weights = [embedding_vector]
                                     , mask_zero=False
                                     #, trainable=False  #if True transfer learning is enabled, the weights from the past epoch are used as starting points for the next epoch
                                     , input_length = maxlen #the max sequence length, this is the length that all sequences will be padded to (so all sequences will have same length)
                                     ))
    
    #ADD CNN LAYER WITH SELU ACTIVATION AND GAUSSIAN DROPOUT  
    #NOTE:specify guassian dropout befire activation function has been specified
    #WARNING: if you specify guassian dropout after activation function  the resulting values may be out-of-range 
    #from what the activation function may normally provide. For example, a value with added noise may be less than zero,
    #whereas the relu activation function will only ever output values 0 or larger.  
    model.add(keras.layers.Conv1D(filters=164, kernel_size=10,padding='valid' ,strides=1))
    model.add(keras.layers.MaxPooling1D(pool_size=4))
    model.add(keras.layers.GaussianDropout(0.7))
    model.add(keras.layers.Activation('selu'))
    
    
    #ADD BILSTM WITH DROPOUT 
    model.add(keras.layers.Bidirectional(keras.layers.LSTM(units = 400, 
                                                           return_sequences=True,
                                                           #dropout=.3, #dropout not applied here becase we apply it via the guassian dropout specificed below
                                                           recurrent_dropout=.7,
                                                           recurrent_regularizer=keras.regularizers.L1L2(l1=0.0, l2=0.01),
                                                           kernel_regularizer = keras.regularizers.L1L2(l1=0,l2=.01),
                                                           bias_regularizer = keras.regularizers.L1L2(l1=0,l2=.01),
                                                           )))
    #ADD NON RECURRENT DROPUT TO LSTM 
    model.add(keras.layers.GaussianDropout(0.7))
    model.add(keras.layers.Activation('selu'))
    
    #SELF ATTENTION LAYER 
    model.add(SeqSelfAttention(
                            attention_width=15,
                            attention_type=SeqSelfAttention.ATTENTION_TYPE_MUL,
                            attention_activation=None,
                            kernel_regularizer=keras.regularizers.L1L2(1e-6),
                            bias_regularizer=keras.regularizers.l1(1e-4),
                            use_attention_bias=True,    
                            attention_regularizer_weight=1e-4,
                            name='Attention',))
    
    #FLATTENED LAYER (CONVERTS 2D tensor to 1D)
    model.add(keras.layers.Flatten())
    
    #OUTPUT LAYER(units = # target labels, for binary this =1)
    model.add(keras.layers.Dense(units =3,activation='softmax'))
    
    #COMPILE MODEL WITH CUSTOM KERAS METRICS (functions defined at top of script)
    model.compile(optimizer='adam',loss = 'sparse_categorical_crossentropy',metrics =['accuracy'])#,recall,fmeasure,precision,fbeta_score] )
    return model 

#SPECIFY KERAS CALLBACKS 
def model_callbacks(filepath=None,monitor=None,min_max_metric=None):
    ckpt = ModelCheckpoint(filepath, monitor=monitor , verbose=1, save_best_only=True, save_weights_only=False, mode=min_max_metric)
    early = EarlyStopping(monitor=monitor , mode=min_max_metric, patience=10)
    return ckpt,early


#FIT MODEL 
def fit_model(model=None,callbacks =None,xtr=None,ytr=None,xte=None,yte=None,batch_size =None,epochs=None):
    model_out = model.fit(xtr, ytr, batch_size=batch_size, epochs=epochs
                          , validation_data = (xte,yte)
                          , callbacks=callbacks)
    
    #EVALUATE MODEL FIT 
    y_preds = model.predict_classes(xtr)
    y_preds_test = model.predict_classes(xte)
    
    matrix = metrics.confusion_matrix(ytr, y_preds)
    matrix_test = metrics.confusion_matrix(yte, y_preds_test)
    
    scores = model.evaluate(xtr, ytr, verbose=0)
    scores_test = model.evaluate(xte, yte, verbose=0)
    
    print('train',matrix,'/n','accuracy:{}'.format(scores))
    print('test',matrix_test,'/n','accuracy:{}'.format(scores_test))
    
     
#LOAD BEST MODEL AND COMPARE FIT TO LAST EPOCH 
def load_best_model(model_path = None,xtr=None,xte=None,ytr=None,yte=None,custom_obs  ={'SeqSelfAttention':keras_self_attention.SeqSelfAttention}):
    model_path = model_path
    model_out = keras.models.load_model(model_path,custom_objects=custom_obs)
    
    #GET CONFUSION MATRIX FOR BEST MODEL 
    y_preds = model_out.predict_classes(xtr)
    y_preds_test = model_out.predict_classes(xte)
    
    matrix = metrics.confusion_matrix(ytr, y_preds)
    matrix_test = metrics.confusion_matrix(yte, y_preds_test)
    
    print('Final Model Confusion Matrix')
    print(matrix)
    print('Final Model Confusion Matrix')
    print(matrix_test)


def get_parser():
    '''Builds CLI argument parser for this program'''
    parser = argparse.ArgumentParser(description='Demo Sentiment Classifier')
    parser.add_argument('samplesize', type=int, help='total observations to sample for model')
    return parser



def main(params):
    #load data 
    Data = load_data(datapath = DATAPATH)
    #transform original Df into sequence tokenized data and split into test and train. get list of words in vocab , and maxlen of sequence
    xtr,ytr,xte,yte,word_index, maxlen,words = make_df(Data.head(params.samplesize),      #path to sentence level data 
                                                 max_features,    #maximum number of words to consider in model 
                                                 EMBEDDING_DIM,   #number of dims form embedding vector to use(if pymag used this must be 300)
                                                 stop_list,
                                                 stemmer,
                                                 target,
                                                 'sentence',
                                                test_size = .2)
    
    #Create embedding matrix 
    embedding_vector,nb_words = get_embedding_vectors(max_features=max_features,word_index=word_index,wv=wv,words=words,EMBEDDING_DIM=EMBEDDING_DIM)
    
    #compile model 
    model = create_model(nb_words=nb_words,EMBEDDING_DIM=EMBEDDING_DIM,embedding_vector=embedding_vector,maxlen=maxlen)
    
    #generate callbacks 
    ckpt,early = model_callbacks(filepath=OUTPUTPATH + filepath,monitor=monitor,min_max_metric=min_max_metric)
    
    #fit model 
    fit_model(model=model,callbacks = [ckpt,early],xtr=xtr,ytr=ytr,xte=xte,yte=yte,batch_size = batch_size,epochs=epochs)
     
    #load best model and evaluate (MUST INCLUDE CUSTOM LAYERS EXPLICITLY in custom_obs)
    load_best_model(model_path = OUTPUTPATH + filepath,xtr=xtr,xte=xte,ytr=ytr,yte=yte,custom_obs  ={'SeqSelfAttention':keras_self_attention.SeqSelfAttention})


if __name__ == '__main__':
    #COMMAND LINE SYNTAX : python sentiment_model_keras_zack.py 200
    parser = get_parser()
    params = parser.parse_args()
    main(params)
#######################################################
##############BEGIN MODEL DEVELOPMENT##################
#######################################################



##############################################################################################
##############################################################################################
#######################################FUNCTIONS##############################################
##############################################################################################
##############################################################################################

