# -*- coding: utf-8 -*-
"""
Created on Wed Apr 17 07:23:28 2019
LDA
@author: caridza
"""
import pandas as pd 
from pprint import pprint
import gensim
from gensim import corpora, models
from gensim.utils import simple_preprocess
from gensim.parsing.preprocessing import STOPWORDS
from nltk.stem import WordNetLemmatizer, SnowballStemmer
from nltk.stem.porter import *
import numpy as np
import string
import nltk
from nltk.corpus import stopwords
from gensim.models import CoherenceModel
import re 
import gensim, spacy, logging, warnings

#nltk.download('wordnet')
np.random.seed(2018)

#preprocessing objects
stemmer = SnowballStemmer('english')
stopwords = stopwords.words('english')
newStopWords = ['.','?','%','Google','Wells Fargo','year','thing','would','make','time','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December']
stopwords.extend(newStopWords)
stop_list=set(stopwords)

#lda preprocessings(stemming and lemmatizing, and lowercase , and remove stopwords)
def lemmatize_stemming(text):
    return stemmer.stem(WordNetLemmatizer().lemmatize(text, pos='v'))

#cap case all full UPPER case abreviations and phrases in a pandas series that are not contained in the list of stopwords 
def capcase_abrevs(p_series,stop_list):
    out = p_series.apply(lambda x:  ' '.join([word.title()  if (word.isupper() and word.lower() not in stop_list) else 
                                               word.lower() if word.lower() in stop_list else 
                                               word for word in str(x).split() ]))
    return out 

def preprocess(text):
    result = []
    for token in gensim.utils.simple_preprocess(text):
        if str(token).lower() not in stop_list and len(token) > 3:
            result.append(lemmatize_stemming(token))
    return result


def process_words(texts, stop_words=stop_list, allowed_postags=['NOUN', 'ADJ', 'VERB', 'ADV'],nlp=None):
    """generate bi and tri grams"""
    bigram = gensim.models.Phrases(texts, min_count=4, threshold=100)
    trigram = gensim.models.Phrases(bigram[texts],threshold=50)
    bigram_mod = gensim.models.phrases.Phraser(bigram)
    trigram_mod = gensim.models.phrases.Phraser(trigram)

    """Remove Stopwords, Form Bigrams, Trigrams and Lemmatization"""
    texts = [[word for word in simple_preprocess(str(doc)) if word not in stop_words] for doc in texts]
    texts = [bigram_mod[doc] for doc in texts]
    texts = [trigram_mod[bigram_mod[doc]] for doc in texts]
    texts_out = []
    if nlp is None:
        nlp = spacy.load('en', disable=['parser', 'ner'])
    
    for sent in texts:
        doc = nlp(" ".join(sent)) 
        texts_out.append([token.lemma_ for token in doc if token.pos_ in allowed_postags])
    # remove stopwords once more after lemmatization
    texts_out = [[word for word in simple_preprocess(str(doc)) if word not in stop_words] for doc in texts_out]    
    return texts_out

#func to remove punc from string and return string
def remove_punctuation_str(text,excluded_punct={'+', ':', '[', '^', '"', '|', '{', '@', '=', ')','“','”' ,'%', '#', '`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}):
     return ''.join([word for word in text if word not in excluded_punct])
     #return ''.join([''.join([char for char in word if char not in excluded_punct]) for word in text if word not in excluded_punct])

#function
def reMethod(pat, s):
    return [m.group().split() for m in re.finditer(pat, s)]


#datapaths
DATAPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/NewData/NEW_SENTLEVEL_CLASSIFICATIONS_DF.pickle"
OUTPUTPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/"

#data
data = pd.read_pickle(DATAPATH )

#load spacy nlp model manually from disk(binary)
lang = 'en'
data_path = 'C:/Users/caridza/Downloads/WPy-3662/ZackScripts/docclassify/Lib/site-packages/en_core_web_sm/en_core_web_sm-2.0.0'
cls = spacy.util.get_lang_class(lang)
nlp=cls()
nlp.from_disk(data_path)

##################################
########TEXT PREPROCESSING########
##################################
#only include sentences > 15 characters
data_text = data[data['sentence'].str.len().gt(15)]['sentence'] #subset column based on the length of sentence
#data_text['index'] = data_text.index

#strip punctuation 
data_text = data_text.apply(lambda x: remove_punctuation_str(str(x)))

#remove consequivtly captialized letters and make them cap case
data_text = data_text.apply(lambda x:  ' '.join([word.title()  if (word.isupper() and word.lower() not in stop_list) else 
                                               word.lower() if word.lower() in stop_list else 
                                               word for word in str(x).split() ]))


#identify all proper nouns, consequetive proper nouns contained in comman seperated inner lists 
#NEED TO FIGURE OUT HOW TO TOKENIZE THESE SO THAT THEY ARE CAPITALIZED IN THE OUTPUT STRINGS FOR Open IE based tasked
pattern =  re.compile(r"([A-Z][a-z]*)(\s[A-Z][a-z]*)*")
propnouns = data_text.apply(lambda x:  reMethod(pattern, str(x)))
propnouns = propnouns.apply(lambda x:  [' '.join([word for word in innerlist if len(word)>1])for innerlist in x ])
#propnouns_unique= list(set([item for sublist in propnouns for item in sublist]))
#propnouns_unique2 = [x.replace(' ','_') for x in propnouns_unique]# if (len(x.split())>1 & len(x.split())<8) ]
#pronoun_dic = dict(zip(propnouns_unique,propnouns_unique2))
#uniphrases = [phrase for phrase in propnouns_unique if len(phrase.split())<2]

#drop text with low word counts 
#word tokenize texts and remove words with < 2 characters
processed_docs = data_text.apply(lambda x: nltk.word_tokenize(str(x)))
processed_docs = pd.Series([[str(x).lower() for x in sent if len(str(x))>2] for sent in processed_docs])

#generate bi and tri grams
bigram = gensim.models.Phrases(processed_docs, min_count=4, threshold=100)
trigram = gensim.models.Phrases(bigram[processed_docs],threshold=50)
bigram_mod = gensim.models.phrases.Phraser(bigram)
trigram_mod = gensim.models.phrases.Phraser(trigram)

#preprocess document
preprocessed_docs= process_words(processed_docs, stop_words=stop_list, allowed_postags=['NOUN', 'ADJ', 'VERB', 'ADV'],nlp=nlp)

#preprocess docs with gensim 
stemlem_docs = processed_docs.astype(str).map(preprocess)
stemlem_docs=preprocessed_docs

###############################################################
#########CREATE DICTONARY OF WORDS TO NUMERIC INDICES##########
######AND COUNT OCCURANCES OF EACH WORD IN EACH DOCUMNET#######
###############################################################
#Create a dictionary from 'stemlem_docs' containing the number of times a word appears in the training set.
#output: (#index,word) for each word in stemlem_docs 
dictionary = gensim.corpora.Dictionary(stemlem_docs)
list(dictionary.items())[:10]
    
#filter out tokens taht appear in less than 15 docs and appear no more than in 50% of all docs , keeping the 1000000 most frequent tokens 
dictionary.filter_extremes(no_below=15, no_above=0.5, keep_n=100000)

#For each document we create a dictionary reporting how many words and how many times those words appear. 
bow_corpus = [dictionary.doc2bow(doc,allow_update=True) for doc in stemlem_docs]
#raw word index and number occurances & showing how to use dictonary of word indcies to map word index back to word and print number occurances
bow_corpus[4310];[(dictionary[key[0]],key[1]) for key in bow_corpus[4310]]

#build lda model from gensim bows
lda_model = gensim.models.LdaMulticore(bow_corpus, num_topics=10, id2word=dictionary, passes=4, workers=6,per_word_topics=True)
#for each topic explore the words occuring in that topic and its relative weight
for idx, topic in lda_model.print_topics(-1):
    print('Topic: {} Word: {}'.format(idx, topic))


#generate tfidf to use in lda, passing dictonary to enable mapping of lemmatized stemmed wrds back to original words 
tfidf = models.TfidfModel(bow_corpus,id2word =dictionary,normalize=False)
corpus_tfidf = tfidf[bow_corpus]
for doc in corpus_tfidf: 
    pprint([(dictionary[x[0]],x[1]) for x in doc]) 
    break

#run LDA on bag of words 
lda_model_tfidf = gensim.models.LdaMulticore(corpus_tfidf, num_topics=5,id2word=dictionary, passes=2, chunksize=10000,workers=6,per_word_topics =True)

#for each topic explore the words occuring in that topic and its relative weight
for idx, topic in lda_model_tfidf.print_topics(-1):
    print('Topic: {} Word: {}'.format(idx, topic))
    
  
    
###EVALUATE FIT OF LDA GROUPINGS 
# Compute Perplexity
print('\nPerplexity(lower is better): ', lda_model_tfidf.log_perplexity(bow_corpus))  # a measure of how good the model is. lower the better.

# Compute Coherence Score
coherence_model_lda = CoherenceModel(model=lda_model_tfidf, texts=stemlem_docs, dictionary=dictionary, coherence='c_v')
coherence_lda = coherence_model_lda.get_coherence()
print('\nCoherence Score: ', coherence_lda)

    
# Visualize the topics
import pyLDAvis.gensim 

pyLDAvis.enable_notebook()
vis= pyLDAvis.gensim.prepare(lda_model_tfidf, bow_corpus, dictionary)
vis
    
    