# -*- coding: utf-8 -*-
"""
Created on Wed May  1 11:08:23 2019

@author: caridza
"""
#preprocessing objects
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize , sent_tokenize
import spacy
import pandas as pd 
from pprint import pprint
import gensim
from gensim import corpora, models
from gensim.utils import simple_preprocess
from gensim.parsing.preprocessing import STOPWORDS
from nltk.stem import WordNetLemmatizer, SnowballStemmer
from nltk.stem.porter import *
import numpy as np
import string
import nltk
from gensim.models import CoherenceModel
import re 
import gensim, logging, warnings

pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)
pd.set_option('display.max_colwidth', -1)

stemmer = SnowballStemmer('english')
stopwords = stopwords.words('english')
newStopWords = ['.','?','%','Google','Wells Fargo','guggenheim partners llc','new york','guggenheim partners','bank america','wells fargos','year','thing','would','include','tuesday','make','time','state','bank','certain','country','string','perhaps','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December','from', 'subject', 're', 'edu', 'use', 'not', 'would', 'say', 'could', '_', 'be', 'know', 'good', 'go', 'get', 'do', 'done', 'try', 'many', 'some', 'nice', 'thank', 'think', 'see', 'rather', 'easy', 'easily', 'lot', 'lack', 'make', 'want', 'seem', 'run', 'need', 'even', 'right', 'line', 'even', 'also', 'may', 'take', 'come','the']
stopwords.extend(newStopWords)
stop_list=set(stopwords)

#datapaths
DATAPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/NewData/result_dataframe_MAY19.pickle"
OUTPUTPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/"
SPACYPATH = 'C:/Users/caridza/Downloads/WPy-3662/ZackScripts/docclassify/Lib/site-packages/en_core_web_sm/en_core_web_sm-2.0.0'

#load spacy using symlink created from python -m spacy download en_core_web_sm
nlp = spacy.load("en_core_web_sm", disable=['parser', 'ner'])


def generate_StopWords_Phrases(stop_list):
    stop_terms = []
    stop_phrases = []
    for item in list(stop_list): 
        if len(item.split())==1:
            stop_terms.append(item.lower())
        if len(item.split())>1:
            stop_phrases.append(' '.join([word.lower() for word in item.split()]))
    return stop_terms, stop_phrases

def replace_stopphrases(doc,phrases):
    for item in phrases:
        if item in doc.lower():
            print(item)
            doc = doc.lower().replace(item,'')
        
    return doc


def remove_stopwords(doc,stop_terms):
    tokens = [word for word in doc if word.lower()  not in stop_terms]
    return tokens


#word tokenize and remove punctuation (deacc=True)
def sent_to_words(sentences):
    for sentence in sentences:
        yield(gensim.utils.simple_preprocess(str(sentence), deacc=True))
        
#func to remove punc from string and return string
def remove_punctuation_str(text,excluded_punct={'+','—','-', ':', '[', '^', '"', '|', '{', '@', '=', ')','“','”' ,'%', '#', '`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}):
     return ''.join([word for word in text if word not in excluded_punct])
     #return ''.join([''.join([char for char in word if char not in excluded_punct]) for word in text if word not in excluded_punct])


def make_bigrams(texts):
    return [bigram_mod[doc] for doc in texts]

def make_trigrams(texts):
    return [trigram_mod[bigram_mod[doc]] for doc in texts]

def lemmatization(texts, allowed_postags=['NOUN', 'ADJ', 'VERB', 'ADV']):
    """https://spacy.io/api/annotation"""
    texts_out = []
    for sent in texts:
        doc = nlp(" ".join(sent)) 
        texts_out.append([token.lemma_ for token in doc if token.pos_ in allowed_postags])
    return texts_out

#function
def reMethod(pat, s):
    return [m.group().split() for m in re.finditer(pat, s)]

def process_words(texts, stop_words=stop_list, allowed_postags=['NOUN', 'ADJ', 'VERB', 'ADV'],nlp=None):
    """generate bi and tri grams"""
    bigram = gensim.models.Phrases(texts, min_count=4, threshold=100)
    trigram = gensim.models.Phrases(bigram[texts],threshold=50)
    bigram_mod = gensim.models.phrases.Phraser(bigram)
    trigram_mod = gensim.models.phrases.Phraser(trigram)

    """Remove Stopwords, Form Bigrams, Trigrams and Lemmatization"""
    texts = [[word for word in simple_preprocess(str(doc), deacc=True) if word not in stop_words] for doc in texts]
    texts = [bigram_mod[doc] for doc in texts]
    texts = [trigram_mod[bigram_mod[doc]] for doc in texts]
    texts_out = []
    
    for sent in texts:
        doc = nlp(" ".join(sent)) 
        texts_out.append([token.lemma_ for token in doc if token.pos_ in allowed_postags])
        
    # remove stopwords once more after lemmatization
    texts_out = [[word for word in simple_preprocess(str(doc)) if word not in stop_words] for doc in texts_out]    
    return texts_out

#stop words and phrases to remove    
stop_phrases=generate_StopWords_Phrases(stop_list)[1]
stop_terms= generate_StopWords_Phrases(stop_list)[0]

#data
data = pd.read_pickle(DATAPATH )

##################################
########TEXT PREPROCESSING########
##################################
#only include sentences > 15 characters
#data_text = data[data['content'].str.len().gt(20)]['content'].copy() #subset column based on the length of sentence
data_text = data['desm_sentences'].apply(lambda x: ''.join([sent for sent in x]))
data_text.drop_duplicates(inplace=True)

#strip punctuation 
#data_text = data_text.apply(lambda x: remove_punctuation_str(str(x)))

#remove consequivtly captialized letters and make them cap case
data_text = data_text.apply(lambda x:  ' '.join([word.title()  if (word.isupper() and word.lower() not in stop_list) else 
                                               word for word in str(x).split() ]))

#sample doc for testing 
#doc = data_text[1].lower()
docs = list(data_text)

    
#remove stop phrases before word tokenization and lemmatization with pos tags
#data_text2= remove_StopPhrases(doc,stop_phrases)
data_text2= [sent_tokenize(replace_stopphrases(document,stop_phrases)) for document in docs]

#create POS tags and lemmatize using spacys nlp lemmatizer (it uses the pos tags from nlp() to identify the correct lemmatization)
doc2 = [[token.lemma_ for token in nlp(" ".join(item)) if len(token.lemma_)>2 and token.lemma_ !='-PRON-'] for item in data_text2] 

#remove stopwords 
doc3 = [[word for word in item if word.lower() not in stop_terms] for item in doc2]


# Build the bigram and trigram models
#preprocess document
"""Remove Stopwords, Form Bigrams, Trigrams and Lemmatization"""
preprocessed_docs= process_words(doc3, stop_words=stop_terms, allowed_postags=['NOUN', 'ADJ', 'VERB', 'ADV'],nlp=nlp)



    
