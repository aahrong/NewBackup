import os
import sys
import pandas as pd 
from nltk import sent_tokenize, word_tokenize
from nltk.stem.snowball import SnowballStemmer
stemmer = SnowballStemmer("english")

import spacy
nlp = spacy.load('en_core_web_sm')

sys.path.insert(0, "C://Users//caridza//Desktop//pythonScripts//NLP//Zacks_NLP_Stuff//")
#os.chdir("//home//nlpsomnath//NegNews//rebase//NN_Kafka//")
from FineExtraction.FineExtraction_NER import get_data_from_article_title, load_entity_dict

#dict{entitycommonname:{'OfficalName':'Entity Incorporated', 'MarketCap':3235234940}}
entity_dict = load_entity_dict('C://Users//caridza//Desktop//pythonScripts//NLP//Zacks_NLP_Stuff//FineExtraction//entity_dict.pickle')

df_rlt_complete = pd.read_pickle('C://Users//caridza//Downloads//WPy32-3662//ZacksScripts//Data//fine_extract_test.pkl')
dfnames = list(df_rlt_complete )

df_rlt_complete['sentence_tokenized'] = df_rlt_complete.apply(lambda x: sent_tokenize(x['origtext']+' '+x['summary']+' '+x['title']+' '+x['content']), axis=1)
df_rlt_complete['sentence_tokenized_stemmed'] = df_rlt_complete['sentence_tokenized'].apply(lambda x: [' '.join([stemmer.stem(j) for j in word_tokenize(x[i])]) for i in range(0,len(x))])
df_rlt_complete['sentence_tokenized_tagged'] = df_rlt_complete.apply(lambda x: list(map(lambda sent: nlp(sent), x['sentence_tokenized_stemmed'])), axis=1)
    
df_rlt_complete['fine_info_tuple_lists'] = df_rlt_complete.apply(lambda x: list(map(lambda sent: get_data_from_article_title(entity_dict, tagged_text=sent, entity_name=df_rlt_complete.entity.unique()[0]), x['sentence_tokenized_tagged'])), axis=1)
df_rlt_complete['total_entity_fine_amt'] = df_rlt_complete.apply(lambda x: sum(set([t[1] if t[2] else 0 for t in x['fine_info_tuple_lists']])), axis=1)

print(df_rlt_complete[df_rlt_complete['total_entity_fine_amt']>0].loc[:,['url','total_entity_fine_amt']])




display(
df_rlt_complete[df_rlt_complete['url']=="https://www.cftc.gov/PressRoom/PressReleases/7800-18"].loc[:,['sentence_tokenized_tagged']]
df_rlt_complete[df_rlt_complete['url']=="https://www.thetradenews.com/mizuho-bank-fined-250000-spoofing-futures-markets/"].loc[:,['sentence_tokenized_tagged']]
)






print(df_rlt_complete['word_token'][:1]
,df_rlt_complete['sentence_tokenized'][:1]
)


df_rlt_complete.iloc[:1,df_rlt_complete.columns.get_loc('sentence_tokenized')].values

for row in range(0,df_rlt_complete.shape()[0]):
    for item in row['sentence_tokenized']:
        df_rlt_complete['word_tokenized'] =  ro
        




#looping thorugh rows of a dataframe and the elements in the list contained within each row of that dataframe
df_rlt_complete['word_token'] = df_rlt_complete['sentence_tokenized'].apply(lambda x: [' '.join([stemmer.stem(j) for j in word_tokenize(x[i])]) for i in range(0,len(x))])



df_rlt_complete['sentence_tokenized_stemmed'] = df_rlt_complete.apply(lambda sent: ' '.join([stemmer.stem(word) for word in word_tokenize(sent['sentence_tokenized'])]), axis=1)

df_rlt_complete.to_pickle('//home//nlpsomnath//NegNews//zackc//DTCC_Data//fine_extract_test.pkl')
    




































df
df.entity_count.unique()[0]

df['test'] = apply(lambdanp.where(df.entity_count<1, 0,
                           np.where(df.entity_count>4,1))


df['testcol']=max(min(100,((df['entity_count'] -3) / (14-3))),0)
df.loc[:, ['FinalDocScore','url']]
#df_rlt_complete['total_entity_fine_amt'] = df_rlt_complete.apply(lambda x: sum(set([t[FINE_AMOUNT_IDX] if t[FINE_GENERATE_FLAG_IDX] else 0 for t in x['fine_info_tuple_lists']])), axis=1)
#pd.set_option('display.max_rows', 500)
#display(df_step3.head(10))
#df_step3.entity_count
#display(df_step3.date2.value_counts())
df_step3.to_csv("/home/nlpsomnath/NegNews/zackc/DTCC_Data/prew2vdata.csv") 



max(min(100,343),0)
        

    fine_reports.extend(ef.generate_report_string(docTitles[t], entity_name = se.entity_fname, content = ' '.join(w2vtopsent[t]), nlp = nlp, entity_dict = entity_dict))
        fine_reports.extend([fr for sent in w2vtopsent[t] for fr in ef.generate_report_string(sent, entity_name = se.entity_fname, nlp = nlp, entity_dict = entity_dict)])
        
        

####looking at distributions of results 
import numpy
pd.set_option('display.width', 100)
pd.set_option('display.max_columns', 500)
pd.set_option('display.max_colwidth', -1)

def func(x,bin_means):   
    if 0 < x <= bin_means[0]:
        return 'Low'
    elif bin_means[0] < x <= bin_means[1]:
        return 'Medium'
    return 'High'


bin_means = (numpy.histogram(df_step6.w2vDfSorted[0]['FinalDocScore'], bins=3, weights=df_step6.w2vDfSorted[0]['FinalDocScore'])[0] /
             numpy.histogram(df_step6.w2vDfSorted[0]['FinalDocScore'], bins=3)[0])
dftest = pd.DataFrame(df_step6.w2vDfSorted[0])
dftest['FinalBin'] = dftest['FinalDocScore'].apply(lambda x: func(x,bin_means))



df_step6.w2vDfSorted[0]#[['Doc','NewsSource','Title','date','DocSent','DocSim','FinalDocScore']].drop_duplicates()
#df_step6.w2vDfSorted[0][['Doc','NewsSource','Title']].drop_duplicates()
aggregation = {
    'Similarity':{
        'max_sim':'max',
        'avg_sim':'mean',
        'min_sim':'min',
        'std_sim':'std'
    },
    'Sentiment':{
        'max_sent':'max',
        'avg_sent':'mean',
        'min_sent':'min',
        'std_sent':'std'
    },
    'FinalDocScore':{
       # 'minDocScore':'min', 
        'maxDocScore':'max',
       # 'RangeDocScore': lambda x:max(x)-min(x)
    }
}
result_stats_person = pd.DataFrame(df_step6.w2vDfSorted[0].groupby(['Doc','Title'],as_index=False).agg(aggregation))
result_stats_person
result_stats_person.sort_values(by=[("FinalDocScore","maxDocScore")],ascending = False,inplace=True)
result_stats_person




df_step6