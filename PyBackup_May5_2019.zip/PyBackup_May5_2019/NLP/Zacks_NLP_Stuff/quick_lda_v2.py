# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 08:53:25 2019

@author: caridza
"""
#https://www.machinelearningplus.com/nlp/topic-modeling-visualization-how-to-present-results-lda-models/
#https://www.machinelearningplus.com/nlp/topic-modeling-visualization-how-to-present-results-lda-models/
import pandas as pd 
from pprint import pprint
import gensim
from gensim import corpora, models
from gensim.utils import simple_preprocess
from gensim.parsing.preprocessing import STOPWORDS
from nltk.stem import WordNetLemmatizer, SnowballStemmer
from nltk.stem.porter import *
import numpy as np
import string
import nltk
from nltk.corpus import stopwords
from gensim.models import CoherenceModel
import re 
import gensim, spacy, logging, warnings

#preprocessing objects
stemmer = SnowballStemmer('english')
stopwords = stopwords.words('english')
newStopWords = ['.','?','%','Google','Wells Fargo','year','thing','would','include','tuesday','make','time','state','bank','certain','country','string','perhaps','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December','from', 'subject', 're', 'edu', 'use', 'not', 'would', 'say', 'could', '_', 'be', 'know', 'good', 'go', 'get', 'do', 'done', 'try', 'many', 'some', 'nice', 'thank', 'think', 'see', 'rather', 'easy', 'easily', 'lot', 'lack', 'make', 'want', 'seem', 'run', 'need', 'even', 'right', 'line', 'even', 'also', 'may', 'take', 'come','the']
stopwords.extend(newStopWords)
stop_list=set(stopwords)

#word tokenize and remove punctuation (deacc=True)
def sent_to_words(sentences):
    for sentence in sentences:
        yield(gensim.utils.simple_preprocess(str(sentence), deacc=True))
        
# Define functions for stopwords, bigrams, trigrams and lemmatization
def remove_stopwords(texts,stop_words = stop_list):
    return [[word for word in simple_preprocess(str(doc)) if word not in stop_words] for doc in texts]

# remove_stop_phrases() is our custom preprocessing function.
def remove_stop_phrases(doc):
    
    # note: this regex considers "... red. Roses..." as fair game for removal.
    #       if that's not what you want, just use ["red roses"] instead.
    stop_phrases= ["red(\s?\\.?\s?)roses"]
    for phrase in stop_phrases:
        doc = re.sub(phrase, "", doc, flags=re.IGNORECASE)
    return doc

def make_bigrams(texts):
    return [bigram_mod[doc] for doc in texts]

def make_trigrams(texts):
    return [trigram_mod[bigram_mod[doc]] for doc in texts]

def lemmatization(texts, allowed_postags=['NOUN', 'ADJ', 'VERB', 'ADV']):
    """https://spacy.io/api/annotation"""
    texts_out = []
    for sent in texts:
        doc = nlp(" ".join(sent)) 
        texts_out.append([token.lemma_ for token in doc if token.pos_ in allowed_postags])
    return texts_out

#func to remove punc from string and return string
def remove_punctuation_str(text,excluded_punct={'+','—','-', ':', '[', '^', '"', '|', '{', '@', '=', ')','“','”' ,'%', '#', '`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}):
     return ''.join([word for word in text if word not in excluded_punct])
     #return ''.join([''.join([char for char in word if char not in excluded_punct]) for word in text if word not in excluded_punct])

#function
def reMethod(pat, s):
    return [m.group().split() for m in re.finditer(pat, s)]



def process_words(texts, stop_words=stop_list, allowed_postags=['NOUN', 'ADJ', 'VERB', 'ADV'],nlp=None):
    """generate bi and tri grams"""
    bigram = gensim.models.Phrases(texts, min_count=4, threshold=100)
    trigram = gensim.models.Phrases(bigram[texts],threshold=50)
    bigram_mod = gensim.models.phrases.Phraser(bigram)
    trigram_mod = gensim.models.phrases.Phraser(trigram)

    """Remove Stopwords, Form Bigrams, Trigrams and Lemmatization"""
    texts = [[word for word in simple_preprocess(str(doc), deacc=True) if word not in stop_words] for doc in texts]
    texts = [bigram_mod[doc] for doc in texts]
    texts = [trigram_mod[bigram_mod[doc]] for doc in texts]
    texts_out = []
    
    if nlp is None:
        nlp = spacy.load('en', disable=['parser', 'ner'])
    
    for sent in texts:
        doc = nlp(" ".join(sent)) 
        texts_out.append([token.lemma_ for token in doc if token.pos_ in allowed_postags])
        
    # remove stopwords once more after lemmatization
    texts_out = [[word for word in simple_preprocess(str(doc)) if word not in stop_words] for doc in texts_out]    
    return texts_out

def compute_coherence_values(dictionary, corpus, texts, limit, start=2, step=3):
    """
    Compute c_v coherence for various number of topics

    Parameters:
    ----------
    dictionary : Gensim dictionary
    corpus : Gensim corpus
    texts : List of input texts
    limit : Max num of topics

    Returns:
    -------
    model_list : List of LDA topic models
    coherence_values : Coherence values corresponding to the LDA model with respective number of topics
    """
    coherence_values = []
    model_list = []
    for num_topics in range(start, limit, step):
        #model = gensim.models.wrappers.LdaMallet(mallet_path, corpus=corpus, num_topics=num_topics, id2word=id2word)
        model = gensim.models.LdaMulticore(corpus, id2word=dictionary, passes=4, workers=6,per_word_topics=True,iterations=10)

        model_list.append(model)
        coherencemodel = CoherenceModel(model=model, texts=texts, dictionary=dictionary, coherence='c_v')
        coherence_values.append(coherencemodel.get_coherence())

    return model_list, coherence_values


pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)
pd.set_option('display.max_colwidth', -1)

#datapaths
#DATAPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/NewData/NEW_SENTLEVEL_CLASSIFICATIONS_DF.pickle"
#DATAPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/All_Source_Data.pickle"
DATAPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/NewData/result_dataframe_MAY19.pickle"
OUTPUTPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/"
SPACYPATH = 'C:/Users/caridza/Downloads/WPy-3662/ZackScripts/docclassify/Lib/site-packages/en_core_web_sm/en_core_web_sm-2.0.0'

#load spacy using symlink created from python -m spacy download en_core_web_sm
nlp = spacy.load("en_core_web_sm", disable=['parser', 'ner'])

#load spacy nlp model manually from disk(binary)
#lang = 'en'
#cls = spacy.util.get_lang_class(lang)
#nlp=cls()
#nlp.from_disk(SPACYPATH, disable=['parser', 'ner'])

#data
data = pd.read_pickle(DATAPATH )

##################################
########TEXT PREPROCESSING########
##################################
#only include sentences > 15 characters
#data_text = data[data['content'].str.len().gt(20)]['content'].copy() #subset column based on the length of sentence
data_text = data['desm_sentences'].apply(lambda x: ''.join([sent for sent in x]))
data_text.drop_duplicates(inplace=True)

#strip punctuation 
data_text = data_text.apply(lambda x: remove_punctuation_str(str(x)))

#remove consequivtly captialized letters and make them cap case
data_text = data_text.apply(lambda x:  ' '.join([word.title()  if (word.isupper() and word.lower() not in stop_list) else 
                                               word for word in str(x).split() ]))

#word tokenize text 
data_words = list(sent_to_words(data_text))    
data_words = [[str(x) for x in sent if len(str(x))>2] for sent in data_words]

# Build the bigram and trigram models
#preprocess document
"""Remove Stopwords, Form Bigrams, Trigrams and Lemmatization"""
preprocessed_docs= process_words(data_words, stop_words=stop_list, allowed_postags=['NOUN', 'ADJ', 'VERB', 'ADV'],nlp=nlp)



###############################################################
#########CREATE DICTONARY OF WORDS TO NUMERIC INDICES##########
######AND COUNT OCCURANCES OF EACH WORD IN EACH DOCUMNET#######
###############################################################
#Create a dictionary from 'stemlem_docs' containing the number of times a word appears in the training set.
#output: (#index,word) for each word in stemlem_docs 
dictionary = gensim.corpora.Dictionary(preprocessed_docs)
list(dictionary.items())[:10]
    
#filter out tokens taht appear in less than 15 docs and appear no more than in 50% of all docs , keeping the 1000000 most frequent tokens 
dictionary.filter_extremes(no_below=5, no_above=0.3, keep_n=100000)

#For each document we create a dictionary reporting how many words and how many times those words appear. 
bow_corpus = [dictionary.doc2bow(doc,allow_update=True) for doc in preprocessed_docs]
#raw word index and number occurances & showing how to use dictonary of word indcies to map word index back to word and print number occurances
bow_corpus[410];[(dictionary[key[0]],key[1]) for key in bow_corpus[410]]

#identify optimal number of topics  
start = 2
limit = 20 
step = 2
model_list, coherence_values = compute_coherence_values(dictionary=dictionary, corpus=bow_corpus, texts=preprocessed_docs, start=start, limit=limit, step=step)


# Show graph
import matplotlib.pyplot as plt
x = range(start, limit, step)
plt.plot(x, coherence_values)
plt.xlabel("Num Topics")
plt.ylabel("Coherence score")
plt.legend(("coherence_values"), loc='best')
plt.show()

for m, cv in zip(x, coherence_values):
    print("Num Topics =", m, " has Coherence Value of", round(cv, 4))
    

optimal_model = [model[0] for model in zip(model_list,coherence_values) if model[1]==max(coherence_values)][0]
optimal_topics = [model[0] for model in zip(x,coherence_values) if model[1]==max(coherence_values)][0]

#specify optimal model 
model = gensim.models.LdaMulticore(bow_corpus
                                   , num_topics =optimal_topics
                                   , id2word=dictionary
                                   , passes=100
                                   , chunksize=250
                                   , workers=6
                                   , per_word_topics=True
                                   , iterations=100
                                   , minimum_phi_value = .4 #if words per topic == True, this represents a lower bound on the term probabilities
                                   , minimum_probability =.3 #topics with a probability lower than this threshold will be filtered out 
                                   #, offset = 1
                                   , decay=.8 #what percentage of the previous lamnbda value is forgotten when each new document is exammped (kappa)
                                   )

#get top words associated with each topic 
model_topics = model.show_topics(formatted=False)
pprint(model.print_topics(num_words=10))


#WHAT IS THE DOMINANT TOPIC AND ITS PERCENT CONTRIBUTION IN EACH DOCUMENT 
#each document is ocmposed of multiple topics. but only one of the topics tends to be dominate. 
#below extracts teh dominatnt topic for each sentence and show sthe weight of the topic and the keywords 
#This way, you will know which document belongs predominantly to which topic.
def format_topics_sentences(ldamodel=None, corpus=bow_corpus, texts=preprocessed_docs):
    # Init output
    sent_topics_df = pd.DataFrame()

    # Get main topic in each document
    for i, row_list in enumerate(ldamodel[corpus]):
        row = row_list[0] if ldamodel.per_word_topics else row_list            
        # print(row)
        row = sorted(row, key=lambda x: (x[1]), reverse=True)
        # Get the Dominant topic, Perc Contribution and Keywords for each document
        for j, (topic_num, prop_topic) in enumerate(row):
            if j == 0:  # => dominant topic
                wp = ldamodel.show_topic(topic_num)
                topic_keywords = ", ".join([word for word, prop in wp])
                sent_topics_df = sent_topics_df.append(pd.Series([int(topic_num), round(prop_topic,4), topic_keywords]), ignore_index=True)
            else:
                break
    sent_topics_df.columns = ['Dominant_Topic', 'Perc_Contribution', 'Topic_Keywords']

    # Add original text to the end of the output
    contents = pd.Series(texts)
    sent_topics_df = pd.concat([sent_topics_df, contents], axis=1)
    return(sent_topics_df)


df_topic_sents_keywords = format_topics_sentences(ldamodel=model, corpus=bow_corpus, texts=preprocessed_docs)
df_dominant_topic = df_topic_sents_keywords.reset_index()
df_dominant_topic.columns = ['Document_No', 'Dominant_Topic', 'Topic_Perc_Contrib', 'Keywords', 'Text']
df_dominant_topic.head(10)


#EXTRACT MOST REPRESENTATIVE SENTENCE FOR EACH TOPIC 
pd.options.display.max_colwidth = 100
sent_topics_sorteddf_mallet = pd.DataFrame()
sent_topics_outdf_grpd = df_topic_sents_keywords.groupby('Dominant_Topic')

for i, grp in sent_topics_outdf_grpd:
    sent_topics_sorteddf_mallet = pd.concat([sent_topics_sorteddf_mallet, 
                                             grp.sort_values(['Perc_Contribution'], ascending=False).head(1)], 
                                            axis=0)
# Reset Index    
sent_topics_sorteddf_mallet.reset_index(drop=True, inplace=True)
sent_topics_sorteddf_mallet.columns = ['Topic_Num', "Topic_Perc_Contrib", "Keywords", "Representative Text"]
sent_topics_sorteddf_mallet.head(10)


#FREQUENCEY DISTRIBUTION OF WORD COUNTS IN DOCUMENTS 
doc_lens = [len(d) for d in df_dominant_topic.Text]

# Plot
plt.figure(figsize=(16,7), dpi=160)
plt.hist(doc_lens, bins = 1000, color='navy')
plt.text(750, 100, "Mean   : " + str(round(np.mean(doc_lens))))
plt.text(750,  90, "Median : " + str(round(np.median(doc_lens))))
plt.text(750,  80, "Stdev   : " + str(round(np.std(doc_lens))))
plt.text(750,  70, "1%ile    : " + str(round(np.quantile(doc_lens, q=0.01))))
plt.text(750,  60, "99%ile  : " + str(round(np.quantile(doc_lens, q=0.99))))

plt.gca().set(xlim=(0, 1000), ylabel='Number of Documents', xlabel='Document Word Count')
plt.tick_params(size=16)
plt.xticks(np.linspace(0,1000,9))
plt.title('Distribution of Document Word Counts', fontdict=dict(size=22))
plt.show()


import seaborn as sns
import matplotlib.colors as mcolors
cols = [color for name, color in mcolors.XKCD_COLORS.items()]  # more colors: 'mcolors.XKCD_COLORS'

fig, axes = plt.subplots(int(round(optimal_topics/2,0)),2,figsize=(10,20), dpi=160, sharex=True, sharey=True)

for i, ax in enumerate(axes.flatten()):    
    df_dominant_topic_sub = df_dominant_topic.loc[df_dominant_topic.Dominant_Topic == i, :]
    doc_lens = [len(d) for d in df_dominant_topic_sub.Text]
    ax.hist(doc_lens, bins = 100, color=cols[i])
    ax.tick_params(axis='y', labelcolor=cols[i], color=cols[i])
    sns.kdeplot(doc_lens, color="black", shade=False, ax=ax.twinx())
    ax.set(xlim=(0, 500), xlabel='Document Word Count')
    ax.set_ylabel('Number of Documents', color=cols[i])
    ax.set_title('Topic: '+str(i), fontdict=dict(size=10, color=cols[i]))

fig.tight_layout()
fig.subplots_adjust(top=0.90)
plt.xticks(np.linspace(0,500,9))
fig.suptitle('Distribution of Document Word Counts by Dominant Topic', fontsize=22)
plt.show()


# 1. Wordcloud of Top N words in each topic
from matplotlib import pyplot as plt
from wordcloud import WordCloud, STOPWORDS
import matplotlib.colors as mcolors

cols = [color for name, color in mcolors.XKCD_COLORS.items()]  # more colors: 'mcolors.XKCD_COLORS'

cloud = WordCloud(stopwords=stop_list,
                  background_color='white',
                  width=2500,
                  height=1800,
                  max_words=10,
                  colormap='tab10',
                  color_func=lambda *args, **kwargs: cols[i],
                  prefer_horizontal=1.0)

topics = model.show_topics(formatted=False)

fig, axes = plt.subplots(int(round(optimal_topics/2,0)), 2, figsize=(10,10), sharex=True, sharey=True)

for i, ax in enumerate(axes.flatten()):
    fig.add_subplot(ax)
    topic_words = dict(topics[i][1])
    cloud.generate_from_frequencies(topic_words, max_font_size=300)
    plt.gca().imshow(cloud)
    plt.gca().set_title('Topic ' + str(i), fontdict=dict(size=16))
    plt.gca().axis('off')


plt.subplots_adjust(wspace=0, hspace=0)
plt.axis('off')
plt.margins(x=0, y=0)
plt.tight_layout()
plt.show()


#plot word counts of topic keywords
from collections import Counter
topics = model.show_topics(formatted=False)
data_flat = [w for w_list in preprocessed_docs for w in w_list]
counter = Counter(data_flat)

out = []
for i, topic in topics:
    for word, weight in topic:
        out.append([word, i , weight, counter[word]])

df = pd.DataFrame(out, columns=['word', 'topic_id', 'importance', 'word_count'])        

# Plot Word Count and Weights of Topic Keywords
fig, axes = plt.subplots(int(round(optimal_topics/2,0)), 2, figsize=(16,10), sharey=True, dpi=160)
cols = [color for name, color in mcolors.XKCD_COLORS.items()]
for i, ax in enumerate(axes.flatten()):
    print(i)
    ax.bar(x='word', height="word_count", data=df.loc[df.topic_id==i, :], color=cols[i], width=0.5, alpha=0.3, label='Word Count')
    ax_twin = ax.twinx()
    ax_twin.bar(x='word', height="importance", data=df.loc[df.topic_id==i, :], color=cols[i], width=0.2, label='Weights')
    #ax.set_ylabel('Word Count', color=cols[i])
    ax_twin.set_ylim(0, 0.030); ax.set_ylim(0, 500)
    ax.set_title('Topic: ' + str(i), color=cols[i], fontsize=10)
    ax.tick_params(axis='y', left=False)
    ax.set_xticklabels(df.loc[df.topic_id==i, 'word'], rotation=30, horizontalalignment= 'right')
    ax.legend(loc='upper left'); ax_twin.legend(loc='upper right')

fig.tight_layout(w_pad=2)    
fig.suptitle('Word Count and Importance of Topic Keywords', fontsize=22, y=1.05)    
plt.show()