# -*- coding: utf-8 -*-
"""
Created on Fri Jun 16 14:38:33 2017

@author: caridza
"""
import csv 
import spacy
import collections 
import pandas 


#load english tokenizer, tagger, parser, NER and word vectors 
nlp= spacy.load('en')

#process the document 
text = "C:\\Users\\caridza\\Desktop\\EY\\AI\\Emails.csv"

#import text 
Data = pandas.read_csv(text
                , sep=','
                , header= 0  #header row 
               # , usecols = #subset of cols to retrun ex.[0,1,2]
               # , squeeze = #if data only contains one column then return a series
                , mangle_dupe_cols = True #duplicate column names are given a suffix to prevent one from being overwritten by another 
               # , true_values = #values to consider as true 
               # , false_values = #values to consider as false 
               # , skipinitialspace = #skip initial space after delimiter 
               # , skiprows = #line numbers to skip, or number of lines to skip at start of file 
               # , skipfooter = #number of lines at bottom of file to skip 
               # , nrows = #number of rows from the file to read in 
               # , na_values #list of strings to be recognized as NA 
               # , skip_blank_lines = #if TRUE, skip over blank lines rather than interpresting as NaN values 
               # , iterator = #return TextFileReadere object for iteration or getting chunks with get_chunk
               # , compression = #for on fly decrompression of zip files ('infer','gzip','zip',etc....)
               # , tupleize_cols = #boolean, if TRUE leaves a list of tuples o columns as is? 
               # , error_bad_lines = #boolean, if FALSE, bad lines will be dropped from the dataframe that is returned, if true, no dataframe is returned 
                )

#describe the data

list(Data.columns.values)

Data.shape    #dimensions 
Data.shape[0] #rows
Data.shape[1] #cols

#summary of data 
Data.describe(percentiles = None , include = 'all' )

# Text needs to be fed into spaCy as unicode
raw_document = unicode(open(text).read().decode('utf8'))


fileobj = open(text,"rb")
data = csv.reader(fileobj)
fileobj.close()

with open(text) as csvfile: 
    reader = csv.DictReader(csvfile)
    for row in reader:
        print(row)


# Text needs to be fed into spaCy as unicode
raw_document = unicode(open(text).read().decode('utf8'))

text=open("C://Users//caridza//Desktop//EY//AI//Emails.csv","r")

print.text.read(4)