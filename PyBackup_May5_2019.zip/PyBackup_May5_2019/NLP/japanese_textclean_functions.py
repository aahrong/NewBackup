# -*- coding: utf-8 -*-
"""
Created on Mon Nov 19 12:39:32 2018

@author: caridza
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Nov 19 11:27:02 2018

@author: caridza
"""
import re
pip install --proxy http://caridza:Wildcard17!@empweb2.ey.net:8080 langdetect
nltk.set_proxy('http://caridza:Wildcard17!@empweb2.ey.net:8080', ('USERNAME', 'PASSWORD'))


examplearticletext='ログイン アカウントをお持ちでない方は 新規登録 へ 新規登録 Facebook Facebookで新規登録 Welcome to NewsPicks NewsPicks has both U.S. and Japan editions. Which do you want to see? U.S. Japan アカデミア申し込み案内メール アカデミアプランでは毎月1回、講義イベントへの参加権と、新刊書籍をお届けいたします。 さらに講義の動画をオンラインで視聴することができます。 毎月1日・16日に新規のアカデミア会員を募集しています。 募集開始の際に案内メールを受け取りますか？ プレミアムプラン ビジネスに気づきを与える ここでしか読めない記事 NewsPicks編集部が制作する 記事コンテンツが 全て閲覧できるようになります。 海外の 有料メディアが読める 海外メディアから 編集部が厳選した翻訳記事や The Wall Street Journal（日本版）で配信された記事を読むことが出来ます。 有料サービスについて詳しく見る 有料コンテンツの購読 現在、Web上での有料コンテンツ購読機能は準備中です。 ご不便をおかけしますが、有料コンテンツを購読希望の方は モバイルアプリ上で購読の手続きを行ってください 実名登録を行う 下記の方法から一つを選んで 実名認証を行いましょう。 Facebookで認証する 名刺等を使って認証する 名刺または学生証を利用して 実名登録を行いましょう 名刺または学生証をアップロード ※ 名刺等の情報は照合にのみ利用します ※ アップロードされた資料は公開されません 入力された情報に虚偽があった場合、認証が取り消されることがあります。 これに同意の上、下記のチェックボックスにチェックして登録を完了してください。 実名登録を行う Facebookを利用して 実名登録を行いましょう 入力された情報に虚偽があった場合、認証が取り消されることがあります。 これに同意の上、下記のチェックボックスにチェックして登録を完了してください。 実名登録を行う 実名登録が完了しました 利用を続ける あなたのコメントを 他のユーザーに届けましょう 実名であることを表明すると コメントをサービス上に公開できます。 Facebookで認証する 名刺等を使って認証する 来年度の学割プラン継続確認 学割プランは毎年 月に更新の確認を行っております。 月以降も学割プランを継続されたい方は、 学生情報を更新してください。 学生情報を更新されない場合、 次回更新時に自動解約となります。 また、通常のプレミアムプランに移行される方は アンケートに答えると1ヶ月無料期間をサービスします。 学割プランを更新されない場合 学生の場合 学生の間であれば、またいつでも学割プランにお申込み頂けます。 社会人になる場合 いま、アンケートに答えてプレミアムプランに移行すると1ヶ月無料の特典が受けられます。 ここで「更新しない」を選択すると、後からは1ヶ月無料の特典は受けられなくなりますのでご注意ください。 学割プラン申し込み案内メール 学割プランはプレミアムサービスをお得にご利用いただけるプランです。 学割プランへの申し込みに関して、案内メールを受け取りますか？ Open an app Download an app Close'
delim = '。'


#replaces OrigTxt_Preprocess and DTCC_OrigTextPreprocess
def OrigTxt_PreProcess(self, origtextlist, delim):
    
    #assumption: all text from each document is consumed and sentence tokenized with standard tokenization
    
    #change 1: remove all english characters from string before processing 
    NonEnglishText= ''.join([w for w in origtextlist if not re.match(r'[a-zA-Z\.?]+', w, re.I)])
    
    #change 2 , split tex into sentences based on custum languge delim
    text2 = NonEnglishText.split(delim)#split based on custom delimiter
    
    #strip leading and trailing spaces
    text3 = [y.strip() for y in text2 if text2]  #strip trailing and leading white space 
    
    #strip blank strings
    text4 = [y for y in text3 if not y =='']
    
    #replace multiple speaces with a single space
    text5 = [re.sub(' +',' ',y) for y in text4]
        
            
    #create list of original text with or without windowing depending on option specs
    origtext_delimlist = []
    test11=[]
    for doc in text5:
            origtext_delimlist.append(doc)
            test11.append(doc)
            
    return test11, origtext_delimlist
             

#OrigTxt_PreProcess(origtextlist=examplearticletext, delim ='。')[0]
#OrigTxt_PreProcess_DTCC(examplearticletext, delim ='。')



import tinysegmenter
segmenter = tinysegmenter.TinySegmenter()
print(' | '.join(segmenter.tokenize(u"私の名前は中野です")))


#functional tokenizer based on languge selcted in config. 
tokenizerDict={
 'english': word_tokenize(kwargs**)
 'japanese':tinysegmenter.TinySegmenter().tokenize(kwargs**)
  }


from nltk import word_tokenize
from nltk.corpus import stopwords
import string
sent = "this is a foo bar, bar black sheep."
stop = stopwords.words('japanese') + list(string.punctuation)
[i for i in word_tokenize(sent.lower()) if i not in stop]
['foo', 'bar', 'bar', 'black', 'sheep']








