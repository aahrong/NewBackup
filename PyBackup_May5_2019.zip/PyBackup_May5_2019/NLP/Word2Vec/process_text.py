from sklearn.datasets import fetch_20newsgroups
import nltk
from pprint import pprint
import string
import gensim

newsgroups = fetch_20newsgroups(categories=['comp.graphics',
                                            'comp.os.ms-windows.misc',
                                            'comp.sys.ibm.pc.hardware',
                                            'comp.sys.mac.hardware',
                                            'comp.windows.x',
                                            'rec.autos',
                                            'rec.motorcycles',
                                            'rec.sport.baseball',
                                            'rec.sport.hockey',
                                            'sci.electronics',
                                            'sci.space', ],
                                subset='all', shuffle=True, random_state=1)

# Uncomment ntlk.download() if you do not have the packages
# nltk.download()


pprint(list(newsgroups.target_names))

print("%d documents" % len(newsgroups.data))
print("%d categories" % len(newsgroups.target_names))

newsgroups_tokenized = [nltk.word_tokenize(text) for text in newsgroups.data]

news_corpus = []
for text in newsgroups_tokenized:
    lemms = []
    for word in text:
        if word not in string.punctuation:
            lemms.append(word.lower())
news_corpus.append(lemms)

model_CBOW = gensim.models.Word2Vec(news_corpus, size=200, workers=24)
model_SG = gensim.models.Word2Vec(news_corpus, size=200, workers=24, sg=1)
model_CBOW.save("C:/Users/kellymi/Downloads/W2V_CBOW.mm")
model_SG.save("C:/Users/kellymi/Downloads/W2V_Skip_Gram.mm")
model = gensim.models.Word2Vec.load("C:/Users/kellymi/Downloads/W2V_CBOW.mm")
print(model.most_similar('schedule'))

