from sklearn.datasets import fetch_20newsgroups
import re
import nltk
from nltk.corpus import stopwords
from pandas import DataFrame


# This function combines all the row corpus' into one master corpus to be fed into word2vec.
def get_corpus(data):
    corpus_tmp = []
    for index in data.index:
        corpus_tmp.append(data.iloc[index]['row_corpus'])
    return corpus_tmp


# This function obtains the corpus for a specific document as well as
def get_row_corpus(tokenized_text, language):
    stop = set(stopwords.words(language))
    row_corpus = []
    for text in tokenized_text:
        if re.match("^[a-zA-Z]*$", text) and text not in stop and len(text) > 2:
            row_corpus.append(text.lower())
    return row_corpus


# This function processes the data if the user is on a desktop, as the processing power
# Won't have enough ram to do every word combination. It's more of a POC with the 20 newsgroups only.
def process_newsgroups():
    #tmp_dict = {'comp.graphics': 'graphics','talk.religion.misc': 'religion'}
    # tmp_dict = {'comp.graphics': 'graphics','comp.os.ms-windows.misc': 'microsoft'}
    tmp_dict = {'comp.graphics': 'graphics', 'comp.os.ms-windows.misc': 'microsoft',
                'comp.sys.ibm.pc.hardware': 'ibm',
                'comp.sys.mac.hardware': 'mac', 'comp.windows.x': 'windows', 'rec.autos': 'autos',
                'rec.motorcycles': 'motorcycles',
                'rec.sport.baseball': 'baseball', 'rec.sport.hockey': 'hockey', 'sci.electronics': 'electronics',
                'sci.space': 'space', 'alt.atheism': 'atheism', 'misc.forsale': 'sale', 'sci.crypt': 'cryptography',
                'sci.electronics': 'electronics', 'sci.med': 'medical', 'soc.religion.christian': 'christian',
                'talk.politics.guns': 'guns', 'talk.politics.mideast': 'middle east',
                'talk.politics.misc': 'politics', 'talk.religion.misc': 'religion'
                }
    return tmp_dict


def pre_process_newsgroups(category, combo_word, language):
    category = str(category)
    newsgroups = fetch_20newsgroups(categories=[category, ], subset='all', shuffle=True, random_state=1)
    df = DataFrame(newsgroups.data, columns=['raw_text'])
    df['orig_category'] = category
    df['combo_word'] = combo_word
    df['tokenized'] = df.apply(lambda row: nltk.word_tokenize(row['raw_text']), axis=1)
    df['row_corpus'] = df.apply(lambda row: get_row_corpus(row['tokenized'], language), axis=1)

    return df


def check_cosine(category, combo, vocab2, model, cosine_amt):
    global res, int
    res = {}
    int = 0
    try:
        if combo != vocab2:
            cosine = model.similarity(combo, vocab2)
            if cosine >= cosine_amt:
                seeds = model.most_similar([combo, vocab2])
                res[int] = {'category': str(category), 'combo': combo, 'vocab': vocab2, 'cosine': cosine,
                            'S1': seeds[0][0], 'S1_CS': seeds[0][1],
                            'S2': seeds[1][0], 'S2_CS': seeds[1][1], 'S3': seeds[2][0], 'S3_CS': seeds[2][1],
                            'S4': seeds[3][0], 'S4_CS': seeds[3][1], 'S5': seeds[4][0], 'S5_CS': seeds[4][1],
                            'S6': seeds[5][0], 'S6_CS': seeds[5][1], 'S7': seeds[6][0], 'S7_CS': seeds[6][1],
                            'S8': seeds[7][0], 'S8_CS': seeds[7][1], 'S9': seeds[8][0], 'S9_CS': seeds[8][1],
                            'S10': seeds[9][0], 'S10_CS': seeds[9][1]}
                int = int + 1
    except Exception as e:
        print(e)
        pass
    results = DataFrame.from_dict(res, orient='index')
    return results


def build_report(results, raw, item):
    try:
        criteria = str(results['combo'][item]) + "|" + str(results['vocab'][item])
        print(criteria)
        filter = raw[raw['orig_category'] == results['category'][item]]
        match = filter[filter['row_corpus'].str.contains(criteria)]
        results.at[results.index[item], 'document_match'] = len(match)
        results.at[results.index[item], 'document_indexes'] = match.index.values
        results.at[results.index[item], 'parent_total'] = len(filter)
    except Exception as e:
        print(e)
        pass