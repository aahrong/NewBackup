from pandas import  *

#articles=read_csv("C://python_files//articles.csv",encoding="cp1252")

tmp_df=pandas.DataFrame()
tmp_df['Model']=''
tmp_df['DOC_ID']=''
tmp_df['Count']=''
tmp_df['Vocab']=''
tmp_df['Category']=''
tmp_df['S1']=''
tmp_df['S2']=''
tmp_df['S3']=''
tmp_df['Cosine']=''


final_df=pandas.DataFrame()


raw=read_csv('C:/Users/mtkel/master_data.csv',encoding="cp1252")
results=read_csv('C:/Users/mtkel/results.csv',encoding="cp1252")
results['document_match']=''
results['document_indexes']=''
results['parent_total']=''
raw['Count_1']=''

for item in results.category.unique():

    bar=results[results['category']==str(item)]

    filter = raw[raw['orig_category']==str(item)]
    orig_count = len(filter)
    combo=bar.combo.unique()[0]
    x=bar['cosine'].nlargest(3)
    for val in x.index:
        vocab=bar[bar.index==val]
        match = filter[filter['row_corpus'].str.contains(str(vocab['vocab'].values[0]))]

        for res in match.index:
             tmp_4=match[match.index==res]
             try:
                count=tmp_4['row_corpus'].str.count(str(vocab['vocab'].values[0]))
                counts=' '.join(map(str, count))
                tmp_df.set_value(res,'DOC_ID',res)
                tmp_df.set_value(res,'Count',counts[0])
                tmp_df.set_value(res, 'Vocab',vocab['vocab'].values[0])
                tmp_df.set_value(res, 'Category', tmp_4.loc[res]['combo_word'])
                tmp_df.set_value(res, 'Original_Category', item)
                tmp_df.set_value(res, 'S1', vocab['S1'].values[0])
                tmp_df.set_value(res, 'S2', vocab['S2'].values[0])
                tmp_df.set_value(res, 'S3', vocab['S3'].values[0])
                tmp_df.set_value(res, 'Cosine', vocab['cosine'].values[0])
                tmp_df.set_value(res, 'Model', 'CBOW')
                tmp_df.set_value(res, 'Total_Original',  orig_count)

                final_df=final_df.append(tmp_df)

             except Exception as e:
                 print(e)
                 pass

final_df['Count']=final_df['Count'].astype(int)
report=final_df.groupby(['DOC_ID']).max()
report_1=report.groupby(['Model','Original_Category','Category', 'Vocab','Cosine','S1', 'S2', 'S3','Total_Original']).sum()

report_1.to_csv('C:/Users/mtkel/james_5.csv')



         #   foo3=match[match.index==res]
          #  print(foo3)
           # count=foo3['row_corpus'].str.count(str(vocab['vocab'].values[0]))
            #tmp_df['Count']=count
            #tmp_df['ID']=foo3.index
            #tmp_df['Vocab']=str(vocab['vocab'].values[0])
            #final_df =final_df.append(tmp_df)



        #results['Count']=filter[['row_corpus']].applymap(lambda x: str.count(x, str(vocab['vocab'].values[0])))
        #results['Count_Val']=str(vocab['vocab'][val])
        #results['Category']=item
        #tmp_results=results[['Unnamed: 0','Count','Count_Val','Category']]
        #final_df=final_df.append(tmp_results)
#final_df.to_csv('C:/Users/mtkel/kevin.csv')





#for item in results.index:
    #x=str(results['combo'][item])+"|"+str(results['vocab'][item])

#    filter = raw[raw['orig_category']==results['category'][item]]
 #   top3 = results[results['category'][item]==raw['orig_category']]
 #   foo=top3.sort_values('cosine',ascending=False).head(3)
  #  print(foo)
    #match = filter[filter['row_corpus'].str.contains(str(results['combo'][item]))]
    #match_2 = match[match['row_corpus'].str.contains(str(results['vocab'][item]))]
    #match_3 = match_2[match_2['row_corpus'].str.contains(str(results['s1'][item]))].sum()


    #results.at[results.index[item], 'document_match'] = len(match_3)
    #results.at[results.index[item], 'document_indexes'] = match_2.index.values
    #results.at[results.index[item], 'parent_total'] = len(filter)


#results.to_csv('C:/Users/mtkel/tmp_res_1.csv')


#df3.to_csv('C:/Users/mtkel/words.csv')