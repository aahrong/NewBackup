from w2v_functions import *
from pandas import *
import concurrent.futures
import multiprocessing
import gensim

def main():
    print('Processing NLP with ' + str(multiprocessing.cpu_count()) + ' cores')
    global master_data, results
    results = pandas.DataFrame()
    master_data = pandas.DataFrame()

    with concurrent.futures.ProcessPoolExecutor() as executor:
        categories = process_newsgroups()
        newsgroups = {executor.submit(pre_process_newsgroups, category, categories[category], 'english'): category for
                      category in categories.keys()}
        for future in concurrent.futures.as_completed(newsgroups):
            try:
                data = future.result()
            except Exception as exc:
                print(exc)
                pass
            else:
                if data is not None:
                    master_data = master_data.append(data)

        corpus = get_corpus(master_data)
        model = gensim.models.Word2Vec(corpus, size=200, window=10, workers=multiprocessing.cpu_count() * 8)
        vocab = DataFrame(list(model.vocab.keys()), columns=['vocab'])


        for category in categories.keys():
            process_results = {
                executor.submit(check_cosine, category, categories[category], vocab.iloc[v]['vocab'], model, 0.80): v for
                v in vocab.index}
            for future in concurrent.futures.as_completed(process_results):
                try:
                    data = future.result()
                except Exception as exc:
                    print(exc)
                    pass
                else:
                    if data is not None:
                        results = results.append(data, ignore_index=True)

        results['document_match'] = ''
        results['document_indexes'] = ''
        results['parent_total'] = ''
        results['method'] = 'CBOW'


        #for item in results.index:
            #build_report(results, master_data, item)
            #filter = master_data[master_data['orig_category'] == results['category'][item]]
            #print(results['combo'][item])
            #match_tmp =  filter[filter['row_corpus'].str.contains(str(results['combo'][item]))]

            #print(match_tmp)

            #match = match_tmp[match_tmp['row_corpus'].str.contains(str(results['vocab'][item]))]

            #results.at[results.index[item], 'document_match'] = len(match)
            #results.at[results.index[item], 'document_indexes'] = match.index.values
            #results.at[results.index[item], 'parent_total'] = len(filter)
        master_data.to_csv('C:/Users/mtkel/master_data.csv')
        results.to_csv('C:/Users/mtkel/results.csv')


if __name__ == '__main__':
    main()
