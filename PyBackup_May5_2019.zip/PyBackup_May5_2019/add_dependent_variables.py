'''
Zach C created the joined Origination and performance data in a file called
myoutput.csv

Zach E is going to create a new file where there is only 1 row per Loan ID
and is going to introduce 2 new columns:
DELINQUENCY_FLAG: 1 or 0 Flag for whether the Loan is ever delinquent
MAX_DELINQUENCY: Categorical variable describing the level of delinquency 
'''

'''
# Head file 
count = 0
with open("E:\Use Case Testing\Mortgage\Freddie Data\MortgSamp\dependent_variables.csv","r") as input:
    for line in input:
        print(line)
        count += 1
        if count > 50:
            break
'''

'''
# Creating the 2 extra columns (dependent variables)
import h2o
h2o.init()
import csv

count = 0
old_loan_id = 'F199Q1000002'
delinquency_flag = 0
max_delinquency = "XX"
first_line = 1
row_old = []
with open("E:\Use Case Testing\Mortgage\Freddie Data\MortgSamp\myoutput.csv","r") as input:
    with open("E:\Use Case Testing\Mortgage\Freddie Data\MortgSamp\dependent_variables.csv","w+") as output:
        reader = csv.reader(input)
        writer = csv.writer(output)
        for row in reader:
            if first_line:
                
                # Write line to file
                row.append("DELINQUENCY_FLAG")
                row.append("MAX_DELINQUENCY")
                writer.writerows([row])
                
                first_line = 0
            else:
                
                # Track progress
                count += 1
                if count % 100000 == 0:
                    print(str(count*100/402600000) + "%")
                        
                # Same Loan ID
                if old_loan_id == row[0]:
                    
                    # Save delinquency info
                    new_delinquency = row[28]
                    
                    # Determine max_delinqueny
                    try:
                        new_delinquency = int(new_delinquency)
                        if max_delinquency == "XX":
                            max_delinquency = new_delinquency
                        elif max_delinquency == "R":
                            max_delinquency == "R"
                        else:
                            max_delinquency = max(max_delinquency,new_delinquency)
                    except ValueError:
                        if new_delinquency == "R":
                            max_delinquency = "R"
                    
                # New Loan ID
                else:
                    
                    # Determine delinquency_flag
                    if max_delinquency == "XX":
                        delinquency_flag = 0
                    elif max_delinquency == "R":
                        delinquency_flag = 1
                    elif max_delinquency > 0:
                        delinquency_flag = 1
                    else:
                        delinquency_flag = 0
                        
                    # Add dependent variables
                    if max_delinquency != "XX":
                        row_old.append(delinquency_flag)
                        row_old.append(max_delinquency)
    
                        # Write line to file
                        writer.writerows([row_old])
                    
                    # Re-initialize variables
                    old_loan_id = row[0]

                    # Determine max_delinqueny
                    new_delinquency = row[28]
                    max_delinquency = "XX"
                    try:
                        new_delinquency = int(new_delinquency)
                        if max_delinquency == "XX":
                            max_delinquency = new_delinquency
                        elif max_delinquency == "R":
                            max_delinquency == "R"
                        else:
                            max_delinquency = max(max_delinquency,new_delinquency)
                    except ValueError:
                        if new_delinquency == "R":
                            max_delinquency = "R"
                    delinquency_flag = 0
                    
            # Re-initialize variables
            row_old = row
'''

'''
# Statistics for becoming delinquent
import h2o
h2o.init()
import csv
import numpy as np
import statistics

count = 0
old_loan_id = "old"
delinquency_flag = 0
first_line = 1
delinquency_months = []
months_until_delinquency = 0
current_count = 0
with open("E:\Use Case Testing\Mortgage\Freddie Data\MortgSamp\myoutput.csv","r") as input:
    reader = csv.reader(input)
    for row in reader:
        if first_line:
            first_line = 0
        else:
            
            # Track progress
            count += 1
            if count % 100000 == 0:
                print(str(count*100/402600000) + "%")
                    
            # Same Loan ID
            if old_loan_id == row[0]:
                
                # Update months_until_delinquency
                months_until_delinquency += 1
                
                # Pass if already delinquent
                if delinquency_flag == 1:
                    pass
                
                else:
                
                    # Save delinquency info
                    new_delinquency = row[28]
                    
                    # Determine max_delinqueny
                    try:
                        new_delinquency = int(new_delinquency)
                        if new_delinquency != 0:
                            delinquency_flag = 1
                    except ValueError:
                        if new_delinquency == "R":
                            delinquency_flag = 1
                
            # New Loan ID
            else:
                
                # Store months_until_delinquency
                if delinquency_flag == 1:
                    delinquency_months.append(months_until_delinquency)
                else:
                    current_count += 1
                
                # Re-initialize variables
                old_loan_id = row[0]
                new_delinquency = row[28]
                delinquency_flag = 0
                try:
                    new_delinquency = int(new_delinquency)
                    if new_delinquency != 0:
                        delinquency_flag = 1
                except ValueError:
                    if new_delinquency == "R":
                        delinquency_flag = 1
                months_until_delinquency = 1
del months_until_delinquency, delinquency_flag, new_delinquency, old_loan_id, count, first_line, row

np.mean(delinquency_months)
# delinquency_months mean 73.30 months
np.std(delinquency_months)
# delinquency_months std 45.96 months
np.median(delinquency_months)
# delinquency_months median 63 months
statistics.mode(delinquency_months)
# delinquency_months mode 28 months
'''

'''
df = h2o.import_file("E:\\Use Case Testing\\Mortgage\\Freddie Data\\MortgSamp\\dependent_variables.csv")     
df[u'FPD'].max()
# Latest information is at 201606
del df

# The mean 73 months is approximately 6 years
num_months = 0
first_line = 1
with open("E:\Use Case Testing\Mortgage\Freddie Data\MortgSamp\dependent_variables.csv","r") as input:
    with open("E:\Use Case Testing\Mortgage\Freddie Data\MortgSamp\dependent_variables_mmsd.csv","w+") as output:
        reader = csv.reader(input)
        writer = csv.writer(output)
        for row in reader:
            if first_line:
                first_line = 0
                writer.writerows([row])
                pass
            else:
                if int(row[2]) < 201403:
                    num_months += 1
                    writer.writerows([row])
del first_line, row
# m num_months = 6648939 ~77.17%
# mmsd num_months = 8024533 
'''

'''
# Create > 60 day Flag
first_line = 1
with open("E:\Use Case Testing\Mortgage\Freddie Data\MortgSamp\dependent_variables.csv","r") as input:
    with open("E:\Use Case Testing\Mortgage\Freddie Data\MortgSamp\dependent_variables_60DPD.csv","w+") as output:
        reader = csv.reader(input)
        writer = csv.writer(output)
        for row in reader:
            if first_line:
                first_line = 0
                row = row[0:-2]
                row.append("60DPDFLAG")
                writer.writerows([row])
            else:
                delinquency = row[48]
                delinquency_60_flag = 0
                try:
                    delinquency = int(delinquency)
                    if delinquency >= 2:
                        delinquency_60_flag = 1
                except ValueError:
                    if delinquency == "R":
                        delinquency_60_flag = 1
                    else:
                        print(row[0],delinquency)
                row = row[0:-2]
                row.append(delinquency_60_flag)
                writer.writerows([row])
del first_line, row, delinquency, delinquency_60_flag
'''

# Normalize 60DPD
def normalize(row):
    # Normalize the (appropriate (numeric) data columns
    # Fico, INS_PCT, 

first_line = 1
with open("E:\Use Case Testing\Mortgage\Freddie Data\MortgSamp\dependent_variables_60DPD.csv","r") as input:
    with open("E:\Use Case Testing\Mortgage\Freddie Data\MortgSamp\dependent_variables_normalized_60DPD.csv","w+") as output:
        reader = csv.reader(input)
        writer = csv.writer(output)
        for row in reader:
            if first_line:
                first_line = 0
                row = row[0:-2]
                row.append("60DPDFLAG")
                writer.writerows([row])
            else:
                row = normalize(row)
                writer.writerows([row])
del row, first_line
    
 