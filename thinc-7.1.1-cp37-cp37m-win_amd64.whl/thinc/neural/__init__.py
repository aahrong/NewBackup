# coding: utf8
from __future__ import unicode_literals

from ._classes.model import Model  # noqa: F401
