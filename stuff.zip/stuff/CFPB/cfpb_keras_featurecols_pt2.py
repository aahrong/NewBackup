# -*- coding: utf-8 -*-
"""
Created on Thu Jun  6 07:58:15 2019

@author: caridza
https://www.pyimagesearch.com/2019/02/04/keras-multiple-inputs-and-mixed-data/
https://stackoverflow.com/questions/52485242/how-to-use-embedding-layer-and-other-feature-columns-together-in-a-network-using
"""
#feature column with cfpb data
import pandas as pd
import numpy as np
from sklearn.datasets import load_iris
import matplotlib.pyplot as plt
import sys 
sys.path.insert(0, "C:\\Users\\caridza\\Desktop\\pythonScripts\\ExploratoryDataAnalysis\\")
sys.path.insert(0,"C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\CFPB\\")
from EDA_Funcs.EDA_Functions  import fill_missing,drop_constant_column, df_rowtypes, percent_col_total, plot_counts, df_rowtypes,create_catmap,fillNA_convertoCat
from cfpb_funcs.cfpb_helpers import get_meta_dict, train_test_valid,cfpb_preproc_pt1,text_clean,get_doc2bow,check_catlevel_counts,encode_target_alt,encode_ordinal,encode_nominal
from cfpb_funcs.cfpb_featcol_helpers import df_to_dataset

#modeleling libararies 
from keras.backend.tensorflow_backend import set_session
from keras.models import Sequential
from keras import applications
import tensorflow as tf
from tensorflow.keras.backend import random_uniform
from sklearn.model_selection import train_test_split

#feature col functions
from tensorflow import feature_column
from tensorflow.keras import layers


#static paths
DATAPATH="C:\\Users\\caridza\\Desktop\\pythonScripts\\Data\\cfpb\\"
OUTPUTPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/"
PYMAGPATH = "C://Users//caridza//Downloads//crawl-300d-2M.magnitude"
filename = "cfpb_complaints.csv"

# load the dataset
data = pd.read_csv(DATAPATH+filename).copy()
data = data[~data['Consumer complaint narrative'].isna()]

#cfpb preproc data 
data =cfpb_preproc_pt1(data)

#must rename columns to remove _ for sklearn pipelines
data = data.rename(columns={col:col.replace('_','').replace('-','').replace(' ','').replace('?','') for col in list(data)})
list(data)

#create mapping of categorical vairables 
cat_dict = {}
cat_dict['Product']={'type':'nominal','use':'target'}
cat_dict['Subproduct']={'type':'nominal','use':'no'}
cat_dict['Issue']={'type':'nominal','use':'yes'}
cat_dict['Subissue']={'type':'nominal','use':'no'}
cat_dict['Companypublicresponse']={'type':'nominal','use':'yes'}
cat_dict['Company']={'type':'nominal','use':'no'}
cat_dict['State']={'type':'nominal','use':'yes'}
cat_dict['ZIPcode']={'type':'nominal','use':'yes'}
cat_dict['Tags']={'type':'nominal','use':'yes'}
cat_dict['Consumerconsentprovided']={'type':'nominal','use':'yes'}
cat_dict['submittedvia']={'type':'nominal','use':'yes'}
cat_dict['Datesenttocompany']={'type':'ordinal','use':'yes'}
cat_dict['Datereceived']={'type':'ordinal','use':'yes'}
cat_dict['Companyresponsetoconsumer']={'type':'nominal','use':'yes'}
cat_dict['Timelyresponse']={'type':'ordinal','use':'yes'}
cat_dict['Consumerdisputed']={'type':'ordinal','use':'yes'}

#encode target 
Data ,targDefs= encode_target_alt(data,target='Product')

#metadata dictonary for each columns
d_types = pd.DataFrame(get_meta_dict(Data)).T

#fill in missing values for all columns with >1 type of data 
#NOTE: CANNOT convert series to tf.tensor if there is > 1 datatype in column 
for col in list(Data):
    if len(d_types.loc[col,'dtype'])>1:
        Data[col] = fill_missing(Data,col,MisConst='Missing')

#SPLIT DATA
train_df,test_df,valid_df = train_test_valid(Data,test_size=.2,stratify='label_id')

#load dataframes into tf datasets (returns a yield iterator of batch size 50)
batch_size = 50
train_ds = df_to_dataset(train_df,target='label_id', batch_size=batch_size)
val_ds = df_to_dataset(valid_df,target='label_id', shuffle=False, batch_size=batch_size)
test_ds = df_to_dataset(test_df,target='label_id', shuffle=False, batch_size=batch_size)

for feature_batch, label_batch in train_ds.take(1):
  print('Every feature:', list(feature_batch.keys()))
  print('A batch of ages:', feature_batch['Issue'])
  print('A batch of targets:', label_batch )

for feature_batch,latbel_bath in train_ds.take(1):
    print('key:{}'.format(list(feature_batch.keys())[2]),'\n',
          'values: {}'.format(feature_batch[list(feature_batch.keys())[2]])
          )
   
#CREATE FEATURE COLUMNS 
exclude = ['label_id','Subproduct','Consumercomplaintnarrative','Product']
feature_columns = []

#numeric 
for col in ['CountUniqMoneyVals','CountUniqNonMoneyVals']:
    feature_columns.append(feature_column.numeric_column(col))
    
#indicator cols(for low level categoric variables)
for col in list(d_types[d_types['nunique']<=20].index):
    if col not in exclude:
        newcol = feature_column.categorical_column_with_vocabulary_list(col,list(Data[col].unique()))
        feature_columns.append(feature_column.indicator_column(newcol))
    
#categorical embeddings 
#Note: to use embedding column, the categorical column must first be converted to categorical with vocabulary list 
for col in list(d_types[(d_types['nunique']>20) & (d_types['dtype']=='str')].index):
    if col not in exclude:
        newcol = feature_column.categorical_column_with_vocabulary_list(col,list(Data[col].unique()))
        feature_columns.append( feature_column.embedding_column(newcol, dimension=20))
        
        

#CREATE FEATURE LAYER 
feature_layer = tf.keras.layers.DenseFeatures(feature_columns)


#FIT MODEL 
model = tf.keras.Sequential([
  feature_layer,
  layers.Dense(128, activation='relu'),
  layers.Dense(128, activation='relu'),
  layers.Dense(len(Data['label_id'].unique()), activation='softmax')
])

model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

model.fit(train_ds,
          validation_data=val_ds,
          epochs=5)






















