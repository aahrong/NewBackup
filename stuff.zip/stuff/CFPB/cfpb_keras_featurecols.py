# -*- coding: utf-8 -*-
"""
Created on Wed May 22 15:25:05 2019

@author: caridza
"""
#resources 
#https://github.com/mayanksatnalika/ipython/blob/master/embeddings%20project/cycle_sharing/entity_embeddings_regression.ipynb
#https://machinelearningmastery.com/use-features-lstm-networks-time-series-forecasting/
##https://towardsdatascience.com/how-to-build-a-wide-and-deep-model-using-keras-in-tensorflow-2-0-2f7a236b5a4b
#https://colab.research.google.com/github/tensorflow/docs/blob/master/site/en/r2/tutorials/keras/feature_columns.ipynb

#NOTE: YOU SHOULD USE KERAS FUNCTIONAL MODEL API instead of sequential API. Sequential API does not allow for multi-feature inputs
#NOTE: TO USE keras feature columns correectly you must understand TF DATA MODULE from Tensorflow 
#EXAMPLE INCLUDING EMBEDDING LAYER MERGING THROUGH CONCATENATE: https://stackoverflow.com/questions/52485242/how-to-use-embedding-layer-and-other-feature-columns-together-in-a-network-using
'''
#TF DATA OVERVIEW


#tf.data.Dataset: represents a sequence of elments, in which each element contains one or more Tensor objects (ex. element mihgt be a single traning example, with a pair of tensors representing the data and the target label)
    #2 ways to create a dataset 
        #1. creating a source (dataset.from_tensor_slices()) constructs a dataset from one or more tf.Tensor objects 
        #2. applying transformation (e.g Dataset.batch()) constrcuts a dataset from one or more tf.data.Dataset objects 

#tf.data.Iterator: provides the main way to extract elements from a dataset
    #Iterator.get_next() yields the next element of a dataset when executed. acts as the interface between input piepline code and your model 
        #the simplest form "one-shot iterator" is associated with a particular Dataset and iterates through it one time
        
#Basic Mechanics 
        
    #1.DEFINE A SOURCE: to start a pipeline you must define a source. 
        #In Memory data Sources
            #tf.data.Dataset.from_tensors()
            #tf.data.Dataset.from_tensor_slices()
            
        #On Disk data Sources 
            #tf.data.TFRecordDataset
    
    #2.Consume values from a Dataset(source): commonly done by creating an iterator object that provides access to one element of the dataset at a time(ex. calling Dataset.make_one_shot_iterator())
        #tf.data.Iterator provides two operations 
            #1.Iterator.initializer: enables you to reinitialize the iterators state 
            #2.Iterator.get_next(): returns tf.Tensor objects that correspond to the syumboliv next element 
'''

'''
#Dataset Structure 
    
    #dataset comprises elments that each have the same structure. Each element contains components
        #component: one or more tf.Tensor objects. each component has a tf.Dtype and a tf.Tensorshape property enabled  you to inspect theinferred types and shapes of each component in the dataset 
    
    #Dataset.output_types & Dataset.output_shapes: properties enable inspection of components of a dataset element. 
        #The nested structure of these properties map to the structure of an element, which may be a single tensor, a tuple of tensors, or a nested tuple of tensors.
'''
from keras.backend.tensorflow_backend import set_session
from keras.models import Sequential
from keras import applications
import tensorflow as tf
from tensorflow.keras.backend import random_uniform
from sklearn.model_selection import train_test_split

#GET DATA
URL = 'https://storage.googleapis.com/applied-dl/heart.csv'
dataframe = pd.read_csv(URL)
dataframe.head()

#SPLIT DATA
train, test = train_test_split(dataframe, test_size=0.2)
train, val = train_test_split(train, test_size=0.2)
print(len(train), 'train examples')
print(len(val), 'validation examples')
print(len(test), 'test examples')

#CREATE INPUT PIPELINE USING TF.DATA
# utility method to create a tf.data dataset from a Pandas Dataframe
# dict(dataframe) converts each column name to a key, and value for each key is the series of row values from the datatframe column 
def df_to_dataset(dataframe, shuffle=True, batch_size=32):
  dataframe = dataframe.copy()
  labels = dataframe.pop('target')
  ds = tf.data.Dataset.from_tensor_slices((dict(dataframe), labels))
  if shuffle:
    ds = ds.shuffle(buffer_size=len(dataframe))
  ds = ds.batch(batch_size)
  return ds

#train , test, valid input pipelines
batch_size = 5 # A small batch sized is used for demonstration purposes
train_ds = df_to_dataset(train, batch_size=batch_size)
val_ds = df_to_dataset(val, shuffle=False, batch_size=batch_size)
test_ds = df_to_dataset(test, shuffle=False, batch_size=batch_size)


#VIEW OUTPUT TENSORS
#view of the independent variables and target tensors after conversion to dataset
#we created a set of 2 tensors both of unique shape(tensor1: DataFrame of input variables, tensor2:series of labels for training)
#this is why train_ds.take(1) returns 2 tensors, where each tensor is of length batch_size
#take() : used like head, except here take(1) means take the first batch of 5 records from each tensor defined in tf.data.Dataset.from_tensor_slices()
for feature_batch, label_batch in train_ds.take(1):
  print('Every feature:', list(feature_batch.keys()))
  print('A batch of ages:', feature_batch['age'])
  print('A batch of targets:', label_batch )

for feature_batch,latbel_bath in train_ds.take(1):
    print('key:{}'.format(list(feature_batch.keys())[2]),'\n',
          'values: {}'.format(feature_batch[list(feature_batch.keys())[2]])
          )
   

#CREATE FEATURE COLUMNS
#OUTPUT from feature column becomes input to the model
from tensorflow import feature_column
from tensorflow.keras import layers

#0.extract sample batch to demonstrate various feature types 
example_batch = next(iter(train_ds))[0]

#0.create utility method to create a feature column and to transform a batch of data
def demo(feature_column):
  feature_layer = layers.DenseFeatures(feature_column)
  print(feature_layer(example_batch).numpy())

#1.Different feature column types (overview of each)
#Numeric feature columns(model receives the column value from the dataframe unchanged)
  #Input: Numeric Variable 
  #Output: Numeric Variable 
age = feature_column.numeric_column("age")
demo(age)


#Bucketized columns (split numeric column into categories based on numerical ranges).
    #OUTPUT: one hot encoded list of features, one for each level defined in boundaries
age_buckets = feature_column.bucketized_column(age, boundaries=[18,25,30,35,40,45,50,55,60,65])
demo(age_buckets)


#Categorical columns 
    #we cannot feed strings to a model, we must map them to numeric values 
    #categorical vocabulary coluns provide a way to represent strings as a hone hot vector. The vocabulary can be passed as a list using categorical_column_with_vocabulary_list , or loaded from a file using categorical_column_with_vocabulary_file 
thal = feature_column.categorical_column_with_vocabulary_list('thal',['fixed','normal','reversible'])

thal_one_hot = feature_column.indicator_column(thal)
demo(thal_one_hot)

#Embedded columns 
#use when we have hundreds / thousands of values per categorical variable. 
#embedding column represents that data as a lower-dimensional, dense vector in which each cell can contain any number not just 0 or 1
#the size of the embedding(8 in ex below) must be tuned 
#NOTICE: the input to the embedding column is the categorical column 
thal_embedding = feature_column.embedding_column(thal,dimension=8)
demo(thal_embedding)

#Crossed feature columns (modeling interactions!)
#combining features into a single feature, enables a model to learn seperate weights for each combination of features 
#ex. create new feature that is represents the interaction of age and thail 
#does not build the full table of all possible combinations, instead, it is backed by a hashed_column so you can choose how large the table is
crossed_feature = feature_column.crossed_column([age_buckets,thal],hash_bucket_size=10)
demo(feature_column.indicator_column(crossed_feature))


#MODEL BUILD 
#2.Choose which columns to use 
feature_columns = []

# numeric cols
for header in ['age', 'trestbps', 'chol', 'thalach', 'oldpeak', 'slope', 'ca']:
  feature_columns.append(feature_column.numeric_column(header))

# bucketized cols
age_buckets = feature_column.bucketized_column(age, boundaries=[18, 25, 30, 35, 40, 45, 50, 55, 60, 65])
feature_columns.append(age_buckets)

# indicator cols
thal = feature_column.categorical_column_with_vocabulary_list(
      'thal', ['fixed', 'normal', 'reversible'])
thal_one_hot = feature_column.indicator_column(thal)
feature_columns.append(thal_one_hot)

# embedding cols
# input to embedding must be the categorical feature column with vocabulary list created above
thal_embedding = feature_column.embedding_column(thal, dimension=8)
feature_columns.append(thal_embedding)

# crossed cols
#crossed_feature = feature_column.crossed_column([age_buckets, thal], hash_bucket_size=1000)
#crossed_feature = feature_column.indicator_column(crossed_feature)
#feature_columns.append(crossed_feature)

#create a feature layer
feature_layer = tf.keras.layers.DenseFeatures(feature_columns)


#RUN MODEL WITH LARGER BATCH SIZE 
batch_size = 32
train_ds = df_to_dataset(train, batch_size=batch_size)
val_ds = df_to_dataset(val, shuffle=False, batch_size=batch_size)
test_ds = df_to_dataset(test, shuffle=False, batch_size=batch_size)


model = tf.keras.Sequential([
  feature_layer,
  layers.Dense(128, activation='relu'),
  layers.Dense(128, activation='relu'),
  layers.Dense(1, activation='sigmoid')
])

model.compile(optimizer='adam',
              loss='binary_crossentropy',
              metrics=['accuracy'])

model.fit(train_ds,
          validation_data=val_ds,
          epochs=5)

















#load dataset from a set of arrays (4 arrays, each 10 elements long)
dataset1 = tf.data.Dataset.from_tensor_slices(random_uniform([4, 10]))
print(dataset1.output_types)  # ==> "tf.float32"
print(dataset1.output_shapes)  # ==> "(10,)"




dataset2 = tf.data.Dataset.from_tensor_slices(
   (random_uniform([4]),
    random_uniform([4, 100], maxval=100, dtype=tf.int32)))

print(dataset2.output_types)  # ==> "(tf.float32, tf.int32)"
print(dataset2.output_shapes)  # ==> "((), (100,))"

dataset3 = tf.data.Dataset.zip((dataset1, dataset2))
print(dataset3.output_types)  # ==> (tf.float32, (tf.float32, tf.int32))
print(dataset3.output_shapes)  # ==> "(10, ((), (100,)))"


import numpy as np 
rand_uni = np.random.uniform(size = (4,10))





# Import required libraries
import pandas as pd
from sklearn.datasets import load_iris
import matplotlib.pyplot as plt
import sys 
sys.path.insert(0, "C:\\Users\\caridza\\Desktop\\pythonScripts\\ExploratoryDataAnalysis\\")
from EDA_Funcs.EDA_Functions  import drop_constant_column, df_rowtypes, percent_col_total, plot_counts, df_rowtypes,create_catmap,fillNA_convertoCat

DATAPATH="C:\\Users\\caridza\\Desktop\\pythonScripts\\Data\\cfpb\\"
OUTPUTPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/"
PYMAGPATH = "C://Users//caridza//Downloads//crawl-300d-2M.magnitude"
filename = "cfpb_complaints.csv"

# load the dataset
data = pd.read_csv(DATAPATH+filename).copy()

#create mapping of categorical vairables 
cat_dict = {}
cat_dict['Product']={'type':'nominal','use':'target'}
cat_dict['Sub-product']={'type':'nominal','use':'no'}
cat_dict['Issue']={'type':'nominal','use':'yes'}
cat_dict['Sub-issue']={'type':'nominal','use':'no'}
cat_dict['Company public response']={'type':'nominal','use':'yes'}
cat_dict['Company']={'type':'nominal','use':'no'}
cat_dict['State']={'type':'nominal','use':'yes'}
cat_dict['ZIP code']={'type':'nominal','use':'yes'}
cat_dict['Tags']={'type':'nominal','use':'yes'}
cat_dict['Consumer consent provided?']={'type':'nominal','use':'yes'}
cat_dict['submitted via']={'type':'nominal','use':'yes'}
cat_dict['Date sent to company']={'type':'ordinal','use':'yes'}
cat_dict['Date received']={'type':'ordinal','use':'yes'}
cat_dict['Company response to consumer']={'type':'nominal','use':'yes'}
cat_dict['Timely response?']={'type':'ordinal','use':'yes'}
cat_dict['Consumer disputed?']={'type':'ordinal','use':'yes'}



d_types = {col:{'dtype':' ,'.join([type for type in df_rowtypes(data,cols=[col])[col].unique()]),
                'colclass':data[col].dtypes.type.__name__,
                'nunique': len(list(data[col].unique())),
                'nmissing':data[col].isnull().sum(),
                'mode_NonNANFreq': len(data[data[col]==data[col].mode(dropna=True)[0]][col]),
                'mode' : data[col].mode(dropna=False)[0],
                'mode_NonNAN' : data[col].mode(dropna=True)[0],
                'top_3_counts': percent_col_total(df=data,col=col,topn=20),
                }for col in data.columns}

#save metadata to df and plot most freq items from each column 
metadata = pd.DataFrame(d_types).T
cols_nomiss = metadata[metadata['nmissing']==0].index.values







