import pandas as pd
import textblob, string, pickle, sys
from itertools import islice #iterating over vectorized objects (countvectorizer, tfidfvectorizer,etc..)
import sklearn
from sklearn.compose import ColumnTransformer

#text parsing
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
#plotting
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
import numpy as np
import mpu
import scikitplot as skplt
import joblib
import re
import os.path 
from os import path
#custom modules 
import negative_news2
from negative_news2 import consumer
from negative_news2.consumer import utils
from negative_news2.consumer.utils  import Num2Int_Transformer, plot_cm,CatSelector,TextSelector, NumberSelector,orig_text_clean,load_and_score,remove_punctuation,remove_stop,stem_words,remove_nonchars,pipelinize,sk_model_stats
#required for corrolation 
import scipy
import statistics
from scipy.stats.stats import pearsonr   
#custom modules
import sys
sys.path.insert(0, "C:\\Users\\caridza\\Desktop\\pythonScripts\\ExploratoryDataAnalysis\\")
sys.path.insert(0,"C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\Text_Preprocessing\\PreProcessFuncs\\")
sys.path.insert(0,"C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\Clustering\\ClusMetrics\\")
sys.path.insert(0,"C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\CFPB\\")
from EDA_Funcs.EDA_Functions  import drop_constant_column, df_rowtypes, percent_col_total, plot_counts, df_rowtypes,create_catmap,fillNA_convertoCat
from PreProcess_Funcs import find_numerics, generate_StopWords_Phrases, replace_stopphrases, remove_stopwords_string, remove_nonchars, incorp_phrases, lemma_wordtok_text,corp_WordFreqs
from metrics import compute_coherence_values,topic_prob_extractor
from cfpb_funcs.cfpb_helpers import cfpb_preproc_pt1,text_clean,get_doc2bow,check_catlevel_counts,encode_target_alt,encode_ordinal,encode_nominal
#load spacy using symlink created from python -m spacy download en_core_web_sm
import spacy 

#####################
#Dataset Preperation#
##################### 
DATAPATH="C:\\Users\\caridza\\Desktop\\pythonScripts\\Data\\cfpb\\"
OUTPUTPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/"
filename = "cfpb_complaints.csv"

TARGET = 'Product'
CATMISCONSTANT = 'Missing'
MINSTRINGLEN = 20 #min length of text to be consiered 
LOW_DOC_LIM = 10  #minimum number of docs a word must be found in to be considerd 
UPPER_DOC_PERC = .4 #maximum percent of docs a word can be found in to be considered 

# load the dataset

def process_cfpb_data(data,DATAPATH,OUTPUTPATH,TARGET,CATMISCONSTANT,MINSTRINGLEN,stop_phrases,stop_terms,stop_list):
    
    #preprocessing part 1   
    Data = cfpb_preproc_pt1(data)
    print('data shape after initial preprocessing:{}'.format(Data.Shape[0]))
        
    #data mapping variable level(THIS IS DONE MANUALLY)
    #defines what variables from original data set will be used, as well as the data type we want to process them by 
    #create dic of catvars with mapping to ordinal or nominal 
    cat_dict = {}
    cat_dict['Product']={'type':'nominal','use':'target'}
    cat_dict['Sub-product']={'type':'nominal','use':'no'}
    cat_dict['Issue']={'type':'nominal','use':'yes'}
    cat_dict['Sub-issue']={'type':'nominal','use':'no'}
    cat_dict['Company public response']={'type':'nominal','use':'yes'}
    cat_dict['Company']={'type':'nominal','use':'no'}
    cat_dict['State']={'type':'nominal','use':'yes'}
    cat_dict['ZIP code']={'type':'nominal','use':'yes'}
    cat_dict['Tags']={'type':'nominal','use':'yes'}
    cat_dict['Consumer consent provided?']={'type':'nominal','use':'yes'}
    cat_dict['submitted via']={'type':'nominal','use':'yes'}
    cat_dict['Date sent to company']={'type':'ordinal','use':'yes'}
    cat_dict['Date received']={'type':'ordinal','use':'yes'}
    cat_dict['Company response to consumer']={'type':'nominal','use':'yes'}
    cat_dict['Timely response?']={'type':'ordinal','use':'yes'}
    cat_dict['Consumer disputed?']={'type':'ordinal','use':'yes'}
    
    #encode target 
    Data ,targDefs= encode_target_alt(Data,target=TARGET)
    print('Target Encoded: {}'.format(targDefs))
    
    #encode oridinal 
    ordinals= [key for key in cat_dict.keys() if (cat_dict[key]['type']=='ordinal' and key in Data and cat_dict[key]['use']=='yes')]
    for col in ordinals: 
        Data[col+'_id']= encode_ordinal(Data,col,CatMisConst=CATMISCONSTANT,ordered=True)
    print('Oridinal Columns Encoded:{}'.format(ordinals))
    
    #encode nomoinal variables as onehotencoded 
    #[(x,len(Data[x].unique())) for x in nominals ]
    nominals= [key for key in cat_dict.keys() if (cat_dict[key]['type']=='nominal' and key in Data and cat_dict[key]['use']=='yes')]
    Data = encode_nominal(Data,nominals,CatMisConst=CATMISCONSTANT,DropOneLevel=True)
    print('Nominal Columns Encoded:{}'.format(nominals))
    print('Data Shape after Independent variable transformations:{}'.format(Data.shape))
    
    
    #clean text (remove stop phrases->remove_nonchar->remove_stopwords)
    Data['Consumer complaint narrative']= text_clean(Data,textcol='Consumer complaint narrative',stop_phrases=stop_phrases,stop_list=stop_list)
    print('Stop Phrases Removed')
        
    #subset dataframe to only include rows with at least 10 words
    mask = (Data['Consumer complaint narrative'].str.len()>MINSTRINGLEN )
    Data = Data.loc[mask]
    print('Text with < {} removed. Remaining observations = {}'.format(MINSTRINGLEN,Data.shape[0]))
    
    #build phrases into corpus 
    Data['Consumer complaint narrative']  = incorp_phrases(Data['Consumer complaint narrative'], stop_words=stop_list)
    print('Phrases incorporated into texts')
        
    #data returned has not been lemmatized or filtered based on text presence
    return Data 


if __name__=='__main__':
    
    from nltk.corpus import stopwords
    nlp = spacy.load("en_core_web_sm", disable=['parser', 'ner'])
    
    #text preprocesing
    excluded_punct={'+', ':', '[', '^', '"', '|', '{', '@', '=', ')', '%', '#', '+','`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}
    stopwords = stopwords.words('english')
    newStopWords = ['.','?','%','Google','Wells Fargo','guggenheim partners llc','new york','guggenheim partners','bank america','wells fargos','year','thing','would','include','tuesday','make','time','state','bank','certain','country','string','perhaps','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December','from', 'subject', 're', 'edu', 'use', 'not', 'would', 'say', 'could', '_', 'be', 'know', 'good', 'go', 'get', 'do', 'done', 'try', 'many', 'some', 'nice', 'thank', 'think', 'see', 'rather', 'easy', 'easily', 'lot', 'lack', 'make', 'want', 'seem', 'run', 'need', 'even', 'right', 'line', 'even', 'also', 'may', 'take', 'come','the']
    stopwords.extend(newStopWords)
    stop_list=set(stopwords)
    
    #stop words and phrases to remove    
    stop_phrases=generate_StopWords_Phrases(stop_list)[1]
    stop_terms= generate_StopWords_Phrases(stop_list)[0]

    DATAPATH="C:\\Users\\caridza\\Desktop\\pythonScripts\\Data\\cfpb\\"
    OUTPUTPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/"
    filename = "cfpb_complaints.csv"
    
    TARGET = 'Product'
    CATMISCONSTANT = 'Missing'
    MINSTRINGLEN = 20 #min length of text to be consiered 
    LOW_DOC_LIM = 10  #minimum number of docs a word must be found in to be considerd 
    UPPER_DOC_PERC = .4 #maximum percent of docs a word can be found in to be considered 

    #execute function    
    if path.exists(DATAPATH + 'cfpb_complaints_generaluse.pickle')==False:

        data = pd.read_csv(DATAPATH+filename).copy()
        Data =  process_cfpb_data(data,DATAPATH,OUTPUTPATH,TARGET,CATMISCONSTANT,MINSTRINGLEN,stop_phrases,stop_terms,stop_list)
        pd.to_pickle(Data,DATAPATH + 'cfpb_complaints_generaluse.pickle')
    
    else:    
        print('cfpb Preprocessing has already been executed, file is located at {}'.format(DATAPATH + 'cfpb_complaints_generaluse.pickle'))
        
    

    
    
    
    