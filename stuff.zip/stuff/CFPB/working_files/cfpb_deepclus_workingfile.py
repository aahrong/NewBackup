#https://github.com/Tony607/Keras_Deep_Clustering/blob/master/Keras-DEC.ipynb
import pandas as pd 
import gensim
import re
import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt

#load spacy using symlink created from python -m spacy download en_core_web_sm
import spacy 
nlp = spacy.load("en_core_web_sm", disable=['parser', 'ner'])

#load custom funcs
import sys
sys.path.insert(0,"C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\Clustering\\ClusMetrics\\")
from DeepClust2_Helpers import train_autoencoder, train_encoder_with_Clustlayer,eval_deepclust

#input/output paths
DATAPATH="C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\Data\\NewData\\"
OUTPUTPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/"
PYMAGPATH = "C://Users//caridza//Downloads//crawl-300d-2M.magnitude"


#load pymag file 
import pymagnitude
wv=pymagnitude.Magnitude(PYMAGPATH)


#data
Data = pd.read_pickle(DATAPATH+'cfpb_finaldata2.pickle').head(10000)

#check if embeddings have been created, if not , create them 
if 'sent_vecs' not in Data:
    #NOTE: IF YOU HAVE SENTENCE TOKENIZED DATA, THEN YOU WILL NEED TO USE LIST COMPREHENSION TO GENERATE THE LIST OF SENT_VECTORS FOR EACH SENTENCE IN TEXT 
    #return the avg vector for each sentence by taking the average embedding from all words in senetence 
    if any(isinstance(el, list) for el in Data['final_complaint_text'].iloc[0]):
        Data['sent_vecs'] = Data.apply(lambda row: [np.nanmean(wv.query(sent_tokens),axis=0) for sent_tokens in row['final_complaint_text']],axis=1)
        Data['phrase_vecs'] = Data.apply(lambda row: np.nanmean(row['sent_vecs'],axis=0),axis=1)
        
    else:
        #NO SENTENCE TOKENIZED, ALL WORDS IN SINGLE LIST PER ROW
        Data['sent_vecs'] = Data.apply(lambda row: np.nanmean(wv.query(row['final_complaint_text']),axis=0),axis=1)


########################
#inputs for autoencoder#
########################
top_levels_to_model = 4
target = 'Product'
text_tokens_col = 'final_complaint_text'
encode_decode_layer_nodes = [50,50,100,200]
learning_rate = 1
momentum = .9
pretrain_epochs = 300
batch_size = 256
save_dir = 'C:\\Users\\caridza\\Downloads\\'

autoencoder,encoder,targlevels,X_Norm,Y,n_clusters = train_autoencoder(top_levels_to_model,target,text_tokens_col,encode_decode_layer_nodes,learning_rate,momentum,pretrain_epochs,batch_size,save_dir)


model, loss = train_encoder_with_Clustlayer(encoder,autoencoder,save_dir,n_clusters,batch_size)


eval_deepclust(model,save_dir,X_Norm,Y,loss)



























#TRAIN CLUSTERING AND AUTOENCODER AT THE SAME TIME 
autoencoder, encoder = autoencoderConv2D_1()
autoencoder.load_weights(save_dir+'/conv_ae_weights.h5')
clustering_layer = ClusteringLayer(n_clusters, name='clustering')(encoder.output)
model = Model(inputs=encoder.input,
                           outputs=[clustering_layer, autoencoder.output])




#compare encoders 
en_orig = autoencoder()
#build clustering autoencoder with deep embeddings at the phrase level 
#sys.path.insert(0,"C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\Clustering\\ClusMetrics\\")
#from build_DeepclustEncoder import build_deep_clust_encoder
#build_deep_clust_encoder(Data.head(10000),'Product',16,'final_complaint_text',wv=wv)



















