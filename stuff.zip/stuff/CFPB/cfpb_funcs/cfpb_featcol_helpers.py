# -*- coding: utf-8 -*-
"""
Created on Thu Jun  6 08:38:05 2019
CFPB KERAS FEATURE COLUMN FUNCTIONS
DESCRIPTION: helper functions to enable use of multi-type inputs to keras model (embedding layer, numeric cols, cat_embeddings, etc)
NOTE: TO ENABLE FULL FUNCTIONALITY YOU SHOULD BE USING THE FUCNTIONAL MODEL API FOR KERAS, NOT THE SEQUENTIAL MODEL API 
@author: caridza
"""


####TF DATASET FUNCTIONS FOR FEATURE_COLUMN MODELING 
import tensorflow as tf 
from tensorflow import feature_column
from tensorflow.keras import layers

#CREATE INPUT PIPELINE USING Tensorflows tf.data.Dataset.from_tensor_slices()
# utility method to create a tf.data dataset from a Pandas Dataframe
# dict(dataframe) converts each column name to a key, and value for each key is the series of row values from the datatframe column 
def df_to_dataset(dataframe, target='target',shuffle=True, batch_size=32):
  dataframe = dataframe.copy()
  labels = dataframe.pop(target)
  ds = tf.data.Dataset.from_tensor_slices((dict(dataframe), labels))
  if shuffle:
    ds = ds.shuffle(buffer_size=len(dataframe))
  ds = ds.batch(batch_size)
  return ds