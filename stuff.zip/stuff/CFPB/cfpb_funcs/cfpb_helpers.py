# -*- coding: utf-8 -*-
"""
Created on Tue May 21 15:02:24 2019
cfpb_helpers
@author: caridza
"""
import pandas as pd
import sys 
from sklearn import preprocessing
import re 
import sklearn
from sklearn.model_selection import train_test_split

sys.path.insert(0,"C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\Text_Preprocessing\\PreProcessFuncs\\")
import PreProcess_Funcs as ppf

sys.path.insert(0, "C:\\Users\\caridza\\Desktop\\pythonScripts\\ExploratoryDataAnalysis\\")
import EDA_Funcs.EDA_Functions as edaf


#train test split 
def train_test_valid(Data,test_size=.2,stratify=None):
    #SPLIT DATA
    
    if stratify==None:
        train, test = train_test_split(Data, test_size=0.2,stratify=None)
        train, val = train_test_split(train, test_size=0.2)
    else:
        train, test = train_test_split(Data, test_size=0.2,stratify=Data[stratify])
        train, val = train_test_split(train, test_size=0.2,stratify=train[stratify])
    
    print(len(train), 'train examples')
    print(len(val), 'validation examples')
    print(len(test), 'test examples')

    return train,test,val
    

#returns dictonary of metadata based on functions found in this script
def get_meta_dict(data):
    #metadata dictonary for each columns
    d_types = {col:{'dtype':' ,'.join([type for type in edaf.df_rowtypes(data,cols=[col])[col].unique()]),
                    'colclass':data[col].dtypes.type.__name__,
                    'nunique': len(list(data[col].unique())),
                    'nmissing':data[col].isnull().sum(),
                    'mode_NonNANFreq': len(data[data[col]==data[col].mode(dropna=True)[0]][col]),
                    'mode' : data[col].mode(dropna=False)[0],
                    'mode_NonNAN' : data[col].mode(dropna=True)[0],
                    'top_3_counts': edaf.percent_col_total(df=data,col=col,topn=20),
                    }for col in data.columns}
    return d_types
    
    
def text_clean(Data,textcol='Consumer complaint narrative',stop_phrases=None,stop_list=None):
    #remove consequivtly captialized letters and make them cap case and remove stop phrases (must remove stop phrases before stop words)
    #then: remove numbers -> remove stopwords & phrases-> remove excluded punct 
    Data[textcol] = Data[textcol].apply(lambda x:  ' '.join([word.title()  if (word.isupper() and word.lower() not in stop_list) else 
        word for word in ppf.remove_stopwords_string(
                ppf.remove_nonchars(
                        ppf.replace_stopphrases(
                                str(x),stop_phrases
                                ))).split()
        ]))

    return Data[textcol]


def cfpb_preproc_pt1(data):
    
    #subset data to only include observations with valid complaint narratives
    Data = data[~data['Consumer complaint narrative'].isna()].copy()
    
    if len(Data)==0:
        raise Exception("dataframe has no rows , check presence of data")
    
    #drop constant coloumns 
    Data = edaf.drop_constant_column(Data)
    
    #remove XX's from zipcodes and subset zipcode to first 3 elements
    Data['ZIP code'] = Data['ZIP code'].apply(lambda x: re.sub("[^0-9]", "",str(x))[:3])
    
    #remove sensored words (containing XXX)
    Data['Consumer complaint narrative'] = Data['Consumer complaint narrative'].apply(lambda x:  ' '.join([word for word in str(x).split() if word.count('X')<3 ]))

    #remove numeric references to dollar amounts and replace with words 
    NewCols = ['Consumer complaint narrative','Consumer_Complaint_MoneyVals','Consumer_Complaint_NumVals']
    Data[NewCols[0]],Data[NewCols[1]],Data[NewCols[2]]= zip(*Data['Consumer complaint narrative'].map(ppf.find_numerics))

    #create count columns to use in modeling 
    Data['CountUniqMoneyVals'] = Data['Consumer_Complaint_MoneyVals'].apply(lambda x: len(list(set(x))))
    Data['CountUniqNonMoneyVals'] = Data['Consumer_Complaint_NumVals'].apply(lambda x: len(list(set(x))))
    Data.drop(columns = ['Consumer_Complaint_MoneyVals','Consumer_Complaint_NumVals'],inplace=True)
    return Data

def encode_target(data,target='LegalAction'):
    le = preprocessing.LabelEncoder() 
    le.fit(data[target])
    data['label_id'] =le.transform(data[target])
    return data

def encode_target_alt(data,target='LegalAction'):
    factor = pd.factorize(data[target])
    transvals = factor[0]
    definitions = factor[1]
    
    data['label_id'] =transvals
    data = data.drop(columns = target)
    return data, definitions

        
#categoric cols 
import numpy as np
def encode_ordinal(DF,col,CatMisConst='Missing',ordered=False):
    categories = np.array(DF[col].unique())
    if any(pd.isnull(categories)):
        DF[col].fillna(CatMisConst,inplace=True)
        categories = np.array(DF[col].unique())
        #Newcol=DF[col].astype('category',categories = categories, copy=False,ordered=ordered)
        Newcol=pd.Categorical(DF[col],categories = categories,ordered=ordered)
        #Newcol = Newcol.rename_categories([str(i) for i in range(0,len(categories))])
        NewCol = pd.factorize(Newcol,sort=True)[0]
        
    else:
        categories = np.array(DF[col].unique())
        #Newcol=DF[col].astype('category',categories = categories, copy=False,ordered=ordered)
        Newcol=pd.Categorical(DF[col],categories = categories,ordered=ordered)
        #Newcol=Newcol.rename_categories([str(i) for i in range(0,len(categories))])
        NewCol = pd.factorize(Newcol,sort=True)[0]

    return NewCol

def encode_nominal(data,cols,CatMisConst = 'Missing',DropOneLevel=True):
    for col in cols:
        categories = np.array(data[col].unique())
        if any(pd.isnull(categories)):
            data[col].fillna(CatMisConst,inplace=True)
    
    #create one hot encoded dataframe
    Data = one_hot(data,cols,drop_first = DropOneLevel)
    return Data
    
    
def one_hot(df, cols,drop_first = True):
    """
    @param df pandas DataFrame
    @param cols a list of columns to encode 
    @return a DataFrame with one-hot encoding
    """
    for each in cols:
        dummies = pd.get_dummies(df[each], prefix=each+'_', drop_first=drop_first)
        df = pd.concat([df, dummies], axis=1)
    return df


#Objective: use this function to see the impact of creating dummies on a subset of levels 
#ex. if variable has 10000 levels, but only 100 have > 1 observation, we can use this to identify the levels to create dummies for
import matplotlib.pyplot as plt
def check_catlevel_counts(Data,col,start,end,step):
    Data[col].fillna('Missing',inplace=True)

    out_list = []
    for i in range(start,end,step):
        out_list.append(len(Data[Data.groupby(col)[col].transform(len) > i][col].unique()))
    plt.plot(out_list)
    return out_list



import gensim 
#get diconary of sequences and occurances of words for each string 
#input is a column containing word tokenized string (ex. ['I','am','happy'])
def get_doc2bow(Data,text_col,filter_extrms=True,low_doc_lim =10,upper_doc_perc=.4, maxterms = None):
    """
    Data : Dataframe
    text_col: str (ex. 'final_text_col') , referencing a column containing observations of word tokenized strings (first order list)
    filter_extrms: boolean (if True, each string will be filtered to only include the values captured within the filtering critera)
    low_doc_lim: int (only used if filter_extrms ==True, indicates the lowest number of documents a term must be found in to consider in output)
    upper_doc_perc: float (only used if filter_extrms==True, indicates the max percentage of documents containing a word, if p(word)>upper_doc_perc then the term is filtered out of output)
    """
    input_text = Data[text_col]
    
    #create dictonary mapping of each word in text
    id2word = gensim.corpora.Dictionary(input_text)
    
    #filter common and very rare words, and limit total words to use in final output list of strings (word tokenized list of words)
    if filter_extrms ==True:
        id2word.filter_extremes(no_below=low_doc_lim, no_above=upper_doc_perc, keep_n=maxterms)
    
        #remove gaps in id sequence after words taht were removed
        id2word.compactify()
        
    #for each document create a dictonary reporting how many times each word appears in string
    bow_corpus = [id2word.doc2bow(doc,allow_update=False) for doc in input_text]
    
    return id2word, bow_corpus















