# -*- coding: utf-8 -*-
"""
Created on Tue May 21 09:47:37 2019
CFPB DATA 
MODEL: MLP and RF 
INPUTS: TFIDF WEIGHTS FOR EACH TERM IN EACH DOC + CATEGORICAL AND NUMERICAL VARIABLES FROM SUPPORTING DATASET
CUSTOM MODULES: Negative_News2 , EDA_Funcs, PreProcess_Funcs, metrics, cfpb_funcs
@author: caridza
"""

# -*- coding: utf-8 -*-
#VirtualEnv: docclassify
#VirtualEnv Location: C:\Users\caridza\Downloads\WPy32-3662\ZacksScripts\docclassify
#######################
#######IMPORTS#########
#######################
#install tensorflow: pip3 install --upgrade https://storage.googleapis.com/tensorflow/mac/cpu/tensorflow-1.12.0-py3-none-any.whl
#base modules 
import pandas as pd
import xgboost, numpy, textblob, string, pickle, sys
from itertools import islice #iterating over vectorized objects (countvectorizer, tfidfvectorizer,etc..)
#required modules for data preprocessing and modeling
import sklearn
from sklearn import decomposition, ensemble, tree, svm,model_selection, preprocessing, linear_model, naive_bayes, metrics, svm
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer,TfidfTransformer
from sklearn.pipeline import Pipeline,make_pipeline
from sklearn.preprocessing import StandardScaler,MinMaxScaler
from sklearn.model_selection import train_test_split,GridSearchCV,cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import GradientBoostingClassifier,RandomForestClassifier,AdaBoostClassifier
from sklearn.pipeline import FeatureUnion 
from sklearn.model_selection import StratifiedKFold
from sklearn.neural_network import MLPClassifier
from sklearn.gaussian_process.kernels import RBF
from sklearn.compose import ColumnTransformer

#text parsing
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
#plotting
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
import numpy as np
import mpu
import scikitplot as skplt
import joblib
import re
import os.path 
from os import path
#custom modules 
import negative_news2
from negative_news2 import consumer
from negative_news2.consumer import utils
from negative_news2.consumer.utils  import Num2Int_Transformer, plot_cm,CatSelector,TextSelector, NumberSelector,
orig_text_clean,load_and_score,remove_punctuation,remove_stop,stem_words,remove_nonchars,pipelinize,sk_model_stats


#required for corrolation 
import scipy
import statistics
from scipy.stats.stats import pearsonr   


import sys
sys.path.insert(0, "C:\\Users\\caridza\\Desktop\\pythonScripts\\ExploratoryDataAnalysis\\")
sys.path.insert(0,"C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\Text_Preprocessing\\PreProcessFuncs\\")
sys.path.insert(0,"C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\Clustering\\ClusMetrics\\")
sys.path.insert(0,"C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\CFPB\\")
from EDA_Funcs.EDA_Functions  import drop_constant_column, df_rowtypes, percent_col_total, plot_counts, df_rowtypes,create_catmap,fillNA_convertoCat
from PreProcess_Funcs import find_numerics, generate_StopWords_Phrases, replace_stopphrases, remove_stopwords_string, remove_nonchars, incorp_phrases, lemma_wordtok_text,corp_WordFreqs
from metrics import compute_coherence_values,topic_prob_extractor
from cfpb_funcs.cfpb_helpers import cfpb_preproc_pt1,text_clean,get_doc2bow,check_catlevel_counts,encode_target_alt,encode_ordinal,encode_nominal



#load spacy using symlink created from python -m spacy download en_core_web_sm
import spacy 
nlp = spacy.load("en_core_web_sm", disable=['parser', 'ner'])

#text preprocesing
excluded_punct={'+', ':', '[', '^', '"', '|', '{', '@', '=', ')', '%', '#', '+','`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}
stopwords = stopwords.words('english')
newStopWords = ['.','?','%','Google','Wells Fargo','guggenheim partners llc','new york','guggenheim partners','bank america','wells fargos','year','thing','would','include','tuesday','make','time','state','bank','certain','country','string','perhaps','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December','from', 'subject', 're', 'edu', 'use', 'not', 'would', 'say', 'could', '_', 'be', 'know', 'good', 'go', 'get', 'do', 'done', 'try', 'many', 'some', 'nice', 'thank', 'think', 'see', 'rather', 'easy', 'easily', 'lot', 'lack', 'make', 'want', 'seem', 'run', 'need', 'even', 'right', 'line', 'even', 'also', 'may', 'take', 'come','the']
stopwords.extend(newStopWords)
stop_list=set(stopwords)

#stop words and phrases to remove    
stop_phrases=generate_StopWords_Phrases(stop_list)[1]
stop_terms= generate_StopWords_Phrases(stop_list)[0]

#####################
#Dataset Preperation#
##################### 
DATAPATH="C:\\Users\\caridza\\Desktop\\pythonScripts\\Data\\cfpb\\"
OUTPUTPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/"
PYMAGPATH = "C://Users//caridza//Downloads//crawl-300d-2M.magnitude"
filename = "cfpb_complaints.csv"

# load the dataset
data = pd.read_csv(DATAPATH+filename).copy()

#preprocessing part 1
try:
    Data = cfpb_preproc_pt1(data)
except Exception as e:
    print(e.args)

#data mapping variable level(THIS IS DONE MANUALLY)
#defines what variables from original data set will be used, as well as the data type we want to process them by 
#create dic of catvars with mapping to ordinal or nominal 
cat_dict = {}
cat_dict['Product']={'type':'nominal','use':'target'}
cat_dict['Sub-product']={'type':'nominal','use':'no'}
cat_dict['Issue']={'type':'nominal','use':'yes'}
cat_dict['Sub-issue']={'type':'nominal','use':'no'}
cat_dict['Company public response']={'type':'nominal','use':'yes'}
cat_dict['Company']={'type':'nominal','use':'no'}
cat_dict['State']={'type':'nominal','use':'yes'}
cat_dict['ZIP code']={'type':'nominal','use':'yes'}
cat_dict['Tags']={'type':'nominal','use':'yes'}
cat_dict['Consumer consent provided?']={'type':'nominal','use':'yes'}
cat_dict['submitted via']={'type':'nominal','use':'yes'}
cat_dict['Date sent to company']={'type':'ordinal','use':'yes'}
cat_dict['Date received']={'type':'ordinal','use':'yes'}
cat_dict['Company response to consumer']={'type':'nominal','use':'yes'}
cat_dict['Timely response?']={'type':'ordinal','use':'yes'}
cat_dict['Consumer disputed?']={'type':'ordinal','use':'yes'}

#encode target 
Data ,targDefs= encode_target_alt(Data,target='Product')

#encode oridinal 
ordinals= [key for key in cat_dict.keys() if (cat_dict[key]['type']=='ordinal' and key in Data and cat_dict[key]['use']=='yes')]
for col in ordinals: 
    Data[col+'_id']= encode_ordinal(Data,col,CatMisConst='Missing',ordered=True)

#encode nomoinal variables as onehotencoded 
#[(x,len(Data[x].unique())) for x in nominals ]
nominals= [key for key in cat_dict.keys() if (cat_dict[key]['type']=='nominal' and key in Data and cat_dict[key]['use']=='yes')]
Data = encode_nominal(Data,nominals)

#clean text 
Data['Consumer complaint narrative']= text_clean(Data,textcol='Consumer complaint narrative',stop_phrases=stop_phrases)

#subset dataframe to only include rows with at least 10 words
mask = (Data['Consumer complaint narrative'].str.len()>20)
Data = Data.loc[mask]

#build phrases into corpus 
Data['Consumer complaint narrative']  = incorp_phrases(Data['Consumer complaint narrative'], stop_words=stop_list)

#lemmatize all words in strings 
Data['Consumer complaint narrative']  = Data['Consumer complaint narrative'].apply(lambda x: lemma_wordtok_text(x,allowed_postags='(NN)',min_length=3))
Data.dropna(subset=['Consumer complaint narrative'],inplace=True)

#create doc2bow and id2word mapping 
id2word,bow_corpus = get_doc2bow(Data,'Consumer complaint narrative',filter_extrms=True,low_doc_lim =10,upper_doc_perc=.4, maxterms = None)

#if filtering is applied subset original texts to only include the words present after filtering 
#new subset vocab
vocab= list(set([item for sublist in [[id2word[key[0]] for key in bow_corpus[i]] for i in range(0,len(Data))] for item in sublist]))
texts = [[word for word in doc if word in vocab]for doc in Data['Consumer complaint narrative']]
Data['final_complaint_text']=texts

#tfidf requies inputs to be string not word tokens, so we join the tokens into a string
Data['final_complaint_string']= Data['final_complaint_text'].apply(lambda x: ' '.join([term for term in x]))
Data.drop(columns = ['final_complaint_text','Consumer complaint narrative'])

#must rename columns to remove _ for sklearn pipelines
Data = Data.rename(columns={col:col.replace('_','') for col in list(Data)})

#create final id2word, bow_corpus mapping with filtered corpus
id2word,bow_corpus = get_doc2bow(Data,'finalcomplainttext',filter_extrms=False)

#save file after all preprocessing 
if path.exists(DATAPATH+'cfpb_postbowfilter.pickle')==False:
    pd.to_pickle(Data,DATAPATH+'cfpb_postbowfilter.pickle')


#SKLEARN PIPELINE START
#categorical and numerical columns in dataframe 
target = 'labelid'
#columns to remove (associated wiht original columns that were conveted to onehot or oridinals , oridinal cols now come with suffix _index these will not be dropped)
colsrm = [col.replace('_','') for col in nominals]+ [col.replace('_','') for col in ordinals] + ['Complaint ID']+['finalcomplaintstring']+['finalcomplainttext']+['ConsumerComplaintMoneyVals']+['ConsumerComplaintNumVals']+['Consumer complaint narrative']

#numeric features we want to use in conjunction with text features (the tfidf features)
numeric_features = list(set(list(Data)) - set(colsrm)- set([target]) - set(list(cat_dict.keys())))

#text columns we are using to generate tfidf features
text_col = 'finalcomplaintstring'

#pipeline for processing text columns
text_transformer = Pipeline(steps=[('tfidf',  TfidfVectorizer(analyzer='word', ngram_range=(1,1), max_features=40000,min_df=.01
                                                       ,max_df=.8, smooth_idf=True, norm='l2',sublinear_tf=True,lowercase=True,))])
    

#pipeline to incorporate all other numeric columns we want to consider from original input dataset 
#note: a custom transformer class is used for Num2Int_Transformer
num_transformer= Pipeline(steps=[('imputer', sklearn.impute.SimpleImputer(strategy='constant',fill_value=np.nan)),
                                 ('toint', Num2Int_Transformer(int))
                                 ])
    
#leveraging column transformer to incorporate the text features and the numeric features 
#THIS IS VERY SIMILAR TO FEATURE UNION 
preprocessor = ColumnTransformer(
        transformers = [
                ('text',text_transformer,text_col),
                ('num',num_transformer, numeric_features)])

#define final pipeline
#to leverage oversampling we must use the pipeline class from imblearn
import imblearn
from imblearn.pipeline import Pipeline
from imblearn.over_sampling import RandomOverSampler

clf = Pipeline(steps=[('preprocessor',preprocessor),
                      
                      ('oversamp',RandomOverSampler()),
                      ('rf',RandomForestClassifier(n_estimators=100,oob_score=True,max_depth=21,n_jobs=10))])

#split data and create dictonary 
train_x,valid_x,train_y,valid_y= model_selection.train_test_split(Data,
                                                                  Data['labelid'],
                                                                  shuffle=True,
                                                                  stratify=Data['labelid'],
                                                                  test_size=.2,
                                                                  random_state=10)

#fit model 
clf.fit(train_x,train_y)
print("model score: %.3f" % clf.score(valid_x, valid_y))

#performance eval 
plot_cm(train_x,train_y,clf,targDefs)
print_classification_report(in_x,in_y,clf)



#save model to file 
import joblib
filename = 'C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/CFPB/models/cfpb_RF_Product.sav'
joblib.dump(clf, filename)









































# Fit the grid search objects
print('Performing model optimizations.d..')
best_acc = 0.0
best_clf = 0
best_gs = ''
for key, value in model_dic.items():
	print('\nEstimator: %s' % model_dic[key])		
	value.fit(train_x, train_y)
	# Best params
	print('Best params: %s' % gs.best_params_)
	# Best training data accuracy
	print('Best training accuracy: %.3f' % gs.best_score_)
	# Predict on test data with best params
	y_pred = gs.predict(valid_x)
	# Test data accuracy of model with best params
	print('Test set accuracy score for best params: %.3f ' % accuracy_score(valid_y, y_pred))
	# Track best (highest test accuracy) model
	if accuracy_score(valid_y, y_pred) > best_acc:
		best_acc = accuracy_score(valid_y, y_pred)
		best_gs = gs
		best_clf = idx
print('\nClassifier with best test set accuracy: %s' % grid_dict[best_clf])



#apply feature pipeline and then apply models 
pipe_rf = Pipeline([('features',feats),
                    #('svm', sklearn.decomposition.TruncatedSVD(n_components=100,random_state=42)),
                    #('clf', RandomForestClassifier(n_estimators=1000,oob_score=True
                    #                               ,min_samples_split=20,max_depth=10
                    #                               ,class_weight='balanced_subsample'
                    #                               ,max_features=100,n_jobs=4))
                    # 
                    
                    ('feature_selection', SelectFromModel(ExtraTreesClassifier(n_estimators=400,n_jobs=6))),
                   #('feature_selection', RFECV(RandomForestClassifier(),cv = StratifiedKFold(5),scoring='f1_weighted')),
                    #('feature_selection', SelectFromModel(LinearSVC(loss='l2',penalty="l1",dual=False),threshold='mean')), 
                    ('clf', LogisticRegression(random_state=42,max_iter=10000))])

#view all attributes that can be tuned andlist of all scoring metrics that can be used
pipe_rf.get_params().keys()
sorted(sklearn.metrics.SCORERS.keys())

#logistic hyper parameters
hyperparameters = [{'feature_selection__max_features':[100,200],
                    'clf__solver':['newton-cg','saga'],
                    'clf__penalty': ['l2'],
                    'clf__C': [1.0, 0.5, 0.1],               #Inverse of regularization strength; smaller values specify stronger regularization
                    'clf__class_weight':['balanced']         #“balanced” mode uses the values of y to automatically adjust weights inversely proportional to class frequencies in the input data as n_samples / (n_classes * np.bincount(y)).
                    }] 


clf = GridSearchCV(pipe_rf, hyperparameters, cv=3, scoring='balanced_accuracy', refit=True, verbose=5)#,n_jobs=jobs)
#clfr = RandomizedSearchCV(pipe_rf, hyperparameters, cv=5, n_iter =20,scoring='balanced_accuracy',n_jobs=3)
  
#split data 
train_x,valid_x,train_y,valid_y= model_selection.train_test_split(trainDF[features],trainDF[target],shuffle=True, stratify=trainDF[target],test_size=.2, random_state=10)

#train model with no gridsearch
pipe_rf.fit(train_x, train_y)

#train model with gridsearch 
clf.fit(train_x,train_y)
best_model=clf.best_estimator_

#train preds
train_preds= get_preds(best_model,train_x,train_y,return_preds=True)
train_stats =get_preds(best_model,train_x,train_y,return_preds=False)
print(metrics.classification_report(train_y,train_preds))


train_preds = pipe_rf.predict(train_x)
train_pred_probs = pipe_rf.predict_proba(train_x)
plotmetrics(train_y,train_pred_probs,train_preds)
print('Avg Accuracy:',np.mean(train_preds == valid_y),'\n'
,'min Accuracy:',np.min(train_preds == valid_y),'\n'
,'max Accuracy:',np.max(train_preds == valid_y),'\n'
,'std Accuracy:',np.std(train_preds == valid_y))



#valid preds
def get_preds(model_pipe,x,y,return_preds=True):
    preds = model_pipe.predict(x)
    pred_probs = model_pipe.predict_proba(x)
    
    #accuracy_dic
    accuracy_stats={'avg_Accuracy':np.mean(preds == y)
    ,'min_Accuracy':np.min(preds == y)
    ,'max_Accuracy':np.max(preds == y)
    ,'std_Accuracy':np.std(preds == y)
    }
    
    print((k,v) for k,v in accuracy_stats.items())
    if return_preds==True:
        return preds
    else: 
        plotmetrics(y,pred_probs,preds)
        return accuracy_stats


            
print('Avg Accuracy:',np.mean(preds == valid_y),'\n',
,'std Accuracy:',np.std(preds == valid_y))


cf = metrics.confusion_matrix(valid_y, valid_preds)
filename = 'C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/DocumentClassificationMethods/FinalModel/NN_Logistic.sav'
joblib.dump(pipe_rf, filename)
    

#test 
pipe_rf.get_params

len(pipe_rf.named_steps['clf'].coef_[0])
dir(pipe_rf.named_steps['clf'].get_params)
print(pipe_rf.summary())















#create tf-idf for entire dataframe
tfidf = TfidfVectorizer(sublinear_tf=True, min_df=.05,max_df=.8, norm='l2',ngram_range=(1, 2), stop_words='english')
features = tfidf.fit_transform(trainDF.text).toarray()
labels = trainDF.label_id

#identify terms most corrolated with each target level 
from sklearn.feature_selection import chi2
import numpy as np

N = 10
for label, label_id in sorted(label_to_id.items()):
    print(label)
    features_chi2 = chi2(features, labels == label_id)
    indices = np.argsort(features_chi2[label_id])
    chi2vals =np.array(features_chi2[label_id])[indices]
    feature_names = np.array(tfidf.get_feature_names())[indices]
    
    if ('chi2df' not in locals() and 'chi2df' not in globals()):
        chi2df = pd.DataFrame(list(zip(indices,feature_names,chi2vals)))
        chi2df['label_id']=label_id
    else: 
        df = pd.DataFrame(list(zip(indices,feature_names,chi2vals)))
        chi2df.append(df)


#build training tfidf representaiton for modeling 
count_vect = CountVectorizer()
X_train_counts = count_vect.fit_transform(train_x)
tfidf_transformer = TfidfTransformer()
X_train_tfidf = tfidf_transformer.fit_transform(X_train_counts)

#models to evaluate 
models = [
    RandomForestClassifier(n_estimators=200, max_depth=3, random_state=0),
    LinearSVC(),
    MultinomialNB(),
    LogisticRegression(random_state=0),
]

#cross validation metrics setup 
CV = 5
cv_df = pd.DataFrame(index=range(CV * len(models)))
entries = []
for model in models:
  model_name = model.__class__.__name__
  accuracies = cross_val_score(model, features, labels, scoring='balanced_accuracy', cv=CV)
  for fold_idx, accuracy in enumerate(accuracies):
    entries.append((model_name, fold_idx, accuracy))
cv_df = pd.DataFrame(entries, columns=['model_name', 'fold_idx', 'accuracy'])

#plot cv 
import seaborn as sns
sns.boxplot(x='model_name', y='accuracy', data=cv_df)
sns.stripplot(x='model_name', y='accuracy', data=cv_df, 
              size=8, jitter=True, edgecolor="gray", linewidth=2)
plt.show()

cv_df.groupby('model_name').accuracy.mean()



# Utility function to report best scores
def report(results, n_top=3):
    for i in range(1, n_top + 1):
        candidates = np.flatnonzero(results['rank_test_score'] == i)
        for candidate in candidates:
            print("Model with rank: {0}".format(i))
            print("Mean validation score: {0:.3f} (std: {1:.3f})".format(
                  results['mean_test_score'][candidate],
                  results['std_test_score'][candidate]))
            print("Parameters: {0}".format(results['params'][candidate]))
            print("")






















#logistic pipeline with preprocessed data(score new data:log_pipe.score(valid_x,valid_y))
pipe_log = Pipeline([('tfidf_vec', TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=4000, smooth_idf=True, sublinear_tf=False,lowercase=True,)),('log',  linear_model.LogisticRegression())])
pipe_log.steps #view all steps in above pipeline 
vars(pipe_log.named_steps['log'])
model_perf_dict = model_eval(pipe_log, train_x,train_y,valid_x,valid_y)

  

#knn pipeline 
pipe_knn = KNN_TFIDF_Classifer(train_x,train_y,valid_x,valid_y)
knn_perf_dict = model_eval(pipe_knn, train_x,train_y,valid_x,valid_y)

  
#dt pipeline 
#pipe_dt = DT_TFIDF_Classifer(train_x,train_y,valid_x,valid_y)
pipe_dt = generic_pipeline(train_x,train_y,valid_x,valid_y 
                 ,TfidfVectorizer
                 , tree.DecisionTreeClassifier
                 ,{'analyzer':'word', 'token_pattern':r'\w{1,}', 'max_features':5000, 'smooth_idf':True, 'sublinear_tf':False,'lowercase':True}
                 ,{'random_state':42})
dt_perf_dict = model_eval(pipe_dt, train_x,train_y,valid_x,valid_y)

#rf pipeline 
pipe_rf = generic_pipeline(train_x,train_y,valid_x,valid_y 
                 ,TfidfVectorizer
                 ,RandomForestClassifier
                 ,{'analyzer':'word', 'token_pattern':r'\w{1,}', 'max_features':5000, 'smooth_idf':True, 'sublinear_tf':False,'lowercase':True}
                 #,{'n_estimators':100, 'criterion':'gini','max_depth':20,'min_samples_split':20,'min_samples_leaf':5,'max_features':10})
                 ,{'n_estimators':100, 'criterion':'gini'})
rf_perf_dict = model_eval(pipe_rf, train_x,train_y,valid_x,valid_y)

#mlp pipeline 
pipe_mlp = generic_pipeline(train_x,train_y,valid_x,valid_y 
                 ,TfidfVectorizer
                 ,MLPClassifier
                 ,{'analyzer':'word', 'token_pattern':r'\w{1,}', 'max_features':5000, 'smooth_idf':True, 'sublinear_tf':False,'lowercase':True}
                 ,{'hidden_layer_sizes':(10,), 'activation':'relu','solver':'adam','learning_rate':'constant','shuffle':True})
mlp_perf_dict = model_eval(pipe_mlp, train_x,train_y,valid_x,valid_y)

#evalute models 
#create dictonary to store the name of pipelines in dictonary to be used to display results 
pipe_dic = {0: 'logistic', 1: 'knn', 2:'DT', 3:'RF',4:'mlp'}

#list the four pipelines to execute those pipelines iterativelly
pipelines = [pipe_log,pipe_knn, pipe_dt,pipe_rf,pipe_mlp]

# Fit the pipelines
for pipe in pipelines:
  pipe.fit(train_x, train_y)

# Compare accuracies
for idx, val in enumerate(pipelines):
  print('%s pipeline test accuracy: %.3f' % (pipe_dic[idx], val.score(valid_x, valid_y)))
  
#extract and print infomration on the best model 
best_accuracy = 0
best_classifier = 0
best_pipeline = ''
for idx, val in enumerate(pipelines):
    if val.score(train_x, train_y) > best_accuracy:
        best_accuracy = val.score(valid_x, valid_y)
        best_pipeline = val
        best_classifier = idx
print('%s Classifier has the best accuracy of %.2f' % (pipe_dic[best_classifier],best_accuracy))

#######SAVING MODEL AND LOADING MODEL FOR LATER USE#######
#NOTE: Generate requirements.txt when exporting model so you can replicate the requirments needed to run the saved model 
#save best model to pickle for use on future data 
filename = 'nn_finalmodel.sav'
pickle.dump(pip_log, open(filename,'wb'))

#load pickled model for evaluation on unseen data 
loaded_model = pickle.load(open(filename,'rb'))
OOS_predictions = loaded_model.score(valid_x,valid_y)
print(OOS_predictions)

#option 2:save model using joblib(useful when algo requires a lot of parameters or store the entire dataset)
#save model 
joblib.dump(pip_log, filename)
#load model 
loaded_model = joblib.load(filename)
OOS_predictions = loaded_model.score(valid_x,valid_y)
print(OOS_predictions)

