# -*- coding: utf-8 -*-
"""
Created on Fri May 17 08:47:14 2019

@author: caridza
"""

# -*- coding: utf-8 -*-
"""
Created on Fri May 10 09:20:26 2019

@author: caridza
"""
import pandas as pd 
import gensim
from gensim.test.utils import common_corpus, common_dictionary
from gensim.utils import simple_preprocess
from gensim.models import HdpModel,CoherenceModel
import re
import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt

#load spacy using symlink created from python -m spacy download en_core_web_sm
import spacy 
nlp = spacy.load("en_core_web_sm", disable=['parser', 'ner'])

#load custom funcs
import sys
sys.path.insert(0, "C:\\Users\\caridza\\Desktop\\pythonScripts\\ExploratoryDataAnalysis\\")
sys.path.insert(0,"C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\Text_Preprocessing\\PreProcessFuncs\\")
sys.path.insert(0,"C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\Clustering\\ClusMetrics\\")
#from EDA_Funcs.EDA_Functions  import drop_constant_column, df_rowtypes, percent_col_total, plot_counts, df_rowtypes,create_catmap,fillNA_convertoCat
#from PreProcess_Funcs import find_numerics, generate_StopWords_Phrases, replace_stopphrases, remove_stopwords_string, remove_nonchars, incorp_phrases, lemma_wordtok_text,corp_WordFreqs
from metrics import compute_coherence_values,topic_prob_extractor

#input/output paths
DATAPATH="C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\Data\\NewData\\"
OUTPUTPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/"
PYMAGPATH = "C://Users//caridza//Downloads//crawl-300d-2M.magnitude"

#load pymag file 
import pymagnitude
wv=pymagnitude.Magnitude(PYMAGPATH)

#data
Data = pd.read_pickle(DATAPATH+'cfpb_finaldata2.pickle')

#NOTE: IF YOU HAVE SENTENCE TOKENIZED DATA, THEN YOU WILL NEED TO USE LIST COMPREHENSION TO GENERATE THE LIST OF SENT_VECTORS FOR EACH SENTENCE IN TEXT 
#return the avg vector for each sentence by taking the average embedding from all words in senetence 
#check if embeddings have been created, if not , create them 
if 'sent_vecs' not in Data:
    #NOTE: IF YOU HAVE SENTENCE TOKENIZED DATA, THEN YOU WILL NEED TO USE LIST COMPREHENSION TO GENERATE THE LIST OF SENT_VECTORS FOR EACH SENTENCE IN TEXT 
    #return the avg vector for each sentence by taking the average embedding from all words in senetence 
    if any(isinstance(el, list) for el in Data['final_complaint_text'].iloc[0]):
        Data['sent_vecs'] = Data.apply(lambda row: [np.nanmean(wv.query(sent_tokens),axis=0) for sent_tokens in row['final_complaint_text']],axis=1)
        #DONT NEED THIS BECUASE WE TREAT EACH FULL SEEQUENCE OF WORDS AS A STRING(EVEN THOUGH THIS IS NOT A GOOD IDEA BEUCASE UR VECTORS WILL CONTAIN MUSH)
        #return averge vector for each document /phrase by averaging the relationships from the sentence vectors 
        Data['phrase_vecs'] = Data.apply(lambda row: np.nanmean(row['sent_vecs'],axis=0),axis=1)
        
    else:
        #NO SENTENCE TOKENIZED, ALL WORDS IN SINGLE LIST PER ROW
        Data['sent_vecs'] = Data.apply(lambda row: np.nanmean(wv.query(row['final_complaint_text']),axis=0),axis=1)


#to allow vstacking you must have all elements in each array be same length(the length of the embeddings used during querying)
Data.dropna(axis=0,subset=['final_complaint_text'],inplace=True)

leng=[len(x) for x in Data['sent_vecs']]
sns.boxplot(leng)

#lookup mapping of words to index 
import gensim 
input_text=Data['final_complaint_text']
id2word = gensim.corpora.Dictionary(input_text) #Create a dictionary containing the number of times a word appears in the training set.
#id2word.filter_extremes(no_below=10, no_above=0.4, keep_n=10000) ##filter out tokens taht appear in less than 15 docs and appear no more than in 50% of all docs , keeping the 1000000 most frequent tokens 
id2word.compactify()
bow_corpus = [id2word.doc2bow(doc,allow_update=False) for doc in input_text] ##For each document we create a dictionary reporting how many words and how many times those words appear. 


###################
#####BASIC LSA#####
###################
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.pipeline import Pipeline
from sklearn.cluster import KMeans

from sklearn.mixture import GaussianMixture
from metrics import plot_gmm
import sklearn.cluster as cluster
import matplotlib.pyplot as plt
import hdbscan
from metrics import plot_clusters
import time

#data(full document strings (not word tokenized))
lsa_input = [' '.join([word for word in doc]) for doc in Data['final_complaint_text']]

# raw documents to tf-idf matrix: 
vectorizer = TfidfVectorizer(stop_words='english',  use_idf=True,  smooth_idf=True)
 
# SVD to reduce dimensionality: 
svd_model = TruncatedSVD(n_components=1000, algorithm='randomized', n_iter=10)

# pipeline of tf-idf + SVD, fit to and applied to documents:
# svd_matrix can later be used to compare documents, compare words, or compare queries with documents  
svd_transformer = Pipeline([('tfidf', vectorizer), ('svd', svd_model)])
svd_matrix = svd_transformer.fit_transform(lsa_input)

#gaussian mixture
#Covariance output dimensions are dependent on covairance type selected
targlevels = list(Data['Product'].unique())
gmm  = GaussianMixture(n_components=len(targlevels),covariance_type='diag' , reg_covar = 1e-3, n_init=100,verbose=True,verbose_interval=10,init_params ='kmeans')
plot_gmm(gmm,svd_matrix,label=True)

#kmeans optimal clusters 
from metrics import kmeans_elbowplot
kmeans_elbowplot(X=svd_matrix,max_k=20)

#all other non deep clustering methods
plot_kwds = {'alpha' : 0.25, 's' : 80, 'linewidths':0}
plot_clusters(svd_matrix, cluster.KMeans, (), {'n_clusters':4})
plot_clusters(svd_matrix, hdbscan.HDBSCAN, (), {'min_cluster_size':15,'min_samples':1})
plot_clusters(svd_matrix, cluster.AgglomerativeClustering, (), {'n_clusters':6, 'linkage':'ward'})
plot_clusters(svd_matrix, cluster.SpectralClustering, (), {'n_clusters':6})
plot_clusters(svd_matrix, cluster.MeanShift, (0.175,), {'cluster_all':False})
plot_clusters(svd_matrix, cluster.AffinityPropagation, (), {'preference':-5.0, 'damping':0.95})


#LDA 
#identify optimal number of topics by leveraging dhp which requires no specification of cluster 

#trying to use hdp to identify optimal clusters, this fails
hdp = HdpModel(bow_corpus, id2word,T=10)
hdp.get_topics().shape
hdp.show_topics()
hdptopics = hdp.show_topics(formatted=False)
alpha = hdp.hdp_to_lda()[0];
topic_prob_extractor(hdp)

#identify optimal topics to use and associated lda model by looping through coherence scores 
start = 6
limit = 14 
step = 2
model_list, coherence_values ,topics= compute_coherence_values(dictionary=id2word, corpus=bow_corpus, texts=input_text, start=start, limit=limit, step=step)
plot_coherence_values(coherence_values=coherence_values,start=start, limit = limit ,step = step )
optimal_model = [model[0] for model in zip(model_list,coherence_values) if model[1]==max(coherence_values)][0]
optimal_topics = [model[2] for model in zip(model_list,coherence_values,topics) if model[1]==max(coherence_values)][0]

#specify optimal model 
model = gensim.models.ldamulticore.LdaMulticore(bow_corpus
                                   , num_topics =14
                                   , id2word=id2word
                                   , passes=2
                                   , chunksize=10000
                                   , workers=5
                                   , per_word_topics=True
                                   , iterations=50
                                   , eval_every = 1000
                                   #, minimum_phi_value = .4 #if words per topic == True, this represents a lower bound on the term probabilities
                                   #, minimum_probability =.3 #topics with a probability lower than this threshold will be filtered out 
                                   #, offset = 1
                                   #, decay=.8 #what percentage of the previous lamnbda value is forgotten when each new document is exammped (kappa)
                                   )

#model coherence
coherencemodel = CoherenceModel(model=model, texts= Data['final_complaint_text'], dictionary=id2word, coherence='c_v')
coherencemodel.get_coherence()

#get top words associated with each topic 
from pprint import pprint
model_topics = model.show_topics(formatted=False)
pprint(model.print_topics(num_words=10))
topics = len(model_topics )

#convert lda weights into feature vectors 
train_vecs = []
for i in range(len(Data)):
    top_topics = model.get_document_topics(bow_corpus[i], minimum_probability=0.0)
    topic_vec = [top_topics[i][1] for i in range(topics)]
    #topic_vec.extend([Data.iloc[i].State]) # counts of reviews for restaurant
    topic_vec.extend([Data.iloc[i].TimelyResp__No]) # length review
    topic_vec.extend([Data.iloc[i].TimelyResp__Yes]) # length review
    topic_vec.extend([len(Data.iloc[i].final_complaint_text)]) # length review
    train_vecs.append(topic_vec)
    
    


#training classifier using lda output and additional features
#https://towardsdatascience.com/unsupervised-nlp-topic-models-as-a-supervised-learning-input-cf8ee9e5cf28
from sklearn.model_selection import KFold
from sklearn.preprocessing import StandardScaler
from sklearn import linear_model
from sklearn.metrics import f1_score
from sklearn.ensemble import RandomForestClassifier

X = np.array(train_vecs)
y = np.array(Data.Product)


kf = KFold(5, shuffle=True, random_state=42)
score=[]
for train_ind, val_ind in kf.split(X, y):
    # Assign CV IDX
    X_train, y_train = X[train_ind], y[train_ind]
    X_val, y_val = X[val_ind], y[val_ind]
    
    # Scale Data
    scaler = StandardScaler()
    X_train_scale = scaler.fit_transform(X_train)
    X_val_scale = scaler.transform(X_val)

     #SGD Modified Huber
    sgd_huber = linear_model.SGDClassifier(
        max_iter=1000,
        tol=1e-3,
        alpha=20,
        loss='modified_huber',
        class_weight='balanced'
    ).fit(X_train_scale, y_train)
    
    
    y_pred = sgd_huber.predict(X_val_scale)
    score.append(f1_score(y_val, y_pred, average='macro'))
    
    
#random forest implementation 
clf = RandomForestClassifier(n_estimators=500,oob_score=True,max_depth=20
                                               ,n_jobs=6
                                              # ,max_features=100
                                              # ,min_samples_leaf=10
                                              # ,min_samples_split=20
                                               )

model_out = clf.fit(X,y)


model_out.

###################################
##BEING DEEP EMBEDDING CLUSTERING##
###################################
#clustering module functions
sys.path.insert(0, "C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\Clustering\\ClusMetrics\\")
import metrics 
from metrics import acc, nmi,ari,ClusteringLayer,autoencoder_build,target_distribution,draw_ellipse,plot_gmm
 



#LDA2VEC
#https://github.com/ONLPS/lda2vec/blob/master/notebooks/lda2vec_model.ipynb