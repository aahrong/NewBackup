# -*- coding: utf-8 -*-
"""
Created on Fri May 10 09:20:26 2019

@author: caridza
"""
import pandas as pd 
import gensim
from gensim.test.utils import common_corpus, common_dictionary
from gensim.utils import simple_preprocess
from gensim.models import HdpModel,CoherenceModel
import re
import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk import regexp_tokenize
from nltk.tokenize import word_tokenize , sent_tokenize
excluded_punct={'+', ':', '[', '^', '"', '|', '{', '@', '=', ')', '%', '#', '+','`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}
stopwords = stopwords.words('english')
newStopWords = ['.','?','%','Google','Wells Fargo','guggenheim partners llc','new york','guggenheim partners','bank america','wells fargos','year','thing','would','include','tuesday','make','time','state','bank','certain','country','string','perhaps','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December','from', 'subject', 're', 'edu', 'use', 'not', 'would', 'say', 'could', '_', 'be', 'know', 'good', 'go', 'get', 'do', 'done', 'try', 'many', 'some', 'nice', 'thank', 'think', 'see', 'rather', 'easy', 'easily', 'lot', 'lack', 'make', 'want', 'seem', 'run', 'need', 'even', 'right', 'line', 'even', 'also', 'may', 'take', 'come','the']
stopwords.extend(newStopWords)
stop_list=set(stopwords)

#load spacy using symlink created from python -m spacy download en_core_web_sm
import spacy 
nlp = spacy.load("en_core_web_sm", disable=['parser', 'ner'])

#load custom funcs
import sys
sys.path.insert(0, "C:\\Users\\caridza\\Desktop\\pythonScripts\\ExploratoryDataAnalysis\\")
sys.path.insert(0,"C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\Text_Preprocessing\\PreProcessFuncs\\")
sys.path.insert(0,"C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\Clustering\\ClusMetrics\\")
from EDA_Funcs.EDA_Functions  import drop_constant_column, df_rowtypes, percent_col_total, plot_counts, df_rowtypes,create_catmap,fillNA_convertoCat
from PreProcess_Funcs import find_numerics, generate_StopWords_Phrases, replace_stopphrases, remove_stopwords_string, remove_nonchars, incorp_phrases, lemma_wordtok_text,corp_WordFreqs
from metrics import compute_coherence_values,topic_prob_extractor

#input/output paths
DATAPATH="C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\Data\\NewData\\"
OUTPUTPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/"
PYMAGPATH = "C://Users//caridza//Downloads//crawl-300d-2M.magnitude"


#load pymag file 
import pymagnitude
wv=pymagnitude.Magnitude(PYMAGPATH)

#stop words and phrases to remove    
stop_phrases=generate_StopWords_Phrases(stop_list)[1]
stop_terms= generate_StopWords_Phrases(stop_list)[0]

#download data from website directly (example dataset 3) and save to dataset 
import urllib
import os.path 
from os import path
directory= "C:\\Users\\caridza\\Desktop\\pythonScripts\\Data\\cfpb\\"
filename= "cfpb_complaints.csv"

if path.exists(directory+filename)==False:
    url = 'https://data.consumerfinance.gov/api/views/s6ew-h6mp/rows.csv?accessType=DOWNLOAD'
    urllib.request.urlretrieve(url,directory+filename)

#load data
data = pd.read_csv(directory+filename)

#metadata
d_types = {col:{'dtype':' ,'.join([type for type in df_rowtypes(data,cols=[col])[col].unique()]),
                'colclass':data[col].dtypes.type.__name__,
                'nunique': len(list(data[col].unique())),
                'nmissing':data[col].isnull().sum(),
                'mode_NonNANFreq': len(data[data[col]==data[col].mode(dropna=True)[0]][col]),
                'mode' : data[col].mode(dropna=False)[0],
                'mode_NonNAN' : data[col].mode(dropna=True)[0],
                'top_3_counts': percent_col_total(df=data,col=col,topn=20),
                }for col in data.columns}

#save metadata to df and plot most freq items from each column 
metadata = pd.DataFrame(d_types).T
cols_nomiss = metadata[metadata['nmissing']==0].index.values
plot_counts(metadata['top_3_counts'])


####################
#text preprocessing#
####################

#data
Data = data[~data['Consumer complaint narrative'].isna()].copy()
Data = drop_constant_column(Data)

#remove XX's from zipcodes
Data['ZIP code'] = Data['ZIP code'].apply(lambda x: re.sub("[^0-9]", "",str(x)))

#map categtorical variables to categoric indexes 
Data['Product']= fillNA_convertoCat(Data,'Product')
Data['Issue']= fillNA_convertoCat(Data,'Issue')
Data['State'] = fillNA_convertoCat(Data,'State')
Issue_map = create_catmap(Data['Issue'])
Product_map = create_catmap(Data['Product'])
state_map= create_catmap(Data['State'])

#Create dummies for sparse variables 
Data= pd.get_dummies(Data, columns=["Tags"], prefix=[ "Tag_"])
Data= pd.get_dummies(Data, columns=["Timely response?"], prefix=[ "TimelyResp_"])
Data= pd.get_dummies(Data, columns=["Company public response"], prefix=[ "Comp_Resp"])
Data= pd.get_dummies(Data, columns=["Company response to consumer"], prefix=[ "Comp_ConsResp"])


#remove sensored words (containing XXX)
Data['Consumer complaint narrative'] = Data['Consumer complaint narrative'].apply(lambda x:  ' '.join([word for word in str(x).split() if word.count('X')<3 ]))

#remove numeric references to dollar amounts and replace with words 
NewCols = ['Consumer complaint narrative','Consumer_Complaint_MoneyVals','Consumer_Complaint_NumVals']
Data[NewCols[0]],Data[NewCols[1]],Data[NewCols[2]]= zip(*Data['Consumer complaint narrative'].map(find_numerics))

#remove consequivtly captialized letters and make them cap case and remove stop phrases (must remove stop phrases before stop words)
#then: remove numbers -> remove stopwords & phrases-> remove excluded punct 
Data['Consumer complaint narrative'] = Data['Consumer complaint narrative'].apply(lambda x:  ' '.join([word.title()  if (word.isupper() and word.lower() not in stop_list) else 
                                               word for word in 
                                               remove_stopwords_string(
                                                       remove_nonchars(
                                                               replace_stopphrases(
                                                                       str(x),stop_phrases
                                                                       ))).split()
                                                               ]))

#subset dataframe to only include rows with at least 10 words
mask = (Data['Consumer complaint narrative'].str.len()>20)
Data = Data.loc[mask]

#create POS tags and lemmatize using spacys nlp lemmatizer (it uses the pos tags from nlp() to identify the correct lemmatization)
#Data['Consumer complaint narrative5'] = Data['Consumer complaint narrative4'].apply(lambda X: token.lemma_ for token in nlp(" ".join(str(X))))
Data['Consumer complaint narrative']  = incorp_phrases(Data['Consumer complaint narrative'], stop_words=stop_list)
Data['Consumer complaint narrative']  = Data['Consumer complaint narrative'].apply(lambda x: lemma_wordtok_text(x,allowed_postags='(NN)',min_length=3))

#get wordfreqs across all docs 
word_freqs=corp_WordFreqs(Data,'Consumer complaint narrative',pre_wordtokenized=True)
wordfreqdf = pd.DataFrame(word_freqs, columns=['word', 'freq'])
plt.scatter(wordfreqdf.iloc[:,1].head(10),wordfreqdf.iloc[:,0].head(10))
plt.scatter(wordfreqdf.iloc[:,1].tail(10),wordfreqdf.iloc[:,0].tail(10))
plt.show()

#plot text lengths and identify threshold for series truncation
import seaborn as sns
import scipy
txtlen=[len(x) for x in Data['Consumer complaint narrative'] if x is not None]
sns.boxplot(txtlen)

#truncate long sequences over the 3rd quartile of text length 
MAXWORDS =  int(scipy.stats.scoreatpercentile(txtlen,per=.75) + 5*scipy.stats.iqr(txtlen))
MINWORDS =  round(max(5,scipy.stats.scoreatpercentile(txtlen,per=.25) - 1.5*scipy.stats.iqr(txtlen)),0)

#truncate sequences of words to 
Data['final_complaint_text']=Data['Consumer complaint narrative'].apply(lambda row: row[:MAXWORDS] if len(row)> MINWORDS else None)
Data.dropna(subset=['final_complaint_text'],inplace=True)
sns.boxplot([len(x) for x in Data['final_complaint_text'] if x is not None])

#lookup mapping of words to index 
input_text=Data['final_complaint_text']
id2word = gensim.corpora.Dictionary(input_text) #Create a dictionary containing the number of times a word appears in the training set.
id2word.filter_extremes(no_below=10, no_above=0.4, keep_n=10000) ##filter out tokens taht appear in less than 15 docs and appear no more than in 50% of all docs , keeping the 1000000 most frequent tokens 
id2word.compactify()
bow_corpus = [id2word.doc2bow(doc,allow_update=False) for doc in input_text] ##For each document we create a dictionary reporting how many words and how many times those words appear. 

#new subset vocab
vocab= list(set([item for sublist in [[id2word[key[0]] for key in bow_corpus[i]] for i in range(0,len(input_text))] for item in sublist]))
texts = [[word for word in doc if word in vocab]for doc in input_text]

Data['final_complaint_text']=texts
#pd.to_pickle(Data,DATAPATH+'cfpb_finaldata.pickle')

#build clustering autoencoder with deep embeddings at the phrase level 
sys.path.insert(0,"C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\Clustering\\ClusMetrics\\")
from build_DeepclustEncoder import build_deep_clust_encoder
build_deep_clust_encoder(Data,'Product',16,'final_complaint_text')

###################
#####BASIC LSA#####
###################
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.pipeline import Pipeline
from sklearn.cluster import KMeans

from sklearn.mixture import GaussianMixture
from metrics import plot_gmm
import sklearn.cluster as cluster
import matplotlib.pyplot as plt
import hdbscan
from metrics import plot_clusters
import time

#data(full document strings (not word tokenized))
lsa_input = [' '.join([word for word in doc]) for doc in Data['final_complaint_text']]

# raw documents to tf-idf matrix: 
vectorizer = TfidfVectorizer(stop_words='english',  use_idf=True,  smooth_idf=True)
 
# SVD to reduce dimensionality: 
svd_model = TruncatedSVD(n_components=100, algorithm='randomized', n_iter=10)

# pipeline of tf-idf + SVD, fit to and applied to documents:
# svd_matrix can later be used to compare documents, compare words, or compare queries with documents  
svd_transformer = Pipeline([('tfidf', vectorizer), ('svd', svd_model)])
svd_matrix = svd_transformer.fit_transform(lsa_input)

#gaussian mixture
#Covariance output dimensions are dependent on covairance type selected
targlevels = list(Data['Product'].unique())
gmm  = GaussianMixture(n_components=len(targlevels),covariance_type='diag' , reg_covar = 1e-3, n_init=100,verbose=True,verbose_interval=10,init_params ='kmeans')
plot_gmm(gmm,svd_matrix,label=True)

#kmeans optimal clusters 
from metrics import kmeans_elbowplot
kmeans_elbowplot(X=svd_matrix,max_k=20)

#all other non deep clustering methods
plot_kwds = {'alpha' : 0.25, 's' : 80, 'linewidths':0}
plot_clusters(svd_matrix, cluster.KMeans, (), {'n_clusters':4})
plot_clusters(svd_matrix, hdbscan.HDBSCAN, (), {'min_cluster_size':15,'min_samples':1})
plot_clusters(svd_matrix, cluster.AgglomerativeClustering, (), {'n_clusters':6, 'linkage':'ward'})
plot_clusters(svd_matrix, cluster.SpectralClustering, (), {'n_clusters':6})
plot_clusters(svd_matrix, cluster.MeanShift, (0.175,), {'cluster_all':False})
plot_clusters(svd_matrix, cluster.AffinityPropagation, (), {'preference':-5.0, 'damping':0.95})


#LDA 
#identify optimal number of topics by leveraging dhp which requires no specification of cluster 

#trying to use hdp to identify optimal clusters, this fails
hdp = HdpModel(bow_corpus, id2word,T=10)
hdp.get_topics().shape
hdp.show_topics()
hdptopics = hdp.show_topics(formatted=False)
alpha = hdp.hdp_to_lda()[0];
topic_prob_extractor(hdp)

#identify optimal topics to use and associated lda model by looping through coherence scores 
start = 6
limit = 14 
step = 2
model_list, coherence_values ,topics= compute_coherence_values(dictionary=id2word, corpus=bow_corpus, texts=input_text, start=start, limit=limit, step=step)
plot_coherence_values(coherence_values=coherence_values,start=start, limit = limit ,step = step )
optimal_model = [model[0] for model in zip(model_list,coherence_values) if model[1]==max(coherence_values)][0]
optimal_topics = [model[2] for model in zip(model_list,coherence_values,topics) if model[1]==max(coherence_values)][0]

#specify optimal model 
model = gensim.models.ldamulticore.LdaMulticore(bow_corpus
                                   , num_topics =14
                                   , id2word=id2word
                                   , passes=30
                                   , chunksize=100
                                   , workers=10
                                   , per_word_topics=True
                                   , iterations=50
                                   , eval_every = 100
                                   #, minimum_phi_value = .4 #if words per topic == True, this represents a lower bound on the term probabilities
                                   #, minimum_probability =.3 #topics with a probability lower than this threshold will be filtered out 
                                   #, offset = 1
                                   #, decay=.8 #what percentage of the previous lamnbda value is forgotten when each new document is exammped (kappa)
                                   )

#model coherence
coherencemodel = CoherenceModel(model=model, texts= Data['final_complaint_text'], dictionary=id2word, coherence='c_v')
coherencemodel.get_coherence()

#get top words associated with each topic 
from pprint import pprint
model_topics = model.show_topics(formatted=False)
pprint(model.print_topics(num_words=10))
topics = len(model_topics )

#convert lda weights into feature vectors 
train_vecs = []
for i in range(len(Data)):
    top_topics = model.get_document_topics(bow_corpus[i], minimum_probability=0.0)
    topic_vec = [top_topics[i][1] for i in range(topics)]
    topic_vec.extend([Data.iloc[i].State]) # counts of reviews for restaurant
    topic_vec.extend([Data.iloc[i].TimelyResp__No]) # length review
    topic_vec.extend([Data.iloc[i].TimelyResp__Yes]) # length review
    topic_vec.extend([len(Data.iloc[i].final_complaint_text)]) # length review
    train_vecs.append(topic_vec)

#training classifier using lda output and additional features
#https://towardsdatascience.com/unsupervised-nlp-topic-models-as-a-supervised-learning-input-cf8ee9e5cf28
from sklearn.model_selection import KFold
from sklearn.preprocessing import StandardScaler
from sklearn import linear_model
from sklearn.metrics import f1_score

X = np.array(train_vecs)
y = np.array(Data.Product)
kf = KFold(5, shuffle=True, random_state=42)
score=[]
for train_ind, val_ind in kf.split(X, y):
    # Assign CV IDX
    X_train, y_train = X[train_ind], y[train_ind]
    X_val, y_val = X[val_ind], y[val_ind]
    
    # Scale Data
    scaler = StandardScaler()
    X_train_scale = scaler.fit_transform(X_train)
    X_val_scale = scaler.transform(X_val)

     #SGD Modified Huber
    sgd_huber = linear_model.SGDClassifier(
        max_iter=1000,
        tol=1e-3,
        alpha=20,
        loss='modified_huber',
        class_weight='balanced'
    ).fit(X_train_scale, y_train)
    
    y_pred = sgd_huber.predict(X_val_scale)
    score.append(f1_score(y_val, y_pred, average='macro'))
    
###################################
##BEING DEEP EMBEDDING CLUSTERING##
###################################
#clustering module functions
sys.path.insert(0, "C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\Clustering\\ClusMetrics\\")
import metrics 
from metrics import acc, nmi,ari,ClusteringLayer,autoencoder_build,target_distribution,draw_ellipse,plot_gmm
 

#return the avg vector for each sentence by taking the average embedding from all words in senetence 
data['sent_vecs'] = data.apply(lambda row: [np.nanmean(wv.query(sent_tokens),axis=0) for sent_tokens in row['article_tokens']],axis=1)

#return averge vector for each document /phrase by averaging the relationships from the sentence vectors 
data['phrase_vecs'] = data.apply(lambda row: np.nanmean(row['sent_vecs'],axis=0),axis=1)

#to allow vstacking you must have all elements in each array be same length(the length of the embeddings used during querying)
data.dropna(axis=0,subset=['final_complaint_text'],inplace=True)


#LDA2VEC
#https://github.com/ONLPS/lda2vec/blob/master/notebooks/lda2vec_model.ipynb