# -*- coding: utf-8 -*-
"""
Created on Wed May 22 13:43:31 2019

@author: caridza
"""

#stopwords, stemmer
import pandas as pd 
import pymagnitude
import string 
from nltk.corpus import stopwords

#makedf 
from nltk.tokenize import word_tokenize , sent_tokenize
import gensim 
from keras.preprocessing.sequence import pad_sequences 
from keras.preprocessing.text import Tokenizer 
from imblearn.over_sampling import SMOTE
from sklearn import preprocessing , model_selection, metrics
from keras import backend as K

#keras modeling
import keras
from keras.callbacks import ModelCheckpoint, EarlyStopping
from keras_self_attention import SeqSelfAttention 
from keras.callbacks import Callback

import gensim
from imblearn.over_sampling import SMOTE  # or: import RandomOverSampler
from imblearn.pipeline import Pipeline as imbPipeline
from matplotlib import pyplot
import matplotlib.pyplot as plt
import sys 

sys.path.insert(0,"C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\CFPB\\")
from cfpb_funcs.cfpb_lstm_helpers import make_df  , make_embeddings_pymag , precision, recall,fbeta_score,fmeasure

#text processing functions
exclude = set(string.punctuation)
stopwords = stopwords.words('english')
newStopWords = ['.','?','%','Google','Wells Fargo','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December']
stopwords.extend(newStopWords)
stop_list=set(stopwords)


DATAPATH="C:\\Users\\caridza\\Desktop\\pythonScripts\\Data\\cfpb\\"
OUTPUTPATH = "C://Users//caridza//Desktop//pythonScripts//NLP//Zacks_NLP_Stuff//"
PYMAGPATH = "C://Users//caridza//Downloads//crawl-300d-2M.magnitude"
MODELPATH = "C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\CFPB\\Models\\"

#inputs requiring path specification
max_features = 100000 #maximum number of words to consider in analysis 
EMBEDDING_DIM = 300 #NOTE: becuase we use pymag this must be set to 300 
stop_list = stop_list
target = 'label_id'
textcol = 'final_complaint_string'

#embeddings
wv=pymagnitude.Magnitude(PYMAGPATH)

#read in preprocessed cfpb dataset 
Data = pd.read_pickle(DATAPATH + 'cfpb_complaints_generaluse.pickle')

Data['final_complaint_string']= Data['Consumer complaint narrative'].apply(lambda x: ' '.join([term for term in x]))
Data.drop(columns = ['Consumer complaint narrative'])


#create sequences 
xtr,ytr,xte,yte,word_index, maxlen,words = make_df(Data , max_features,EMBEDDING_DIM,stop_list,target,rebalance_data=False,test_size=.2,textcol=textcol)


#######################################################
##############BEGIN MODEL DEVELOPMENT##################
#######################################################
#GENERATE EMBEDDING MATRIX FOR EMBEDDING LAYER IN MODEL(using pymagnitude converted vectors)
nb_words = min(max_features, len(word_index)+1) #total features to consider, min of the max feats vs total feats 
embedding_vector =  make_embeddings_pymag(wv, max_features,words, word_index, EMBEDDING_DIM, nb_words)


#BEGIN MODEL LAYER DEFFINITIONS 
#Initialize Sequential Model class  
model=keras.models.Sequential()

#add embedding layer
model.add(keras.layers.Embedding(input_dim = nb_words #max_features
                                 , output_dim= EMBEDDING_DIM #embedding size 
                                 , weights = [embedding_vector]
                                 , mask_zero=False
                                 #, trainable=False  #if True transfer learning is enabled, the weights from the past epoch are used as starting points for the next epoch
                                 , input_length = maxlen #the max sequence length, this is the length that all sequences will be padded to (so all sequences will have same length)
                                 ))

#ADD CNN LAYER WITH SELU ACTIVATION AND GAUSSIAN DROPOUT  
#NOTE:specify guassian dropout befire activation function has been specified
#WARNING: if you specify guassian dropout after activation function  the resulting values may be out-of-range 
#from what the activation function may normally provide. For example, a value with added noise may be less than zero,
#whereas the relu activation function will only ever output values 0 or larger.  
model.add(keras.layers.Conv1D(filters=164, kernel_size=10,padding='valid' ,strides=1))
model.add(keras.layers.MaxPooling1D(pool_size=4))
model.add(keras.layers.GaussianDropout(0.7))
model.add(keras.layers.Activation('selu'))

#ADD BILSTM WITH DROPOUT 
model.add(keras.layers.Bidirectional(keras.layers.LSTM(units = 400, 
                                                       return_sequences=True,
                                                       #dropout=.3, #dropout not applied here becase we apply it via the guassian dropout specificed below
                                                       recurrent_dropout=.7,
                                                       recurrent_regularizer=keras.regularizers.L1L2(l1=0.0, l2=0.01),
                                                       kernel_regularizer = keras.regularizers.L1L2(l1=0,l2=.01),
                                                       bias_regularizer = keras.regularizers.L1L2(l1=0,l2=.01),
                                                       )))
#ADD NON RECURRENT DROPUT TO LSTM 
model.add(keras.layers.GaussianDropout(0.7))
model.add(keras.layers.Activation('selu'))

#SELF ATTENTION LAYER 
model.add(SeqSelfAttention(
                        attention_width=15,
                        attention_type=SeqSelfAttention.ATTENTION_TYPE_MUL,
                        attention_activation=None,
                        kernel_regularizer=keras.regularizers.L1L2(1e-6),
                        bias_regularizer=keras.regularizers.l1(1e-4),
                        use_attention_bias=True,    
                        attention_regularizer_weight=1e-4,
                        name='Attention',))

#FLATTENED LAYER (CONVERTS 2D tensor to 1D)
#model.add(GlobalMaxPool1D())
model.add(keras.layers.Flatten())

#OUTPUT LAYER(units = # target labels, for binary this =1)
model.add(keras.layers.Dense(units =18,activation='softmax'))

#COMPILE MODEL WITH CUSTOM KERAS METRICS (functions defined at top of script)
model.compile(optimizer='adam',loss = 'sparse_categorical_crossentropy',metrics =['accuracy',recall,fmeasure,precision,fbeta_score] )

#SPECIFY KERAS CALLBACKS 
filepath = MODELPATH+"best_bilstm.hdf5"
monitor = 'val_fmeasure'
min_max_metric = 'max'
ckpt = ModelCheckpoint(filepath, monitor=monitor , verbose=1, save_best_only=True, save_weights_only=False, mode=min_max_metric)
early = EarlyStopping(monitor=monitor , mode=min_max_metric, patience=10)

#FIT MODEL 
model_out = model.fit(xtr, ytr, batch_size=200, epochs=50
                      , validation_data = (xte,yte)
                      #, class_weight=ClassWeights
                      , callbacks=[ckpt, early])


#EVALUATE MODEL FIT 
y_preds = model.predict_classes(xte)
matrix = metrics.confusion_matrix(yte, y_preds)
scores = model.evaluate(xte, yte, verbose=0)
print(matrix)
print(scores)



























