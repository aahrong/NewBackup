# -*- coding: utf-8 -*-
"""
Created on Wed May  8 11:35:23 2019
PreProcess_Funcs
@author: caridza
"""
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize , sent_tokenize
import spacy
import pandas as pd 
from pprint import pprint
import gensim
from gensim import corpora, models
from gensim.utils import simple_preprocess
from gensim.parsing.preprocessing import STOPWORDS
from nltk.stem import WordNetLemmatizer, SnowballStemmer
from nltk.stem.porter import *
import numpy as np
import string
import nltk
from gensim.models import CoherenceModel
import re 
import gensim, logging, warnings

from gensim.utils import lemmatize
import operator 

#load spacy using symlink created from python -m spacy download en_core_web_sm
nlp = spacy.load("en_core_web_sm", disable=['parser', 'ner'])

excluded_punct={'+', ':', '[', '^', '"', '|', '{', '@', '=', ')', '%', '#', '+','`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}
stopwords = stopwords.words('english')
newStopWords = ['.','?','%','Google','Wells Fargo','guggenheim partners llc','new york','guggenheim partners','bank america','wells fargos','year','thing','would','include','tuesday','make','time','state','bank','certain','country','string','perhaps','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December','from', 'subject', 're', 'edu', 'use', 'not', 'would', 'say', 'could', '_', 'be', 'know', 'good', 'go', 'get', 'do', 'done', 'try', 'many', 'some', 'nice', 'thank', 'think', 'see', 'rather', 'easy', 'easily', 'lot', 'lack', 'make', 'want', 'seem', 'run', 'need', 'even', 'right', 'line', 'even', 'also', 'may', 'take', 'come','the']
stopwords.extend(newStopWords)
stop_list=set(stopwords)

#word tokenize and remove punctuation (deacc=True)
#gensim simple_preprocessing word toekenizes and removes punctiouation from each sentence 
def sent_to_words(sentences):
    for sentence in sentences:
        yield(gensim.utils.simple_preprocess(str(sentence), deacc=True))
        


def generate_StopWords_Phrases(stop_list):
    stop_terms = []
    stop_phrases = []
    for item in list(stop_list): 
        if len(item.split())==1:
            stop_terms.append(item.lower())
        if len(item.split())>1:
            stop_phrases.append(' '.join([word.lower() for word in item.split()]))
    return stop_terms, stop_phrases

def replace_stopphrases(doc,phrases):
    for item in phrases:
        if item in doc.lower():
            print(item)
            doc = doc.lower().replace(item,'')
    return doc

# Define functions for stopwords, bigrams, trigrams and lemmatization
def remove_stopwords(texts,stop_words = stop_list):
    return [[word for word in simple_preprocess(str(doc)) if word not in stop_words] for doc in texts]

def remove_stopwords_string(text,stop_words = stop_list,min_len=2):
    return ' '.join([word for word in simple_preprocess(str(text)) if word not in stop_words and len(word)>min_len])

#lemmaitize test with spacy nlp parser 
def lemmatization(texts, allowed_postags=['NOUN', 'ADJ', 'VERB', 'ADV']):
    """https://spacy.io/api/annotation"""
    texts_out = []
    for sent in texts:
        doc = nlp(" ".join(sent)) 
        texts_out.append([token.lemma_ for token in doc if token.pos_ in allowed_postags])
    return texts_out


#func to remove punc from string and return string
def remove_punctuation_char(word,excluded_punct={'+','—','-', ':', '[', '^', '"', '|', '{', '@', '=', ')','“','”' ,'%', '#', '`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}):
     return ''.join([char for char in word if char not in excluded_punct])
     #return ''.join([''.join([char for char in word if char not in excluded_punct]) for word in text if word not in excluded_punct])

#remove non alpha characters from text 
def remove_nonchars(text):
    return ' '.join([re.sub('[^A-Za-z|^\$|^\.]+', ' ', word) for word in text.split(' ') if (word.isalnum() and len(word)>2)])


#func to remove punc from string and return string
def remove_punctuation_words(text,excluded_punct={'+','—','-', ':', '[', '^', '"', '|', '{', '@', '=', ')','“','”' ,'%', '#', '`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}):
     return ''.join([word for word in text if word not in excluded_punct])
     #return ''.join([''.join([char for char in word if char not in excluded_punct]) for word in text if word not in excluded_punct])


#SOLUTION TO GET START ANE END POSITION OF SRING BETWeEN "{" and "}"
#STRING TO REPLACE(CAPTURES SPECIAL CHARS):myString[pos2replace[i][0]:pos2replace[i][1]]
#NEW STRING: n2w.convert(remove_punctuation_char(myString[pos2replace[i][0]+1:pos2replace[i][1]-1]))
#output: (sentence with no numerics, all $ numerics, all other numerics)
def find_numerics(sent,start_pat="{",end_pat="}"):
    
    sent = sent
    strings = []
    dollars = []
    numbers = []
    #identify initial set of ALL matches
    pos2replace = [(m.start(0),n.start(0)+1) for m,n in zip(re.finditer(start_pat,sent),re.finditer(end_pat,sent))]
    
    #append all strings found 
    if len(pos2replace)>0:
      for i in range(0,len(pos2replace)):
          strings.append(sent[pos2replace[i][0]:pos2replace[i][1]])
    
    #extract dollars and general numbers
    for val in strings:
        if val.find("$")>0:
            dollars.append(val.replace("$","").replace(start_pat,"").replace(end_pat,""))
        else:
            numbers.append(val.replace(start_pat,"").replace(end_pat,""))
 
        sent = re.sub(' +',' ',sent.replace(val,"")) #replace multiple spaces with single sapce 
        
    return sent, dollars,numbers

#    return sent, '||'.join(dollars),'||'.join(numbers)
   
    


def process_words(texts, stop_words=None, allowed_postags=['NOUN', 'ADJ', 'VERB', 'ADV'],nlp=None):
    
    #PROCESSING ON CONGLOMORATE OF ALL TEXTS
    """generate bi and tri grams from ALL TEXTS"""
    bigram = gensim.models.Phrases(texts, min_count=4, threshold=100)
    trigram = gensim.models.Phrases(bigram[texts],threshold=100)
    bigram_mod = gensim.models.phrases.Phraser(bigram)
    trigram_mod = gensim.models.phrases.Phraser(trigram)
    
    #DOCUMENT LEVEL PROCESSING
    """Remove Stopwords, Form Bigrams, Trigrams and Lemmatization"""
    texts = [[word for word in simple_preprocess(str(doc), deacc=True) if word not in stop_words] for doc in texts]
    texts = [bigram_mod[doc] for doc in texts]
    #texts = [trigram_mod[bigram_mod[doc]] for doc in texts]
    texts_out = []
    
    for sent in texts:
        doc = nlp(" ".join(sent)) 
        texts_out.append([token.lemma_ for token in doc if token.pos_ in allowed_postags])
        
    # remove stopwords once more after lemmatization
    texts_out = [[word for word in simple_preprocess(str(doc)) if word not in stop_words] for doc in texts_out]    
    return texts_out


def make_bigrams(texts):
    return [bigram_mod[doc] for doc in texts]

def make_trigrams(texts):
    return [trigram_mod[bigram_mod[doc]] for doc in texts]

# Function takes a tokenized sentence and returns the words
def sequence_to_text(list_of_indices):
    # Looking up words in dictionary
    words = [reverse_word_map.get(letter) for letter in list_of_indices]
    return(words)


def incorp_phrases(texts, stop_words=stop_list):
    """Remove Stopwords, Form Bigrams, Trigrams and Lemmatization"""
    texts = [[word for word in simple_preprocess(str(doc), deacc=True) if word not in stop_words] for doc in texts]
    
    """generate bi and tri grams"""
    bigram = gensim.models.Phrases(texts, min_count=10, threshold=10)
    trigram = gensim.models.Phrases(bigram[texts],threshold=30)
    bigram_mod = gensim.models.phrases.Phraser(bigram)
    trigram_mod = gensim.models.phrases.Phraser(trigram)


    texts = [bigram_mod[doc] for doc in texts]
    texts = [trigram_mod[bigram_mod[doc]] for doc in texts]
    return texts

def lemma_text(text,nlp=None, allowed_postags=['NOUN', 'ADJ', 'VERB', 'ADV'],stop_words=stop_list):
    
    doc = nlp(" ".join(text)) 
    lemma_text = [token.lemma_ for token in doc if token.pos_ in allowed_postags]
        
    # remove stopwords once more after lemmatization
    text_out = [word for word in simple_preprocess(str(lemma_text)) if word not in stop_words]
    return text_out

def lemma_wordtok_text(word_toks,allowed_postags='(NN)',min_length=3):
    textin =' '.join([word for word in word_toks])
    text = [word.decode('utf-8').split('/')[0] for word in lemmatize(textin, allowed_tags=re.compile(allowed_postags),min_length=min_length)]
    return text


#return word freq dictonary containing total number of times each word is used across all documents
def corp_WordFreqs(Data , text_col,pre_wordtokenized = True):
    wordfreq = {}
    
    
    input_text =  text_col
    
    if pre_wordtokenized == True:
        texts = Data[input_text].apply(lambda x:  ' '.join([word for word in x]))
    else:
        texts = Data[input_text]
    
    
    text = ''.join([text for text in texts])
    
    for raw_word in text.split():
        word = raw_word.strip()
        if word not in wordfreq:
            wordfreq[word] = 0 
        wordfreq[word] += 1

    sorted_x = sorted(wordfreq.items(), key=operator.itemgetter(1),reverse=True)
    return sorted_x
