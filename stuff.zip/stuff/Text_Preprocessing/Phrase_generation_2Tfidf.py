# -*- coding: utf-8 -*-


#VirtualEnv: docclassify
#VirtualEnv Location: C:\Users\caridza\Downloads\WPy32-3662\ZacksScripts\docclassify
#######################
#######IMPORTS#########
#######################
import pandas as pd
import string
import xgboost, numpy, textblob, string, pickle, sys
from itertools import islice #iterating over vectorized objects (countvectorizer, tfidfvectorizer,etc..)
import sklearn
from sklearn import decomposition, ensemble, tree, svm,model_selection, preprocessing, linear_model, naive_bayes, metrics, svm

#text parsing
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer
from collections import Counter
import numpy as np
import mpu
import scikitplot as skplt
import joblib
import re

#custom modules 
import negative_news2
from negative_news2 import consumer
from negative_news2.consumer import utils
from negative_news2.consumer.utils  import TextSelector, NumberSelector,orig_text_clean,load_and_score,remove_punctuation,remove_stop,stem_words,remove_nonchars,pipelinize,sk_model_stats

#phrase generation 
from gensim.test.utils import datapath 
from gensim.models.word2vec import Text8Corpus 
from gensim.models.phrases import Phrases, Phraser

#required for corrolation 
import scipy
import statistics
from scipy.stats.stats import pearsonr   

import pandas as pd
import string 
import nltk
import re
import scikitplot as skplt
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from sklearn import preprocessing,metrics
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline,make_pipeline,FeatureUnion
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from collections import Counter
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC,LinearSVC

pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)
pd.set_option('display.max_colwidth', -1)

#punctuation to remove, stopwords to remove, stemming and lemmatizing objects for preprocessing
stemmer = SnowballStemmer('english')
wordnet_lemmatizer = WordNetLemmatizer()
exclude = set(string.punctuation)
stopwords = stopwords.words("english")

######################################################
####GENERATING PHRASES TO INCLUDE IN TFIDF GENERATION#
##############GENSIM IMPLEMENTATION###################
#constants 
target = 'LegalAction'

# load the dataset
data = pd.read_pickle("C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/NN_ClassificationModelData2.pickle")

#text preprocessing
data['sent_tokenized'] =data['processed_text'].apply(lambda x: quick_preprocess(x) ) 
data['DocText_Nophrases'] =data['sent_tokenized'].apply(lambda x: ' '.join(x) )

#binairze target label to int 
le = preprocessing.LabelEncoder() 
le.fit(data[target])
data['label_id'] =le.transform(data[target])


#PHRASE GENERATION 
#Sentences to evaluate (list of lists of sentence tokenized documents)
trainDF = data.copy()

#word tokenize sentences
trainDF['sentences_words']= [[text.split() for text in sent] for sent in  trainDF['sent_tokenized']]

#CREAETE BIGRAM PHRASES
#train phraser model on word tokenized sentences 
#new list of word tokenized sentences , with bigrams added using "_"s     
bigrams = create_bigram_vocab(df_col=trainDF['sentences_words'],min_count=5)    
trainDF['sentences_words_bigram'] =[[list(bigrams[sent]) for sent in doc] for doc in trainDF['sentences_words']]
trainDF['sentences_sent_bigram'] = trainDF['sentences_words_bigram'].apply(lambda x:[ ' '.join(word) for word in x])
trainDF['FinalDocText_bi'] = trainDF['sentences_sent_bigram'].apply(lambda x: ' '.join(x) )

#CREATE TRIGRAM PHRASES
trigrams= create_trigram_vocab(df_col=trainDF['sentences_words_bigram'],min_count=50)    
trainDF['sentences_words_trigram'] =[[list(trigrams[sent]) for sent in doc] for doc in trainDF['sentences_words_bigram']]
trainDF['sentences_sent_trigram'] = trainDF['sentences_words_trigram'].apply(lambda x:[ ' '.join(word) for word in x])
trainDF['FinalDocText_tri'] = trainDF['sentences_sent_trigram'].apply(lambda x: ' '.join(x) )

#MODEL START 
#categorical and numerical columns in dataframe 
target = 'label_id'
texts = ['FinalDocText_tri','FinalDocText_bi','DocText_Nophrases']
outcm = {}
for text in texts:
    features= [text]
    numeric_features= []#[c for c in trainDF.columns.values if c  not in ['label','author','text',target,'source','source_id','label_id','cleantxt']]
    
    
    #text transformation pipelines to create (each transformation will be placed in indepedent pipelines and feature unioned together to generate final training dataset)
    text_feats = {'tfidf_pipe':{'analyzer':'word','ngram_range':(1,1)}
    }
    
    #create a categorical feature pipeline for each set of categorical transformations defined in text_feats
    catfeat_pipe_dic = {key : Pipeline([('selector', TextSelector(key=text)),
                                ('tfidf',  TfidfVectorizer(analyzer=val['analyzer'], ngram_range=val['ngram_range'], max_features=400,min_df=.01,max_df=.8, smooth_idf=True, norm='l1',sublinear_tf=True,lowercase=True,))
                                ]) for key,val in text_feats.items()
                }   
    
    #create pipe for each numerical features generated by orig_text_clean 
    #numfeat_pipe_dic= {val: Pipeline([('selector', NumberSelector(key=val)),('standard', preprocessing.StandardScaler())]) for val in numeric_features}
    
    #create final list of pipelines, starting with text preprocessing, and finishing with the numeric column normalizations(items listed in order of exectuion so we build initial list with text processing and append all numeric processing tasks after)
    final_pipeline = [(k,v) for k, v in catfeat_pipe_dic.items()]
    #final_pipeline.extend([(k,v) for k, v in numfeat_pipe_dic.items()])
    
    #make a pipeline from all of our pipelines, we dao the same thing, but now we use a FeatureUnion to join the feature processing pipelines.
    feats = FeatureUnion(final_pipeline)
    
    #view parameters that resulted in best model 
    final_rf= Pipeline([('features',feats),
                        #('clf', RandomForestClassifier(n_estimators=100,oob_score=True,max_depth=10 ,n_jobs=6,max_features=100,min_samples_leaf=1,min_samples_split=5))
                        ('clf', MLPClassifier(solver='adam',tol=.0001,max_iter=500,learning_rate='adaptive',alpha=.01))
                        ])
    
    #refitting on entire training data using best settings
    #view predictions and probabilities of each class 
    x = trainDF[features]
    y = trainDF['label_id']
    train_x,valid_x,train_y,valid_y= model_selection.train_test_split(x,y,shuffle=True, stratify=y,test_size=.2, random_state=10)
    
    final_rf.fit(train_x,train_y)
    train_preds = final_rf.predict(train_x)
    train_probs = final_rf.predict_proba(train_x)
    valid_preds = final_rf.predict(valid_x)
    valid_probs = final_rf.predict_proba(valid_x)
    
    validcm = metrics.confusion_matrix(valid_y,valid_preds)
    traincm = metrics.confusion_matrix(train_y,train_preds)

    outcm[text] = {'traincm':traincm,'validcm':validcm}
    
#stats=sk_model_stats({'RandomForest':final_rf},x,y,data_type='train')

for key in outcm.keys():
    print(key,':',outcm[key])












########################################################
##ANALYZE EMBEDDING RELATIONSHIPS WHEN INCLUDING NGRAMS#
########################################################
import pymagnitude

#embeddings
wv=pymagnitude.Magnitude("C://Users//caridza//Desktop//pythonScripts//NLP//Embeddings//GoogleNewsvectors_negative300.magnitude")

#test constants
stem = "fraud"
keys2compare = ["found_guilty","regulator","illegal"]

#query the distance of two or multiple keys 
wv.distance(stem,keys2compare)

#query for the most similar of two or multiple keys 
wv.similarity(stem,keys2compare)

#query for the msot similar key out of a list of keys to a given key 
wv.most_similar_to_given(stem,keys2compare)

#generate pos embeddings 
pos_vectors = pymagnitude.FeaturizerMagnitude(100,namespace="PartsOfSpeech")
dependency_vectors = pymagnitude.FeaturizerMagnitude(100, namespace = "SyntaxDependencies")

#concat all vectors 
vectors = pymagnitude.Magnitude(wv, pos_vectors, dependency_vectors) # concatenate word2vec with pos and dependencies

#build classification model in keras 
#https://colab.research.google.com/drive/1lOcAhIffLW8XC6QsKzt5T_ZqPP4Y9eS4#scrollTo=J1g2PqPbyjE4

def quick_preprocess(text,stopwords = stopwords):
    #func to remove punc from string and return string
    step0 = nltk.sent_tokenize(text)
    step1 = [remove_punctuation(sent) for sent in step0]
    step2 = [remove_stop(sent,stopwords=stopwords) for sent in step1]
    step3 = [remove_nonchars(sent) for sent in step2]
    step4 = [lower_all(sent) for sent in step3]
    
    return(step4)

def remove_stop(text,stopwords=['the','is','a','i','are','it']):
    return ' '.join([word for word in text.split(' ') if word.lower() not in stopwords])

def lower_all(text):
    return ' '.join([word.lower() for word in text.split(' ')])


def text_clean(data,target='LegalAction',txtfeild='origtext',maplabelvars=['source'],stopwords=['the','is','a','i','are','it'],score_new=False,returnTargOnly=False):
    trainDF = pd.DataFrame()
    trainDF['text'] = data[txtfeild].apply(lambda x: remove_nonchars(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_stop(x,stopwords=stopwords))
    trainDF[txtfeild] = trainDF['text']
    
    if score_new==False:
        trainDF['label'] = data[target]
        le = preprocessing.LabelEncoder() 
        le.fit(trainDF['label'])
        trainDF['label_id'] =le.transform(trainDF['label'])
    
    if returnTargOnly==False:
        #trainDF['source'] = data['source']
        trainDF['txt_lngth'] = trainDF[txtfeild].apply(lambda x: len(x))
        trainDF['txt_words'] = trainDF[txtfeild].apply(lambda x: len(x.split(' ')))
        trainDF['txt_nonstopwords'] = trainDF[txtfeild].apply(lambda x: len([t for t in x.split(' ') if t not in stopwords]))
        trainDF['total_commas'] = data[txtfeild].apply(lambda x: x.count(','))
    
        for var in maplabelvars: 
            le.fit(data[var])
            trainDF[var+'_id'] =le.transform(data[var])
        
    trainDF=trainDF.reset_index(drop=True)
    trainDF.drop(columns = ['text','label'],inplace=True)
    return trainDF 