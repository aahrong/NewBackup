# -*- coding: utf-8 -*-
"""
Created on Fri Apr 12 13:57:02 2019

@author: caridza
"""


# -*- coding: utf-8 -*-
#VirtualEnv: docclassify
#VirtualEnv Location: C:\Users\caridza\Downloads\WPy32-3662\ZacksScripts\docclassify
#######################
#######IMPORTS#########
#######################
import pandas as pd
import string
import xgboost, numpy, textblob, string, pickle, sys
from itertools import islice #iterating over vectorized objects (countvectorizer, tfidfvectorizer,etc..)
import sklearn
from sklearn import decomposition, ensemble, tree, svm,model_selection, preprocessing, linear_model, naive_bayes, metrics, svm

#text parsing
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk.stem import WordNetLemmatizer

from collections import Counter
import numpy as np
import mpu
import scikitplot as skplt
import joblib
import re

#custom modules 
import negative_news2
from negative_news2 import consumer
from negative_news2.consumer import utils
from negative_news2.consumer.utils  import TextSelector, NumberSelector,orig_text_clean,load_and_score,remove_punctuation,remove_stop,stem_words,remove_nonchars,pipelinize,sk_model_stats

#required for corrolation 
import scipy
import statistics
from scipy.stats.stats import pearsonr   

pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)
pd.set_option('display.max_colwidth', -1)

#punctuation to remove, stopwords to remove, stemming and lemmatizing objects for preprocessing
stemmer = SnowballStemmer('english')
wordnet_lemmatizer = WordNetLemmatizer()
exclude = set(string.punctuation)
stopwords = stopwords.words("english")

######################################################
####GENERATING PHRASES TO INCLUDE IN TFIDF GENERATION#
##############GENSIM IMPLEMENTATION###################
# load the dataset
data = pd.read_pickle("C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/NN_ClassificationModelData2.pickle")

#create a dataframe using texts and lables and conduct preprocessing
#saving objects with label informaiton for visualizations and filtering
trainDF = orig_text_clean(data,txtfeild='processed_text',target='LegalAction',maplabelvars=['source'],stopwords=stopwords,stemmer=None)
trainDF = trainDF.dropna(subset = ['processed_text'])
trainDF['sent_tokenized'] =trainDF['processed_text'].apply(lambda x: nltk.sent_tokenize(x))
trainDF['sent_tokenized'].head()

#PHRASE GENERATION 
from gensim.test.utils import datapath 
from gensim.models.word2vec import Text8Corpus 
from gensim.models.phrases import Phrases, Phraser

#Sentences to evaluate (list of lists of sentence tokenized documents)
sentences = trainDF['processed_text'].dropna()

#word tokenize sentences
sentences_words = [text.split() for text in sentences]

#CREAETE BIGRAM PHRASES
#train phraser model on word tokenized sentences 
bigrams = Phrases()
for sent in sentences_words:
    bigrams.add_vocab([sent])

#new list of word tokenized sentences , with bigrams added using "_"s     
new_sentences = list(bigrams[sentences_words])   

#ADD TRi-GRAMS
#retrain phraser model on word tokenized sentences (that include the bigrams found above)
trigrams= Phrases(new_sentences,min_count=20)
New_Sentences = [trigrams[line] for line in new_sentences]

#View count of Trigrams
test = [[word for word in Sent if len(str(word).split("_"))>2] for Sent in New_Sentences ]
Counter([item for sublist in test for item in sublist]).most_common(100)


########################################################
##ANALYZE EMBEDDING RELATIONSHIPS WHEN INCLUDING NGRAMS#
########################################################
import pymagnitude

#embeddings
wv=pymagnitude.Magnitude("C://Users//caridza//Desktop//pythonScripts//NLP//Embeddings//GoogleNewsvectors_negative300.magnitude")

#test constants
stem = "fraud"
keys2compare = ["found_guilty","regulator","illegal"]

#query the distance of two or multiple keys 
wv.distance(stem,keys2compare)

#query for the most similar of two or multiple keys 
wv.similarity(stem,keys2compare)

#query for the msot similar key out of a list of keys to a given key 
wv.most_similar_to_given(stem,keys2compare)

#generate pos embeddings 
pos_vectors = pymagnitude.FeaturizerMagnitude(100,namespace="PartsOfSpeech")
dependency_vectors = pymagnitude.FeaturizerMagnitude(100, namespace = "SyntaxDependencies")

#concat all vectors 
vectors = pymagnitude.Magnitude(wv, pos_vectors, dependency_vectors) # concatenate word2vec with pos and dependencies

#build classification model in keras 
#https://colab.research.google.com/drive/1lOcAhIffLW8XC6QsKzt5T_ZqPP4Y9eS4#scrollTo=J1g2PqPbyjE4




def text_clean(data,target='LegalAction',txtfeild='origtext',maplabelvars=['source'],stopwords=['the','is','a','i','are','it'],score_new=False,returnTargOnly=False):
    trainDF = pd.DataFrame()
    trainDF['text'] = data[txtfeild].apply(lambda x: remove_nonchars(x))
    trainDF['text'] = trainDF['text'].apply(lambda x: remove_stop(x,stopwords=stopwords))
    trainDF[txtfeild] = trainDF['text']
    
    if score_new==False:
        trainDF['label'] = data[target]
        le = preprocessing.LabelEncoder() 
        le.fit(trainDF['label'])
        trainDF['label_id'] =le.transform(trainDF['label'])
    
    if returnTargOnly==False:
        #trainDF['source'] = data['source']
        trainDF['txt_lngth'] = trainDF[txtfeild].apply(lambda x: len(x))
        trainDF['txt_words'] = trainDF[txtfeild].apply(lambda x: len(x.split(' ')))
        trainDF['txt_nonstopwords'] = trainDF[txtfeild].apply(lambda x: len([t for t in x.split(' ') if t not in stopwords]))
        trainDF['total_commas'] = data[txtfeild].apply(lambda x: x.count(','))
    
        for var in maplabelvars: 
            le.fit(data[var])
            trainDF[var+'_id'] =le.transform(data[var])
        
    trainDF=trainDF.reset_index(drop=True)
    trainDF.drop(columns = ['text','label'],inplace=True)
    return trainDF 


def create_bigram_vocab(df_col,min_count = 10):
    bigrams = Phrases(min_count=min_count)
    for doc in df_col:
        for sent in doc:
            bigrams.add_vocab([sent])
    return(bigrams)
    
    
#input word tokenized sentences across all documents 
def create_trigram_vocab(df_col,min_count = 10):
    trigrams = Phrases(min_count=min_count)
    for doc in df_col:
        for sent in doc:
            trigrams.add_vocab([sent])
    return(trigrams)