# -*- coding: utf-8 -*-
"""
Created on Tue May  7 13:38:17 2019

@author: caridza
"""
import os 
import sys
import pandas as pd 
import pymagnitude
import re
import string 
import numpy as np
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk import regexp_tokenize
from nltk.tokenize import word_tokenize , sent_tokenize
import gensim

import statistics

#input/output paths
#DATAPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/Data/NewData/NEW_SENTLEVEL_CLASSIFICATIONS_DF.pickle"
DATAPATH="C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\Data\\NewData\\result_dataframe_MAY19.pickle"
OUTPUTPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/"

#text preprocessing constants
stemmer = SnowballStemmer('english')
exclude = set(string.punctuation)
stopwords = stopwords.words('english')
newStopWords = ['.','?','%','Google','Wells Fargo','guggenheim partners llc','new york','guggenheim partners','bank america','wells fargos','year','thing','would','include','tuesday','make','time','state','bank','certain','country','string','perhaps','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December','from', 'subject', 're', 'edu', 'use', 'not', 'would', 'say', 'could', '_', 'be', 'know', 'good', 'go', 'get', 'do', 'done', 'try', 'many', 'some', 'nice', 'thank', 'think', 'see', 'rather', 'easy', 'easily', 'lot', 'lack', 'make', 'want', 'seem', 'run', 'need', 'even', 'right', 'line', 'even', 'also', 'may', 'take', 'come','the']
stopwords.extend(newStopWords)
stop_list=set(stopwords)
excluded_punct={'+', ':', '[', '^', '"', '|', '{', '@', '=', ')', '%', '#', '+','`', '}', "'", '(', ',', '!', '*', '_', '>', '?', '&', '-', '~', '\\', '<', '/', '.', ']', ';', '$'}
replace_pattern = '[^A-Za-z|^\$|^\.]+'

#vectors 
wv=pymagnitude.Magnitude('C://Users//caridza//Downloads//crawl-300d-2M.magnitude')

#data
data = pd.read_pickle(DATAPATH)
data['text'] = data.desm_sentences.apply(lambda x: ''.join(x))

#tokenize textt
data['sent_tokenized']= data['text'].apply(lambda x: nltk.tokenize.sent_tokenize(x))
data['word_tokenized']= data.apply(lambda row: [nltk.tokenize.word_tokenize(sent) for sent in row['sent_tokenized']],axis=1)

#remove stopwords, punctuation and words < 3 chars long
#to incorporate filtering of nonchars (or whatever regex is specified in custom_pattern) incoprorate -> re.sub(replace_pattern, ' ', word) 
data['article_tokens'] = data.apply(lambda row: [[word for word in sent if (
        word.lower() not in stop_list 
        and word not in excluded_punct 
        and len(word)>2
        )] for sent in row['word_tokenized']],axis=1)


#return the avg vector for each sentence by taking the average embedding from all words in senetence 
data['sent_vecs'] = data.apply(lambda row: [np.nanmean(wv.query(sent_tokens),axis=0) for sent_tokens in row['article_tokens']],axis=1)

#return averge vector for each document /phrase by averaging the relationships from the sentence vectors 
data['phrase_vecs'] = data.apply(lambda row: np.nanmean(row['sent_vecs'],axis=0),axis=1)

#to allow vstacking you must have all elements in each array be same length(the length of the embeddings used during querying)
data.dropna(axis=0,subset=['phrase_vecs'],inplace=True)

#vstack all article vectors to enable tsne
tsne_in = np.vstack(data['phrase_vecs'])

import sklearn
from sklearn.manifold import TSNE
tsne_out = TSNE(n_components=2).fit_transform(tsne_in)

























