# -*- coding: utf-8 -*-
"""
Created on Thu May  2 09:40:23 2019
EXAMPLE OF HOW STATEFULNESS IS USED IN KERAS

GOAL:Understand that if the first value of the sequence is 1, then the result(Y) is 1, 0 otherwise.
http://philipperemy.github.io/keras-stateful-lstm/
@author: caridza
"""
import numpy as np
from sklearn.model_selection import train_test_split

N_train = 1000
X_train = np.random.rand(1200,20)
one_indexes = np.random.choice(a=N_train, size=int(N_train / 2), replace=False)

X_train[one_indexes, 0] = 1  # very long term memory.

#execute function on array using lamda and np.vectorize
binizer = lambda x: 1 if x==1 else 0
vfunc = np.vectorize(binizer)
Y = vfunc(X_train[:,0])

#count values in array
y=np.bincount(Y)
ii=np.nonzero(y)[0]
np.vstack((ii,y[ii])).T

#split into train and test 
train_x,valid_x,train_y,valid_y= train_test_split(X_train,Y,shuffle=False,test_size=.2, random_state=10)


#Imact of sequences subsampling on STATLESS LSTM 
#Objective: prove that if we split LARGE sequences from X into smaller sequences, the model CANNOT converge
#function to split big sequences into sub sequences 
    #As an example, if we have X=[1,0,0,0,0], Y=1 and if window_length=2, the output will be:
    #Xout=[[1,0],[0,0],[0,0],[0,0]], Yout=[1,1,1,1]. 
    #The operation is not destructive but reversible.
    # We repeat the procedure for every (Xi,Yi) to re create our new matrices (X,Y) that will used as inputs to the LSTM.
def prepare_sequences(x_train, y_train, window_length):
    
    #create lists to hold all subsequences and associated y values
    windows = []
    windows_y = []
    
    #for each sequence in x
    for i, sequence in enumerate(x_train):
        #identify sequence length 
        len_seq = len(sequence)
        
        #identify total subsequences that each sequence can be split into based on the specified window_size
        for window_start in range(0, len_seq - window_length + 1):
            
            #identify the end of the sub_sequence being processed ()
            #NOTE: SUBSEQUENCES WILL OVERLAP (subseq1(start+1) = subseq2(start)) & subseq1(start+2) = subseq2(start+1)
            #NOTE CONT: len_seq - window_length + 1 = number of subsequences we will get from a sequence of length len_seq
            window_end = window_start + window_length
            
            #generate subsequence
            window = sequence[window_start:window_end]
            
            #append subsequence to list
            windows.append(window)
            
            #for each subsequence of sequence i, append the y value associated with the sequence for each subsequence 
            #y value will be constant for all subsequences in sequence i,as the value is being assigned in the inner loop
            windows_y.append(y_train[i])
            
    return np.array(windows), np.array(windows_y)


#create the new matrices of subsequences for the training and testing datasets 
X_TRAIN,Y_TRAIN = prepare_sequences(train_x,train_y,10)
X_TEST,Y_TEST = prepare_sequences(valid_x,valid_y,10)


#reshape and add constant dimension
#Q: WHY DO WE HAVE TO ADD THIS CONSTANT DIMENSION TO THE ARRAY FOR KERAS??????
Y_TRAIN =Y_TRAIN.reshape(Y_TRAIN.shape[0],1)
X_TRAIN=X_TRAIN.reshape(X_TRAIN.shape[0],X_TRAIN.shape[1],1)
Y_TEST =Y_TEST.reshape(Y_TEST.shape[0],1)
X_TEST=X_TEST.reshape(X_TEST.shape[0],X_TEST.shape[1],1)
X_TEST.shape

#COMPARE trainign data shape With Subsampling vs without
#in a sequence of length 20, we have exactly (20−10+1) sequences of length 10 
#Because we have 960 samples (sequences) in the training set, we have 960∗11=10560 subsequences in our resulting training set (we make sure to keep the order). 
print('size of training data WITHOUT subsampling: {}'.format(train_x.shape),'\n',
'size of training data WITH subsampling: {}'.format(X_TRAIN.shape))
print('size of target WITHOUT subsampling: {}'.format(train_y.shape),'\n',
'size of training data WITH subsampling: {}'.format(Y_TRAIN.shape))

#Building STATELESS MODEL(TOTAL FAIL)
#MUST IMPORT ALL FROM EITHER KERAS or Tensorflow.python.keras. YOU CANNOT MIX
import keras 
max_len= max([len(s)for s in X_TRAIN]) 
batch_size = 200

print('Building STATELESS model...')
model = keras.models.Sequential()
model.add(keras.layers.LSTM(10, input_shape=(max_len, 1), return_sequences=False, stateful=False))
model.add(keras.layers.Dense(1, activation='sigmoid'))
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
model.fit(X_TRAIN, Y_TRAIN, batch_size=batch_size, nb_epoch=15,
          validation_data=(X_TEST, Y_TEST), shuffle=False)
score, acc = model.evaluate(X_TEST, Y_TEST, batch_size=batch_size, verbose=0)    

#CONCLUSION ON ABOVE MODEL
#As a conclusion, subsampling does not help the LSTM converge. So when you have a big time series (e.g. in financial markets)
#the lookback window length is crucial and can be found with Bayesian Optimization .


#STATEFUL MODEL 

#start with original FULL series and add constnat dimension for keras 
Y_TRAIN =train_y.reshape(train_y.shape[0],1)
X_TRAIN=train_x.reshape(train_x.shape[0],train_x.shape[1],1)
Y_TEST =valid_y.reshape(valid_y.shape[0],1)
X_TEST=valid_x.reshape(valid_x.shape[0],valid_x.shape[1],1)



print('size of training data WITH subsampling: {}'.format(X_TRAIN.shape),'\n',
'size of training data WITH subsampling: {}'.format(Y_TRAIN.shape))

#set batch size = 1 (splits the full sequence into elements of size 1 and feeds them to the LSTm).Once the full sequence is over , we manually reset the states of the LSTM 
#to have a clean setup for the next one. For each element, we associate the related target Yi. 
#ex. For instance, if we have Xi=[1,0,0...,0] and Yi=[1], we feed ((xi0=[1],yi=[1]), (xi1=[0],yi=[1]),…, (xi20=[0],yi=[1])) to the LSTM.

#Because the LSTM is stateful, the state will be propagated to the next batch. 
#Also because the batch_size=1, we are sure that the state of the last element will be used as input to the current element.

batch_size = 1
print('Build STATEFUL model...')
model = keras.models.Sequential()
model.add(keras.layers.LSTM(10, batch_input_shape=(1, 1, 1), return_sequences=False, stateful=True))
model.add(keras.layers.Dense(1, activation='sigmoid'))
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

print('Train...')
for epoch in range(15):
    mean_tr_acc = []
    mean_tr_loss = []
    
    #for each sequence 
    for i in range(len(Y_TRAIN)):
        
        #identify the truth 
        y_true = Y_TRAIN[i]
        
        #for each elmeent j in the sequence i
        for j in range(max_len):
            
            #train the model in batch on the X_train subsequence of len 1 , and the y value 
            tr_loss, tr_acc = model.train_on_batch(np.expand_dims(np.expand_dims(X_TRAIN[i][j], axis=1), axis=1),
                                                   np.array([y_true]))
            
            #append accuracy metric
            mean_tr_acc.append(tr_acc)
            #append loss metrics 
            mean_tr_loss.append(tr_loss)
        
        #reset the state for the next sequence being processed
        model.reset_states()

    #EXECUTE THE SAME STEPS ON THE TEST DATA
    print('accuracy training = {}'.format(np.mean(mean_tr_acc)))
    print('loss training = {}'.format(np.mean(mean_tr_loss)))
    print('___________________________________')

    mean_te_acc = []
    mean_te_loss = []
    for i in range(len(X_TEST)):
        for j in range(max_len):
            te_loss, te_acc = model.test_on_batch(np.expand_dims(np.expand_dims(X_TEST[i][j], axis=1), axis=1),
                                                  Y_TEST[i])
            mean_te_acc.append(te_acc)
            mean_te_loss.append(te_loss)
        model.reset_states()

        for j in range(max_len):
            y_pred = model.predict_on_batch(np.expand_dims(np.expand_dims(X_TEST[i][j], axis=1), axis=1))
        model.reset_states()

    print('accuracy testing = {}'.format(np.mean(mean_te_acc)))
    print('loss testing = {}'.format(np.mean(mean_te_loss)))
    print('___________________________________')