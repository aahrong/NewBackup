# -*- coding: utf-8 -*-
"""
Created on Thu Jun  6 07:58:15 2019

@author: caridza
https://www.pyimagesearch.com/2019/02/04/keras-multiple-inputs-and-mixed-data/
https://stackoverflow.com/questions/52485242/how-to-use-embedding-layer-and-other-feature-columns-together-in-a-network-using
"""
#feature column with cfpb data
import pandas as pd
import numpy as np
from sklearn.datasets import load_iris
import matplotlib.pyplot as plt
import sys 
sys.path.insert(0, "C:\\Users\\caridza\\Desktop\\pythonScripts\\ExploratoryDataAnalysis\\")
sys.path.insert(0,"C:\\Users\\caridza\\Desktop\\pythonScripts\\NLP\\Zacks_NLP_Stuff\\CFPB\\")
from EDA_Funcs.EDA_Functions  import fill_missing,drop_constant_column, df_rowtypes, percent_col_total, plot_counts, df_rowtypes,create_catmap,fillNA_convertoCat
from cfpb_funcs.cfpb_helpers import get_meta_dict, train_test_valid,cfpb_preproc_pt1,text_clean,get_doc2bow,check_catlevel_counts,encode_target_alt,encode_ordinal,encode_nominal
from cfpb_funcs.cfpb_featcol_helpers import df_to_dataset

#modeleling libararies 
from keras.backend.tensorflow_backend import set_session
from keras.models import Sequential
from keras import applications
import tensorflow as tf
from tensorflow.keras.backend import random_uniform
from sklearn.model_selection import train_test_split

#feature col functions
from tensorflow import feature_column
from tensorflow.keras import layers


# import the necessary packages
from sklearn.preprocessing import LabelBinarizer
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
import numpy as np

#static paths
DATAPATH="C:\\Users\\caridza\\Desktop\\pythonScripts\\Data\\cfpb\\"
OUTPUTPATH = "C:/Users/caridza/Desktop/pythonScripts/NLP/Zacks_NLP_Stuff/"
PYMAGPATH = "C://Users//caridza//Downloads//crawl-300d-2M.magnitude"
filename = "cfpb_complaints.csv"

# load the dataset
data = pd.read_csv(DATAPATH+filename).copy()
data = data[~data['Consumer complaint narrative'].isna()]

#cfpb preproc data 
data =cfpb_preproc_pt1(data)

#must rename columns to remove _ for sklearn pipelines
data = data.rename(columns={col:col.replace('_','').replace('-','').replace(' ','').replace('?','') for col in list(data)})
list(data)

#create mapping of categorical vairables 
cat_dict = {}
cat_dict['Product']={'type':'nominal','use':'target'}
cat_dict['Subproduct']={'type':'nominal','use':'no'}
cat_dict['Issue']={'type':'nominal','use':'yes'}
cat_dict['Subissue']={'type':'nominal','use':'no'}
cat_dict['Companypublicresponse']={'type':'nominal','use':'yes'}
cat_dict['Company']={'type':'nominal','use':'no'}
cat_dict['State']={'type':'nominal','use':'yes'}
cat_dict['ZIPcode']={'type':'nominal','use':'yes'}
cat_dict['Tags']={'type':'nominal','use':'yes'}
cat_dict['Consumerconsentprovided']={'type':'nominal','use':'yes'}
cat_dict['submittedvia']={'type':'nominal','use':'yes'}
cat_dict['Datesenttocompany']={'type':'ordinal','use':'yes'}
cat_dict['Datereceived']={'type':'ordinal','use':'yes'}
cat_dict['Companyresponsetoconsumer']={'type':'nominal','use':'yes'}
cat_dict['Timelyresponse']={'type':'ordinal','use':'yes'}
cat_dict['Consumerdisputed']={'type':'ordinal','use':'yes'}

#encode target 
Data ,targDefs= encode_target_alt(data,target='Product')

#metadata dictonary for each columns
d_types = pd.DataFrame(get_meta_dict(Data)).T

#fill in missing values for all columns with >1 type of data 
#NOTE: CANNOT convert series to tf.tensor if there is > 1 datatype in column 
for col in list(Data):
    if len(d_types.loc[col,'dtype'])>1:
        Data[col] = fill_missing(Data,col,MisConst='Missing')

#SPLIT DATA
train,test,valid = train_test_valid(Data,test_size=.2,stratify='label_id')


'''
#FUNCTIONAL VS SEQUENTIAL API 

#Sequential 
model = sequential()
model.add(Dense(8,input_shape=(10,),activation="relu"))
model.add(Dense(4,activation="relu"))
model.add(Dense(1,activation="linear"))

#Funcitonal 
#Allows for more complex models 
#does not require use of sequence class
inputs = Input(shape=(10,))
x=Dense(8,activation="relu")(inputs)
x=Dense(4,activation="relu")(x)
x=Dense(1,activation="lienar")(x)
model=Model(inputs,x)
'''

#FUNCTIONAL WITH MULTIPLE INPUTS 

#process continous and categorical attributes 
def process_attributes(df,train,test):
    
    #numeric column names
    continuous= ['CountUniqMoneyVals','CountUniqNonMoneyVals']

    #perform min-max sclaing on each continous column 
    normFunc = MinMaxScaler()
    trainContinous = cs.fit_transform(train[continuous])
    testContinous = cs.transform(test[continuous])
    
    
    #categorical column names 
    cat = 'Tags'
    
    #create one hot encoding for categorical variable 
    zipBinarizer = LabelBinarizer().fit(df[cat])
    trainCategorical = zipBinarizer.transform(train[cat])
    testCategorical = zipBinarizer.transform(test[cat])
    
    #Categorical embeddings 
    #embeddingCol = 'Zipcode'
    #embeddingClasses = feature_column.categorical_column_with_vocabulary_list(embeddingCol,list(df[embeddingCol].unique()))
    #embeddingFeat = feature_column.embedding_column(embeddingClasses, dimension=20)
    
    #construct training and testing datapoints by concatenating the categorical features with teh continous features 
    trainX = np.hstack([trainCategorical,trainContinous])
    testX = np.hstack([testCategorical,testContinous])
    #trainX = np.hstack([trainCategorical,trainContinous,embeddingFeat])
    #testX = np.hstack([testCategorical,testContinous,embeddingFeat])
    
    #return concatenated training and testing data 
    return (trainX,testX)



#load embedding vectors 
import tensorflow
from tensorflow.keras.layers import Input
import pymagnitude 
import string
from sklearn import preprocessing , model_selection, metrics
from sklearn.model_selection import StratifiedShuffleSplit
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from nltk import regexp_tokenize
from nltk.tokenize import word_tokenize , sent_tokenize
from keras.preprocessing.sequence import pad_sequences 
from keras.preprocessing.text import Tokenizer 

import gensim
wv=pymagnitude.Magnitude('C://Users//caridza//Downloads//crawl-300d-2M.magnitude')

#create embedding vectors and input specifications for lstm 
trainX,trainEmbedVec, word_index, maxlen, words, EMBEDDING_DIM, nb_words = get_embeddings(train.head(1000), 'Consumercomplaintnarrative',wv,stopwords)
testX, testEmbedVec, _,_, _, _, _= get_embeddings(test.head(1000), 'Consumercomplaintnarrative',wv,stopwords)
trainY = train['label_id']
testY = test['label_id']
numTargLevels = len(list(Data['label_id'].unique()))
#create lstm 


##LSTM functional api test####
INPUT = tensorflow.keras.layers.Input(shape=(trainX.shape[1],),name='INPUT')
x = tensorflow.keras.layers.Embedding(output_dim = EMBEDDING_DIM ,
                           input_dim = nb_words,
                           input_length=maxlen, 
                           weights = [trainEmbedVec],
                           mask_zero=False
                           )(INPUT)

x = tensorflow.keras.layers.GaussianDropout(rate = .3)(x)
x =tensorflow.keras.layers.Activation('selu')(x)

lstm_out = tensorflow.keras.layers.Bidirectional(
        tensorflow.keras.layers.LSTM(units=30,
                          return_sequences=True,
                          recurrent_dropout=.5,
                          recurrent_regularizer = tensorflow.keras.regularizers.L1L2(l1=0.0,l2=0.01),
                          kernel_regularizer = tensorflow.keras.regularizers.L1L2(l1=0.0,l2=0.01),
                          bias_regularizer = tensorflow.keras.regularizers.L1L2(l1=0.0,l2=0.01),                          
                          ))(x)
        
lstm_out = tensorflow.keras.layers.GaussianDropout(rate = .5)(lstm_out)
lstm_out = tensorflow.keras.layers.Activation('selu')(lstm_out)
flat_out = tensorflow.keras.layers.Flatten()(lstm_out)
output_layer = tensorflow.keras.layers.Dense(units = numTargLevels,activation='softmax')(flat_out)

#compile model
model = tensorflow.keras.models.Model(inputs = INPUT,outputs=output_layer)
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy')

mod_out = model.fit(trainX,trainY.head(1000),epochs=2,batch_size=250)
score = model.evaluate(testX ,testY , batch_size=128)

###end test#### 

def lstm_model_text(embedding_vecotr,nb_words,EMBEDDING_DIM,maxlen,numTargLevels):

    #BEGIN MODEL LAYER DEFFINITIONS 
    #Initialize Sequential Model class  
    model=keras.models.Sequential()
    
    #add embedding layer
    model.add(keras.layers.Embedding(input_dim = nb_words #max_features
                                     , output_dim= EMBEDDING_DIM #embedding size 
                                     , weights = [embedding_vector]
                                     , mask_zero=False
                                     #, trainable=False  #if True transfer learning is enabled, the weights from the past epoch are used as starting points for the next epoch
                                     , input_length = maxlen #the max sequence length, this is the length that all sequences will be padded to (so all sequences will have same length)
                                     ))
    
    #add dropout 
    model.add(keras.layers.GaussianDropout(0.7))
    model.add(keras.layers.Activation('selu'))
    
    #ADD BILSTM WITH DROPOUT 
    model.add(keras.layers.Bidirectional(keras.layers.LSTM(units = 400, 
                                                           return_sequences=True,
                                                           #dropout=.3, #dropout not applied here becase we apply it via the guassian dropout specificed below
                                                           recurrent_dropout=.7,
                                                           recurrent_regularizer=keras.regularizers.L1L2(l1=0.0, l2=0.01),
                                                           kernel_regularizer = keras.regularizers.L1L2(l1=0,l2=.01),
                                                           bias_regularizer = keras.regularizers.L1L2(l1=0,l2=.01),
                                                           )))
    
    #ADD NON RECURRENT DROPUT TO LSTM 
    model.add(keras.layers.GaussianDropout(0.7))
    model.add(keras.layers.Activation('selu'))
    
    #flatten output to 1D
    model.add(keras.layers.Flatten())
    
    #OUTPUT LAYER(units = # target labels, for binary this =1)
    model.add(keras.layers.Dense(units =numTargLevels,activation='softmax'))
    
    return model 

#BUILD KERAS MULTI-INPUT MODEL 

#requirments
#1.the first branch will be a MLP designed to handle categorical/numerical inputs 
#2.the second branch will be a lstm to operate over the sequences of text in the 'complaint column'
#3.the 2 branches must be concatenated toghetehr to form the FINAL multi-input keras model 




# import the necessary packages
from keras.models import Sequential
from keras.layers.normalization import BatchNormalization
from keras.layers.convolutional import Conv2D
from keras.layers.convolutional import MaxPooling2D
from keras.layers.core import Activation
from keras.layers.core import Dropout
from keras.layers.core import Dense
from keras.layers import Flatten
from keras.layers import Input
from keras.models import Model
 
#mlp for categorical and numerical data
def create_mlp(dim, numTargLevels,regress=False):
	# define our MLP network
	model = Sequential()
	model.add(Dense(8, input_dim=dim, activation="relu"))
	model.add(Dense(numTargLevels, activation="relu"))
 
	# check to see if the regression node should be added
	if regress:
		model.add(Dense(1, activation="linear"))
 
	# return our model
	return model


#embedding framework for processing text field 
    
















def get_embeddings(df,textcol,wv,stopwords):
    
    #stopwords, stemmer
    stemmer = SnowballStemmer('english')
    exclude = set(string.punctuation)
    stopwords = stopwords.words('english')
    newStopWords = ['.','?','%','Google','Wells Fargo','Donald Trump','Charles Schwab','Morgan Stanley','Credit Suisse','Reuters','Bank of America','Guggenheim','Deutsch Bank','Goldman Sachs','Facebook','Fifth Third Bank','New York','Washington','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December']
    stopwords.extend(newStopWords)
    stop_list=set(stopwords)
    wv=pymagnitude.Magnitude('C://Users//caridza//Downloads//crawl-300d-2M.magnitude')
    
    #inputs requiring path specification
    max_features = 100000 #maximum number of words to consider in analysis 
    EMBEDDING_DIM = 300 #NOTE: becuase we use pymag this must be set to 300 
    stop_list = stop_list
    stemmer = stemmer

    #make dataframe 
    #generate list of unique words based on total words specified to consider
    X = df[textcol]
    lines = X.values.tolist()
    lines = [word_tokenize(sent) for sent in lines]
    model=gensim.models.Word2Vec(sentences=lines, size=EMBEDDING_DIM,window=5,workers=4,min_count=1)
    words = list(model.wv.vocab)

     #model process 
    #fit tokenizer to words and turn to sequences 
    tokenizer_obj = Tokenizer()
    tokenizer_obj.fit_on_texts(X)
    sequences = tokenizer_obj.texts_to_sequences(X)
    
    #define max length for padding and total vocab size
    maxlen = max([len(s.split()) for s in X]) 
    vocab_size = len(tokenizer_obj.word_index)+1
    
    #pad sequences 
    word_index = tokenizer_obj.word_index
    review_pad = pad_sequences(sequences,maxlen=maxlen)

    #GENERATE EMBEDDING MATRIX FOR EMBEDDING LAYER IN MODEL(using pymagnitude converted vectors)
    nb_words = min(max_features, len(word_index)+1) #total features to consider, min of the max feats vs total feats 
    embedding_vector =  make_embeddings_pymag(wv, max_features,words, word_index, EMBEDDING_DIM, nb_words)

    return review_pad,embedding_vector, word_index, maxlen, words, EMBEDDING_DIM, nb_words

    



#pymagnitude vectors 
def make_embeddings_pymag(wv, max_features,words, word_index, embed_size, nb_words):
    #embeddings using pymagnitude 
    embeddings_index = {}
    for w in words:
        word =w
        coefs = wv.query(word) #np.asarray(values[1:])
        embeddings_index[word]=coefs

    embedding_matrix = np.zeros((nb_words, embed_size))
    for word, i in word_index.items():
        if i >= max_features:
            continue
        embedding_vector = embeddings_index.get(word)
        if embedding_vector is not None:
            embedding_matrix[i] = embedding_vector
    return embedding_matrix




