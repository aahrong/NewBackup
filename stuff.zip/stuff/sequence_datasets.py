# -*- coding: utf-8 -*-
"""
Created on Mon May  6 10:34:03 2019

@author: caridza
"""


import os 
import tarfile
import pandas as pd
import numpy as np
import io
import gzip
import urllib.request 



#load data (ex dataset 1)
#https://bigml.com/user/czuriaga/gallery/dataset/50d845a2035d073999000132
directory= "C:\\Users\\caridza\\Desktop\\pythonScripts\\Data\\BigML\\"
train_data = pd.read_csv(directory+'FaceBook_Activity.csv',error_bad_lines=False)
#test_data = pd.read_csv(directory+'test.csv',error_bad_lines=False)

#load data (ex dataset 2)
#https://www.kaggle.com/c/santander-value-prediction-challenge/discussion/62378
directory= "C:\\Users\\caridza\\Desktop\\pythonScripts\\Data\\avazu-ctr-prediction\\"
train_data = pd.read_csv(directory+'train.csv',error_bad_lines=False)
test_data = pd.read_csv(directory+'test.csv',error_bad_lines=False)

#load data from website directly (example dataset 3)
url = 'https://archive.ics.uci.edu/ml/machine-learning-databases/msnbc-mld/msnbc990928.seq.gz'
urllib.request.urlretrieve(url,directory+"msnbc990928.seq.gz")
dat = []
gz = gzip.open(directory+"msnbc990928.seq.gz",'rb')
f = io.BufferedReader(gz)
for line in f.readlines():
    dat.append(line)
gz.close()


#load data from website directly (example dataset 3) and save to dataset 
#url = 'https://archive.ics.uci.edu/ml/machine-learning-databases/msnbc-mld/msnbc990928.seq.gz'
directory= "C:\\Users\\caridza\\Desktop\\pythonScripts\\Data\\cfpb\\"
url = 'https://data.consumerfinance.gov/api/views/s6ew-h6mp/rows.csv?accessType=DOWNLOAD'
urllib.request.urlretrieve(url,directory+"cfpb_complaints.csv")




import pymagnitude
from nltk.tokenize import word_tokenize , sent_tokenize
wv=pymagnitude.Magnitude('C://Users//caridza//Downloads//crawl-300d-2M.magnitude')

doc = 'My name is Zack. I live in the capital of North Carolina. I donot think i am moving to Iceland.'
docs = ['My name is Zack. I live in the capital of North Carolina. I donot think i am moving to Iceland.']
doc2 = ['The yellow man is red. His name is ruby, and he likes red fruit. His middle name is bubba becuase he likes bubbalicious.']

article_token_list= [nltk.tokenize.word_tokenize(sent) for sent in nltk.tokenize.sent_tokenize(doc)] #single doc
#article_token_list= [[nltk.tokenize.word_tokenize(sent) for sent in nltk.tokenize.sent_tokenize(doc)] for doc in docs] #list of docs

#sent_vecs = [[wv.query(nltk.tokenize.word_tokenize(sent)) for sent in nltk.tokenize.sent_tokenize(doc)] for doc in docs]
#num_to_pad = 2 
#sent_vectors = np.vstack((sent_vecs[0][0],np.zeros((num_to_pad,wv.dim))))


len_before = [len(article_token_list[i]) for i in range(0,len(article_token_list))]

article_to_vec(wv,article_token_list)

def sentence_to_vec(wv, token_list, sentence_len):
    #INPUTS
        #wv = pymag word embedding file 
        #token_list = list of word tokenized sentences 
        #sentence_len = length of the sentence being processed(total words)
    
    #query embeddings for all tokens in sentence
    sent_vector = wv.query(token_list)
    
    #identify if padding is requred to ensure original sentence length is maintained 
    num_to_pad = max(0, sentence_len - len(sent_vector))

    #if padding required, stack arrays of 0 of dim np.zeros((padding,embeddingdim))
    #sent_vecor dim explained = (len(sent_vector),wv.dim) -> each sentence vector is 1D of length = wv.dim
    if(num_to_pad):
        sent_vector = np.vstack((sent_vector, np.zeros((num_to_pad, wv.dim))))
        
    return sent_vector

def article_to_vec(wv, article_token_list):
    sent_vectors = np.stack([sentence_to_vec(wv, sent_tokens, MAX_WORDS) for sent_tokens in article_token_list], axis=0)
    
    num_to_pad = max(0, MAX_SENTENCES - len(sent_vectors))
    
    #at the article level the sentence vectors have 3 dimensions (?????)
    if(num_to_pad):
        sent_vectors = np.vstack((sent_vectors, np.zeros((num_to_pad, MAX_WORDS, wv.dim))))
        
    return sent_vectors